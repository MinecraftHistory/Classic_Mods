XCommands [public beta]
=======================
For Minecraft 2.0

Written by q3hardcore

Code is used from:
* Single Player Commands by simo_415
* Minecraft Forge (various authors)
* WorldEdit by sk89q, et al.

Includes WorldEdit by sk89q.

Installation
------------
*REGARDING WORLDEDIT*
It doesn't matter if you put WorldEdit.jar in minecraft.jar,
as it will be automatically extracted to the bin folder.
However, if you already have WorldEdit installed,
you should overwrite it with the included version.

~~~Client~~~
Open minecraft.jar using 7-zip or similar.
Copy all files except the two .txt files (readme and changelog) into minecraft.jar
Delete the META-INF folder.

minecraft.jar is found in .minecraft/bin
To get there, open Minecraft and click "Texture Packs".
Then click on "Open texture pack folder"
A new window should appear, displaying the texturepacks folder.
Go up one level (alt+up arrow on Windows) - you should be in .minecraft now.
Switch back to Minecraft and close it.
From the .minecraft folder, enter the bin folder.

~~~Server~~~
Open minecraft_server.jar using 7-zip or similar.
Copy all files except the .txt files into minecraft_server.jar
*VERY IMPORTANT*
Unlike client installation, you do NOT have to delete META-INF.
In fact, if you do delete META-INF you can't run Minecraft Server.

Note
----
All versions from 3.0 onwards will include WorldEdit support, unless otherwise noted.
Version 4.5 includes an easter egg: sometimes dungeons will have a Snow Golem spawner.

Bugs
----
- creating a stronghold may crash the game (to do with chests)
- WorldEdit //undo command doesn't properly restore doors, beds or chests
- WorldEdit support doesn't include tile entities
- Paint hasn't been re-written to support multiple players

Notes
-----
XCommands works in LAN games - currently clients do *not* need XCommands installed.

You must prefix all commands with /c, for example "/c /give diamond 3"
Some commands can be used normally (without /c) but not all of them.

You can now generate a biome-specific feature, using "/c /structure biomefeature"
This will generate a different structure depending on which biome you are in.
Swamp biome = witch hut, Jungle biome = jungle temple, Other biomes = Pyramid

Some commands have been left out, due to Minecraft having similar commands.

Not all commands work currently, this will gradually be fixed.

Available commands
------------------
~COMMAND~		~DESCRIPTION~
oldhelp			- displays help from old version of Console
hunger [value]		- sets hunger amount
feed [value]		- feeds player specified amount of food
restoreitems		- REMOVED (use the keepInventory gamerule instead)
drops			- toggles item drops
time get		- display current time
time set day		- day time
time set night		- night time
time set hour [value]	- set hour
time set day [value]	- set day
time set minute [value]	- set minute
seed			- display current seed
kill			- kills player
dimension		- teleport to specified dimension
platform		- places block of glass directly underneath player
god			- toggles invincibility
give item amount damage	- gives specified item, amount and damage are optional
clearchat		- clears messages
biome			- displays current biome
pos			- displays current position
spawnportal nether	- spawns nether portal
spawnportal end		- spawns end portal (non-stronghold)
help			- lists commands
help [commandname]	- displays help for specified command
remove			- removes entity you're pointing at (CURRENTLY UNFINISHED)
removeblock		- removes block you're pointing at
spawn [entity] [amount]	- spawns specified entity - amount optional
spawn list		- lists all entities, spawnable or not
spawner [entity]	- changes entity spawned by mob spawner you're pointing at
listcolors		- lists available command colors
color [number]		- sets command color
color error [number]	- sets error color
clearwater		- REMOVED (use /light command instead)
allowfly		- toggles flying (works in survival)
find [item]		- find id(s) for item with specified (partial) name (case sensitive)
itemname [id]		- finds item name for specified item id
storeinventory		- upon death, store inventory (retrievable via Ender Chest)
togglecheats		- toggles Minecraft's inbuilt cheats on/off
skullowner		- lets you set the owner of a head
serverinfo		- displays integrated server version
reach			- sets reach distance, for use with /generate command
showchat		- brings up the chat GUI (this bound to ~ by default)
phelp			- displays a list of plugin commands
phelp [commandname]	- displays help for specific plugin command
plugin version [plugin]	- displays version of specified plugin
plugin list		- lists currently enable plugins
plugin dlist		- lists currently disabled plugins
plugin disable [plugin]	- disable specified plugin
plugin enable [plugin]	- enable specified plugin
resolveid (itemid)	- finds the name for specified item ID
deathpositions		- displays death positions NOTE: reset upon exit
superheat [all]		- smelt current item or all items 

New Minecraft commands
======================
XCommands now adds new commands to Minecraft (that aren't used through /c)
This current includes:
* All WorldEdit Commands
* /light
* /waypoint

Plugin commands
===============

Description
-----------
The following plugins are included:

 ported plugins: (from SinglePlayerCommands)
 - Bind
 - Enchant
 - Inventory
 - Item
 - Light
 - Paint
 - Path
 - Weather

 native plugins:
 - Generate
 - Kill Player
 - MC Commands
 - Mob Commands
 - Structure Generation
 - Waypoint

 worldedit plugins:
 - WorldEdit
 - WorldEditGUI (depending on version)

Note
----
All commands must be prefixed with /c
For example, type '/c /weather rain' to make it rain.
WorldEdit commands require an additional forward slash.
Type '/c ///help' to get a list of WorldEdit commands.

Bind Command
------------
Use '/c /bind [key] [command]' to bind a key to the specified command.
Note that you do *NOT* prefix the command name with /c.
For example, '/c /bind g /god' will make g toggle god mode.

Due to WorldEdit functionality no longer being available through '/c',
you can now bind a key to do a 'vanilla' command by prefixing it with '!'.
For example, for 'n' to give you the wand: '/c /bind n !/wand'

Enchant Commands
----------------
All of these commands begin with /enchant:
add name/id level	- add specified enchantment to currently held item
forceadd		- force adding specified enchantment to currently held item
forceremove		- force removing all enchantments from currently held item
list			- lists available enchantments
remove			- remove all enchantments from currently help item

Inventory Commands
------------------
enderchest		- bring up enderchest GUI without having enderchest
repair <all>		- repair current item (or all items in inventory)

Attempting to repair non-damaged items, for example wool, can lead to unexpected results.
e.g. wool uses damage values to determine which colour it is, so it will be reset to white.

Item Commands
-------------
Item Commands are prefixed with /item (typing this by itself displays current item ID)
clearname		- removes item name
cleartag		- resets item tag
name			- displays current name
name (NAME)		- allows you to name current item

MC Commands
-----------
These are commands built into Minecraft, but you can use them without enabling cheats.
difficulty [0-3]	- for changing difficulty
exp [amount]		- add specified amount of experience
gamemode [0|1|2]	- change gamemode to survival, creative or adventure
gamerule [rule] [state]	- enable or disable specified game rule

Mob Commands
------------
hurtmob [lightning]	- hurt mob you're pointing at (lightning optional)
lendarmor		- lend your armor to a mob
lenditem		- lend currently selected item to mob
liberatearmor [erase]	- give a copy of mob's armor to you
liberateitem [erase]	- give a copy of mob's item to you

Waypoint Commands
-----------------
setspawn		- sets spawn position to current coordinates
setspawn [x] [y] [z]	- sets spawn position to specified co-ordinates
getspawn		- displays current spawn position
home			- teleport to home(bed)
return			- return to last position before teleporting
deathpos		- teleport to position player died (fixed in 3.9)
tp [x] [y] [z]		- teleports to specified coordinates, eg. 'tp 150 70 80'
spawnpoint		- teleports to spawn point
gethome			- displays current home (bed) position

NOTE: /deathpos requires you to be in the same dimension as you were when you died.

Weather Commands
----------------
weather rain		- changes weather to rain
weather thunder		- changes weather to storm (rain and thunder/lightning)
weather lightning	- creates a lightning bolt at block you're pointing at
weather sun		- changes weather to sunny

Structure Commands
------------------
(standard structures)
structure village	- create village (desert village if in desert)
structure netherbridge	- create nether bridge (regardless of dimension)
structure mineshaft	- create (abandoned) mineshaft
structure stronghold	- create stronghold

(biome-specific structures)
structure biomefeature	- create biome-specific structure
structure hut		- create witch hut
structure pyramid	- create desert pyramid
structure temple	- create jungle temple

For example, to generate a stronghold, you would type '/c /structure stronghold'

You can prefix a structure command with either 'forceflat' or 'forcenormal'.
If you find pyramids spawn in the air, use '/c /structure pyramid forceflat'.


Generate Commands
-----------------
Use '/c /generate [anti-structure]' to generate an anti-structure.
For example, '/generate swamptree' will generate a swamp tree.
The anti-structure is generated at the block you're pointing at.

Type '/c /generate mode 0' to generate at your current position.
Use '/c /generate mode 1' if you want the default behaviour.

If you want to generate an anti-structure at specific co-ordinates,
use '/c /generate pumpkin 0 64 0' for example.

You can adjust the offsets used when generating anti-structures.
Use '/c /generate xoffset [number]' to adjust the xoffset.
Use '/c /generate yoffset [number]' to adjust the yoffset.
Use '/c /generate zoffset [number]' to adjust the zoffset.
You will need to adjust the yoffset if you change the generation mode to 0.

To get the default offsets back, type:
/c /generate xoffset 0
/c /generate yoffset 1
/c /generate zoffset 0

Some anti-structures allow custom parameters.
For example, '/c /generate jungletree 128' will generate a jungle tree 128 blocks high.
To specify a custom block for mineable, you might type '/generate mineable oreDiamond'.

Different types of trees:
- foresttree is a birch tree. (whitebark)
- tree1 is a regular tree.
- tree2 is a jungle tree with vines.
- tree3 is a jungle tree without vines.
- taigatree1 is a tall sequoia tree. (redwood)
- taigatree2 is a regular sequoia tree. (redwood)
- jungletree is a huge jungle tree.
- swamptree is a tree with vines.
- bigtree is a big tree.

A fix for generating dungeons is included.

Glowstone only generates on netherrack.

Anti-structure list
-------------------

chest		- generates bonus chest
waterlily	- generates water lily
pumpkin		- generates pumpkins
mineable	- generates mineable blocks (allows custom block)
flower		- generates yellow flowers
rose		- generates roses (red)
mushroombrown	- generates brown mushrooms
mushroomred	- generates red mushrooms
tallgrass	- generates tall grass
ferns		- generates ferns
lavalake	- generates lake of lava
waterlake	- generates lake of water
vines		- generates vines
netherlava	- generates lava when in The Nether
netherfire	- generatres fire when in The Nether
clay		- generates clay
water		- generates water
lava		- generates lava
glowstone1	- generates glowstone
glowstone2	- generates glowstone
reeds		- generates sugar cane on sand
taigatree1	- generates 1st type of taiga tree
taigatree2	- generates 2nd type of taiga tree
deadbush	- generates dead bushes
spikes		- generates end spikes on end stone
cactus		- generates cactus on sand
dungeon		- generates dungeon (doesn't work)
sand		- generates sand around water
gravel		- generates gravel around water
swamptree	- generates a swamp tree (formerly known as vinetree)
well		- generates a well
shrub		- generates a shrub
bigmushroom	- generates a giant mushroom (random type)
bigmushroom1	- generates a giant mushroom (1st type)
bigmushroom2	- generates a giant mushroom (2nd type)
bigtree		- generates a large tree
jungletree	- generates a jungle tree (allows custom height)
foresttree	- generates a forest tree
tree1		- generates 1st type of tree
tree2		- generates 2nd type of tree (allows custom height)
tree3		- generates 3rd type of tree (allows custom height)