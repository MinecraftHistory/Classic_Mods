package net.minecraftforge.event.entity;

import net.minecraft.src.mp;
import net.minecraftforge.event.Event;

public class EntityEvent extends Event {

	public EntityEvent(mp entity) {}

}