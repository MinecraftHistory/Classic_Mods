package net.minecraftforge.event;

public class Event {

	public enum Result {
		DENY,
		DEFAULT,
		ALLOW
	}

	public boolean isCanceled() {
		return true;
	}

}