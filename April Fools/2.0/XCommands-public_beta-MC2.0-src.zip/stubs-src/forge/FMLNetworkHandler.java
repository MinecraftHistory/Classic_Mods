package cpw.mods.fml.common.network;

import net.minecraft.src.cg; // INetworkManager
import net.minecraft.src.cw; // Packet3Chat
import net.minecraft.src.db; // Packet131
import net.minecraft.src.dk; // Packet250
import net.minecraft.src.ej; // ServerHandler

public class FMLNetworkHandler {

	public static cw handleChatMessage(ej serverhandler, cw chat) {
		return null;
	}

	public static void handlePacket250Packet(dk packet250, cg inetworkman, ej serverHandler) {}

	public static void handlePacket131Packet(ej serverHandler, db packet131) {}

}