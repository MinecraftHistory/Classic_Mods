package net.minecraftforge.event;

import net.minecraft.src.jc; // EntityPlayerMP

public class ServerChatEvent extends Event {

	public String line;

	public ServerChatEvent(jc player, String msg, String ln) {}

}