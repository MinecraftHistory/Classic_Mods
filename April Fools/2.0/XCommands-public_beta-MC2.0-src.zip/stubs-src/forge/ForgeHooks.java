package net.minecraftforge.common;

import net.minecraft.src.mg; // DamageSource
import net.minecraft.src.ng; // EntityLiving

public class ForgeHooks {

	public static boolean onLivingDeath(ng entity, mg src) {
		return false;
	}

}
