package net.minecraftforge.event.entity.player;

import net.minecraft.src.sp; // EntityPlayer
import static net.minecraftforge.event.Event.Result;
import static net.minecraftforge.event.Event.Result.*;

public class PlayerInteractEvent extends PlayerEvent {

	public static enum Action {
		RIGHT_CLICK_AIR,
		RIGHT_CLICK_BLOCK,
		LEFT_CLICK_BLOCK
	}

	public Result useBlock = DEFAULT;
	public Result useItem = DEFAULT;

	public PlayerInteractEvent(sp player, Action action, int x, int y, int z, int face) {
		super(player);
	}

}