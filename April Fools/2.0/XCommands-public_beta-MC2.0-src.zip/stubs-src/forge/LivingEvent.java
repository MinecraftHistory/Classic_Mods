package net.minecraftforge.event.entity.living;

import net.minecraft.src.ng; // EntityLiving
import net.minecraftforge.event.entity.EntityEvent;

public class LivingEvent extends EntityEvent {

	public LivingEvent(ng entity) {
		super(entity);
	}

}