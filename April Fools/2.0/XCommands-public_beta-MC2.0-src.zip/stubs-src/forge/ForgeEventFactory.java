package net.minecraftforge.event;

import net.minecraft.src.sp; // EntityPlayer
import net.minecraft.src.wm; // ItemStack
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.Action;

public class ForgeEventFactory {

	public static PlayerInteractEvent onPlayerInteract(sp player, Action action, int x, int y, int z, int face) {
		return null;
    	}

	public static void onPlayerDestroyItem(sp player, wm stack) {}

}
