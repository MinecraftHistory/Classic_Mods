package net.minecraftforge.event.entity.player;

import java.util.ArrayList;
import net.minecraft.src.mg; // DamageSource
import net.minecraft.src.rg; // EntityItem
import net.minecraft.src.sp; // EntityPlayer
import net.minecraftforge.event.entity.living.LivingEvent;

public class PlayerDropsEvent extends LivingEvent {

	public PlayerDropsEvent(sp entity, mg source,
		ArrayList<rg> drops, boolean recentlyHit) {
		super(entity);
	}
}