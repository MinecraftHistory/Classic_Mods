package net.minecraftforge.event;

public class EventBus {

	public boolean post(Event event) {
		return false;
	}
}
