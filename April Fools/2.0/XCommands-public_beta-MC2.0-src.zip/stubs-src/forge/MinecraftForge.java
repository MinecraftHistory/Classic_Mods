package net.minecraftforge.common;

import net.minecraftforge.event.EventBus;

public class MinecraftForge {

    public static final EventBus EVENT_BUS = new EventBus();

}
