package net.minecraftforge.event.entity.player;

import net.minecraft.src.sp; // EntityPlayer
import net.minecraftforge.event.entity.living.LivingEvent;

public class PlayerEvent extends LivingEvent {

	public PlayerEvent(sp player) {
		super(player);
	}

}