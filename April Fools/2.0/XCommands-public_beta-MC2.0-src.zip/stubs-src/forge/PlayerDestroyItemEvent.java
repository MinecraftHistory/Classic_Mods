package net.minecraftforge.event.entity.player;

import net.minecraft.src.sp; // EntityPlayer
import net.minecraft.src.wm; // ItemStack

public class PlayerDestroyItemEvent extends PlayerEvent {

	public PlayerDestroyItemEvent(sp player, wm original) {
		super(player);
	}

}
