package net.minecraftforge.event.world;

import net.minecraft.src.jc; // EntityPlayerMP
import net.minecraft.src.zv; // ChunkCoordIntPair
import net.minecraftforge.event.Event;

public class ChunkWatchEvent extends Event {
    
	public ChunkWatchEvent(zv chunk, jc player) {}
    
	public static class Watch extends ChunkWatchEvent {
		public Watch(zv chunk, jc player) {
			super(chunk, player);
		}        
	}

}
