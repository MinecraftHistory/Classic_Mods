package wecui.event;

import wecui.WorldEditCUI;
import wecui.fevents.Event;

public class CUIEvent extends Event {

	public CUIEvent(WorldEditCUI wecui, String type, String[] params) {}

}