package wecui;

import wecui.fevents.EventManager;

public class WorldEditCUI {

	public EventManager getEventManager() {
		return null;
	}

	public static String getVersion() {
		return "";
	}

}