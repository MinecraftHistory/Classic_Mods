package wecui.fevents;

public class EventManager {

	public void callEvent(Event event) {}

}