package wecui.fevents;

public class Event {}