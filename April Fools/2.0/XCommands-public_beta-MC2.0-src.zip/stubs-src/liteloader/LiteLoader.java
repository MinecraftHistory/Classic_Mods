package com.mumfrey.liteloader.core;

import java.io.File;
import java.io.FilenameFilter;

public final class LiteLoader implements FilenameFilter {

	public static LiteLoader getInstance() {
		return null;
	}

	public boolean accept(File dir, String fileName) {
		return false;
	}

}