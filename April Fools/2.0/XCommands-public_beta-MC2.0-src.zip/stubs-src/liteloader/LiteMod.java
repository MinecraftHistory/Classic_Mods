package com.mumfrey.liteloader;

public interface LiteMod {

	public String getName();

}