package com.sijobe.spc.overwrite;

import net.minecraft.src.jh; // NetServerHandler

public class ONetServerHandler extends jh {

	public ONetServerHandler() {
		super(null, null, null);
	}

	public jh getOldInstance() {
		return null;
	}

}