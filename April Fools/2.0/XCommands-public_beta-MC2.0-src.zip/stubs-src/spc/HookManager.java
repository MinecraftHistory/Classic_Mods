package com.sijobe.spc.core;

import java.util.ArrayList;
import java.util.List;

public class HookManager {

   @SuppressWarnings("unchecked")
   public <H extends IHook> List<H> getHooks(Class<H> type) {
      List<H> thisType = new ArrayList<H>();
      return thisType;
   }

   @SuppressWarnings("unchecked")
   public <H extends IHook> void loadHooks(Class<H> type) {}

}
