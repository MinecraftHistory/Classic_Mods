package com.sijobe.spc.wrapper;

public class Player {

	private final net.minecraft.src.sp player;

	public Player(net.minecraft.src.sp player) {
		this.player = player;
	}

}
