package com.sijobe.spc.core;

import com.sijobe.spc.wrapper.Player;

public interface IPlayerMP extends IHook {

   public void onTick(Player player);

}
