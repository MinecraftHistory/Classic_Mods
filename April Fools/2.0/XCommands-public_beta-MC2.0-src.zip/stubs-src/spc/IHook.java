package com.sijobe.spc.core;

public interface IHook {

   public boolean isEnabled();

   public void init(Object... params);

}
