package com.sijobe.spc.core;

import com.sijobe.spc.wrapper.Player;

public interface IPlayerSP extends IHook {

   public void onTick(Player player);

   public void movePlayer(Player plr, float fwd, float strafe, float spd);

}
