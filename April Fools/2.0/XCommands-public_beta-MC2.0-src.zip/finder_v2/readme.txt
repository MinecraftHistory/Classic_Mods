This is a small utility designed to get the 'MCP name' of a class from fernflower-decompiled source.

~ q3hardcore