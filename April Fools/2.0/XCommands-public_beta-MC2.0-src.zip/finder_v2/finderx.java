import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class finderx {

	private static HashMap<String, String> classes = new HashMap<String, String>();
	private static HashMap<String, String> occurenceData = new HashMap<String, String>();
	private static HashMap<String, String> xData = new HashMap<String, String>();
	private static HashMap<String, String[]> xMap = new HashMap<String, String[]>();
	private static File mcDir;
	private static String mcpName;

	public static void main(String[] args) {
		FileReader fileReader;

		try {
			fileReader = new FileReader("xclass.txt");
		} catch (FileNotFoundException fnfe) {
			System.out.println("Couldn't find xclass.txt");
			return;
		}

		try {
			readClassesFile(fileReader);
		} catch (IOException ioe) {
			System.out.println("File corrupt");
		}

		try {
			fileReader = new FileReader("xmap.txt");
		} catch (FileNotFoundException fnfe) {
			System.out.println("Couldn't find xmap.txt");
			return;
		}

		try {
			readXFile(fileReader);
		} catch (IOException ioe) {
			System.out.println("File corrupt");
		}

		if(args.length < 1) {
			System.out.println("specify mc dir");
		} else {
			mcDir = new File(args[0]);
		}

		if(!mcDir.exists()) {
			System.out.println("not exist");
			return;
		}

		if(args.length < 2) {
			if(System.console() == null) {
				System.out.println("no class specified, defaulting to EntityPlayerMP");
				mcpName = "EntityPlayerMP";
			} else {
				mcpName = System.console().readLine("MCP class name: ");
			}
		} else {
			mcpName = args[1];
		}

		String fragment;
		if((fragment = classes.get(mcpName)) != null) {
			System.out.println("searching");
			try {
				searchFiles(fragment, false);
			} catch (IOException ioe) {
				ioe.printStackTrace();
				return;
			}
		} else {
			System.out.println("unknown class");
			return;
		}

	}

	public static void readClassesFile(FileReader fileReader) throws IOException {
		BufferedReader reader = new BufferedReader(fileReader);
		String nextLine;
		while((nextLine = reader.readLine()) != null) {
			if(nextLine.startsWith("#")) {
				// System.out.println("skipping comment");
			} else {
				String[] split = nextLine.split("////");
				if(split.length >= 3) {
					classes.put(split[0], split[1]);
					occurenceData.put(split[0], split[2]);
					if(split.length == 4) {
						xData.put(split[0], split[3]);
					}
				}
			}
		}
	}

	public static void readXFile(FileReader fileReader) throws IOException {
		BufferedReader reader = new BufferedReader(fileReader);
		String nextLine;
		while((nextLine = reader.readLine()) != null) {
			if(nextLine.startsWith("#")) {
				// System.out.println("skipping comment");
			} else {
				String[] split = nextLine.split("////");
				if(split.length == 2) {
					String[] xSplit = split[1].split(",");
					if(xSplit.length >= 1) {
						xMap.put(split[0], xSplit);
					} else {
						System.err.println(split[0] + " has no x mapping!");
					}
				}
			}
		}
	}

	public static String searchFiles(String fragment, boolean quick) throws IOException {
		for(String className : classes.keySet()) {
			if(fragment.contains(className + " ") || fragment.contains(className + "[")) {
				System.out.println("Obfuscating fragment");
				String obfuscName = searchFiles(classes.get(className), true);
				String[] splitFragment = fragment.split(className);
				if(splitFragment.length == 2) {
					fragment = splitFragment[0] + obfuscName + splitFragment[1];
				} else {
					System.out.println("Invalid fragment");
					return "";
				}
			}
		}

		File[] files;
		if((files = mcDir.listFiles()) != null) {

			HashMap<File, Integer> correctFiles = new HashMap<File, Integer>();

			for(File file : files) {
				FileReader fileReader = new FileReader(file);
				BufferedReader reader = new BufferedReader(fileReader);
				String nextLine;
				while((nextLine = reader.readLine()) != null) {
					if(nextLine.contains(fragment)) {
						if(!correctFiles.containsKey(file)) {
							correctFiles.put(file, 1);
							String fileString = file.toString();
							String shortName = fileString.substring(fileString.lastIndexOf("\\")+1, fileString.lastIndexOf("."));
							if(quick) {
								System.out.println("Fragment was: " + shortName + ", continuing");
								return shortName;
							} else {
								System.out.println("Found possible class: " + shortName);
							}
						} else {
							int occurences = correctFiles.get(file);
							occurences++;
							correctFiles.put(file, occurences);
						}
					}
				}
			}

			String occurenceString;
			if((occurenceString = occurenceData.get(mcpName)) != null) {
				try {
					int occurenceInt = Integer.parseInt(occurenceString);
					for(File correctFile : correctFiles.keySet()) {
						if(correctFiles.get(correctFile) == occurenceInt) {
							System.out.println("Correct occurences: " + correctFile.getName());
							String correctFileName = correctFile.getName();
							searchFilesX(correctFileName.substring(0, correctFileName.indexOf(".")));
						} else {
							System.out.println("Incorrect occurences: " + correctFile.getName());
						}
					}
				} catch (NumberFormatException nfe) {
					System.out.println("Invalid occurence data");
					return "";
				}
			}

		} else {
			System.out.println("not directory");
			return "";
		}

		return "";
	}

	public static void searchFilesX(String fragment) throws IOException {
		System.out.println("X: " + fragment);
		File[] files;
		if((files = mcDir.listFiles()) != null) {

			HashMap<File, String> xFiles = new HashMap<File, String>();

			for(File file : files) {
				FileReader fileReader = new FileReader(file);
				BufferedReader reader = new BufferedReader(fileReader);
				String nextLine;
				while((nextLine = reader.readLine()) != null) {
					if(nextLine.contains("extends " + fragment + " ")) {
						String fileString = file.toString();
						String shortName = fileString.substring(fileString.lastIndexOf("\\")+1, fileString.lastIndexOf("."));
						xFiles.put(file, shortName);
						System.out.println("Found X class: " + shortName);
					}
				}
			}

			List<String> files1 = new ArrayList<String>();
			List<String> files2 = new ArrayList<String>();
			List<String> files3 = new ArrayList<String>();
			List<String> filesOther = new ArrayList<String>();

			for(File xFile : xFiles.keySet()) {
				String xFileName = xFiles.get(xFile);
				if(xFileName.length() == 1) {
					files1.add(xFileName);
				} else if(xFileName.length() == 2) {
					files2.add(xFileName);
				} else if(xFileName.length() == 3) {
					files3.add(xFileName);
				} else {
					filesOther.add(xFileName);
				}
			}

			Collections.sort(files1);
			Collections.sort(files2);
			Collections.sort(files3);
			Collections.sort(filesOther);

			String[] xClasses = new String[files1.size() + files2.size() + files3.size() + filesOther.size()];

			int offset = 0;
			for(String x : files1) {
				xClasses[offset] = x;
				offset++;
			}
			for(String x : files2) {
				xClasses[offset] = x;
				offset++;
			}
			for(String x : files3) {
				xClasses[offset] = x;
				offset++;
			}
			for(String x : filesOther) {
				xClasses[offset] = x;
				offset++;
			}
			if(xData.containsKey(mcpName)) {
				String mapKey = xData.get(mcpName);
				String[] unmapped = xMap.get(mapKey);
				if(unmapped.length == xClasses.length) {
					System.out.println("Beginning re-map");
					for(int i = 0; i < unmapped.length; i++) {
						String mapping = mapKey.replace("*", unmapped[i]);
						System.out.println(xClasses[i] + ": " + mapping);
					}
				}
			}
		} else {
			System.out.println("not directory");
		}
	}

}