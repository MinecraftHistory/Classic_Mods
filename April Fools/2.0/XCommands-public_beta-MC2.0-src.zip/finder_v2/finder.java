import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class finder {

	private static HashMap<String, String> classes = new HashMap<String, String>();
	private static HashMap<String, String> occurenceData = new HashMap<String, String>();
	private static File mcDir;
	private static String mcpName;

	public static void main(String[] args) {
		FileReader fileReader;

		try {
			fileReader = new FileReader("class.txt");
		} catch (FileNotFoundException fnfe) {
			System.out.println("Couldn't find class.txt");
			return;
		}

		try {
			readClassesFile(fileReader);
		} catch (IOException ioe) {
			System.out.println("File corrupt");
		}

		if(args.length < 1) {
			System.out.println("specify mc dir");
		} else {
			mcDir = new File(args[0]);
		}

		if(!mcDir.exists()) {
			System.out.println("not exist");
			return;
		}

		if(args.length < 2) {
			if(System.console() == null) {
				System.out.println("no class specified, defaulting to EntityPlayerMP");
				mcpName = "EntityPlayerMP";
			} else {
				mcpName = System.console().readLine("MCP class name: ");
			}
		} else {
			mcpName = args[1];
		}

		String fragment;
		if((fragment = classes.get(mcpName)) != null) {
			System.out.println("searching");
			try {
				searchFiles(fragment, false);
			} catch (IOException ioe) {
				ioe.printStackTrace();
				return;
			}
		} else {
			System.out.println("unknown class");
			return;
		}

	}

	public static void readClassesFile(FileReader fileReader) throws IOException {
		BufferedReader reader = new BufferedReader(fileReader);
		String nextLine;
		while((nextLine = reader.readLine()) != null) {
			if(nextLine.startsWith("#")) {
				// System.out.println("skipping comment");
			} else {
				String[] split = nextLine.split("////");
				classes.put(split[0], split[1]);
				occurenceData.put(split[0], split[2]);
			}
		}
	}

	public static String searchFiles(String fragment, boolean quick) throws IOException {
		for(String className : classes.keySet()) {
			if(fragment.contains(className + " ") || fragment.contains(className + "[")) {
				System.out.println("Obfuscating fragment");
				String obfuscName = searchFiles(classes.get(className), true);
				String[] splitFragment = fragment.split(className);
				if(splitFragment.length == 2) {
					fragment = splitFragment[0] + obfuscName + splitFragment[1];
				} else {
					System.out.println("Invalid fragment");
					return "";
				}
			}
		}

		File[] files;
		if((files = mcDir.listFiles()) != null) {

			HashMap<File, Integer> correctFiles = new HashMap<File, Integer>();

			for(File file : files) {
				FileReader fileReader = new FileReader(file);
				BufferedReader reader = new BufferedReader(fileReader);
				String nextLine;
				while((nextLine = reader.readLine()) != null) {
					if(nextLine.contains(fragment)) {
						if(!correctFiles.containsKey(file)) {
							correctFiles.put(file, 1);
							String fileString = file.toString();
							String shortName = fileString.substring(fileString.lastIndexOf("\\")+1, fileString.lastIndexOf("."));
							if(quick) {
								System.out.println("Fragment was: " + shortName + ", continuing");
								return shortName;
							} else {
								System.out.println("Found possible class: " + shortName);
							}
						} else {
							int occurences = correctFiles.get(file);
							occurences++;
							correctFiles.put(file, occurences);
						}
					}
				}
			}

			String occurenceString;
			if((occurenceString = occurenceData.get(mcpName)) != null) {
				try {
					int occurenceInt = Integer.parseInt(occurenceString);
					for(File correctFile : correctFiles.keySet()) {
						if(correctFiles.get(correctFile) == occurenceInt) {
							System.out.println("Correct occurences: " + correctFile.getName());
						} else {
							System.out.println("Incorrect occurences: " + correctFile.getName());
						}
					}
				} catch (NumberFormatException nfe) {
					System.out.println("Invalid occurence data");
					return "";
				}
			}

		} else {
			System.out.println("not directory");
			return "";
		}

		return "";
	}

}