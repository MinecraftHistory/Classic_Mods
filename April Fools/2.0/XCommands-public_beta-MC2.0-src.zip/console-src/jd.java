package net.minecraft.src;

import java.util.List;

/* <Console>------------------------------------------------------------- */
import com.q3hardcore.console.command.WorldEditCommandSet;
import com.q3hardcore.console.wrapper.WPlayer;
import java.util.LinkedList;
/* </Console>------------------------------------------------------------ */

/* <Forge>--------------------------------------------------------------- */
import com.q3hardcore.console.proxy.Proxy;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/* </Forge>-------------------------------------------------------------- */

public class jd {

   public aac a;
   public jc b;
   private aak c;
   private boolean d;
   private int e;
   private int f;
   private int g;
   private int h;
   private int i;
   private boolean j;
   private int k;
   private int l;
   private int m;
   private int n;
   private int o;

   /* <Console>------------------------------------------------------------- */
   private final List<String> pendingMessages = new LinkedList<String>();
   private static boolean hasComplained = false;
   /* </Console>------------------------------------------------------------ */

   /* <Forge>--------------------------------------------------------------- */
   private double blockReachDistance = 5.0D;
   private static final boolean HAS_FORGE = ConsoleHelper.getHasForge();
   /* </Forge>-------------------------------------------------------------- */

   public jd(aac var1) {
      this.c = aak.a;
      this.o = -1;
      this.a = var1;

      /* <Console>------------------------------------------------------------- */
      if(!ConsoleHelper.checkWorldEditLoaded(pendingMessages) && !hasComplained) {
         if(ConsoleHelper.hasConsole()) {
            pendingMessages.add("WorldEdit support unavailable. (Unable to find WorldEdit.jar)");
         }
         hasComplained = true;
      }
      /* </Console>------------------------------------------------------------ */

   }

   public void a(aak var1) {
      this.c = var1;
      var1.a(this.b.cf);
      this.b.n();
   }

   public aak b() {
      return this.c;
   }

   public boolean d() {
      return this.c.d();
   }

   public void b(aak var1) {
      if(this.c == aak.a) {
         this.c = var1;
      }

      this.a(this.c);
   }

   public void a() {

      /* <Console>------------------------------------------------------------- */
      if(pendingMessages.size() > 0) {
         for(String msg : pendingMessages) {
            this.b.b(msg);
         }
         pendingMessages.clear();
      }
      /* </Console>------------------------------------------------------------ */

      ++this.i;
      int var1;
      float var4;
      int var5;
      if(this.j) {
         var1 = this.i - this.n;
         int var2 = this.a.a(this.k, this.l, this.m);
         if(var2 == 0) {
            this.j = false;
         } else {
            apd var3 = apd.r[var2];
            var4 = var3.a(this.b, this.b.q, this.k, this.l, this.m) * (float)(var1 + 1);
            var5 = (int)(var4 * 10.0F);
            if(var5 != this.o) {
               this.a.f(this.b.k, this.k, this.l, this.m, var5);
               this.o = var5;
            }

            if(var4 >= 1.0F) {
               this.j = false;
               this.b(this.k, this.l, this.m);
            }
         }
      } else if(this.d) {
         var1 = this.a.a(this.f, this.g, this.h);
         apd var12 = apd.r[var1];
         if(var12 == null) {
            this.a.f(this.b.k, this.f, this.g, this.h, -1);
            this.o = -1;
            this.d = false;
         } else {
            int var13 = this.i - this.e;
            var4 = var12.a(this.b, this.b.q, this.f, this.g, this.h) * (float)(var13 + 1);
            var5 = (int)(var4 * 10.0F);
            int var6 = this.f;
            int var7 = this.g;
            int var8 = this.h;
            float var9 = var12 instanceof anv?0.05F:0.01F;
            if(this.a.s.nextFloat() < var9) {
               List<?> var10 = this.a.a(nm.class, arb.a().a((double)var6, (double)var7, (double)var8, (double)(var6 + 1), (double)(var7 + 1), (double)(var8 + 1)));
               if(var10.isEmpty()) {
                  nm var11 = new nm(this.a, var6, var7, var8);
                  var11.a(nm.d());
                  this.a.d((mp)var11);
               }
            }

            if(var5 != this.o) {
               this.a.f(this.b.k, this.f, this.g, this.h, var5);
               this.o = var5;
            }
         }
      }

   }

   public void a(int var1, int var2, int var3, int var4) {

      /* <Console>------------------------------------------------------------- */
      if(ConsoleHelper.hasConsole()) {
         WPlayer player = new WPlayer(this.b);
         player.getConsole().handleLeftClick(var1, var2, var3, var4);
         if(ConsoleHelper.hasWorldEdit()) {
            WorldEditCommandSet.handleMouseButtonDown(player, var1, var2, var3, var4, true);
         }
      }
      /* </Console>------------------------------------------------------------ */

      if(!this.c.c() || this.b.e(var1, var2, var3)) {

         /* <Forge>--------------------------------------------------------------- */
         final Object forgeEvent;
         if(HAS_FORGE) {
            forgeEvent = Proxy.FORGE_HELPER.handleBlockClicked(this, var1, var2, var3, var4);
            if(Proxy.FORGE_HELPER.isEventCanceled(forgeEvent)) {
               b.a.b(new fp(var1, var2, var3, a));
               // thisPlayerMP.playerNetServerHandler.sendPacketToPlayer, Packet53BlockChange, theWorld 
               return;
            }
         } else {
            forgeEvent = null;
         }
         /* </Forge>-------------------------------------------------------------- */

         if(this.d()) {
            if(!this.a.a((sp)null, var1, var2, var3, var4)) {
               this.b(var1, var2, var3);
            }

         } else {

            /* <Forge>--------------------------------------------------------------- */
            if(!HAS_FORGE) {
               this.a.a((sp)null, var1, var2, var3, var4);
            }
            /* <Forge>--------------------------------------------------------------- */

            this.e = this.i;
            float var5 = 1.0F;
            int var6 = this.a.a(var1, var2, var3);

            /* <Forge>--------------------------------------------------------------- */
            if(HAS_FORGE) {
               var5 = Proxy.FORGE_HELPER.allowBlockClicked(this, forgeEvent, var6, var1, var2, var3, var4);
               if(var5 == -777.0F) {
                  return;
               }
            } else {
               if(var6 > 0) {
                  apd.r[var6].a(this.a, var1, var2, var3, (sp)this.b);
                  var5 = apd.r[var6].a(this.b, this.b.q, var1, var2, var3);
               }
            }
            /* </Forge>-------------------------------------------------------------- */

            if(var6 > 0 && var5 >= 1.0F) {
               this.b(var1, var2, var3);
            } else {
               this.d = true;
               this.f = var1;
               this.g = var2;
               this.h = var3;
               int var7 = (int)(var5 * 10.0F);
               this.a.f(this.b.k, var1, var2, var3, var7);
               this.o = var7;
            }

         }
      }
   }

   public void a(int var1, int var2, int var3) {
      if(var1 == this.f && var2 == this.g && var3 == this.h) {
         int var4 = this.i - this.e;
         int var5 = this.a.a(var1, var2, var3);
         if(var5 != 0) {
            apd var6 = apd.r[var5];
            float var7 = var6.a(this.b, this.b.q, var1, var2, var3) * (float)(var4 + 1);
            if(var7 >= 0.7F) {
               this.d = false;
               this.a.f(this.b.k, var1, var2, var3, -1);
               this.b(var1, var2, var3);
            } else if(!this.j) {
               this.d = false;
               this.j = true;
               this.k = var1;
               this.l = var2;
               this.m = var3;
               this.n = this.e;
            }
         }
      }

   }

   public void c(int var1, int var2, int var3) {

      /* <Console>------------------------------------------------------------- */
      if(ConsoleHelper.hasConsole()) {
         WPlayer player = new WPlayer(this.b);
         player.getConsole().handleLeftClick(var1, var2, var3, 13);
         if(ConsoleHelper.hasWorldEdit()) {
            if(ConsoleHelper.isPlayerNonCreativeClient(player)) {
               // System.out.println("Using client wand fix.");
               WorldEditCommandSet.handleMouseButtonDown(player, var1, var2, var3, 0, true);
            }
         }
      }
      /* </Console>------------------------------------------------------------ */

      this.d = false;
      this.a.f(this.b.k, this.f, this.g, this.h, -1);
   }

   private boolean d(int var1, int var2, int var3) {
      apd var4 = apd.r[this.a.a(var1, var2, var3)];
      int var5 = this.a.h(var1, var2, var3);
      if(var4 != null) {
         var4.a(this.a, var1, var2, var3, var5, (sp)this.b);
      }

      /* <Forge>--------------------------------------------------------------- */
      final boolean var6;
      if(HAS_FORGE) {
         var6 = (var4 != null && Proxy.FORGE_HELPER.removeBlockByPlayer(var4, a, b, var1, var2, var3));
      } else {
         var6 = this.a.i(var1, var2, var3);
      }
      /* </Forge>-------------------------------------------------------------- */

      if(var4 != null && var6) {
         var4.g(this.a, var1, var2, var3, var5);
      }

      return var6;
   }

   public boolean b(int var1, int var2, int var3) {
      if(this.c.c() && !this.b.e(var1, var2, var3)) {
         return false;
      } else {

         /* <Forge>--------------------------------------------------------------- */
         if(HAS_FORGE) {
            wm stack = b.cb(); // ItemStack, thisPlayerMP.getCurrentEquippedItem
            if(stack != null && Proxy.FORGE_HELPER.onBlockStartBreak(stack, var1, var2, var3, b)) { // getItem
               return false;
            }
         }
         /* </Forge>-------------------------------------------------------------- */

         int var4 = this.a.a(var1, var2, var3);
         int var5 = this.a.h(var1, var2, var3);
         this.a.a(this.b, 2001, var1, var2, var3, var4 + (this.a.h(var1, var2, var3) << 12));

         /* <Forge>--------------------------------------------------------------- */
         boolean var6;
         if(HAS_FORGE) {
            var6 = false;
         } else {
            var6 = this.d(var1, var2, var3);
         }
         /* </Forge>-------------------------------------------------------------- */

         if(this.d()) {

            /* <Forge>--------------------------------------------------------------- */
            if(HAS_FORGE) {
               var6 = d(var1, var2, var3);
            }
            /* </Forge>-------------------------------------------------------------- */

            this.b.a.b(new fp(var1, var2, var3, this.a));
         } else {
            wm var7 = this.b.cb();

            /* <Forge>--------------------------------------------------------------- */
            final boolean var8;
            if(HAS_FORGE) {
               apd block = apd.r[var4]; // Block, Block.blocksList
               if (block != null) {
                  var8 = Proxy.FORGE_HELPER.canHarvestBlock(block, b, var5);
               } else {
                  var8 = false;
               }
            } else {
               var8 = this.b.a(apd.r[var4]);
            }
            /* </Forge>-------------------------------------------------------------- */

            if(var7 != null) {
               var7.a(this.a, var4, var1, var2, var3, this.b);
               if(var7.a == 0) {
                  this.b.cc();
               }
            }

            /* <Forge>--------------------------------------------------------------- */
            if(HAS_FORGE) {
               var6 = d(var1, var2, var3); // removeBlock
            }
            /* </Forge>-------------------------------------------------------------- */

            if(var6 && var8) {
               apd.r[var4].a(this.a, this.b, var1, var2, var3, var5);
            }
         }

         return var6;
      }
   }

   public boolean a(sp var1, aac var2, wm var3) {
      int var4 = var3.a;
      int var5 = var3.k();
      wm var6 = var3.a(var2, var1);
      if(var6 == var3 && (var6 == null || var6.a == var4 && var6.n() <= 0 && var6.k() == var5)) {
         return false;
      } else {
         var1.bL.a[var1.bL.c] = var6;
         if(this.d()) {
            var6.a = var4;
            if(var6.g()) {
               var6.b(var5);
            }
         }

         if(var6.a == 0) {
            var1.bL.a[var1.bL.c] = null;

            /* <Forge>--------------------------------------------------------------- */
            if(HAS_FORGE) {
               Proxy.FORGE_HELPER.destroyPlayerItem(b, var6);
            }
            /* </Forge>-------------------------------------------------------------- */

         }

         if(!var1.bV()) {
            ((jc)var1).a(var1.bM);
         }

         return true;
      }
   }

   public boolean a(sp var1, aac var2, wm var3, int var4, int var5, int var6, int var7, float var8, float var9, float var10) {

      /* <Console>------------------------------------------------------------- */
      if(ConsoleHelper.hasConsole()) {
         WPlayer player = new WPlayer(this.b);
         player.getConsole().handleRightClick(var4, var5, var6, var7);
         int blockId = a.a(var4, var5, var6); // getBlockId
         if(blockId > 0) { // this check is seemingly unnecessary
            if(ConsoleHelper.hasWorldEdit()) {
               WorldEditCommandSet.handleMouseButtonDown(player, var4, var5, var6, var7, false);
            }
         }
      }
      /* </Console>------------------------------------------------------------ */

      /* <Forge>--------------------------------------------------------------- */
      if(HAS_FORGE) {
         return Proxy.FORGE_HELPER.activateBlockOrUseItem(this, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
      }
      /* </Forge>-------------------------------------------------------------- */

      int var11;
      if(!var1.ag() || var1.bG() == null) {
         var11 = var2.a(var4, var5, var6);
         if(var11 > 0 && apd.r[var11].a(var2, var4, var5, var6, var1, var7, var8, var9, var10)) {
            return true;
         }
      }

      if(var3 == null) {
         return false;
      } else if(this.d()) {
         var11 = var3.k();
         int var12 = var3.a;
         boolean var13 = var3.a(var1, var2, var4, var5, var6, var7, var8, var9, var10);
         var3.b(var11);
         var3.a = var12;
         return var13;
      } else {
         return var3.a(var1, var2, var4, var5, var6, var7, var8, var9, var10);
      }
   }

   public void a(iz var1) {
      this.a = var1;
   }

   /* <Console>------------------------------------------------------------- */
   static {
      try {
         final Class<?> proxyClass = Class.forName("com.q3hardcore.console.proxy.Proxy");
         proxyClass.newInstance();
      } catch (Throwable t) {
         t.printStackTrace();
         System.err.println("SPConsole: Failed to instantiate proxy.");
      }
   }
   /* </Console>------------------------------------------------------------ */

   /* <Forge>--------------------------------------------------------------- */
   public double getBlockReachDistance() {
      return blockReachDistance;
   }

   public void setBlockReachDistance(double distance) {
      blockReachDistance = distance;
   }
   /* <Forge>--------------------------------------------------------------- */

}
