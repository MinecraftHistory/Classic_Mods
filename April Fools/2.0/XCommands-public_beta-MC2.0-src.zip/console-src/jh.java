package net.minecraft.src;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import net.minecraft.server.MinecraftServer;

/* <Forge>--------------------------------------------------------------- */
import com.q3hardcore.console.proxy.Proxy;
import com.q3hardcore.console.util.ModLoaderHelper;
import com.q3hardcore.console.wrapper.WPlayer;
import cpw.mods.fml.common.network.FMLNetworkHandler;
/* </Forge>-------------------------------------------------------------- */

/* <Console>------------------------------------------------------------- */
@SuppressWarnings({"unchecked", "rawtypes"})
/* </Console>------------------------------------------------------------ */

public class jh extends ej {

   public final cg a;
   private final MinecraftServer d;
   public boolean b = false;
   public jc c;
   private int e;
   private int f;
   private boolean g;
   private int h;
   private long i;
   private static Random j = new Random();
   private long k;
   private int l = 0;
   private int m = 0;
   private double n;
   private double o;
   private double p;
   private boolean q = true;
   private kr r = new kr();

   /* <Console>------------------------------------------------------------- */
   private boolean clientHasXCommands = false;
   private static boolean criticalErrorOccured = false;
   /* </Console>------------------------------------------------------------ */

   /* <Forge>--------------------------------------------------------------- */
   private static final boolean HAS_FORGE = ConsoleHelper.getHasForge();
   private static final boolean HAS_MODLOADER = ConsoleHelper.getHasModLoader();
   /* </Forge>-------------------------------------------------------------- */

   public jh(MinecraftServer var1, cg var2, jc var3) {
      this.d = var1;
      this.a = var2;
      var2.a((ej)this);
      this.c = var3;
      var3.a = this;
   }

   public void d() {

      /* <Console>------------------------------------------------------------- */
      if(!criticalErrorOccured) {
         try {
            if(this.c.clientHasXCommands != clientHasXCommands) {
               System.out.println("Updating clientHasXCommands");
               this.c.clientHasXCommands = clientHasXCommands;
            }
         } catch (Throwable t) {
            criticalErrorOccured = true;
            t.printStackTrace();
         }
      }
      /* <Console>------------------------------------------------------------- */

      this.g = false;
      ++this.e;
      this.d.a.a("packetflow");
      this.a.b();
      this.d.a.c("keepAlive");
      if((long)this.e - this.k > 20L) {
         this.k = (long)this.e;
         this.i = System.nanoTime() / 1000000L;
         this.h = j.nextInt();
         this.b(new ds(this.h));
      }

      if(this.l > 0) {
         --this.l;
      }

      if(this.m > 0) {
         --this.m;
      }

      this.d.a.c("playerTick");
      this.d.a.b();
   }

   public void c(String var1) {
      if(!this.b) {
         this.c.k();
         this.b(new dl(var1));
         this.a.d();
         this.d.ad().a((ei)(new cw(EnumChatFormatting.o + this.c.bT + " left the game.")));
         this.d.ad().e(this.c);
         this.b = true;
      }
   }

   public void a(ee var1) {

      /* <Console>------------------------------------------------------------- */
      if(ConsoleHelper.hasConsole()) {
         ConsoleHelper.checkNoclip(new WPlayer(this.c));
      }
      /* </Console>------------------------------------------------------------ */

      iz var2 = this.d.a(this.c.ar);
      this.g = true;
      if(!this.c.j) {
         double var3;
         if(!this.q) {
            var3 = var1.b - this.o;
            if(var1.a == this.n && var3 * var3 < 0.01D && var1.c == this.p) {
               this.q = true;
            }
         }

         if(this.q) {
            double var5;
            double var7;
            double var9;
            double var13;
            if(this.c.o != null) {
               float var34 = this.c.A;
               float var4 = this.c.B;
               this.c.o.U();
               var5 = this.c.u;
               var7 = this.c.v;
               var9 = this.c.w;
               double var35 = 0.0D;
               var13 = 0.0D;
               if(var1.i) {
                  var34 = var1.e;
                  var4 = var1.f;
               }

               if(var1.h && var1.b == -999.0D && var1.d == -999.0D) {
                  if(Math.abs(var1.a) > 1.0D || Math.abs(var1.c) > 1.0D) {
                     System.err.println(this.c.bT + " was caught trying to crash the server with an invalid position.");
                     this.c("Nope!");
                     return;
                  }

                  var35 = var1.a;
                  var13 = var1.c;
               }

               this.c.F = var1.g;
               this.c.g();
               this.c.d(var35, 0.0D, var13);
               this.c.a(var5, var7, var9, var34, var4);
               this.c.x = var35;
               this.c.z = var13;
               if(this.c.o != null) {
                  var2.b(this.c.o, true);
               }

               if(this.c.o != null) {
                  this.c.o.U();
               }


               /* <Forge>--------------------------------------------------------------- */
               if(HAS_FORGE && !this.q) { // hasMoved
                  return;
               }
               /* </Forge>-------------------------------------------------------------- */

               this.d.ad().d(this.c);
               this.n = this.c.u;
               this.o = this.c.v;
               this.p = this.c.w;
               var2.g(this.c);
               return;
            }

            if(this.c.bz()) {
               this.c.g();
               this.c.a(this.n, this.o, this.p, this.c.A, this.c.B);
               var2.g(this.c);
               return;
            }

            var3 = this.c.v;
            this.n = this.c.u;
            this.o = this.c.v;
            this.p = this.c.w;
            var5 = this.c.u;
            var7 = this.c.v;
            var9 = this.c.w;
            float var11 = this.c.A;
            float var12 = this.c.B;
            if(var1.h && var1.b == -999.0D && var1.d == -999.0D) {
               var1.h = false;
            }

            if(var1.h) {
               var5 = var1.a;
               var7 = var1.b;
               var9 = var1.c;
               var13 = var1.d - var1.b;
               if(!this.c.bz() && (var13 > 1.65D || var13 < 0.1D)) {
                  this.c("Illegal stance");
                  this.d.al().b(this.c.bT + " had an illegal stance: " + var13);
                  return;
               }

               if(Math.abs(var1.a) > 3.2E7D || Math.abs(var1.c) > 3.2E7D) {
                  this.c("Illegal position");
                  return;
               }
            }

            if(var1.i) {
               var11 = var1.e;
               var12 = var1.f;
            }

            this.c.g();
            this.c.X = 0.0F;
            this.c.a(this.n, this.o, this.p, var11, var12);
            if(!this.q) {
               return;
            }

            var13 = var5 - this.c.u;
            double var15 = var7 - this.c.v;
            double var17 = var9 - this.c.w;

            /* <Forge>--------------------------------------------------------------- */
            final double var19;
            final double var21;
            final double var23;
            if(HAS_FORGE) {
               var19 = Math.max(Math.abs(var13), Math.abs(this.c.x));
               var21 = Math.max(Math.abs(var15), Math.abs(this.c.y));
               var23 = Math.max(Math.abs(var17), Math.abs(this.c.z));
            } else {
               var19 = Math.min(Math.abs(var13), Math.abs(this.c.x));
               var21 = Math.min(Math.abs(var15), Math.abs(this.c.y));
               var23 = Math.min(Math.abs(var17), Math.abs(this.c.z));
            }
            /* </Forge>-------------------------------------------------------------- */

            double var25 = var19 * var19 + var21 * var21 + var23 * var23;
            if(var25 > 100.0D && (!this.d.I() || !this.d.H().equals(this.c.bT))) {
               this.d.al().b(this.c.bT + " moved too quickly! " + var13 + "," + var15 + "," + var17 + " (" + var19 + ", " + var21 + ", " + var23 + ")");
               this.a(this.n, this.o, this.p, this.c.A, this.c.B);
               return;
            }

            float var27 = 0.0625F;
            boolean var28 = var2.a(this.c, this.c.E.c().e((double)var27, (double)var27, (double)var27)).isEmpty();
            if(this.c.F && !var1.g && var15 > 0.0D) {
               this.c.j(0.2F);
            }

            /* <Forge>--------------------------------------------------------------- */
            if(HAS_FORGE && !this.q) { // hasMoved
               return;
            }
            /* </Forge>-------------------------------------------------------------- */

            this.c.d(var13, var15, var17);
            this.c.F = var1.g;
            this.c.j(var13, var15, var17);
            double var29 = var15;
            var13 = var5 - this.c.u;
            var15 = var7 - this.c.v;
            if(var15 > -0.5D || var15 < 0.5D) {
               var15 = 0.0D;
            }

            var17 = var9 - this.c.w;
            var25 = var13 * var13 + var15 * var15 + var17 * var17;
            boolean var31 = false;
            if(var25 > 0.0625D && !this.c.bz() && !this.c.c.d()) {
               var31 = true;
               this.d.al().b(this.c.bT + " moved wrongly!");
            }

            /* <Forge>--------------------------------------------------------------- */
            if(HAS_FORGE && !this.q) { // hasMoved
               return;
            }
            /* </Forge>-------------------------------------------------------------- */

            this.c.a(var5, var7, var9, var11, var12);
            boolean var32 = var2.a(this.c, this.c.E.c().e((double)var27, (double)var27, (double)var27)).isEmpty();
            // if(var28 && (var31 || !var32) && !this.c.bz()) {
            if(var28 && (var31 || !var32) && !this.c.bz() && !this.c.Z) { // noClip
               this.a(this.n, this.o, this.p, var11, var12);
               return;
            }

            arb var33 = this.c.E.c().b((double)var27, (double)var27, (double)var27).a(0.0D, -0.55D, 0.0D);
            // if(!this.d.Y() && !this.c.c.d() && !var2.c(var33)) {
            if(!this.d.Y() && !this.c.c.d() && !var2.c(var33) && !c.cf.c) { // playerEntity.capabilities.allowFly
               if(var29 >= -0.03125D) {
                  ++this.f;
                  if(this.f > 80) {
                     this.d.al().b(this.c.bT + " was kicked for floating too long!");
                     this.c("Flying is not enabled on this server");
                     return;
                  }
               }
            } else {
               this.f = 0;
            }

            /* <Forge>--------------------------------------------------------------- */
            if(HAS_FORGE && !this.q) { // hasMoved
               return;
            }
            /* </Forge>-------------------------------------------------------------- */

            this.c.F = var1.g;
            this.d.ad().d(this.c);
            this.c.b(this.c.v - var3, var1.g);
         }

      }
   }

   public void a(double var1, double var3, double var5, float var7, float var8) {
      this.q = false;
      this.n = var1;
      this.o = var3;
      this.p = var5;
      this.c.a(var1, var3, var5, var7, var8);
      this.c.a.b(new eg(var1, var3 + 1.6200000047683716D, var3, var5, var7, var8, false));
   }

   public void a(el var1) {
      iz var2 = this.d.a(this.c.ar);
      if(var1.e == 4) {
         this.c.a(false);
      } else if(var1.e == 3) {
         this.c.a(true);
      } else if(var1.e == 5) {
         this.c.bX();
      } else {
         boolean var3 = false;
         if(var1.e == 0) {
            var3 = true;
         }

         if(var1.e == 1) {
            var3 = true;
         }

         if(var1.e == 2) {
            var3 = true;
         }

         int var4 = var1.a;
         int var5 = var1.b;
         int var6 = var1.c;
         if(var3) {
            double var7 = this.c.u - ((double)var4 + 0.5D);
            double var9 = this.c.v - ((double)var5 + 0.5D) + 1.5D;
            double var11 = this.c.w - ((double)var6 + 0.5D);
            double var13 = var7 * var7 + var9 * var9 + var11 * var11;

            /* <Forge>--------------------------------------------------------------- */
            double dist = this.c.c.getBlockReachDistance() + 1;
            dist *= dist;

            if(var13 > dist) {
               return;
            }
            /* </Forge>-------------------------------------------------------------- */

            if(var5 >= this.d.ab()) {
               return;
            }
         }

         if(var1.e == 0) {
            if(!this.d.a(var2, var4, var5, var6, this.c)) {
               this.c.c.a(var4, var5, var6, var1.d);
            } else {
               this.c.a.b(new fp(var4, var5, var6, var2));
            }
         } else if(var1.e == 2) {
            this.c.c.a(var4, var5, var6);
            if(var2.a(var4, var5, var6) != 0) {
               this.c.a.b(new fp(var4, var5, var6, var2));
            }
         } else if(var1.e == 1) {
            this.c.c.c(var4, var5, var6);
            if(var2.a(var4, var5, var6) != 0) {
               this.c.a.b(new fp(var4, var5, var6, var2));
            }
         }

      }
   }

   public void a(fr var1) {
      iz var2 = this.d.a(this.c.ar);
      wm var3 = this.c.bL.h();
      boolean var4 = false;
      int var5 = var1.d();
      int var6 = var1.f();
      int var7 = var1.g();
      int var8 = var1.h();
      if(var1.h() == 255) {
         if(var3 == null) {
            return;
         }

         /* <Forge>--------------------------------------------------------------- */
         final boolean allowUse;
         if(HAS_FORGE) {
            allowUse = Proxy.FORGE_HELPER.allowUseItem(this.c);
         } else {
            allowUse = true;
         }
         if(allowUse) {
            this.c.c.a(this.c, var2, var3);
         }
         /* </Forge>-------------------------------------------------------------- */

      } else if(var1.f() >= this.d.ab() - 1 && (var1.h() == 1 || var1.f() >= this.d.ab())) {
         this.c.a.b(new cw("" + EnumChatFormatting.h + "Height limit for building is " + this.d.ab()));
         var4 = true;
      } else {
         // if(this.q && this.c.e((double)var5 + 0.5D, (double)var6 + 0.5D, (double)var7 + 0.5D) < 64.0D && !this.d.a(var2, var5, var6, var7, this.c)) {
         /* <Forge>--------------------------------------------------------------- */
         double dist = this.c.c.getBlockReachDistance() + 1;
         dist *= dist;
         if(this.q && this.c.e((double)var5 + 0.5D, (double)var6 + 0.5D, (double)var7 + 0.5D) < dist && !this.d.a(var2, var5, var6, var7, this.c)) {
            this.c.c.a(this.c, var2, var3, var5, var6, var7, var8, var1.j(), var1.k(), var1.l());
         }
         /* </Forge>-------------------------------------------------------------- */

         var4 = true;
      }

      if(var4) {
         this.c.a.b(new fp(var5, var6, var7, var2));
         if(var8 == 0) {
            --var6;
         }

         if(var8 == 1) {
            ++var6;
         }

         if(var8 == 2) {
            --var7;
         }

         if(var8 == 3) {
            ++var7;
         }

         if(var8 == 4) {
            --var5;
         }

         if(var8 == 5) {
            ++var5;
         }

         this.c.a.b(new fp(var5, var6, var7, var2));
      }

      var3 = this.c.bL.h();
      if(var3 != null && var3.a == 0) {
         this.c.bL.a[this.c.bL.c] = null;
         var3 = null;
      }

      if(var3 == null || var3.n() == 0) {
         this.c.h = true;
         this.c.bL.a[this.c.bL.c] = wm.b(this.c.bL.a[this.c.bL.c]);
         ul var9 = this.c.bN.a((lt)this.c.bL, this.c.bL.c);
         this.c.bN.b();
         this.c.h = false;
         if(!wm.b(this.c.bL.h(), var1.i())) {
            this.b(new dj(this.c.bN.d, var9.g, this.c.bL.h()));
         }
      }

   }

   public void a(String var1, Object[] var2) {
      this.d.al().a(this.c.bT + " lost connection: " + var1);
      this.d.ad().a((ei)(new cw(EnumChatFormatting.o + this.c.ax() + " left the game.")));
      this.d.ad().e(this.c);
      this.b = true;
      if(this.d.I() && this.c.bT.equals(this.d.H())) {
         this.d.al().a("Stopping singleplayer server as player logged out");
         this.d.n();
      }

   }

   public void a(ei var1) {
      this.d.al().b(this.getClass() + " wasn\'t prepared to deal with a " + var1.getClass());
      this.c("Protocol error, unexpected packet");
   }

   public void b(ei var1) {
      if(var1 instanceof cw) {
         cw var2 = (cw)var1;
         int var3 = this.c.t();

         /* <Console>------------------------------------------------------------- */
         String[] split = var2.b.split("////");
         final boolean isImportant;
         if(split.length == 3 && split[0].equals("\u00A7cXCOMMANDS")) {
            isImportant = true;
         } else {
            isImportant = false;
         }
         /* </Console>------------------------------------------------------------ */

         if(!isImportant) {
            if(var3 == 2) {
               return;
            }

            if(var3 == 1 && !var2.d()) {
               return;
            }
         }
      }

      try {
         this.a.a(var1);
      } catch (Throwable var5) {
         CrashReport var6 = CrashReport.a(var5, "Sending packet");
         m var4 = var6.a("Packet being sent");
         var4.a("Packet ID", (Callable)(new ji(this, var1)));
         var4.a("Packet class", (Callable)(new jj(this, var1)));
         throw new u(var6);
      }
   }

   public void a(eu var1) {
      if(var1.a >= 0 && var1.a < sn.i()) {
         this.c.bL.c = var1.a;
      } else {
         this.d.al().b(this.c.bT + " tried to set an invalid carried item");
      }
   }

   public void a(cw var1) {

      /* <Console>------------------------------------------------------------- */
      String[] split = var1.b.split("////");
      if(split.length == 3 && split[0].equals("\u00A7cXCOMMANDS")) {
         if(split[1].equals("CHECK") && split[2].equals("TRUE")) {
            clientHasXCommands = true;
            System.out.println(this.c.ax() + " has XCommands.");
            return;
         }
         System.out.println("XCommands: " + var1.b + " was unexpected.");
         return;
       }
       /* </Console>------------------------------------------------------------ */

      /* <Forge>--------------------------------------------------------------- */
      if(HAS_FORGE) {
         var1 = FMLNetworkHandler.handleChatMessage(this, var1);
      } else if(HAS_MODLOADER) {
         ModLoaderHelper.serverChat(this, var1);
      }
      /* </Forge>-------------------------------------------------------------- */

      if(this.c.t() == 2) {
         this.b(new cw("Cannot send chat message."));
      } else {
         String var2 = var1.b;
         if(var2.length() > 100) {
            this.c("Chat message too long");
         } else {
            var2 = var2.trim();

            for(int var3 = 0; var3 < var2.length(); ++var3) {
               if(!v.a(var2.charAt(var3))) {
                  this.c("Illegal characters in chat");
                  return;
               }
            }

            if(var2.startsWith("/")) {
               this.d(var2);
            } else {
               if(this.c.t() == 1) {
                  this.b(new cw("Cannot send chat message."));
                  return;
               }

               /* <Forge>--------------------------------------------------------------- */
               final String old;
               if(HAS_FORGE) {
                  old = var2;
               } else {
                  old = "";
               }
               /* </Forge>-------------------------------------------------------------- */

               var2 = "<" + this.c.ax() + "> " + var2;

               /* <Forge>--------------------------------------------------------------- */
               if(HAS_FORGE) {
                  var2 = Proxy.FORGE_HELPER.handleChat(this.c, old, var2);
                  if(var2 == null) {
                     return;
                  }
               }
               /* </Forge>-------------------------------------------------------------- */

               this.d.al().a(var2);
               this.d.ad().a((ei)(new cw(var2, false)));
            }

            this.l += 20;
            if(this.l > 200 && !this.d.ad().e(this.c.bT)) {
               this.c("disconnect.spam");
            }

         }
      }
   }

   private void d(String var1) {
      this.d.E().a(this.c, var1);
   }

   public void a(ct var1) {
      if(var1.b == 1) {
         this.c.bK();
      }

   }

   public void a(em var1) {
      if(var1.b == 1) {
         this.c.b(true);
      } else if(var1.b == 2) {
         this.c.b(false);
      } else if(var1.b == 4) {
         this.c.c(true);
      } else if(var1.b == 5) {
         this.c.c(false);
      } else if(var1.b == 3) {
         this.c.a(false, true, true);
         this.q = false;
      }

   }

   public void a(dl var1) {
      this.a.a("disconnect.quitting", new Object[0]);
   }

   public int e() {
      return this.a.e();
   }

   public void a(dr var1) {
      iz var2 = this.d.a(this.c.ar);
      mp var3 = var2.a(var1.b);
      if(var3 != null) {
         boolean var4 = this.c.n(var3);
         double var5 = 36.0D; // TODO: this looks like entity reach?
         if(!var4) {
            var5 = 9.0D;
         }

         if(this.c.e(var3) < var5) {
            if(var1.c == 0) {
               this.c.p(var3);
            } else if(var1.c == 1) {
               this.c.q(var3);
            }
         }
      }

   }

   public void a(cy var1) {
      if(var1.a == 1) {
         if(this.c.j) {
            this.c = this.d.ad().a(this.c, 0, true);
         } else if(this.c.o().L().t()) {
            if(this.d.I() && this.c.bT.equals(this.d.H())) {
               this.c.a.c("You have died. Game over, man, it\'s game over!");
               this.d.P();
            } else {
               ft var2 = new ft(this.c.bT);
               var2.b("Death in Hardcore");
               this.d.ad().e().a(var2);
               this.c.a.c("You have died. Game over, man, it\'s game over!");
            }
         } else {
            if(this.c.aX() > 0) {
               return;
            }

            /* <Forge>--------------------------------------------------------------- */
            if(HAS_FORGE) {
               this.c = this.d.ad().a(this.c, this.c.ar, false); // playerEntity.dimension
            } else {
               this.c = this.d.ad().a(this.c, 0, false);
            }
            /* </Forge>-------------------------------------------------------------- */

         }
      }

   }

   public boolean b() {
      return true;
   }

   public void a(er var1) {}

   public void a(df var1) {
      this.c.j();
   }

   public void a(de var1) {
      if(this.c.bN.d == var1.a && this.c.bN.c(this.c)) {
         wm var2 = this.c.bN.a(var1.b, var1.c, var1.f, this.c);
         if(wm.b(var1.e, var2)) {
            this.c.a.b(new dc(var1.a, var1.d, true));
            this.c.h = true;
            this.c.bN.b();
            this.c.i();
            this.c.h = false;
         } else {
            this.r.a(this.c.bN.d, Short.valueOf(var1.d));
            this.c.a.b(new dc(var1.a, var1.d, false));
            this.c.bN.a(this.c, false);
            ArrayList var3 = new ArrayList();

            for(int var4 = 0; var4 < this.c.bN.c.size(); ++var4) {
               var3.add(((ul)this.c.bN.c.get(var4)).c());
            }

            this.c.a(this.c.bN, (List)var3);
         }
      }

   }

   public void a(dd var1) {
      if(this.c.bN.d == var1.a && this.c.bN.c(this.c)) {
         this.c.bN.a((sp)this.c, var1.b);
         this.c.bN.b();
      }

   }

   public void a(ev var1) {
      if(this.c.c.d()) {
         boolean var2 = var1.a < 0;
         wm var3 = var1.b;
         boolean var4 = var1.a >= 1 && var1.a < 36 + sn.i();
         boolean var5 = var3 == null || var3.c < wk.f.length && var3.c >= 0 && wk.f[var3.c] != null;
         boolean var6 = var3 == null || var3.k() >= 0 && var3.k() >= 0 && var3.a <= 64 && var3.a > 0;
         if(var4 && var5 && var6) {
            if(var3 == null) {
               this.c.bM.a(var1.a, (wm)null);
            } else {
               this.c.bM.a(var1.a, var3);
            }

            this.c.bM.a(this.c, true);
         } else if(var2 && var5 && var6 && this.m < 200) {
            this.m += 20;
            rg var7 = this.c.c(var3);
            if(var7 != null) {
               var7.c();
            }
         }
      }

   }

   public void a(dc var1) {
      Short var2 = (Short)this.r.a(this.c.bN.d);
      if(var2 != null && var1.b == var2.shortValue() && this.c.bN.d == var1.a && !this.c.bN.c(this.c)) {
         this.c.bN.a(this.c, true);
      }

   }

   public void a(fj var1) {
      iz var2 = this.d.a(this.c.ar);
      if(var2.f(var1.a, var1.b, var1.c)) {
         aqt var3 = var2.r(var1.a, var1.b, var1.c);
         if(var3 instanceof aqq) {
            aqq var4 = (aqq)var3;
            if(!var4.a()) {
               this.d.g("Player " + this.c.bT + " just tried to change non-editable sign");
               return;
            }
         }

         int var6;
         int var8;
         for(var8 = 0; var8 < 4; ++var8) {
            boolean var5 = true;
            if(var1.d[var8].length() > 15) {
               var5 = false;
            } else {
               for(var6 = 0; var6 < var1.d[var8].length(); ++var6) {
                  if(v.a.indexOf(var1.d[var8].charAt(var6)) < 0) {
                     var5 = false;
                  }
               }
            }

            if(!var5) {
               var1.d[var8] = "!?";
            }
         }

         if(var3 instanceof aqq) {
            var8 = var1.a;
            int var9 = var1.b;
            var6 = var1.c;
            aqq var7 = (aqq)var3;
            System.arraycopy(var1.d, 0, var7.a, 0, 4);
            var7.k_();
            var2.j(var8, var9, var6);
         }
      }

   }

   public void a(ds var1) {
      if(var1.a == this.h) {
         int var2 = (int)(System.nanoTime() / 1000000L - this.i);
         this.c.i = (this.c.i * 3 + var2) / 4;
      }

   }

   public boolean a() {
      return true;
   }

   public void a(ek var1) {
      this.c.cf.b = var1.f() && this.c.cf.c;
   }

   public void a(cv var1) {
      StringBuilder var2 = new StringBuilder();

      String var4;
      for(Iterator var3 = this.d.a((ab)this.c, var1.d()).iterator(); var3.hasNext(); var2.append(var4)) {
         var4 = (String)var3.next();
         if(var2.length() > 0) {
            var2.append("\u0000");
         }
      }

      this.c.a.b(new cv(var2.toString()));
   }

   public void a(cz var1) {
      this.c.a(var1);
   }

   public void a(dk var1) {
      /* <Forge>--------------------------------------------------------------- */
      if(HAS_FORGE) {
         FMLNetworkHandler.handlePacket250Packet(var1, this.a, this);
      } else {
         handleVanilla250Packet(var1);
      }
      /* </Forge>-------------------------------------------------------------- */
   }

   public void handleVanilla250Packet(dk var1) {
      DataInputStream var2;
      wm var3;
      wm var4;
      if("MC|BEdit".equals(var1.a)) {
         try {
            var2 = new DataInputStream(new ByteArrayInputStream(var1.c));
            var3 = ei.c(var2);
            if(!xs.a(var3.q())) {
               throw new IOException("Invalid book tag!");
            }

            var4 = this.c.bL.h();
            if(var3 != null && var3.c == wk.bG.cp && var3.c == var4.c) {
               var4.a("pages", (cf)var3.q().m("pages"));
            }
         } catch (Exception var12) {
            var12.printStackTrace();
         }
      } else if("MC|BSign".equals(var1.a)) {
         try {
            var2 = new DataInputStream(new ByteArrayInputStream(var1.c));
            var3 = ei.c(var2);
            if(!xt.a(var3.q())) {
               throw new IOException("Invalid book tag!");
            }

            var4 = this.c.bL.h();
            if(var3 != null && var3.c == wk.bH.cp && var4.c == wk.bG.cp) {
               var4.a("author", (cf)(new ce("author", this.c.bT)));
               var4.a("title", (cf)(new ce("title", var3.q().i("title"))));
               var4.a("pages", (cf)var3.q().m("pages"));
               var4.c = wk.bH.cp;
            }
         } catch (Exception var11) {
            var11.printStackTrace();
         }
      } else {
         int var14;
         if("MC|TrSel".equals(var1.a)) {
            try {
               var2 = new DataInputStream(new ByteArrayInputStream(var1.c));
               var14 = var2.readInt();
               tj var15 = this.c.bN;
               if(var15 instanceof ud) {
                  ((ud)var15).e(var14);
               }
            } catch (Exception var10) {
               var10.printStackTrace();
            }
         } else {
            int var18;
            if("MC|AdvCdm".equals(var1.a)) {
               if(!this.d.Z()) {
                  this.c.a(this.c.a("advMode.notEnabled", new Object[0]));
               } else if(this.c.a(2, "") && this.c.cf.d) {
                  try {
                     var2 = new DataInputStream(new ByteArrayInputStream(var1.c));
                     var14 = var2.readInt();
                     var18 = var2.readInt();
                     int var5 = var2.readInt();
                     String var6 = ei.a(var2, 256);
                     aqt var7 = this.c.q.r(var14, var18, var5);
                     if(var7 != null && var7 instanceof aqd) {
                        ((aqd)var7).b(var6);
                        this.c.q.j(var14, var18, var5);
                        this.c.a("Command set: " + var6);
                     }
                  } catch (Exception var9) {
                     var9.printStackTrace();
                  }
               } else {
                  this.c.a(this.c.a("advMode.notAllowed", new Object[0]));
               }
            } else if("MC|Beacon".equals(var1.a)) {
               if(this.c.bN instanceof tk) {
                  try {
                     var2 = new DataInputStream(new ByteArrayInputStream(var1.c));
                     var14 = var2.readInt();
                     var18 = var2.readInt();
                     tk var17 = (tk)this.c.bN;
                     ul var19 = var17.a(0);
                     if(var19.d()) {
                        var19.a(1);
                        aqa var20 = var17.e();
                        var20.d(var14);
                        var20.e(var18);
                        var20.k_();
                     }
                  } catch (Exception var8) {
                     var8.printStackTrace();
                  }
               }
            } else if("MC|ItemName".equals(var1.a) && this.c.bN instanceof ug) {
               ug var13 = (ug)this.c.bN;
               if(var1.c != null && var1.c.length >= 1) {
                  String var16 = v.a(new String(var1.c));
                  if(var16.length() <= 30) {
                     var13.a(var16);
                  }
               } else {
                  var13.a("");
               }
            } else if(HAS_MODLOADER) {
               ModLoaderHelper.serverCustomPayload(this, var1);
            }
         }
      }

   }

   /* <Forge>--------------------------------------------------------------- */
   @Override
   public void a(db packet131MapData) {
      if(HAS_FORGE) {
         FMLNetworkHandler.handlePacket131Packet(this, packet131MapData);
      } else {
         super.a(packet131MapData);
      }
   }

   // FORGE_OVERRIDE
   public sp getPlayer() {
      return this.c;
   }
   /* </Forge>-------------------------------------------------------------- */

}
