// Generic Console Helper class
// Currently, mainly used for protected access

package net.minecraft.src;

import java.io.File;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Random;
import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.proxy.Proxy;
import com.q3hardcore.console.util.DeathPos;
import com.q3hardcore.console.util.ReflectionHelper;
import com.q3hardcore.console.wrapper.Coordinate;
import com.q3hardcore.console.wrapper.WDamageSource;
import com.q3hardcore.console.wrapper.WEntityLiving;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WStructureStart;
import com.q3hardcore.console.wrapper.TriState;
import com.q3hardcore.console.wrapper.WWorld;
import com.q3hardcore.console.wrapper.WWorldProvider;

public final class ConsoleHelper {

	private static boolean errorOccured = false;
	private static boolean didCheck = false;
	private static TriState hasConsole;
	private static TriState hasForge;
	private static TriState hasModLoader;
	private static TriState hasSPC;
	private static boolean hasNothing = false;
	private static boolean cachedWorldEditLoaded = false;

	public static void damageEntity(WEntityLiving entityLiving, WDamageSource damageSource, int damageAmount) {
		entityLiving.getRaw().d(damageSource.getMinecraftDamageSource(), damageAmount);
	}

	// OBFUSCATED REFERENCES
	public static File getSaveDirectory(aju saveHandler) {
		return saveHandler.b(); // getSaveDirectory
	}

	public static void generateLightBrightnessTable(WWorldProvider provider) {
		provider.getRaw().a();
	}

	/* <Structures>---------------------------------------------------------- */

	// aes - mineshaft

	public static agz getStructureNetherBridgeStart(WWorld world, Random rand, int x, int z) { // StructureStart
		return new aeu(world.getRaw(), rand, x, z);
	}

	// afo - biomefeature

	public static agz getStructureStrongholdStart(WWorld world, Random rand, int x, int z) { // StructureStart
		return new afx(world.getRaw(), rand, x, z);
	}

	public static agz getStructureVillageStart(WWorld world, Random rand, int x, int z, int villageType) { // StructureStart
		return new ahb(world.getRaw(), rand, x, z, villageType);
	}

	public static void updateBoundingBox(WStructureStart structureStart) {
		structureStart.getRaw().c();
	}

	/* </Structures>--------------------------------------------------------- */

	// OBFUSCATED REFERENCES
	public static String getMinecraftVersion() {
		return new c(null).a(); // CallableMinecraftVersion, minecraftVersion
	}

	// BELOW USED TO BE PROTECTED

	public static boolean hasWorldEdit() {
		try {
			Class<?> helperClass = Class.forName("com.q3hardcore.console.core.Helper");
			Method methodHasWE = helperClass.getDeclaredMethod("getHasWorldEdit");
			Object objectHasWE = methodHasWE.invoke(null);
			if(objectHasWE instanceof Boolean)
				return (Boolean)objectHasWE;
			System.out.println("Helper class invalid.");
			return false;
		} catch (Throwable t) {
			if(!errorOccured) {
				System.out.println("Failed to check for WorldEdit.");
				t.printStackTrace();
				errorOccured = true;
			}
			return false;
		}
	}

	public static boolean checkWorldEditLoaded(List<String> messages) {
		if(!hasConsole()) {
			try {
				Class<?> playerAPIClass = ReflectionHelper.getDefaultPackageClass("PlayerAPI");
				if(playerAPIClass != null) {
					messages.add("XCommands is *NOT* compatible with PlayerAPI!");
					return false;
				}
			} catch (Throwable t) {
				t.printStackTrace();
			}

			messages.add("ERROR: XCommands installed incorrectly.");
			return false;
		}

		if(!Helper.triedLoadingWorldEdit) {
			// System.out.println("Trying to load WorldEdit.");
			System.out.println("SPConsole: Loading WorldEdit.");
			cachedWorldEditLoaded = Helper.tryLoadingWorldEdit(messages);
		}

		return cachedWorldEditLoaded;
	}

	// OBFUSCATED REFERENCES
	public static boolean hasConsole() {
		if(hasNothing) {
			return false;
		}
		if(hasConsole == TriState.OFF) {
			return false;
		} else if(hasConsole == TriState.ON) {
			return true;
		}
		try {
			Class.forName("com.q3hardcore.console.core.Helper");
			jc.class.getField("ph");
			hasConsole = TriState.ON;
			return true;
		} catch (Throwable t) {
			hasConsole = TriState.OFF;
			return false;
		}
	}

	public static void checkNoclip(WPlayer player) {
		if(player.getNoclip() && !player.getCapabilities().getIsFlying()) {
         		player.setNoclip(false);
			Proxy.INSTANCE.setClientNoclip(false);
			player.sendMessage("Noclip auto-disabled. (Player not flying)");
			if(player.isClearBelow(player.getPosition())) {
				return;
			}
         		double y = player.getPosY() - 1; // in case player was standing on ground
			while (y < 260) {
            			if(player.isClear(new Coordinate(player.getPosX(), y++, player.getPosZ()))) {
					player.setPositionAndUpdate(player.getPosX() + 0.5F, y - 1, player.getPosZ() + 0.5F);
					break;
				}
			}
		}
	}

	public static void storeDeathPosition(WPlayer consolePlayer) {
		String userName = consolePlayer.getUsername();
		String worldName = consolePlayer.getWorld().getName();
		DeathPos.storePos(userName, worldName, consolePlayer.getPosition(), consolePlayer.getDimension());
		System.out.println("Stored death position for: " + userName);
	}

	// OBFUSCATED REFERENCES
	public static WPlayer instantiatePlayer(jc player) {
		try {
			return new WPlayer(player);
		} catch (Throwable t) {
			// t.printStackTrace();
			return null;
		}
	}

	public static Console instantiateConsole(WPlayer consolePlayer) {
		try {
			return new Console(consolePlayer);
		} catch (Throwable t) {
			t.printStackTrace();
			return null;
		}
	}

	public static boolean getHasForge() {
		if(hasNothing) {
			return false;
		}
		if(hasForge == TriState.OFF) {
			return false;
		} else if(hasForge == TriState.ON) {
			return true;
		}
		final String rawBranding = "Minecraft Forge";
		String versionBranding = getModVersion("net.minecraftforge.common.MinecraftForge", "getBrandingVersion");
		if(versionBranding != null) {
			System.out.println("SPConsole: " + versionBranding + " installed.");
			hasForge = TriState.ON;
			return true;
		} else {
			System.out.println("SPConsole: " + rawBranding + " not installed.");
			hasForge = TriState.OFF;
			return false;
		}
	}

	public static boolean getHasModLoader() {
		if(hasNothing) {
			return false;
		}
		if(hasModLoader == TriState.OFF) {
			return false;
		} else if(hasModLoader == TriState.ON) {
			return true;
		}
		final String rawBranding = "ModLoader";
		Class<?> mlClass = ReflectionHelper.getDefaultPackageClass("ModLoader");
		if(mlClass == null) {
			System.out.println("SPConsole: " + rawBranding + " not installed.");
			hasModLoader = TriState.OFF;
			return false;
		} else {
			String versionBranding = rawBranding;
			try {
				versionBranding = mlClass.getField("VERSION").get(null).toString();
			} catch (Throwable t) {
				System.out.println("SPConsole: FML installed."); // "Fake Mod Loader" ;)
				hasModLoader = TriState.OFF;
				return false;
			}
			System.out.println("SPConsole: " + versionBranding + " installed.");
			hasModLoader = TriState.ON;
			return true;
		}
	}

	public static boolean getHasSPC() {
		if(hasNothing) {
			return false;
		}
		if(hasSPC == TriState.OFF) {
			return false;
		} else if(hasSPC == TriState.ON) {
			return true;
		}
		final String rawBranding = "SinglePlayerCommands";
		String version = ConsoleHelper.getModVersion("com.sijobe.spc.core.Constants", "getVersion");
		if(version != null) {
			System.out.println("SPConsole: " + rawBranding + " " + version + " installed.");
			hasSPC = TriState.ON;
			return true;
		} else {
			System.out.println("SPConsole: " + rawBranding + " not installed.");
			hasSPC = TriState.OFF;
			return false;
		}
	}

	public static boolean isPlayerNonCreativeClient(WPlayer player) {
		boolean result;
		try {
			result = !player.getCapabilities().getIsCreativeMode(); // isCreativeMode
		} catch (Throwable t) {
			result = false;
		}
		return result;
	}

	public static String getModVersion(String className, String methodName) {
		try {
			Class<?> clazz = Class.forName(className);
			return clazz.getDeclaredMethod(methodName).invoke(null).toString();
		} catch (Exception e) {
			return null;
		}
	}

	static {
		try {
			hasConsole = TriState.UNDEFINED;
			hasForge = TriState.UNDEFINED;
			hasModLoader = TriState.UNDEFINED;
			hasSPC = TriState.UNDEFINED;
		} catch (Throwable t) {
			hasNothing = true;
			t.printStackTrace();
		}
	}

}