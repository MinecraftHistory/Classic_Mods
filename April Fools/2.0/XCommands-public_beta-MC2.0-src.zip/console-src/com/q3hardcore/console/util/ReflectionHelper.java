package com.q3hardcore.console.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Helper class for reflection
 *
 * @author q3hardcore
 * @version 1.3
 */
public class ReflectionHelper {

	private static final String blacklistedClass = "java.lang.Object";

	public static Field getFinalField(String[] fieldNames, Class<?> clazz) {
		Field field = internalGetField(fieldNames, clazz);
		if(field == null) {
			System.err.println(clazz.getName() + " does not have field " + fieldNames[0]);
			return null; 
		} else {
			try {
				Field modifiers = Field.class.getDeclaredField("modifiers");
				modifiers.setAccessible(true);

				modifiers.setInt(field, field.getModifiers() & 0xFFFFFFEF);
				field.setAccessible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return field;
		}
	}

	public static Method getPublicMethodWithParamsLength(Class<?> clazz, String name, int length) {
		if(clazz == null) {
			System.err.println("No class specified.");
			return null;
		}
		try {
			Method[] methods = clazz.getMethods();
			for(Method method : methods) {
				boolean correctName = method.getName().equals(name);
				if(correctName && method.getParameterTypes().length == length) {
					return method;
				}
			}
		} catch (Throwable t) {
			t.printStackTrace();
		}
		System.err.println(clazz.getName() + " does not have method " + name);
		return null;
	}

	public static Class<?> getBaseClass(Class<?> clazz) {
		if(clazz == null) {
			System.err.println("No class specified.");
			return null;
		}
		Class<?> baseClass;
		while((baseClass = clazz.getSuperclass()) != null && !baseClass.getName().equals(blacklistedClass)) {
			clazz = baseClass;
		}
		return clazz;
	}

	public static Class<?> getDefaultPackageClass(String className) {
		if(className == null) {
			System.err.println("No class name specified.");
			return null;
		}
		return getClass(new String[]{className, "net.minecraft.src." + className});
	}

	public static Class<?> getClass(String[] classNames) {
		if(classNames == null || classNames.length < 1) {
			System.err.println("No class name(s) specified.");
			return null;
		}
		Class<?> clazz = null;
		for(String className : classNames) {
			try {
				clazz = Class.forName(className);
			} catch (ClassNotFoundException cnfe) {
				continue;
			} catch (Throwable t) {
				t.printStackTrace();
				continue;
			}
		}
		if(clazz == null) {
			// System.err.println(classNames[0] + " could not be found.");
			return null; 
		} else {
			return clazz;
		}
	}

	public static boolean getBoolean(Field field, Object instance) {
		if(field == null) {
			System.err.println("Null field");
			return false;
		}
		try {
			return field.getBoolean(instance);
		} catch (Exception e) {
			System.err.println(field.getType() + " not assignable from " + Boolean.TYPE);
			return false;
		}
	}

	public static double getDouble(Field field, Object instance) {
		if(field == null) {
			System.err.println("Null field");
			return -1.0D;
		}
		try {
			return field.getDouble(instance);
		} catch (Exception e) {
			System.err.println(field.getType() + " not assignable from " + Double.TYPE);
			return -1.0D;
		}
	}

	public static int getInt(Field field, Object instance) {
		if(field == null) {
			System.err.println("Null field");
			return -1;
		}
		try {
			return field.getInt(instance);
		} catch (Exception e) {
			System.err.println(field.getType() + " not assignable from " + Integer.TYPE);
			return -1;
		}
	}

	public static String getString(Field field, Object instance) {
		if(field == null) {
			System.err.println("Null field");
			return "";
		}
		try {
			return field.get(instance).toString();
		} catch (Exception e) {
			System.err.println(field.getType() + " not convertable to String");
			return "";
		}
	}

	public static boolean setField(Field field, Object instance, Object value) {
		if(field == null) {
			System.err.println("Null field");
			return false;
		}
		try {
			field.set(instance, value);
		} catch (Exception e) {
			System.err.println(field.getType() + " not assignable from " + value.getClass());
			return false;
		}
		return true;
	}

	public static Field getField(String[] fieldNames, Class<?> clazz) {
		Field field = internalGetField(fieldNames, clazz);
		if(field == null) {
			System.err.println(clazz.getName() + " does not have field " + fieldNames[0]);
			return null; 
		} else {
			try {
				field.setAccessible(true);
			} catch (SecurityException se) {}
			return field;
		}
	}

	public static Field getField(String[] fieldNames, Object instance) {
		if(instance != null) {
			return getField(fieldNames, instance.getClass());
		} else {
			return null;
		}
	}

	private static Field internalGetField(String[] fieldNames, Class<?> clazz) {
		if(clazz == null) {
			System.err.println("No class specified.");
			return null;
		}
		if(fieldNames == null || fieldNames.length < 1) {
			System.err.println("No field name(s) specified.");
			return null;
		}
		Field field = null;
		for(String fieldName : fieldNames) {
			try {
				field = clazz.getDeclaredField(fieldName);
				break;
			} catch (NoSuchFieldException nsfe) {
				continue;
			}
		}
		return field;
	}

}