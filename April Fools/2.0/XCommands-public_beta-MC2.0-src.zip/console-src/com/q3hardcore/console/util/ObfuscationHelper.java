package com.q3hardcore.console.util;

import com.q3hardcore.console.wrapper.WAxisAlignedBB;
import com.q3hardcore.console.wrapper.WCommandBase;
import com.q3hardcore.console.wrapper.WEntity;
import com.q3hardcore.console.wrapper.WICommandSender;
import com.q3hardcore.console.wrapper.WMathHelper;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WWorld;
// import com.q3hardcore.console.wrapper.lists.LCommand;
import com.q3hardcore.console.wrapper.lists.LEntities;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.src.ax; // CommandException1
import net.minecraft.src.as; // CommandException2

import net.minecraft.src.mp; // Entity
import net.minecraft.src.rg; // EntityItem

import net.minecraft.src.iz; // WorldServer
import net.minecraft.src.lp; // WeightedRandomChestContent

import net.minecraft.src.akg; // ISaveHandler
import net.minecraft.src.aju; // SaveHandler

import net.minecraft.src.aap; // Teleporter

import net.minecraft.src.ConsoleHelper;

import org.lwjgl.input.Keyboard;

public final class ObfuscationHelper {

	public static void handleMinecraftCommand(WCommandBase command, WPlayer player, String[] split) {
		String[] args = new String[split.length-1];

		for(int i = 1; i < split.length; i++) {
			args[i-1] = split[i];
		}

		WICommandSender sender = player.getSender();

		try {
			command.getRaw().b(player.getMinecraftPlayer(), args); // processCommand
		} catch (ax e) { // WrongUsageException
			Object[] error = new Object[]{sender.translateString(e.getMessage(), e.a())};
			sender.sendChatToPlayer("\u00a7c" + sender.translateString("commands.generic.usage", error)); // getErrorObjects
		} catch (as e) { // CommandException
			sender.sendChatToPlayer("\u00a7c" + sender.translateString(e.getMessage(), e.a())); // getErrorObjects
		} catch (Throwable t) {
			sender.sendChatToPlayer("\u00a7c" + sender.translateString("commands.generic.exception", new Object[0]));
         		t.printStackTrace();
		}	
	}

	@SuppressWarnings("unchecked")
	public static List<WEntity> getEntitiesWithinAABBExcludingEntity(WWorld world, WEntity excludedEntity, WAxisAlignedBB boundingBox) {
		mp rawExcludedEntity;
		if(excludedEntity == null) {
			rawExcludedEntity = null;
		} else {
			rawExcludedEntity = excludedEntity.getRawEntity();
		}
		List<WEntity> list = new ArrayList<WEntity>();
		List<mp> entities = world.getRaw().b(rawExcludedEntity, boundingBox.getRaw());
		for(mp entity : entities) {
			list.add(new WEntity(entity));
		}
		return list;
	}

	public static void removeItemDrops(WPlayer player, int radius) {
		List<?> nearbyEntities = player.getWorld().getRaw().b(player.getMinecraftPlayer(),
			WAxisAlignedBB.getBoundingBoxRaw(player.getPosX() - (double)radius, player.getPosY() - (double)radius, player.getPosZ() - (double)radius,
			player.getPosX() + (double)radius, player.getPosY() + (double)radius, player.getPosZ() + (double)radius));
		// world.b is mc.theWorld.getEntitiesWithinAABBExcludingEntity, AxisAlignedBB.getBoundingBox(), ep.t is ep.posX, ep.u is ep.posY, ep.v is ep.posZ 
		for(int entityIndex = 0; entityIndex < nearbyEntities.size(); entityIndex++) {
			mp entity = (mp)nearbyEntities.get(entityIndex); // Entity
			if(entity instanceof rg) { // if (entity instanceof EntityItem)
				rg entityItem = (rg)entity;
				if(entityItem.b >= 0) { // entityItem.age
					player.getWorld().getRaw().e(entityItem); // mc.theWorld.setEntityDead
				}
			}
		}
	}

	public static lp[] getBonusChestContent() {
		try {
			Field[] fields = iz.class.getDeclaredFields();
			Field field = null;
			for(Field tempField : fields) {
				if(tempField.getType() == lp[].class) {
					field = tempField;
					break;
				}
			}
			if(field == null) {
				System.err.println("SPConsole: Couldn't get bonus chest content.");
				return new lp[0];
			} else {
				field.setAccessible(true);
				Object fieldValue = field.get(null);
				return (lp[])fieldValue;
			}
		} catch (Exception e) {
			return null;
		}
	}

	public static File getWorldDir(WWorld world) {
		akg sh = world.getRaw().K(); // ISaveHandler, getSaveHandler
		return sh instanceof aju?ConsoleHelper.getSaveDirectory((aju)sh):new File("");
		// return sh instanceof agt?((agt)sh).b():new File(""); // SaveHandler, getSaveDirectory
	}

	public static void createPortal(WPlayer player) {
		new aap(player.getMinecraftPlayer().o()).a(player.getMinecraftPlayer()); // New Teleporter, createPortal, theWorld, thePlayer
	}

	public static void createEndPortal(WPlayer player) {
		int x = WMathHelper.floor_double(player.getPosX()); // ep.posX
		int z = WMathHelper.floor_double(player.getPosZ()); // ep.posZ
		WEntity entityDragon = new LEntities.Dragon(player.getWorld()); // EntityDragon
		Class<?> entityDragonClass = entityDragon.getRawEntity().getClass();
		Method[] methods = entityDragonClass.getDeclaredMethods();
		for(Method method : methods) {
			final Class<?>[] parameters = method.getParameterTypes();
			if(parameters.length == 2 && method.getReturnType() == void.class) {
				if(parameters[0] == int.class && parameters[1] == int.class) {
					try {
						method.setAccessible(true);
						method.invoke(entityDragon.getRawEntity(), new Object[]{x, z});
						return;
					} catch (Throwable t) {
						t.printStackTrace();
					}
				}
			}
		}
		player.sendError("Couldn't find end portal code.");
	}

}