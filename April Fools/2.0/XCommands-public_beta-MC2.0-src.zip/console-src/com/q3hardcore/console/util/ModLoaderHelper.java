package com.q3hardcore.console.util;

import java.lang.reflect.Method;

public final class ModLoaderHelper {

	private static Method serverChatMethod;
	private static Method serverCustomPayloadMethod;

	public static void serverChat(Object serverHandler, Object msg) {
		try {
			if(serverChatMethod != null) {
				serverChatMethod.invoke(null, new Object[]{serverHandler, msg});
				return;
			}
			Class<?> mlClass = ReflectionHelper.getDefaultPackageClass("ModLoader");
			for(Method method : mlClass.getMethods()) {
				if(method.getName().equals("serverChat")) {
					method.invoke(null, new Object[]{serverHandler, msg});
					serverChatMethod = method;
					return;
				}
			}
			System.out.println("SPConsole/ML: Unable to find serverChat method.");
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public static void serverCustomPayload(Object serverHandler, Object packet250) {
		try {
			if(serverCustomPayloadMethod != null) {
				serverCustomPayloadMethod.invoke(null, new Object[]{serverHandler, packet250});
				return;
			}
			Class<?> mlClass = ReflectionHelper.getDefaultPackageClass("ModLoader");
			for(Method method : mlClass.getMethods()) {
				if(method.getName().equals("serverCustomPayload")) {
					method.invoke(null, new Object[]{serverHandler, packet250});
					serverCustomPayloadMethod = method;
					return;
				}
			}
			System.out.println("SPConsole/ML: Unable to find serverCustomPayload method.");
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

}