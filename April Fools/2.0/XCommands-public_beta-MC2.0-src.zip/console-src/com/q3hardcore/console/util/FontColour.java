// From SinglePlayerCommands by simo_415

// Obfuscated references: 0

package com.q3hardcore.console.util;

public enum FontColour {
	BLACK("\u00A70"), 
	DARK_BLUE("\u00A71"), 
	DARK_GREEN("\u00A72"), 
	DARK_AQUA("\u00A73"), 
	DARK_RED("\u00A74"), 
	PURPLE("\u00A75"), 
	ORANGE("\u00A76"), 
	GREY("\u00A77"), 
	DARK_GREY("\u00A78"), 
	BLUE("\u00A79"), 
	GREEN("\u00A7a"), 
	AQUA("\u00A7b"), 
	RED("\u00A7c"), 
	PINK("\u00A7d"), 
	YELLOW("\u00A7e"), 
	WHITE("\u00A7f");

	private final String value;

	private FontColour(String value) {
		this.value = value;
	}

	public String toString() {
		return value;
	}
}