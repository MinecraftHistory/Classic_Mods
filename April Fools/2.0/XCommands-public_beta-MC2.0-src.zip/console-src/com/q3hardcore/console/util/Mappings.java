package com.q3hardcore.console.util;

import java.util.HashMap;

/**
 * Class for storing obfuscation mappings
 *
 * @author q3hardcore
 * @version 1.2
 */
public class Mappings extends HashMap<String, String[]> {

	private static final long serialVersionUID = 9008970713661354514L;

	@Override
	public String[] put(String mcpName, String[] alternateMappings) {
		return super.put(mcpName, makeMapping(mcpName, alternateMappings));
	}

	public String[] superPut(String key, String[] value) {
		return super.put(key, value);
	}

	private String[] makeMapping(String mcpName, String[] mappings) {
		String[] newMappings = new String[mappings.length + 1];
		newMappings[0] = mcpName;
		for(int i = 0; i < mappings.length; i++) {
			newMappings[i+1] = mappings[i];
		}
		return newMappings;
	} 

}