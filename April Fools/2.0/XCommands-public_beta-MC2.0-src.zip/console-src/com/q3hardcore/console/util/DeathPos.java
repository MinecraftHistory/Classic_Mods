package com.q3hardcore.console.util;

// Obfuscated references: 0

import com.q3hardcore.console.wrapper.Coordinate;
import java.util.AbstractMap.SimpleImmutableEntry;
import java.util.HashMap;

public final class DeathPos {

	private static HashMap<SimpleImmutableEntry<String, String>, SimpleImmutableEntry<Coordinate, Integer>> deathPositions =
		new HashMap<SimpleImmutableEntry<String, String>, SimpleImmutableEntry<Coordinate, Integer>>();

	public static boolean storePos(String name, String worldName, Coordinate pos, int dimension) {
		boolean alreadyStored = false;
		if(deathPositions.containsKey(name)) {
			alreadyStored = true;
		}
		deathPositions.put(new SimpleImmutableEntry<String, String>(name, worldName), new SimpleImmutableEntry<Coordinate, Integer>(pos, dimension));
		return alreadyStored;
	}

	public static SimpleImmutableEntry<Coordinate, Integer> getPos(String name, String worldName) {
		SimpleImmutableEntry<String, String> key = new SimpleImmutableEntry<String, String>(name, worldName);
		if(!deathPositions.containsKey(key)) {
			return new SimpleImmutableEntry<Coordinate, Integer>(new Coordinate(-1.0D, -1.0D, -1.0D), 0);
		} else {
			return deathPositions.get(key);
		}
	}

	public static HashMap<SimpleImmutableEntry<String, String>, SimpleImmutableEntry<Coordinate, Integer>> getDeathPositions() {
		return deathPositions;
	}
}