package com.q3hardcore.console.wrapper;

import net.minecraft.server.MinecraftServer;

public class WMinecraftServer {

	private final MinecraftServer server;

	private WMinecraftServer(MinecraftServer server) {
		this.server = server;
	}

	public static WMinecraftServer getServer() {
		// return net.minecraft.server.MinecraftServer.D();
		MinecraftServer serverInstance = MinecraftServer.D();
		if(serverInstance == null) {
			return null;
		} else {
			return new WMinecraftServer(serverInstance);
		}
	}

	public String getVersion() {
		return server.x();
	}

	public WCommandHandler getCommandHandler() {
		return new WCommandHandler(server.E());
	}

	public String getServerOwner() {
		return server.H();
	}

	public boolean isSinglePlayer() {
		return server.I();
	}

	public String getFirstPlayerName() throws Exception {
		// return server.H();
		java.util.List<WPlayer> players = getConfigurationManager().getPlayerEntityList();
		if(players.size() >= 1) {
			return players.get(0).getSenderName();
		} else {
			throw new Exception("No players!");
		}
	}

	public WServerConfigurationManager getConfigurationManager() {
		return new WServerConfigurationManager(server.ad());
	}

	public boolean isValid() {
		return server != null;
	}

	@Deprecated
	public MinecraftServer getRaw() {
		return server;
	}

}