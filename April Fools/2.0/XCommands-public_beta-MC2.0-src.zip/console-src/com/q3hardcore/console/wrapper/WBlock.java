package com.q3hardcore.console.wrapper;

import net.minecraft.src.apd; // Block

public final class WBlock {

	private apd block; // Block
	public static final apd[] blocksList = apd.r; // Block[], Block.blocksList

	public WBlock(apd block) {
		this.block = block;
	}

	public int getBlockID() {
		return block.cE; // blockID
	}

	public String getBlockName() {
		return block.a(); // getBlockName
	}

	public void dropBlockAsItemWithChance(WWorld world, int x, int y, int z, int metadata, float dropChance, int bonusChance) {
		block.a(world.getRaw(), x, y, z, metadata, dropChance, bonusChance);
	}

	public String translateBlockName() {
		return block.A();
	}

	public apd getRaw() {
		return block;
	}

	private static int checkHardcodedBlockIDs(String block) {

		if(block.equals("waterMoving")) {
			return 8;
		}

		if(block.equals("waterStill")) {
			return 9;
		}

		if(block.equals("lavaMoving")) {
			return 10;
		}

		if(block.equals("lavaStill")) {
			return 11;
		}

		if(block.equals("mushroomBrown")) {
			return 39;
		}

		if(block.equals("mushroomRed")) {
			return 40;
		}

		if(block.equals("0")) {
			return 0; // air
		}

		return -1;

	}

	public static int getBlockID(String block) {

		int blockId = checkHardcodedBlockIDs(block);

		if(blockId != -1) {
			return blockId;
		}

		try {
			blockId = Integer.parseInt(block);
		} catch (Exception e) {
			blockId = -1; // Just in case
		}

		if(block.equalsIgnoreCase("air")) {
			return 0;
		} else {
	 		for(int i = 0; i < blocksList.length; i++) {
				if(blocksList[i] != null) {
					WBlock tempBlock = new WBlock(blocksList[i]);
					if(blockId == -1) {
						String curName = tempBlock.getBlockName(); // getBlockName
						if(curName == null) { // If the block has no name
							continue;
						}
						curName = curName.substring(curName.indexOf(46) + 1);
						if(block.equalsIgnoreCase(curName)) {
							// Found block with correct name
							return i;
						}
					} else {
						if(tempBlock.getBlockID() == blockId) { // blocksList[i].blockID
							// Found block with correct id
							// System.out.println("ID found.");
							return i;
						}
					}

				}
			}

			// sendDebug("Block not found..");
			// Couldn't find block
			// System.out.println("Failed to resolve Block ID.");
			return -1;
		}
	}

	public boolean isValid() {
		return block != null;
	}

}
