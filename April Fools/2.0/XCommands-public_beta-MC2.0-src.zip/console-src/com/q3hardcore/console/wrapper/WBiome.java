package com.q3hardcore.console.wrapper;

import net.minecraft.src.aaw; // BiomeGenBase

public final class WBiome {

	private aaw biome; // Biome
	private static WBiome[] cachedBiomeList;

	public WBiome(aaw biome) {
		this.biome = biome;
	}

	public int getBiomeID() {
		return biome.N;
	}

	public String getBiomeName() {
		return biome.y;
	}

	public aaw getBiomeGenBase() {
		return biome;
	}

	public static WBiome[] getBiomeList() {
		if(cachedBiomeList == null || cachedBiomeList.length != aaw.a.length) {
			System.out.println("SPConsole: Getting biome list");
			final aaw[] obfList = aaw.a;
			WBiome[] biomeList = new WBiome[obfList.length];
			for(int i = 0; i < obfList.length; i++) {
				if(obfList[i] == null) {
					biomeList[i] = null;
				} else {
					biomeList[i] = new WBiome(obfList[i]);
				}
			}
			cachedBiomeList = biomeList;
		}
		return cachedBiomeList;
	}

}
