package com.q3hardcore.console.wrapper;

import net.minecraft.src.v;

public final class WChatAllowedCharacters {

	public static String getAllowedCharacters() {
		return v.a; // allowedCharacters is final
	}

	public static boolean isAllowedCharacter(char character) {
		return v.a(character);
	}

	public static String filterAllowedCharacters(String string) {
		return v.a(string);
	}

}