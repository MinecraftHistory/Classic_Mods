package com.q3hardcore.console.wrapper.lists;

import com.q3hardcore.console.wrapper.WEntity;
import com.q3hardcore.console.wrapper.WItemStack;
import com.q3hardcore.console.wrapper.WWorld;
import net.minecraft.src.qw; // EntityDragon
import net.minecraft.src.rd; // EntityLightningBolt
import net.minecraft.src.rg; // EntityItem

public final class LEntities {

	public static class Dragon extends WEntity {
		public Dragon(WWorld world) {
			super(new qw(world.getRaw()));
		}
	}

	public static class LightningBolt extends WEntity {
		public LightningBolt(WWorld world, double x, double y, double z) {
			super(new rd(world.getRaw(), x, y, z));
		}
	}

	public static class Item extends WEntity {
		public Item(WWorld world, double x, double y, double z, WItemStack stack) {
			super(new rg(world.getRaw(), x, y, z, stack.getRaw()));
		}
	}

}