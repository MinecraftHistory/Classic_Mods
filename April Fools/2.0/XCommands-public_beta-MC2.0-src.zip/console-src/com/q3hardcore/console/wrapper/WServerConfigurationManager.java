package com.q3hardcore.console.wrapper;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.src.cw; // Packet3Chat
import net.minecraft.src.gu;

public class WServerConfigurationManager {

	private final gu configurationManager;

	public WServerConfigurationManager(gu configurationManager) {
		this.configurationManager = configurationManager;
	}

	public List<WPlayer> getPlayerEntityList() {
		List<WPlayer> newList = new ArrayList<WPlayer>();
		for(Object player : configurationManager.a) {
			try {
				newList.add((WPlayer)WPlayer.class.getConstructors()[0].newInstance(player));
			} catch (Exception e) {
				System.err.println("SPConsole: couldn't get player from server list");
				continue;
			}
		}
		return newList;
	}

	public WPlayer getPlayerForUsername(String username) {
		WPlayer player = new WPlayer(configurationManager.f(username));
		if(!player.isValid()) {
			return null;
		} else {
			return player;
		}
	}

	public void sendChatMsg(String msg) {
		configurationManager.k(msg);
	}

	public void sendChatToAllPlayers(String msg) {
		configurationManager.a(new cw(msg));
	}

}