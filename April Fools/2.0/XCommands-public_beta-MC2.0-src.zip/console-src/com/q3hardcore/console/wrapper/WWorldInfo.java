package com.q3hardcore.console.wrapper;

import net.minecraft.src.ajw;

public class WWorldInfo {

	private ajw worldInfo;

	public WWorldInfo(ajw worldInfo) {
		this.worldInfo = worldInfo;
	}

	public WWorldType getTerrainType() {
		return new WWorldType(worldInfo.u());
	}

	public boolean areCommandsAllowed() {
		return worldInfo.v();
	}

	public boolean isHardcore() {
		return worldInfo.t();
	}

	public String getWorldName() {
		return worldInfo.k();
	}

	public long getWorldTime() {
		return worldInfo.g();
	}

	public void setWorldTime(long time) {
		worldInfo.c(time);
	}

	public Coordinate getSpawn() {
		return new Coordinate(getSpawnX(), getSpawnY(), getSpawnZ());
	}

	public int getSpawnX() {
		return worldInfo.c();
	}

	public int getSpawnY() {
		return worldInfo.d();
	}

	public int getSpawnZ() {
		return worldInfo.e();
	}

	public boolean isThundering() {
		return worldInfo.n();
	}

	public boolean isRaining() {
		return worldInfo.p();
	}

	public void setThundering(boolean value) {
		worldInfo.a(value);
	}

	public void setRaining(boolean value) {
		worldInfo.b(value);
	}

	public void setSpawn(Coordinate position) {
		setSpawnPosition(position.getBlockX(), position.getBlockY(), position.getBlockZ());
	}

	public void setSpawnPosition(int x, int y, int z) {
		worldInfo.a(x, y, z);
	}

	public WNBTTagCompound getNBTTagCompound() {
		return new WNBTTagCompound(worldInfo.a());
	}

	public ajw getRaw() {
		return worldInfo;
	}

	public static WWorldInfo instantiate(WNBTTagCompound nbttagcompound) {
		return new WWorldInfo(new ajw(nbttagcompound.getRaw()));
	}

}