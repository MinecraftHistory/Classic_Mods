package com.q3hardcore.console.wrapper.raw;

import com.q3hardcore.console.wrapper.WBlock;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import net.minecraft.src.aqn; // TileEntityMobSpawner
import net.minecraft.src.aqc; // TileEntityChest
import net.minecraft.src.aig; // Material
import net.minecraft.src.wm; // ItemStack
import net.minecraft.src.wk; // Item
import net.minecraft.src.aac; // World
import net.minecraft.src.apd; // Block
import net.minecraft.src.adk; // WorldGenerator

public final class RWorldGenDungeons extends adk {

   @Override
   public boolean a(aac world, Random rand, int x, int y, int z) {
      byte var6 = 3;
      int var7 = rand.nextInt(2) + 2;
      int var8 = rand.nextInt(2) + 2;
      int var9 = 0;

      int var10;
      int var11;
      int var12;
      for(var10 = x - var7 - 1; var10 <= x + var7 + 1; var10++) {
         for(var11 = y - 1; var11 <= y + var6 + 1; var11++) {
            for(var12 = z - var8 - 1; var12 <= z + var8 + 1; var12++) {
               aig var13 = world.g(var10, var11, var12);
               if(var11 == y - 1 && !var13.a()) {
                  world.f(var10, var11, var12, WBlock.getBlockID("lightgem"), 0, 2);
                  // return false;
               }

               if(var11 == y + var6 + 1 && !var13.a()) {
                  world.f(var10, var11, var12, WBlock.getBlockID("quartzBlock"), 0, 2);
                  // return false;
               }

               if((var10 == x - var7 - 1 || var10 == x + var7 + 1 || var12 == z - var8 - 1 || var12 == z + var8 + 1)
               && var11 == y && world.c(var10, var11, var12) && world.c(var10, var11 + 1, var12)) {
                  var9++;
               }
            }
         }
      }

      if(true) { /* var9 >= 1 && var9 <= 5 */
         for(var10 = x - var7 - 1; var10 <= x + var7 + 1; var10++) {
            for(var11 = y + var6; var11 >= y - 1; --var11) {
               for(var12 = z - var8 - 1; var12 <= z + var8 + 1; var12++) {
                  if(var10 != x - var7 - 1 && var11 != y - 1 && var12 != z - var8 - 1
                  && var10 != x + var7 + 1 && var11 != y + var6 + 1 && var12 != z + var8 + 1) {
                     world.i(var10, var11, var12);
                  // } else if(var11 >= 0 && !world.g(var10, var11 - 1, var12).a()) {
                     // world.i(var10, var11, var12);
                  } else { /* if(world.g(var10, var11, var12).a()) */
                     if(var11 == y - 1 && rand.nextInt(4) != 0) {
                        world.f(var10, var11, var12, apd.as.cE, 0, 2);
                     } else {
                        world.f(var10, var11, var12, apd.A.cE, 0, 2);
                     }
                  }
               }
            }
         }

         var10 = 0;

         while(var10 < 2) {
            var11 = 0;

            while(true) {
               if(var11 < 3) {
                  label210: {
                     var12 = x + rand.nextInt(var7 * 2 + 1) - var7;
                     int var14 = z + rand.nextInt(var8 * 2 + 1) - var8;
                     if(world.c(var12, y, var14)) {
                        int var15 = 0;
                        if(world.g(var12 - 1, y, var14).a()) {
                           var15++;
                        }

                        if(world.g(var12 + 1, y, var14).a()) {
                           var15++;
                        }

                        if(world.g(var12, y, var14 - 1).a()) {
                           var15++;
                        }

                        if(world.g(var12, y, var14 + 1).a()) {
                           var15++;
                        }

                        if(var15 == 1) {
                           world.f(var12, y, var14, apd.ay.cE, 0, 2);
                           aqc var16 = (aqc)world.r(var12, y, var14);
                           if(var16 != null) {
                              for(int var17 = 0; var17 < 8; var17++) {
                                 wm var18 = this.pickCheckLootItem(rand);
                                 if(var18 != null) {
                                    var16.a(rand.nextInt(var16.j_()), var18);
                                 }
                              }
                           }
                           break label210;
                        }
                     }

                     var11++;
                     continue;
                  }
               }

               var10++;
               break;
            }
         }

         world.f(x, y, z, apd.aw.cE, 0, 2);
         aqn var19 = (aqn)world.r(x, y, z);
         if(var19 != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            if(calendar.get(2) + 1 == 12 && calendar.get(5) == 24) {
               var19.a().a("SnowMan");
            } else {
               var19.a().a(this.pickMobSpawner(rand));
            }
         } else {
            System.err.println("Failed to fetch mob spawner entity at (" + x + ", " + y + ", " + z + ")");
         }

         return true;
      } else {
         return false;
      }
   }

   private wm pickCheckLootItem(Random rand) {
      int i = rand.nextInt(12);
      if (i == 0) return new wm(wk.aB);
      if (i == 1) return new wm(wk.p, rand.nextInt(4) + 1);
      if (i == 2) return new wm(wk.V);
      if (i == 3) return new wm(wk.U, rand.nextInt(4) + 1);
      if (i == 4) return new wm(wk.N, rand.nextInt(4) + 1);
      if (i == 5) return new wm(wk.L, rand.nextInt(4) + 1);
      if (i == 6) return new wm(wk.ax);
      if ((i == 7) && (rand.nextInt(100) == 0)) return new wm(wk.au);
      if ((i == 8) && (rand.nextInt(2) == 0)) return new wm(wk.aD, rand.nextInt(4) + 1);
      if ((i == 9) && (rand.nextInt(10) == 0)) return new wm(wk.f[(wk.cd.cp + rand.nextInt(2))]);
      if (i == 10) return new wm(wk.aX, 1, 3);
      if (i == 11) return wk.bX.a(rand);

      return null;
   }
   private String pickMobSpawner(Random rand) {
      int i = rand.nextInt(4);
      if (i == 0) return "Skeleton";
      if (i == 1) return "Zombie";
      if (i == 2) return "Zombie";
      if (i == 3) return "Spider";
      return "";
   }
}
