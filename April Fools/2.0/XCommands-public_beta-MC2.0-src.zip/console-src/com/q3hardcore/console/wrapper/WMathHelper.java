package com.q3hardcore.console.wrapper;

import net.minecraft.src.kx;

public class WMathHelper {

	public static int floor_double(double num) {
		return kx.c(num);
	}

}