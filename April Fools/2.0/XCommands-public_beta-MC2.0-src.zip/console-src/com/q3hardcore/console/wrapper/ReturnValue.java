package com.q3hardcore.console.wrapper;

// for possible future use

public final class ReturnValue {

	public static final String FALSE = "false";
	public static final String TRUE = "true";
	public static final String VOID = "void";

	private final Object object;
	private Object helper;

	public ReturnValue(final Object object) {
		this.object = object;
	}

	public String getString() {
		return object.toString();
	}

	// returned false
	public boolean isFalse() {
		return getString().equalsIgnoreCase(FALSE);
	}

	// returned true
	public boolean isTrue() {
		return getString().equalsIgnoreCase(TRUE);
	}

	// returned
	public boolean isVoid() {
		return getString().equalsIgnoreCase(VOID);
	}

	// returned integer
	public int getInt() {
		try {
			return Integer.parseInt(getString());
		} catch (NumberFormatException nfe) {
			System.out.println(getString() + " is not an integer.");
			return -1;
		}
	}

	public Object getValue() {
		return object;
	}

	public Object getHelper() {
		return helper;
	}

	public void setHelper(final Object helper) {
		this.helper = helper;
	}

}