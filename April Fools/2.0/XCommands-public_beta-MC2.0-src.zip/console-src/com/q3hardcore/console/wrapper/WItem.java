package com.q3hardcore.console.wrapper;

import java.util.HashMap;
import net.minecraft.src.wk; // Item

public class WItem {

	private wk item; // Item
	public static final wk[] itemsList = wk.f; // Item[], Item.itemsList
	private static final HashMap<Integer, String> hardcodedIDs;

	public WItem(wk item) {
		this.item = item;
	}

	public int getItemID() {
		return item.cp; // shiftedIndex
	}

	public String getItemName() {
		return item.a();
	}

	public wk getRaw() {
		return item;
	}

	public static int getItemID(String item) {

		int itemId = -1;

		try {
			itemId = Integer.parseInt(item);
		} catch (Exception e) {
			itemId = -1; // Just in case
		}

		if(item.equalsIgnoreCase("air")) {
			return 0;
		} else {
	 		for(int i = 0; i < itemsList.length; i++) {
				if(itemsList[i] != null) {
					if(itemId == -1) {
						String fullName = resolveID(i);
						if(fullName == null) {
							continue;
						}
						String baseName = fullName.substring(fullName.indexOf(46) + 1);
						if(item.equalsIgnoreCase(baseName)) {
							return i;
						}
					} else {
						WItem tempItem = new WItem(itemsList[i]);
						if(tempItem.getItemID() == itemId) { // itemsList[i].shiftedIndex
							// Found item with correct id
							// System.out.println("SPConsole: everything is fine");
							return i;
						}
					}

				}
			}

			// sendDebug("item not found..");
			// Couldn't find item
			return -1;
		}
	}

	public static String resolveID(int itemID) {
		if(itemID > itemsList.length || itemID < 0) {
			return null;
		}

		String baseName = null;

		if(!hardcodedIDs.containsKey(itemID)) {
			if(itemsList[itemID] != null) {
				String fullName = itemsList[itemID].a();
				if(fullName != null) {
					return fullName;
				}
			} else {
				return null;
			}
		} else {
			baseName = hardcodedIDs.get(itemID);
		}

		if(baseName == null || baseName.equals("")) {
			baseName = "unknownid_" + itemID;
		}

		if(itemID < 256) {
			return "tile." + baseName;
		} else {
			return "item." + baseName;
		}
	}

	static {
		hardcodedIDs = new HashMap<Integer, String>();

		// Blocks
		hardcodedIDs.put(0, "air");
		hardcodedIDs.put(8, "waterMoving");
		hardcodedIDs.put(9, "waterStill");
		hardcodedIDs.put(10, "lavaMoving");
		hardcodedIDs.put(11, "lavaStill");
		hardcodedIDs.put(34, "pistonExtension");
		hardcodedIDs.put(36, "pistonMoving");
		hardcodedIDs.put(39, "mushroomBrown");
		hardcodedIDs.put(40, "mushroomRed");
		hardcodedIDs.put(43, "stoneDoubleSlab");
		hardcodedIDs.put(44, "stoneSingleSlab");
		hardcodedIDs.put(61, "stoneOvenIdle");
		hardcodedIDs.put(62, "stoneOvenActive");
		hardcodedIDs.put(63, "signPost");
		hardcodedIDs.put(68, "signWall");
		hardcodedIDs.put(70, "pressurePlateStone");
		hardcodedIDs.put(72, "pressurePlatePlanks");
		hardcodedIDs.put(74, "oreRedstoneGlowing");
		hardcodedIDs.put(75, "torchRedstoneIdle");
		hardcodedIDs.put(76, "torchRedstoneActive");
		hardcodedIDs.put(77, "stoneButton");
		hardcodedIDs.put(80, "blockSnow");
		hardcodedIDs.put(93, "redstoneRepeaterIdle");
		hardcodedIDs.put(94, "redstoneRepeaterActive");
		hardcodedIDs.put(99, "mushroomCapBrown");
		hardcodedIDs.put(100, "mushroomCapRed");
		hardcodedIDs.put(105, "melonStem");
		hardcodedIDs.put(119, "endPortal");
		hardcodedIDs.put(123, "redstoneLampIdle");
		hardcodedIDs.put(124, "redstoneLampActive");
		hardcodedIDs.put(125, "woodDoubleSlab");
		hardcodedIDs.put(126, "woodSingleSlab");
		hardcodedIDs.put(143, "woodenButton");
		hardcodedIDs.put(149, "comparatorIdle");
		hardcodedIDs.put(150, "comparatorActive");
		hardcodedIDs.put(153, "oreQuartz");
		hardcodedIDs.put(155, "blockQuartz");

		// Items
		hardcodedIDs.put(406, "quartz");
		hardcodedIDs.put(2256, "record13");
		hardcodedIDs.put(2257, "recordCat");
		hardcodedIDs.put(2258, "recordBlocks");
		hardcodedIDs.put(2259, "recordChirp");
		hardcodedIDs.put(2260, "recordFar");
		hardcodedIDs.put(2261, "recordMall");
		hardcodedIDs.put(2262, "recordMellohi");
		hardcodedIDs.put(2263, "recordStal");
		hardcodedIDs.put(2264, "recordStrad");
		hardcodedIDs.put(2265, "recordWard");
		hardcodedIDs.put(2266, "record11");
		hardcodedIDs.put(2267, "recordWait");
	}

}
