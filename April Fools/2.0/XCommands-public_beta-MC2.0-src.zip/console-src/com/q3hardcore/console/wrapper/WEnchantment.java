package com.q3hardcore.console.wrapper;

import net.minecraft.src.za; // Enchantment

public class WEnchantment {

	private za enchantment; // Enchantment
	private static WEnchantment[] cachedEnchantmentsList;

	public WEnchantment(za enchantment) {
		this.enchantment = enchantment;
	}

	public int getEffectId() {
		return enchantment.z; // effectId
	}

	public int getMinLevel() {
		return enchantment.d();
	}

	public int getMaxLevel() {
		return enchantment.b();
	}

	public String getName() {
		return enchantment.a(); // getName
	}

	public String getTranslatedName(int enchantmentLevel) {
		return enchantment.c(enchantmentLevel); // getTranslatedName
	}

	public boolean canApplyTogether(WEnchantment enchant) {
		return enchantment.a(enchant.getRaw());
	}

	public boolean canEnchantItem(WItem item) {
		return enchantment.A.a(item.getRaw()); // type
	}

	public boolean isValid() {
		return enchantment != null;
	}

	public za getRaw() {
		return enchantment;
	}

	public static WEnchantment[] getEnchantmentsList() {
		if(cachedEnchantmentsList != null && cachedEnchantmentsList.length == za.b.length) {
			return cachedEnchantmentsList;
		} else {
			return deobfuscateArray(za.b);
		}
	}

	public static WEnchantment[] deobfuscateArray(za[] obfuscatedArray) {
		WEnchantment[] deobfuscatedArray = new WEnchantment[obfuscatedArray.length];
		int index = 0;
		for(za enchantment : obfuscatedArray) {
			if(enchantment == null) {
				deobfuscatedArray[index] = null;
			} else {
				deobfuscatedArray[index] = new WEnchantment(enchantment);
			}
			index++;
		}
		return deobfuscatedArray;
	}

}
