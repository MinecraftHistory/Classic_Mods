package com.q3hardcore.console.wrapper;

import net.minecraft.src.aam;

public class WWorldType {

	private aam worldType;

	public static final WWorldType DEFAULT = new WWorldType(aam.b);
	public static final WWorldType FLAT = new WWorldType(aam.c);
	public static final WWorldType LARGE_BIOMES = new WWorldType(aam.d);
	public static final WWorldType DEFAULT_1_1 = new WWorldType(aam.e);

	public WWorldType(aam worldType) {
		this.worldType = worldType;
	}

	@Override
	public boolean equals(Object object) {
		if(!(object instanceof WWorldType)) {
			return false;
		} else {
			WWorldType type = (WWorldType)object;
			int currentHash = getRaw().hashCode();
			return currentHash == type.getRaw().hashCode();
		}
	}

	private aam getRaw() {
		return worldType;
	}

}