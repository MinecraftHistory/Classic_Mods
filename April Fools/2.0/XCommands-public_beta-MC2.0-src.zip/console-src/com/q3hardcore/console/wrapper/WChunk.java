package com.q3hardcore.console.wrapper;

import net.minecraft.src.abx;

public final class WChunk {

	private final abx chunk;

	public WChunk(final abx chunk) {
		this.chunk = chunk;
	}

	public byte[] getBiomeArray() {
		return chunk.m();
	}

	public void setBiomeArray(byte[] biomeArray) {
		chunk.a(biomeArray);
	}

	public boolean isValid() {
		return chunk != null;
	}

	public abx getRaw() {
		return chunk;
	}

}