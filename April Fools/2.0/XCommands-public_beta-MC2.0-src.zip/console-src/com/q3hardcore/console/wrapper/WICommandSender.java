package com.q3hardcore.console.wrapper;

import net.minecraft.src.ab;
import net.minecraft.src.t;

public final class WICommandSender implements ab {

	private ab commandSender;

	public WICommandSender(ab commandSender) {
		this.commandSender = commandSender;
	}

	public String getCommandSenderName() {
		return commandSender.c_();
	}

	public void sendChatToPlayer(String msg) {
		commandSender.a(msg);
	}

	public boolean canCommandSenderUseCommand(int permissionLevel, String cmdName) {
		return commandSender.a(permissionLevel, cmdName);
	}

	public String translateString(String string, Object ... args) {
		return commandSender.a(string, args);
	}

	public WChunkCoords getPlayerCoordinates() {
		return new WChunkCoords(commandSender.b());
	}

	@Deprecated
	public ab getRaw() {
		return commandSender;
	}

	@Deprecated
	@Override
	public final String c_() {
		return getCommandSenderName();
	}

	@Deprecated
	@Override
	public final void a(String var1) {
		sendChatToPlayer(var1);
	}

	@Deprecated
	@Override
	public final boolean a(int var1, String var2) {
		return canCommandSenderUseCommand(var1, var2);
	}

	@Deprecated
	@Override
	public final String a(String var1, Object ... var2) {
		return translateString(var1, var2);
	}

	@Deprecated
	@Override
	public final t b() {
		return getPlayerCoordinates().getRaw();
	}

}