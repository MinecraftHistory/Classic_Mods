package com.q3hardcore.console.wrapper;

import net.minecraft.src.arb;

public class WAxisAlignedBB {

	private arb boundingBox;

	public WAxisAlignedBB(arb boundingBox) {
		this.boundingBox = boundingBox;
	}

	public static arb getBoundingBoxRaw(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
		return arb.a(minX, minY, minZ, maxX, maxY, maxZ); // AxisAlignedBB, getBoundingBox
	}

	public static WAxisAlignedBB getBoundingBox(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
		return new WAxisAlignedBB(arb.a(minX, minY, minZ, maxX, maxY, maxZ)); // AxisAlignedBB, getBoundingBox
	}

	public WMovingObjectPosition calculateIntercept(WVec3D initialVector, WVec3D destVector) {
		return new WMovingObjectPosition(boundingBox.a(initialVector.getRaw(), destVector.getRaw()));
	}

	public boolean isVecInside(WVec3D vector) {
		return boundingBox.a(vector.getRaw());
	}

	public WAxisAlignedBB expand(double x, double y, double z) {
		return new WAxisAlignedBB(boundingBox.b(x, y, z));
	}

	public void setBB(WAxisAlignedBB newBox) {
		boundingBox.c(newBox.getRaw());
	}

	public arb getRaw() {
		return boundingBox;
	}

}