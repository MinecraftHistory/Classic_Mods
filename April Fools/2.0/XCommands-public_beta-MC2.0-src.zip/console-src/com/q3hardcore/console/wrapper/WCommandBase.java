package com.q3hardcore.console.wrapper;

import net.minecraft.src.x; // CommandBase

public class WCommandBase {

	private final x command;

	public WCommandBase(x commandBase) {
		this.command = commandBase;
	}

	public final x getRaw() {
		return command;
	}

}