package com.q3hardcore.console.wrapper;

// import net.minecraft.src.arb;

public final class WEnumMovingObjectType {

	public static final int TILE = 0;
	public static final int ENTITY = 1;

}