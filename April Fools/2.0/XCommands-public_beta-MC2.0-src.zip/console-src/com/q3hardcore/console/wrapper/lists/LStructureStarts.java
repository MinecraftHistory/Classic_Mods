package com.q3hardcore.console.wrapper.lists;

import com.q3hardcore.console.wrapper.WStructureStart;
import com.q3hardcore.console.wrapper.WWorld;
import java.util.Random;
import net.minecraft.src.aes; // Mineshaft
import net.minecraft.src.afo; // BiomeFeature
import net.minecraft.src.ConsoleHelper;

public final class LStructureStarts {

	public static class Mineshaft extends WStructureStart {
		public Mineshaft(WWorld world, Random rand, int x, int z) {
			super(new aes(world.getRaw(), rand, x, z));
		}
	}

	public static class NetherBridge extends WStructureStart {
		public NetherBridge(WWorld world, Random rand, int x, int z) {
			super(ConsoleHelper.getStructureNetherBridgeStart(world, rand, x, z));
		}
	}

	public static class BiomeFeature extends WStructureStart {
		public BiomeFeature(WWorld world, Random rand, int x, int z) {
			super(new afo(world.getRaw(), rand, x, z));
		}
	}


	public static class Stronghold extends WStructureStart {
		public Stronghold(WWorld world, Random rand, int x, int z) {
			super(ConsoleHelper.getStructureStrongholdStart(world, rand, x, z));
		}
	}

	public static class Village extends WStructureStart {
		public Village(WWorld world, Random rand, int x, int z, int villageType) {
			super(ConsoleHelper.getStructureVillageStart(world, rand, x, z, villageType));
		}
	}

}