// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.wrapper;

import net.minecraft.src.are;

public class WMovingObjectPosition {

	public int blockx;
	public int blocky;
	public int blockz;
	public int sidehit;
	private WEntity entity;
	private final are mop; // MovingObjectPosion

	public WMovingObjectPosition(final are mop) { // MovingObjectPosion
		this.mop = mop;
		if(mop == null) {
			this.blockx = -1;
			this.blocky = -1;
			this.blockz = -1;
			this.entity = null;
			this.sidehit = -1;
		} else {
			this.blockx = mop.b; // blockX
			this.blocky = mop.c; // blockY
			this.blockz = mop.d; // blockZ
			this.sidehit = mop.e; // sideHit
			if(mop.g != null) { // entityHit
				this.entity = new WEntity(mop.g);
			}

		}
	}

	public int getTypeOfHit() {
		return mop.a.ordinal();
	}

	public are getRaw() {
		return this.mop;
	}

	public WEntity getEntity() {
		return entity;
	}

	public WVec3D getHitVec() {
		return new WVec3D(this.mop.f);
	}

	public static WMovingObjectPosition instantiate(WEntity e) {
		return new WMovingObjectPosition(new are(e.getRawEntity()));
	}

	public boolean isValid() {
		return mop != null;
	}

}
