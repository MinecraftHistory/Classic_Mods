// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.wrapper;

import net.minecraft.src.mp; // Entity
import net.minecraft.src.ConsoleEntityHelper;

public class WEntity {

	private mp e;
	private ConsoleEntityHelper helper;

	public WEntity(mp e) {
		this.e = e;
		this.helper = new ConsoleEntityHelper(e);
	}

	public int rawHashCode() {
		return e.hashCode();
	}

	public int getEntityID() {
		return this.e.k;
	}

	// make sure to create new instance
	public WWorld getWorld() {
		return new WWorld(this.e.q); // worldObj
	}

	public double getPrevPosX() {
		return this.e.r; // prevPosX
	}

	public double getPrevPosY() {
		return this.e.s; // prevPosY
	}

	public double getPrevPosZ() {
		return this.e.t; // prevPosZ
	}

	public double getPosX() {
		return this.e.u; // posX
	}

	public double getPosY() {
		return this.e.v; // posX
	}

	public double getPosZ() {
		return this.e.w; // posZ
	}

	public Coordinate getMotion() {
		return new Coordinate(this.e.x, this.e.y, this.e.z); // motionX, motionY, motionZ
	}

	public float getYaw() {
		return this.e.A; // rotationYaw
	}

	public void setYaw(float yaw) {
		this.e.A = yaw; // rotationYaw
	}

	public float getPitch() {
		return this.e.B; // rotationPitch
	}

	public void setPitch(float pitch) {
		this.e.B = pitch; // rotationPitch
	}

	public WAxisAlignedBB getBoundingBox() {
		return new WAxisAlignedBB(this.e.E);
	}

	public void setNoclip(boolean noclip) {
		this.e.Z = noclip; // noClip
	}

	public boolean getNoclip() {
		return this.e.Z; // noClip
	}

	public int getFire() {
		return this.e.ac; // fireResistance
	}

	public void setFire(int fire) {
		this.e.ac = fire; // fireResistance
	}

	public int getDimension() {
		return this.e.ar; // dimension
	}

	public boolean attackEntityFrom(WDamageSource damageSource, int amountDamage) {
		return e.a(damageSource.getMinecraftDamageSource(), amountDamage);
	}

	public void setPosition(Coordinate position) {
		this.e.b(position.getX(), position.getY(), position.getZ()); // setPosition
	}

	public void setLocationAndAngles(double x, double y, double z, float yaw, float pitch) {
		this.e.b(x, y, z, yaw, pitch);
	}

	public void dropItem(int id, int damage) {
		this.e.b(id, damage); // dropItem
	}

	public float getEyeHeight() {
		return this.e.e(); // getEyeHeight
	}

	public void setAir(int air) {
		this.e.g(air); // setAir
	}

	/* CLIENT-SIDE
	public void setMotion(Coordinate motion) {
		this.e.h(motion.getX(), motion.getY(), motion.getZ()); // setVelocity
	}
	*/

	public void setDead() {
		e.w();
	}

	public boolean getImmuneToFire() {
		return this.e.E(); // isImmuneToFire
	}

	public boolean canBeCollidedWith() {
		return e.K();
	}

	public float getCollisionBorderSize() {
		return e.X();
	}

	public int getAir() {
		return this.e.ak(); // getAir
	}

	public void setPositionAndRotation(double x, double y, double z, float yaw, float pitch) {
		this.e.a(x, y, z, yaw, pitch);
	}

	public Coordinate getPosition() {
		return new Coordinate(this.getPosX(), this.getPosY(), this.getPosZ());
	}

	public String getPrettyPos() {
		int posX = (int) Math.round(getPosX()); // entity.posX
		int posY = (int) Math.round(getPosY()); // entity.posY
		int posZ = (int) Math.round(getPosZ()); // entity.posZ
		String entityType = getClass().isAssignableFrom(WPlayer.class)?"player":"entity";
		return "Current position of " + entityType + ": " + posX + ", " + posY + ", " + posZ;
	}

	public void kill() {
		this.helper.kill(); // kill
	}

	public void setRotation(float yaw, float pitch) {
		this.helper.setRotation(yaw, pitch); // setRotation
	}

	public void setImmuneToFire(boolean immune) {
		this.helper.setImmuneToFire(immune); // isImmuneToFire
	}

	public boolean isValid() {
		return this.e != null;
	}

	public mp getRawEntity() {
		return this.e;
	}

	public static WEntity instantiate(Object object) {
		if(object instanceof mp) {
			return new WEntity((mp)object);
		} else {
			return null;
		}
	}

}
