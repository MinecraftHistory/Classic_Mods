package com.q3hardcore.console.wrapper.raw;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Proxy;
import com.q3hardcore.console.wrapper.WICommandSender;
import com.q3hardcore.console.wrapper.WMinecraftServer;
import com.q3hardcore.console.wrapper.WPlayer;
import net.minecraft.src.x; // CommandBase
import net.minecraft.src.ab; // ICommandSender
import net.minecraft.src.z; // ICommand
import java.util.List;

public abstract class RCommandBase extends x {

	private boolean playerCommand = true;

	public boolean getPlayerCommand() {
		return playerCommand;
	}

	public void setPlayerCommand(boolean val) {
		playerCommand = val;
	}

	@Override
	public final String c() {
		return this.getCommandName();
	}

	@Override
	public final String a(ab par1ICommandSender) {
		return par1ICommandSender.a(this.getCommandUsage(), new Object[0]);
	}

	@Override
	public final void b(ab par1ICommandSender, String[] par2ArrayOfStr) {
		if(playerCommand) {
			this.processCommand(new WPlayer(c(par1ICommandSender)), par2ArrayOfStr);
		} else {
			this.processCommand(new WICommandSender(par1ICommandSender), par2ArrayOfStr);
		}
	}

	@Override
	public final boolean b(ab par1ICommandSender) {
		return canCommandSenderUseCommand(new WICommandSender(par1ICommandSender));
	}

	private final boolean canCommandSenderUseCommand(WICommandSender sender) {
		final boolean canUseCommand = super.b(sender);
		if(canUseCommand) {
			return true;
		} else if(Proxy.INSTANCE.getSide() == EnumSide.CLIENT) {
			return sender.getCommandSenderName().equals(WMinecraftServer.getServer().getServerOwner());
		} else {
			return false;
		}
	}

	@Override
	public final List<String> a(ab commandSender, String[] args) { // addTabCompletionOptions
		return addTabCompletionOptions(new WICommandSender(commandSender), args);
	}

	public List<String> addTabCompletionOptions(WICommandSender sender, String[] args) {
		return null;
	}

	@Override
	public final int compareTo(Object object) {
		if(object instanceof z) {
			return this.a((z)object);
		} else {
			return -1; // TODO: ?
		}
	}

	public String getCommandUsage() {
		return "/" + this.getCommandName();
	}

	public boolean isEnabled() {
		return true;
	}

	public String getDescription() {
		return "";
	}

	public String getVersion() {
		return Helper.getServerVersion();
	}

	public abstract String getCommandName();

	public void processCommand(WPlayer player, String[] args) {};

	public void processCommand(WICommandSender sender, String[] args) {}

}