package com.q3hardcore.console.wrapper.lists;

import com.q3hardcore.console.wrapper.WWorldGenerator;
import com.q3hardcore.console.wrapper.raw.RWorldGenDungeons;
import net.minecraft.src.*;

public class LWorldGen {

	public static class Waterlily extends WWorldGenerator {
		public Waterlily() {
			super(new abs());
		}
	}

	public static class BigTree extends WWorldGenerator {
		public BigTree(boolean bool) {
			super(new adc(bool));
		}
	}

	public static class Forest extends WWorldGenerator {
		public Forest(boolean bool) {
			super(new add(bool));
		}
	}

	public static class BonusChest extends WWorldGenerator {
		public BonusChest(lp[] contents, int numItems) {
			super(new ade(contents, numItems));
		}
	}

	public static class Cactus extends WWorldGenerator {
		public Cactus() {
			super(new adf());
		}
	}

	public static class Clay extends WWorldGenerator {
		public Clay(int numBlocks) {
			super(new adh(numBlocks));
		}
	}

	public static class DeadBush extends WWorldGenerator {
		public DeadBush(int blockID) {
			super(new adi(blockID));
		}
	}

	public static class DesertWells extends WWorldGenerator {
		public DesertWells() {
			super(new adj());
		}
	}

	public static class Flowers extends WWorldGenerator {
		public Flowers(int blockID) {
			super(new adl(blockID));
		}
	}

	public static class Shrub extends WWorldGenerator {
		public Shrub(int woodMeta, int leafMeta) {
			super(new adm(woodMeta, leafMeta));
		}
	}

	public static class Fire extends WWorldGenerator {
		public Fire() {
			super(new adn());
		}
	}

	public static class GlowStone1 extends WWorldGenerator {
		public GlowStone1() {
			super(new ado());
		}
	}

	public static class HellLava extends WWorldGenerator {
		public HellLava(int blockID, boolean secondPass) {
			super(new adp(blockID, secondPass));
		}
	}

	public static class BigMushroom extends WWorldGenerator {
		public BigMushroom() {
			super(new adr());
		}
		public BigMushroom(int mushroomType) {
			super(new adr(mushroomType));
		}
	}

	public static class Lakes extends WWorldGenerator {
		public Lakes(int blockID) {
			super(new ads(blockID));
		}
	}

	public static class GlowStone2 extends WWorldGenerator {
		public GlowStone2() {
			super(new adt());
		}
	}

	public static class HugeTrees extends WWorldGenerator {
		public HugeTrees(boolean doBlockNotify, int minHeight, int woodMeta, int leafMeta) {
			super(new adu(doBlockNotify, minHeight, woodMeta, leafMeta));
		}
	}

	public static class Dungeons extends WWorldGenerator {
		public Dungeons() {
			super(new RWorldGenDungeons());
		}
	}

	public static class Minable extends WWorldGenerator {
		public Minable(int blockID, int numBlocks) {
			super(new adw(blockID, numBlocks));
		}
	}

	public static class Taiga1 extends WWorldGenerator {
		public Taiga1() {
			super(new adx());
		}
	}

	public static class Pumpkin extends WWorldGenerator {
		public Pumpkin() {
			super(new ady());
		}
	}

	public static class Reed extends WWorldGenerator {
		public Reed() {
			super(new adz());
		}
	}

	public static class Sand extends WWorldGenerator {
		public Sand(int radius, int blockID) {
			super(new aea(radius, blockID));
		}
	}

	public static class Spikes extends WWorldGenerator {
		public Spikes(int replaceID) {
			super(new aeb(replaceID));
		}
	}

	public static class Liquids extends WWorldGenerator {
		public Liquids(int blockID) {
			super(new aec(blockID));
		}
	}

	public static class Taiga2 extends WWorldGenerator {
		public Taiga2(boolean doBlockNotify) {
			super(new aed(doBlockNotify));
		}
	}

	public static class Swamp extends WWorldGenerator {
		public Swamp() {
			super(new aee());
		}
	}

	public static class TallGrass extends WWorldGenerator {
		public TallGrass(int blockID, int meta) {
			super(new aef(blockID, meta));
		}
	}

	public static class Trees extends WWorldGenerator {
		public Trees(boolean doBlockNotify) {
			super(new aeg(doBlockNotify));
		}
		public Trees(boolean doBlockNotify, int minHeight, int woodMeta, int leafMeta, boolean vines) {
			super(new aeg(doBlockNotify, minHeight, woodMeta, leafMeta, vines));
		}
	}


	public static class Vines extends WWorldGenerator {
		public Vines() {
			super(new aeh());
		}
	}


}