package com.q3hardcore.console.wrapper;

// wrapper imports
import com.q3hardcore.console.wrapper.WAxisAlignedBB;
import com.q3hardcore.console.wrapper.WEntity;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WVec3D;

// java imports
import java.util.List;

public final class WEntityRenderer {

	public static WMovingObjectPosition getMouseOver(WPlayer player, float partialTickTime) {
		return findNearestEntity(player, partialTickTime, 0);
	}

	public static WMovingObjectPosition getMouseOver(WPlayer player, float partialTickTime, int forceState) {
		return findNearestEntity(player, partialTickTime, forceState);
	}

	private static WMovingObjectPosition findNearestEntity(WPlayer player, float partialTickTime, int forceState) {

		boolean forceNearest = false;
		boolean forceLast = false;

		if(forceState == 1) {
			forceNearest = true;
		} else if(forceState == 2) {
			forceLast = true;
		} else if(forceState != 0) {
			player.sendError("Unknown force state.");
		}

		WEntity pointedEntity;
		WMovingObjectPosition objectMouseOver = null;

		double var2 = (double)player.getBlockReachDistance();
		objectMouseOver = player.rayTrace(var2, partialTickTime);
		double var4 = var2;
		WVec3D pos = player.getPosition(partialTickTime); // getPosition

		if(objectMouseOver.blocky != -1) { // check it's not null
			var4 = objectMouseOver.getHitVec().distanceTo(pos); // hitVec.distanceTo
		}

		WVec3D look = player.getLook(partialTickTime); // getLook
		WVec3D var8 = pos.addVector(look.getXCoord() * var2, look.getYCoord() * var2, look.getZCoord() * var2);
		pointedEntity = null;
		float var9 = 1.0F;
		List<?> var10 = player.getWorld().getRaw().b(player.getMinecraftPlayer(),
			player.getMinecraftPlayer().E.a(look.getXCoord() * var2, look.getYCoord() * var2, look.getZCoord() * var2).b((double)var9, (double)var9, (double)var9));
		double var11 = var4;

		int validEntities = 0;
		WEntity lastEntity = null;

		for(int var13 = 0; var13 < var10.size(); var13++) {
			final WEntity entity;

			try {
				entity = WEntity.instantiate(var10.get(var13));
			} catch (IndexOutOfBoundsException iobe) {
				iobe.printStackTrace();
				// System.out.println("Unknown problem occured.");
				continue;
			}

			if(entity == null) {
				// System.out.println("No entity.");
				continue;
			}

			if(entity.canBeCollidedWith() || forceLast) { // canBeCollidedWith
				validEntities++;
				lastEntity = entity;
				float var15 = entity.getCollisionBorderSize(); // getCollisionBorderSize
				WAxisAlignedBB var16 = entity.getBoundingBox().expand((double)var15, (double)var15, (double)var15); // boundingBox
				WMovingObjectPosition var17 = var16.calculateIntercept(pos, var8); // calculateIntercept
				if(var16.isVecInside(pos)) { // isVecInside
					if(0.0D < var11 || var11 == 0.0D) {
						pointedEntity = entity;
						var11 = 0.0D;
					}
				} else if(var17.getRaw() != null) {
					double var18 = pos.distanceTo(var17.getHitVec());
					if(var18 < var11 || var11 == 0.0D) {
						pointedEntity = entity;
						var11 = var18;
					}
				}
			}
		}

		// System.out.println("Found " + validEntities + " entities.");

		if(pointedEntity != null) {
			// System.out.println("Found possible entity");
		}

		if(pointedEntity != null && (var11 < var4 || objectMouseOver.blocky == -1)) {
			// System.out.println("Found entity");
			objectMouseOver = WMovingObjectPosition.instantiate(pointedEntity);
		}

		if(pointedEntity == null) {
			if(validEntities >= 1) {
				if(!forceLast) {
					// System.out.println("At least one entity in area.");
				} else {
					objectMouseOver = WMovingObjectPosition.instantiate(lastEntity);
				}
			} else if (validEntities == 1 && forceNearest) {
				// System.out.println("Using closest entity.");
				objectMouseOver = WMovingObjectPosition.instantiate(lastEntity);
			}
		}

		return objectMouseOver;
	}

}