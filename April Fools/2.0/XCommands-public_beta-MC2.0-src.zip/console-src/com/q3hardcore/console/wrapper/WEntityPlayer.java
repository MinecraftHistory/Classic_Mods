// Player Base Helper Class
// Uses code from SinglePlayerCommands

package com.q3hardcore.console.wrapper;

import java.util.List;
import java.util.Iterator;

import net.minecraft.src.sp; // PlayerEntity

import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.util.FontColour;

public class WEntityPlayer extends WEntityLiving {

	private final sp player;
	private final WICommandSender sender;

	public WEntityPlayer(sp player) {
		super(player);
		this.player = player;
		this.sender = new WICommandSender(player);
	}

	public float getBlockReachDistance() {
		if(getCapabilities().getIsCreativeMode()) {
			return 5.0F;
		} else {
			return 4.5F;
		}
	}

	public void addChatMessage(String msg) {
		try {
			player.b(msg);
		} catch (Exception e) {
			System.out.println(msg);
			// Console.mc.printChatMessage(msg);
		}
	}	

	public int getFoodLevel() {
		return getFoodStats().getFoodLevel();
	}

	public void setFoodLevel(int amount) {
		amount -= getFoodLevel();
		getFoodStats().addStats(amount, 1.2F);
	}

	public WMovingObjectPosition rayTrace() {
		return rayTrace(getBlockReachDistance(), 1.0F);
	}

	public void setPositionAndUpdate(double x, double y, double z) {
		player.a(x, y, z);
	}

	public WChunkCoords getSpawnChunk() {
		return new WChunkCoords(player.ci());
	}

	public void setSpawnChunk(WChunkCoords coords, boolean forced) {
		player.a(coords.getRaw(), forced);
	}

	public WPlayerCapabilities getCapabilities() {
		return new WPlayerCapabilities(player.cf);
	}

	public WInventoryPlayer getInventory() {
		return new WInventoryPlayer(player.bL);
	}

	public int inventoryHashCode() {
		return getInventory().getRaw().hashCode();
	}

	public WItemStack getCurrentItem() {
		return getInventory().getCurrentItem();
	}

	public void addItemStackToInventory(WItemStack itemStack) {
		getInventory().addItemStackToInventory(itemStack);
	}

	public WFoodStats getFoodStats() {
		return new WFoodStats(player.cl());
	}

	// function am() works too
	public String getUsername() {
		return player.bT;
	}

	public void sendPlayerAbilities() {
		player.n();
	}

	public WIInventory getInventoryEnderChest() {
		return new WIInventory(player.cn());
	}

	public void displayGUIChest(WIInventory inventory) {
		player.a(inventory.getRaw());
	}

	public sp getMinecraftPlayer() {
		return player;
	}

	public void sendMessage(String msg) {
		sendMessage2(Helper.getColor(Helper.normalColor) + msg);
	}

	public void sendMessage2(String msg) {
		addChatMessage(msg);
	}

	public void sendPrettyMessage(String msg) {
		String[] split = msg.split(":");
		if(split.length == 2) {
			sendMessage2(FontColour.GREEN + split[0] + ":" + FontColour.WHITE + split[1]);
		} else {
			sendMessage2(FontColour.WHITE + msg);
		}
	}

	public void sendError(String err) {
		sendMessage2(Helper.getColor(Helper.errorColor) + "ERROR: " + Helper.getColor(Helper.normalColor) + err);
	}

	public void sendError2(String err) {
		sendMessage2("ERROR: " + err);
	}

	public static boolean isEntityInstance(WEntity entity) {
		if(entity.getRawEntity() instanceof sp) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isPlayerFirst() {
		try {
			return WMinecraftServer.getServer().getFirstPlayerName().equals(getUsername());
		} catch (Exception e) {
			System.out.println("Couldn't determine first player."); // occurs when kicked
			return false; // when exiting, NullPointerExpcetion can be thrown
		}
	}

	public WICommandSender getSender() {
		return sender;
	}

	public String getSenderName() {
		return sender.getCommandSenderName();
	}

	public boolean isClear(Coordinate coord) {

		return getWorld().getBlockId(coord.getBlockX(), coord.getBlockY(), coord.getBlockZ()) == 0
		&& getWorld().getBlockId(coord.getBlockX(), coord.getBlockY() + 1, coord.getBlockZ()) == 0
		&& !(getWorld().getBlockId(coord.getBlockX(), coord.getBlockY() - 1, coord.getBlockZ()) == 0);
	}

	public boolean isClearBelow(Coordinate coord) {
		return getWorld().getBlockId(coord.getBlockX(), coord.getBlockY(), coord.getBlockZ()) == 0
		&& getWorld().getBlockId(coord.getBlockX(), coord.getBlockY() + 1, coord.getBlockZ()) == 0
		&& getWorld().getBlockId(coord.getBlockX(), coord.getBlockY() - 1, coord.getBlockZ()) == 0;
	}

}