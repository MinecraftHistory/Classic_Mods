package com.q3hardcore.console.wrapper;

import net.minecraft.src.bs;

public class WNBTTagCompound {

	private final bs nbttagcompound;

	public WNBTTagCompound() {
		this.nbttagcompound = new bs();
	}

	public WNBTTagCompound(bs nbttagcompound) {
		this.nbttagcompound = nbttagcompound;
	}

	public WNBTTagCompound getCompoundTag(String tagName) {
		return new WNBTTagCompound(nbttagcompound.l(tagName));
	}

	public boolean hasKey(String tagName) {
		return nbttagcompound.b(tagName);
	}

	public void removeTag(String tagName) {
		nbttagcompound.o(tagName);
	}

	public void setTag(String tagName, WNBTTagCompound tag) {
		nbttagcompound.a(tagName, tag.getRaw());
	}

	public boolean getBoolean(String tagName) {
		return nbttagcompound.n(tagName);
	}

	public float getFloat(String tagName) {
		return nbttagcompound.g(tagName);
	}

	public String getString(String tagName) {
		return nbttagcompound.i(tagName);
	}

	public void setString(String tagName, String value) {
		nbttagcompound.a(tagName, value);
	}

	public void setBoolean(String tagName, boolean value) {
		nbttagcompound.a(tagName, value);
	}

	public void setFloat(String tagName, float value) {
		nbttagcompound.a(tagName, value);
	}

	public void setInteger(String tagName, int value) {
		nbttagcompound.a(tagName, value);
	}

	public void setLong(String tagName, long value) {
		nbttagcompound.a(tagName, value);
	}

	public static WNBTTagCompound instantiate() {
		return new WNBTTagCompound(new bs());
	}

	public bs getRaw() {
		return nbttagcompound;
	}

	public boolean isValid() {
		return nbttagcompound != null;
	}

}