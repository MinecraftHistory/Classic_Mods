package com.q3hardcore.console.wrapper;

import com.q3hardcore.console.wrapper.raw.RCommandBase;
import java.util.Map;
import net.minecraft.server.MinecraftServer;
import net.minecraft.src.y; // CommandHandler
import net.minecraft.src.z; // ICommand
import net.minecraft.src.aa; // ICommandManager

public class WCommandHandler {

	private aa commandManager; // ICommandManager

	protected WCommandHandler(aa commandManager) {
		this.commandManager = commandManager;
	}

	public Object registerCommand(RCommandBase command) {
		if(commandManager instanceof y) { // CommandHandler
			return ((y)commandManager).a(command);
		} else {
			return null;
		}
	}

	public boolean doesCommandExist(String name) {
		return commandManager.a().containsKey(name);
	}

	public void executeCommand(WICommandSender sender, String command) {
		commandManager.a(sender, command);
	}

	public void executeCommand(WPlayer player, String command) {
		commandManager.a(player.getMinecraftPlayer(), command);
	}

	@SuppressWarnings("unchecked")
	public Map<String, z> getCommands() {
		return commandManager.a();
	}

	public aa getRaw() {
		return commandManager;
	}

	public boolean isValid() {
		return commandManager != null;
	}

}