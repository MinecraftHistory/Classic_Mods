package com.q3hardcore.console.wrapper;

import net.minecraft.src.t; // ChunkCoordinates

// Times re-obfuscated: 3 (Minecraft 1.4.1, 1.4.3, 13w05a)

public class WChunkCoords {

	public int posX;
	public int posY;
	public int posZ;
	private t coords; // ChunkCoordinates

	public WChunkCoords(t coords) {
		this.coords = coords;
		if(coords == null) {
			this.posX = -1;
			this.posY = -1;
			this.posZ = -1;
		} else {
			this.posX = coords.a; // posX
			this.posY = coords.b; // posY
			this.posZ = coords.c; // posZ
		}
	}

	public t getRaw() {
		return this.coords;
	}

	public static WChunkCoords instantiate(int x, int y, int z) {
		return new WChunkCoords(new t(x, y, z));
	}

}
