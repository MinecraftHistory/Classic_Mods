package com.q3hardcore.console.wrapper.lists;

import com.q3hardcore.console.wrapper.WStructureComponent;

import java.util.Random;

import net.minecraft.src.afr; // ComponentScatteredFeatureDesertPyramid
import net.minecraft.src.afs; // ComponentScatteredFeatureJungleTemple
import net.minecraft.src.afv; // ComponentScatteredFeatureSwampHut

public class LComponentScatteredFeature {

	public static class DesertPyramid extends WStructureComponent {
		public DesertPyramid(Random rand, int x, int z) {
			super(new afr(rand, x, z));
		}
	}

	public static class JungleTemple extends WStructureComponent {
		public JungleTemple(Random rand, int x, int z) {
			super(new afs(rand, x, z));
		}
	}

	public static class SwampHut extends WStructureComponent {
		public SwampHut(Random rand, int x, int z) {
			super(new afv(rand, x, z));
		}
	}

}