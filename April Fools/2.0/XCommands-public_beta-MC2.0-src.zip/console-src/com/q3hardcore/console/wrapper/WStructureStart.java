package com.q3hardcore.console.wrapper;

import java.util.LinkedList;
import java.util.Random;
import net.minecraft.src.agz;
import net.minecraft.src.ConsoleHelper;

public class WStructureStart {

	private final agz structureStart;

	public WStructureStart(final agz structureStart) {
		this.structureStart = structureStart;
	}

	public void generateStructure(WWorld world, Random rand, WStructureBoundingBox boundingBox) {
		structureStart.a(world.getRaw(), rand, boundingBox.getRaw());
	}

	@SuppressWarnings("rawtypes")
	private LinkedList getComponents() {
		return structureStart.b();
	}

	@SuppressWarnings("unchecked")
	public void addComponent(WStructureComponent component) {
		getComponents().add(component.getRaw());
	}

	public void clearComponents() {
		getComponents().clear();
	}

	public WStructureBoundingBox getBoundingBox() {
		return new WStructureBoundingBox(structureStart.a());
	}

	public void updateBoundingBox() {
		// structureStart.c();
		ConsoleHelper.updateBoundingBox(this);
	}

	public boolean isValid() {
		return structureStart != null;
	}

	public agz getRaw() {
		return structureStart;
	}

}