package com.q3hardcore.console.wrapper;

import net.minecraft.src.aqt;

public class WTileEntity {

	private final aqt tileEntity;

	public WTileEntity(final aqt tileEntity) {
		this.tileEntity = tileEntity;
	}

	public aqt getRaw() {
		return tileEntity;
	}

}