package com.q3hardcore.console.wrapper;

import net.minecraft.src.aco;
import net.minecraft.src.ConsoleHelper;

public class WWorldProvider {

	private aco worldProvider;

	public WWorldProvider(aco worldProvider) {
		this.worldProvider = worldProvider;
	}

	public int getDimensionId() {
		return worldProvider.h;
	}

	public boolean isHellWorld() {
		return worldProvider.e;
	}

	public void setHellWorld(boolean value) {
		worldProvider.e = value;
	}


	public float[] getLightBrightnessTable() {
		return worldProvider.g; // worldProvider.lightBrightnessTable
	}

	public static WWorldProvider getProviderForDimension(int dimensionId) {
		WWorldProvider dimensionProvider = new WWorldProvider(aco.a(dimensionId));
		if(dimensionProvider.getRaw() == null) {
			return null;
		} else {
			return dimensionProvider;
		}
	}

	public void generateLightBrightnessTable() {
		ConsoleHelper.generateLightBrightnessTable(this);
	}

	public aco getRaw() {
		return worldProvider;
	}

}