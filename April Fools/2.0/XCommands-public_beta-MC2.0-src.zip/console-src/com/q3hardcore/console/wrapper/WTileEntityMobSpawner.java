package com.q3hardcore.console.wrapper;

import net.minecraft.src.aqn;

public class WTileEntityMobSpawner extends WTileEntity {

	private final aqn tileEntityMobSpawner;

	public WTileEntityMobSpawner(final aqn tileEntityMobSpawner) {
		super(tileEntityMobSpawner);
		this.tileEntityMobSpawner = tileEntityMobSpawner;
	}

	public Object getLogic() {
		return tileEntityMobSpawner.a();
	}

	public void setMobID(String mobID) {
		tileEntityMobSpawner.a().a(mobID);
	}

	/* client-side only
	public WEntity getEntity() {
		return new WEntity(tileEntityMobSpawner.a().h());
	}
	*/

	public static WTileEntityMobSpawner instantiate(Object object) {
		if(object instanceof aqn) {
			return new WTileEntityMobSpawner((aqn)object);
		} else {
			return null;
		}
	}

	public boolean isTileEntityInstance(WTileEntity tileEntity) {
		return tileEntity.getRaw() instanceof aqn;
	}

	@Override
	public aqn getRaw() {
		return tileEntityMobSpawner;
	}

}