package com.q3hardcore.console.wrapper;

public class WStringTranslate {

	public static net.minecraft.src.StringTranslate getInstance() {
		return net.minecraft.src.StringTranslate.a();
	}

}
