package com.q3hardcore.console.wrapper;

import net.minecraft.src.agx;

public class WStructureComponent {

	private final agx structureComponent;

	public WStructureComponent(final agx component) {
		this.structureComponent = component;
	}

	public agx getRaw() {
		return structureComponent;
	}

}