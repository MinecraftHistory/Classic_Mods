// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.wrapper;

import com.q3hardcore.console.util.ObfuscationHelper;

import java.io.File;
import java.lang.reflect.Field;
import java.util.List;

import net.minecraft.src.aac; // World
import net.minecraft.src.ajw; // WorldInfo
import net.minecraft.src.aqt; // TileEntity

public class WWorld {

	private final aac world; // World

	public WWorld(final aac world) {
		this.world = world;
	}

	public boolean equalTo(WWorld otherWorld) {
		return rawHashCode() == otherWorld.rawHashCode();
	}

	public int rawHashCode() {
		return world.hashCode();
	}

	/* <High Priority>------------------------------------------------------- */

	public long getSeed() {
		return this.world.F(); // world.getSeed()
	}

	public long getWorldTime() {
		return this.world.H(); // getWorldTime
	}

	public WWorldInfo getWorldInfo() {
		return new WWorldInfo(world.L());
	}

	public WVec3D getVecFromPool(double paramDouble1, double paramDouble2, double paramDouble3) {
		return new WVec3D(world.T().a(paramDouble1, paramDouble2, paramDouble3));
	}

	/* </High Priority>------------------------------------------------------ */

	public int getBlockLightValue(int x, int y, int z) {
		return world.m(x, y, z); // getBlockLightValue
	}

	public int getBlockId(int x, int y, int z) {
		return world.a(x, y, z); // getBlockId
	}

	public int getBlock(Coordinate position, int block) {
		return getBlockId(position.getBlockX(), position.getBlockY(), position.getBlockZ());
	}

	public int getBlockMetadata(int x, int y, int z) {
		return world.h(x, y, z); // getBlockMetadata
	}

	public int getMetadata(Coordinate position, int block) {
		return getBlockMetadata(position.getBlockX(), position.getBlockY(), position.getBlockZ());
	}

	public Coordinate getSpawn() {
		return getWorldInfo().getSpawn();
		// wi.getSpawnX, wi.getSpawnY, wi.getSpawnZ
	}

	public File getWorldDir() {
		return ObfuscationHelper.getWorldDir(this);
	}

	public boolean setBlock(int x, int y, int z, int type) { // World
		return world.f(x, y, z, type, 0, 2); // setBlock
	}

	public void setBlock(Coordinate position, int block) {
		setBlock(position.getBlockX(), position.getBlockY(), position.getBlockZ(), block);
	}

	public boolean setBlockWithNotify(int x, int y, int z, int type) { // World
		return world.c(x, y, z, type); // setBlockWithNotify
	}

	public void setBlockWithNotify(Coordinate position, int block) {
		setBlockWithNotify(position.getBlockX(), position.getBlockY(), position.getBlockZ(), block);
	}

	public boolean setBlockMetadata(int x, int y, int z, int type) { // World
		// return world.b(x, y, z, type); // setBlockMetadata
		return world.b(x, y, z, type, 4); // setBlockMetadata
	}

	public void setMetadata(Coordinate position, int data) {
		setBlockMetadata(position.getBlockX(), position.getBlockY(), position.getBlockZ(), data);
	}

	public void setBlockMetadataWithNotify(int x, int y, int z, int type) { // World
		world.b(x, y, z, type, 2); // setBlockMetadataWithNotify
	}

	public void setMetadataWithNotify(Coordinate position, int data) {
		setBlockMetadataWithNotify(position.getBlockX(), position.getBlockY(), position.getBlockZ(), data);
	}

	public boolean setBlockAndMetadataWithNotify(int x, int y, int z, int block, int meta) { // World
		return world.f(x, y, z, block, meta, 2); // setBlockAndMetadataWithNotify
	}

	public void setSpawn(Coordinate position) {
		getWorldInfo().setSpawn(position); // setSpawnPosition
	}

	public long getTime() {
		return getWorldInfo().getWorldTime(); // getWorldTime
	}

	public int[] getFormattedTime() {
		long worldtime = getWorldTime(); // theWorld.getWorldTime
		int DD = (int)(worldtime / 1000L / 24L);
		int HH = (int)(worldtime / 1000L % 24L);
		int MM = (int)((double)(worldtime % 1000L) / 1000.0D * 60.0D);
		return new int[]{MM, HH, DD};
	}

	public String getPrettyTime() {
		int[] temp = getFormattedTime();
		String hr = temp[1] < 10?"0" + temp[1]:"" + temp[1];
		String mn = temp[0] < 10?"0" + temp[0]:"" + temp[0];
		return "Day: " + temp[2] + " at " + hr + ":" + mn;
	}

	public void setTime(long time) {
		getWorldInfo().setWorldTime(time); // setWorldTime
	}

	public String getName() {
		return getWorldInfo().getWorldName(); // getWorldName
	}

	public WBiome getBiomeGenAt(int x, int y) {
		return new WBiome(this.world.t().a(x, y));
	}

	public boolean addWeatherEffect(WEntity entity) {
		return this.world.c(entity.getRawEntity());
	}

	public int getTopSolidOrLiquidBlock(int x, int z) {
		return this.world.i(x, z);
	}

	public int getSpawnX() {
		return getWorldInfo().getSpawnX();
	}

	public int getSpawnY() {
		return getWorldInfo().getSpawnY();
	}

	public int getSpawnZ() {
		return getWorldInfo().getSpawnZ();
	}

	public int getWorldType() {
		return getWorldProvider().getDimensionId(); // worldProvider, actually dimensionId
	}

	public void spawnEntityInWorld(WEntity entity) {
		world.d(entity.getRawEntity());
	}

	public aqt getBlockTileEntity(int x, int y, int z) {
		return world.r(x, y, z);
	}

	public WTileEntity getBlockTileEntity2(int x, int y, int z) {
		if(getBlockTileEntity(x, y, z) == null) {
			return null;
		} else {
			return new WTileEntity(getBlockTileEntity(x, y, z));
		}
	}

	@SuppressWarnings("unchecked")
	public List<WEntity> getEntitiesWithinAABBExcludingEntity(WEntity excludedEntity, WAxisAlignedBB boundingBox) {
		return ObfuscationHelper.getEntitiesWithinAABBExcludingEntity(this, excludedEntity, boundingBox);
	}

	public WChunk getChunkFromBlockCoords(int x, int z) {
		return new WChunk(this.world.d(x, z));
	}

	public boolean blockExists(int x, int y, int z) {
		return this.world.f(x, y, z);
	}

	public WMovingObjectPosition rayTraceBlocks(WVec3D paramVec3D1, WVec3D paramVec3D2) {
		return new WMovingObjectPosition(world.a(paramVec3D1.getRaw(), paramVec3D2.getRaw()));
	}

	public void changeWorldInfo(String key, Object value) {
		WNBTTagCompound nbt = getWorldInfo().getNBTTagCompound(); // NBTTagCompound, getWorldInfo()
		if(value instanceof String) {
			nbt.setString(key, (String)value);
		} else if(value instanceof Boolean) {
			nbt.setBoolean(key, ((Boolean)value).booleanValue());
		} else if(value instanceof Integer) {
			nbt.setInteger(key, ((Integer)value).intValue());
		} else if(value instanceof Long) {
			nbt.setLong(key, ((Long)value).longValue());
		}

		WWorldInfo info = WWorldInfo.instantiate(nbt); // WorldInfo

		try {
			Field[] e = aac.class.getDeclaredFields(); // World
			Field[] arr$ = e;
			int len$ = e.length;

			for(int i$ = 0; i$ < len$; ++i$) {
				Field field = arr$[i$];
				field.setAccessible(true);
				if(field.get(this.world) instanceof ajw) { // WorldInfo
					field.set(this.world, info.getRaw());
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public aac getRaw() {
		return this.world;
	}

	public WWorldProvider getWorldProvider() {
		return new WWorldProvider(world.t); // provider (public final)
	}

	public WSaveHandler getSaveHandler() {
		return new WSaveHandler(world.K());
	}

}
