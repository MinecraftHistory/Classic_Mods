package com.q3hardcore.console.wrapper;

import java.util.List;
import java.util.Iterator;

import net.minecraft.src.ng; // EntityLiving
import net.minecraft.src.ConsoleHelper;

import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.Helper;

public class WEntityLiving extends WEntity {

	private ng entityLiving;

	public WEntityLiving(ng entity) {
		super(entity);
		entityLiving = entity;
	}

	public int getHealth() {
		return entityLiving.aW();
	}

	public void setHealth(int amount) {
		entityLiving.j(amount); // setEntityHealth
	}

	public WMovingObjectPosition rayTrace(double distance, float partialTickTime) {
		WVec3D posVec = getPosition(partialTickTime);
		WVec3D lookVec = getLook(partialTickTime);
		WVec3D resultantVec = posVec.addVector(
			lookVec.getXCoord() * distance,
			lookVec.getYCoord() * distance,
			lookVec.getZCoord() * distance
		);
		return getWorld().rayTraceBlocks(posVec, resultantVec);
		// MovingObjectPosition soh = new MovingObjectPosition(entityLiving.a(distance, partialTickTime));
		// return soh;
	}

	public Coordinate trace(double distance) {
		WMovingObjectPosition soh = rayTrace(distance, 1.0F);
		return soh.getRaw() == null?null:new Coordinate(soh.blockx, soh.blocky, soh.blockz);
	}

	// because Mojang decided MinecraftServer could do without this..
	public WVec3D getPosition(float partialTickTime) {
		final double offsetY = getPosY() + getEyeHeight();
		final WVec3D posVec;

		if(partialTickTime == 1.0F) {
			posVec = getWorld().getVecFromPool(getPosX(), offsetY, getPosZ());
		} else {
			final double offsetPrevY = getPrevPosY() + getEyeHeight();
			double posX = getPrevPosX() + (getPosX() - getPrevPosX()) * (double)partialTickTime;
			double posY = offsetPrevY + (offsetY - offsetPrevY) * (double)partialTickTime;
			double posZ = getPrevPosZ() + (getPosZ() - getPrevPosZ()) * (double)partialTickTime;
			posVec = getWorld().getVecFromPool(posX, posY, posZ);
		}

		return posVec;
	}

	public WVec3D getLook(float partialTickTime) {
		return new WVec3D(entityLiving.i(partialTickTime));
	}

	public void setPositionAndUpdate(Coordinate coord) {
		entityLiving.a(coord.getX(), coord.getY(), coord.getZ());
	}

	public WItemStack getHeldItem() {
		WItemStack heldItem = new WItemStack(entityLiving.bG());
		if(heldItem.getRaw() == null) {
			return null;
		} else {
			return heldItem;
		}
	}

	public void setCurrentItemOrArmor(int slot, WItemStack stack) {
		if(stack == null) {
			entityLiving.c(slot, null);
		} else {
			entityLiving.c(slot, stack.getRaw());
		}
	}

	public WItemStack getCurrentArmor(int slot) {
		WItemStack itemStack = new WItemStack(entityLiving.q(slot));
		if(itemStack.getRaw() == null) {
			return null;
		} else {
			return itemStack;
		}
	}

	public void initCreature() {
		entityLiving.bJ(); // remember to update this! (find above "?6 -")
	}

	public void playLivingSound() {
		entityLiving.aR(); // remember to update this! (find @ "String var1 = this.")
	}

	public void damageEntity(WDamageSource damageSource, int damageAmount) {
		ConsoleHelper.damageEntity(this, damageSource, damageAmount);
	}

	public ng getRaw() {
		return entityLiving;
	}

	public static boolean isEntityInstance(WEntity entity) {
		if(isRawInstance(entity.getRawEntity())) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isRawInstance(Object o) {
		return (o instanceof ng);
	}

	public static WEntityLiving instantiate(WEntity entity) {
		if(entity.getRawEntity() instanceof ng) {
			return new WEntityLiving((ng)entity.getRawEntity());
		} else {
			return null;
		}
	}

	public static WEntityLiving instantiateRaw(Object object) {
		if(object instanceof ng) {
			return new WEntityLiving((ng)object);
		} else {
			return null;
		}
	}

}