package com.q3hardcore.console.wrapper;

import java.util.HashMap;
import java.util.Map;
import java.lang.reflect.Field;
import net.minecraft.src.wm; // ItemStack
import net.minecraft.src.yg; // FurnaceRecipes

public final class WFurnaceRecipes {

	public static Map<Integer, WItemStack> getSmeltingList() throws Exception {
		Map<Integer, WItemStack> smeltingList = new HashMap<Integer, WItemStack>();
		Map<?, ?> tempMap = yg.a().b();
		for(Object key : tempMap.keySet()) {
			if(key instanceof Integer) {
				Object value = tempMap.get(key);
				if(value instanceof wm) {
					smeltingList.put((Integer)key, new WItemStack((wm)value));
				}
			}
		}
		return smeltingList;
	}

}