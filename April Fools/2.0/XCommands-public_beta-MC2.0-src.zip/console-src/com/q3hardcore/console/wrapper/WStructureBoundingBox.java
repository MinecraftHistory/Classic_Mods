package com.q3hardcore.console.wrapper;

import net.minecraft.src.ael;

public final class WStructureBoundingBox {

	private final ael boundingBox;

	public WStructureBoundingBox(final ael boundingBox) {
		this.boundingBox = boundingBox;
	}

	public int getMinX() {
		return boundingBox.a;
	}

	public int getMinY() {
		return boundingBox.b;
	}

	public int getMinZ() {
		return boundingBox.c;
	}

	public int getMaxX() {
		return boundingBox.d;
	}

	public int getMaxY() {
		return boundingBox.e;
	}

	public int getMaxZ() {
		return boundingBox.f;
	}

	public int setMinX(int num) {
		return boundingBox.a = num;
	}

	public int setMinY(int num) {
		return boundingBox.b = num;
	}

	public int setMinZ(int num) {
		return boundingBox.c = num;
	}

	public int setMaxX(int num) {
		return boundingBox.d = num;
	}

	public int setMaxY(int num) {
		return boundingBox.e = num;
	}

	public int setMaxZ(int num) {
		return boundingBox.f = num;
	}

	protected ael getRaw() {
		return boundingBox;
	}

	public boolean isValid() {
		return boundingBox != null;
	}

}