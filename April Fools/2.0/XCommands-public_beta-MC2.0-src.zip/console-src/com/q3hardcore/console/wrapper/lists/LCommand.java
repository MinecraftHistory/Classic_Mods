package com.q3hardcore.console.wrapper.lists;

import com.q3hardcore.console.wrapper.WCommandBase;
import net.minecraft.src.ag; // CommandExp
import net.minecraft.src.ah; // CommandDifficulty
import net.minecraft.src.ai; // CommandGameMode
import net.minecraft.src.aj; // CommandGameRule

public final class LCommand {

	public static class Exp extends WCommandBase {
		public Exp() {
			super(new ag());
		}
	}

	public static class Difficulty extends WCommandBase {
		public Difficulty() {
			super(new ah());
		}
	}

	public static class GameMode extends WCommandBase {
		public GameMode() {
			super(new ai());
		}
	}

	public static class GameRule extends WCommandBase {
		public GameRule() {
			super(new aj());
		}
	}

}