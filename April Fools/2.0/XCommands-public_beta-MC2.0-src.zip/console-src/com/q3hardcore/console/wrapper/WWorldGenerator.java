package com.q3hardcore.console.wrapper;

import java.util.Random;
import net.minecraft.src.adk;

public class WWorldGenerator {

	private final adk generator;

	public WWorldGenerator(final adk generator) {
		this.generator = generator;
	}	

	public boolean generate(WWorld world, Random rand, int x, int y, int z) {
		return generator.a(world.getRaw(), rand, x, y, z);
	}

}