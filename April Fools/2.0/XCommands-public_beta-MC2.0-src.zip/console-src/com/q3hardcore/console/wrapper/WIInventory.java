package com.q3hardcore.console.wrapper;

import net.minecraft.src.lt;

public class WIInventory {

	private final lt inventory;

	public WIInventory(final lt inventory) {
		this.inventory = inventory;
        }

	public int getSizeInventory() {
		return inventory.j_();
	}

	public WItemStack getStackInSlot(int i) {
		WItemStack stack = new WItemStack(inventory.a(i));
		if(!stack.isValid()) {
			return null;
		} else {
			return stack;
		}
	}

	public void setInventorySlotContents(int slot, WItemStack stack) {
		if(stack == null) {
			inventory.a(slot, null);
		} else {
			inventory.a(slot, stack.getRaw());
		}
	}

	public String getInvName() {
		return inventory.b();
	}

	public boolean isUseableByPlayer(WEntityPlayer player) {
		return inventory.a(player.getMinecraftPlayer());
	}

	public lt getRaw() {
		return inventory;
	}

	public static WIInventory instantiate(Object object) {
		if(object instanceof lt) {
			return new WIInventory((lt)object);
		} else {
			return null;
		}
	}

}