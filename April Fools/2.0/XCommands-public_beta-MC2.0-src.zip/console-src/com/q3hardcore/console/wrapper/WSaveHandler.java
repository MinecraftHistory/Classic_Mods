package com.q3hardcore.console.wrapper;

import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Proxy;

import java.io.File;

import net.minecraft.src.aju; // SaveHandler
import net.minecraft.src.akg; // ISaveHandler

public final class WSaveHandler {

	private final akg saveHandler;

	public WSaveHandler(final akg saveHandler) {
		this.saveHandler = saveHandler;
	}

	public WNBTTagCompound readPlayerData(WEntityPlayer player) {
		if(Proxy.INSTANCE.getSide() == EnumSide.SERVER) {
			return new WNBTTagCompound(saveHandler.e().b(player.getMinecraftPlayer()));
		} else {
			if(saveHandler instanceof aju) {
				return new WNBTTagCompound(((aju)saveHandler).b(player.getMinecraftPlayer()));
			} else {
				return new WNBTTagCompound(null);
			}
		}
	}

	public File getSaveDirectory() {
		return new File(".");
	}	

}