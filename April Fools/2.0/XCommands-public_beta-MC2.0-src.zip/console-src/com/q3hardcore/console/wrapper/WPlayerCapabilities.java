package com.q3hardcore.console.wrapper;

import net.minecraft.src.sm; // PlayerCapabilities

public class WPlayerCapabilities {

	private final sm capabilities;

	protected WPlayerCapabilities(final sm playerCapabilities) {
		capabilities = playerCapabilities;
	}

	public boolean getDisableDamage() {
		return capabilities.a;
	}

	public boolean setDisableDamage(boolean val) {
		return capabilities.a = val;
	}

	public boolean getIsFlying() {
		return capabilities.b;
	}

	public boolean setIsFlying(boolean val) {
		return capabilities.b = val;
	}

	public boolean getAllowFlying() {
		return capabilities.c;
	}

	public boolean setAllowFlying(boolean val) {
		return capabilities.c = val;
	}

	public boolean getIsCreativeMode() {
		return capabilities.d;
	}

	public boolean setIsCreativeMode(boolean val) {
		return capabilities.d = val;
	}

	public boolean getAllowEdit() {
		return capabilities.e;
	}

	public boolean setAllowEdit(boolean val) {
		return capabilities.e = val;
	}

	public void writeCapabilitiesToNBT(WNBTTagCompound tag) {
		capabilities.a(tag.getRaw());
	}

	public void readCapabilitiesFromNBT(WNBTTagCompound tag) {
		capabilities.b(tag.getRaw());
	}

	public float getFlySpeed() {
		return capabilities.a();
	}

	// CLIENT SIDE
	public void setFlySpeed(float speed) {
		// capabilities.a(speed);
	}

	public float getWalkSpeed() {
		return capabilities.b();
	}

	// CLIENT SIDE
	public void setWalkSpeed(float speed) {
		// capabilities.b(speed);
	}

}