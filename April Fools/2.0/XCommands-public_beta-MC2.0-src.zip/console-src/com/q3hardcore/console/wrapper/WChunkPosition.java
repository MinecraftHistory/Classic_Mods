package com.q3hardcore.console.wrapper;

import net.minecraft.src.aau; // ChunkPosition

// Times re-obfuscated: several

public class WChunkPosition {

	public final int x;
	public final int y;
	public final int z;
	private aau position; // ChunkPosition

	public WChunkPosition(aau position) {
		this.position = position;
		if(position == null) {
			this.x = -1;
			this.y = -1;
			this.z = -1;
		} else {
			this.x = position.a; // x
			this.y = position.b; // y
			this.z = position.c; // z
		}
	}

	public aau getPosition() {
		return this.position;
	}
}
