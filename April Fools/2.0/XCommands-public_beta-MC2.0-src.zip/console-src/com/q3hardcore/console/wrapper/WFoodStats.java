package com.q3hardcore.console.wrapper;

import net.minecraft.src.ti; // FoodStats

public final class WFoodStats {

	private final ti foodStats;

	public WFoodStats(final ti foodStats) {
		this.foodStats = foodStats;
	}

	public void addStats(int foodLevel, float foodSaturationModifier) {
		foodStats.a(foodLevel, foodSaturationModifier);
	}

	public int getFoodLevel() {
		return foodStats.a();
	}

}