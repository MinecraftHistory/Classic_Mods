package com.q3hardcore.console.wrapper;

public class PosKey {

	public final String playerName;
	public final String worldName;
	public final int dimension;

	public PosKey(String playerName, String worldName, int dimension) {
		this.playerName = playerName;
		this.worldName = worldName;
		this.dimension = dimension;
	}

	@Override
	public boolean equals(Object object) {
		if(!(object instanceof PosKey)) {
			return false;
		} else {
			PosKey posKey = (PosKey)object;
			return toString().equals(posKey.toString());
		}
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("PosKey[");
		builder.append("player: ");
		builder.append(playerName);
		builder.append("////");
		builder.append("world: ");
		builder.append(worldName);
		builder.append("////");
		builder.append("dimension: ");
		builder.append(dimension);
		builder.append("]");
		return builder.toString();
	}

}