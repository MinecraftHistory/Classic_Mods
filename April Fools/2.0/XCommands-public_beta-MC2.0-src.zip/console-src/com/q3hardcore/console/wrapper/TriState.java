package com.q3hardcore.console.wrapper;

public enum TriState {
        OFF,
	ON,
	UNDEFINED;
}