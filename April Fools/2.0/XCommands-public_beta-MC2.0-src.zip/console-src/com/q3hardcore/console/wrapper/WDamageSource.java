package com.q3hardcore.console.wrapper;

import net.minecraft.src.mg;

public class WDamageSource {

	private mg damageSource;

	public static final WDamageSource outOfWorld = new WDamageSource(mg.i);

	public WDamageSource(mg damageSource) {
		this.damageSource = damageSource;
	}

	public mg getMinecraftDamageSource() {
		return damageSource;
	}

	public static WDamageSource causePlayerDamage(WEntityPlayer player) {
		return new WDamageSource(mg.a(player.getMinecraftPlayer()));
	}

}