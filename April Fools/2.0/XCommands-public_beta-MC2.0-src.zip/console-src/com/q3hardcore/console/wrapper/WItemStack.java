package com.q3hardcore.console.wrapper;

import net.minecraft.src.wm; // ItemStack

public class WItemStack {

	private wm itemStack;

	public WItemStack(wm itemStack) {
		this.itemStack = itemStack;
	}

	public int getItemDamage() {
		return itemStack.j();
	}

	public int getStackSize() {
		return itemStack.a;
	}

	public void setStackSize(int size) {
		itemStack.a = size;
	}

	public int getItemID() {
		return itemStack.c;
	}

	public void setItemDamage(int damage) {
		itemStack.b(damage);
	}

	public int getMaxStackSize() {
		return itemStack.e();
	}

	public WNBTTagCompound getStackTagCompound() {
		if(itemStack.d == null) {
			return null;
		} else {
			return new WNBTTagCompound(itemStack.d);
		}
	}

	public void setStackTagCompound(WNBTTagCompound nbttagcompound) {
		if(nbttagcompound == null) {
			itemStack.d = null;
		} else {
			itemStack.d = nbttagcompound.getRaw();
		}
	}

	public boolean isStackable() {
		return itemStack.f();
	}

	public WItemStack copy() {
		return new WItemStack(itemStack.m());
	}

	public boolean getHasSubtypes() {
		return itemStack.h();
	}

	public boolean isItemDamaged() {
		return itemStack.i();
	}

	public boolean isItemEnchanted() {
		return itemStack.x();
	}

	public void addEnchantment(WEnchantment enchantment, int level) {
		itemStack.a(enchantment.getRaw(), level);
	}

	public WItem getItem() {
		if(itemStack.b() == null) {
			return null;
		} else {
			return new WItem(itemStack.b());
		}
	}

	public wm getRaw() {
		return itemStack;
	}

	public boolean isValid() {
		return itemStack != null;
	}

	public static WItemStack[] deobfuscateArray(wm[] obfuscatedArray) {
		WItemStack[] deobfuscatedArray = new WItemStack[obfuscatedArray.length];
		int index = 0;
		for(wm item : obfuscatedArray) {
			if(item == null) {
				deobfuscatedArray[index] = new WItemStack(null);
			} else {
				deobfuscatedArray[index] = new WItemStack(item);
			}
			index++;
		}
		return deobfuscatedArray;
	}

	public static WItemStack copyItemStack(WItemStack stack) {
		return new WItemStack(wm.b(stack.getRaw()));
	}

	public static WItemStack instantiate(int itemID, int stackSize, int itemDamage) {
		return new WItemStack(new wm(itemID, stackSize, itemDamage));
	}

}