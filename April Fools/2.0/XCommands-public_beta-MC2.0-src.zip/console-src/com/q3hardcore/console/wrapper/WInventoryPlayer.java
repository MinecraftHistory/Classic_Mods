package com.q3hardcore.console.wrapper;

import net.minecraft.src.sn; // InventoryPlayer
import net.minecraft.src.wm; // ItemStack

public final class WInventoryPlayer {

	sn inventory;

	public WInventoryPlayer(final sn inventory) {
		this.inventory = inventory;
	}

	public WItemStack getCurrentItem() {
		WItemStack currentItem = new WItemStack(inventory.h());
		if(currentItem.getRaw() == null) {
			return null;
		} else {
			return currentItem;
		}
	}

	public int getCurrentItemID() {
		return inventory.c;
	}

	public void addItemStackToInventory(WItemStack itemStack) {
		inventory.a(itemStack.getRaw());
	}

	public wm[] getMainInventoryRaw() {
		return inventory.a;
	}

	public WItemStack[] getMainInventory() {
		return WItemStack.deobfuscateArray(inventory.a);
	}

	public WItemStack[] getArmorInventory() {
		return WItemStack.deobfuscateArray(inventory.b);
	}

	public void setInventorySlotContents(int slot, WItemStack item) {
		inventory.a(slot, item.getRaw());
	}

	public void setArmorSlotContents(int slot, WItemStack item) {
		slot += inventory.a.length;
		setInventorySlotContents(slot, item);
	}

	protected sn getRaw() {
		return inventory;
	}

}