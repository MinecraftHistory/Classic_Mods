package com.q3hardcore.console.wrapper;

// Obfuscated references: 0

public class ConsoleException extends Exception {

	private static final long serialVersionUID = 5869522749020177866L;

	public ConsoleException(String msg) {
		super(msg);
	}

}