package com.q3hardcore.console.wrapper;

import com.q3hardcore.console.util.ReflectionHelper;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.src.mv; // EntityList

public final class WEntityList {

	public static WEntity createEntityByName(String entityName, WWorld world) {
		return new WEntity(mv.a(entityName, world.getRaw()));
	}

	public static boolean entityEggsContainsKey(int entityID) {
		return mv.a.containsKey(entityID);
	}

	// This needs updating with most snapshots
	public static Map<String, Integer> getStringtoIDMapping() {
		Map<String, Integer> StringtoIDMapping;
		try {
			Field field = ReflectionHelper.getField(new String[]{"f", "field_75622_f"}, mv.class); // EntityList.class.getDeclaredField("stringToIDMapping")
			Object fieldValue = field.get(null);
			StringtoIDMapping = castMap(fieldValue);
			return StringtoIDMapping;
		} catch (Exception e) {
			// sendError("Couldn't find entity mappings.");
			return null;
		}
	}

	// Used by getStringtoIDMapping
	private static Map<String, Integer> castMap(Object object) {
		Map<Object, Object> tempMap = new HashMap<Object, Object>();
		Map<String, Integer> newMap = new HashMap<String, Integer>();
		if(object instanceof Map) {
			try {
				tempMap.putAll((Map <?, ?>)object);
				Iterator<Entry<Object, Object>> entries = tempMap.entrySet().iterator();
				while(entries.hasNext()) {
					Entry<Object, Object> entry = entries.next();
					if(entry.getKey() instanceof String) {
						if(entry.getValue() instanceof Integer) {
							newMap.put((String)entry.getKey(), (Integer)entry.getValue());
						}
					}
				}
				return newMap;
			} catch (Exception e) {
				// sendError("Map caused exception.");
				return newMap;
			}
		} else {
			// sendError("Not a map.");
			return newMap;
		}
	}

}