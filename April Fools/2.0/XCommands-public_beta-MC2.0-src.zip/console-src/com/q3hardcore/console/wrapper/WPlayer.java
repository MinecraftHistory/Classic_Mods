// Player/Sender Helper Class
// Uses code from SinglePlayerCommands

package com.q3hardcore.console.wrapper;

import java.util.List;
import java.util.Iterator;

import net.minecraft.src.jc; // EntityPlayerMP

import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Side;

public class WPlayer extends WEntityPlayer {

	private final jc player;

	public WPlayer(jc player) {
		super(player);
		this.player = player;
	}

	public void sendClientMessage(String type, Object msg) {
		String clientMsg = "\u00A7cXCOMMANDS////" + type + "////" + msg.toString();
		if(player.clientHasXCommands) {
			addChatMessage(clientMsg);
		}
	}

	public void addChatMessage(String msg) {
		try {
			player.b(msg);
		} catch (Exception e) {
			addPendingMessage(msg);
		}
	}

	public void addPendingMessage(String msg) {
		player.pendingMessages.add(msg);
	}

	public Console getConsole() {
		return player.ph;
	}

	@Override
	public jc getMinecraftPlayer() {
		return player;
	}

	public static WPlayer[] deobfuscateArray(jc[] obfuscatedArray) {
		WPlayer[] deobfuscatedArray = new WPlayer[obfuscatedArray.length];
		int index = 0;
		for(jc player : obfuscatedArray) {
			if(player == null) {
				deobfuscatedArray[index] = null;
			} else {
				deobfuscatedArray[index] = new WPlayer(player);
			}
			index++;
		}
		return deobfuscatedArray;
	}

	@Override
	public float getBlockReachDistance() {
		float distance;
		if(getCapabilities().getIsCreativeMode()) { // isCreativeMode
			distance = 5.0F;
		} else {
			distance = 4.5F;
		}
		if(player.reachDistance > distance) {
			distance = player.reachDistance;
		}
		return distance;
	}

	public float getReachDistance() {
		return player.reachDistance;
	}

	public boolean setReachDistance(float distance) {
		if(distance >= 4.5F && distance <=255.0F) {
			player.reachDistance = distance;
			player.c.setBlockReachDistance(distance);
			return true;
		} else {
			return false;
		}
	}

	@Side(EnumSide.CLIENT)
	public boolean isPlayerOwner() {
		try {
			return WMinecraftServer.getServer().getServerOwner().equals(getUsername());
		} catch (Exception e) {
			System.out.println("couldn't get owner"); // occurs when kicked
			return false; // when exiting, NullPointerExpcetion can be thrown
		}
	}

}