package com.q3hardcore.console.wrapper;

import net.minecraft.src.arg;

public final class WVec3D {

	private arg vector;

	public WVec3D(arg vector) {
		this.vector = vector;
	}

	public WVec3D addVector(double x, double y, double z) {
		return new WVec3D(vector.c(x, y, z));
	}

	public double distanceTo(WVec3D otherVector) {
		return vector.d(otherVector.getRaw());
	}

	public double getXCoord() {
		return vector.c;
	}

	public double getYCoord() {
		return vector.d;
	}

	public double getZCoord() {
		return vector.e;
	}

	public arg getRaw() {
		return vector;
	}

}