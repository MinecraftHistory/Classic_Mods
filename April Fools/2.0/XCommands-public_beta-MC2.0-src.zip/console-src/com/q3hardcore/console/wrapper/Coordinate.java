package com.q3hardcore.console.wrapper;

// From SinglePlayerCommands by simo_415

// Obfuscated references: 0

public class Coordinate {

	private final double x;
	private final double y;
	private final double z;

	public Coordinate(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public Coordinate(int x, int y, int z) {
		this.x = (double)x;
		this.y = (double)y;
		this.z = (double)z;
	}

	public double getX() {
		return this.x;
	}

	public int getBlockX() {
		int x = (int)this.getX();
		return this.getX() < (double)x?x - 1:x;
	}

	public double getY() {
		return this.y;
	}

	public int getBlockY() {
		return (int)this.getY();
	}

	public double getZ() {
		return this.z;
	}

	public int getBlockZ() {
		int z = (int)this.getZ();
		return this.getZ() < (double)z?z - 1:z;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj != null && obj instanceof Coordinate) {
			Coordinate compare = (Coordinate)obj;
			return compare.getX() == this.getX() && compare.getY() == this.getY() && compare.getZ() == this.getZ();
		} else {
			return false;
		}
	}

	@Override
	public String toString() {
		return this.x + "," + this.y + "," + this.z;
	}

	public String toPrettyString() {
		return (int)this.x + ", " + (int)this.y + ", " + (int)this.z;
	}

}
