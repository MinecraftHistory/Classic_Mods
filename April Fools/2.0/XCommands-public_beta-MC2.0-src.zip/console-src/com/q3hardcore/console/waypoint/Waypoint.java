package com.q3hardcore.console.waypoint;

import com.q3hardcore.console.wrapper.Coordinate;
import com.q3hardcore.console.wrapper.WMathHelper;

public final class Waypoint {

	private String name;
	private String playerName;
	private Coordinate coordinate;
	private int dimension;

	public Waypoint(String name, String playerName, Coordinate coordinate, int dimension) {
		this.name = name;
		this.playerName = playerName;
		this.coordinate = coordinate;
		this.dimension = dimension;
	}

	public Coordinate getCoordinate() {
		return coordinate;
	}

	public int getDimension() {
		return dimension;
	}

	public String getName() {
		return name;
	}

	public String getPlayerName() {
		return playerName;
	}

	// String representation is rounded
	@Override
	public String toString() {
		int x = WMathHelper.floor_double(coordinate.getX());
		int y = WMathHelper.floor_double(coordinate.getY());
		int z = WMathHelper.floor_double(coordinate.getZ());
		return playerName + "," + x + "," + y + "," + z + "," + dimension;
	}

}