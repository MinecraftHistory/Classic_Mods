package com.q3hardcore.console.waypoint;

import com.q3hardcore.console.wrapper.Coordinate;
import com.q3hardcore.console.wrapper.WWorld;
import com.q3hardcore.console.util.Settings;
import java.io.File;
import java.util.List;
import java.util.ArrayList;

public final class WaypointHelper {

	public static boolean addWaypoint(File waypointFile, Waypoint waypoint) {
		Settings waypointSettings = new Settings(waypointFile);
		boolean exists = hasWaypoint(waypointFile, waypoint.getName());
		waypointSettings.set(waypoint.getName(), waypoint.toString());
		waypointSettings.save("Waypoints");
		return exists;
	}

	public static void removeWaypoint(File waypointFile, String waypointName) {
		Settings waypointSettings = new Settings(waypointFile);
		waypointSettings.remove(waypointName);
		waypointSettings.save("Waypoints");
	}

	public static Waypoint getWaypoint(File waypointFile, String waypointName) throws WaypointException {
		Settings waypointSettings = new Settings(waypointFile);	
		return resolveWaypoint(waypointName, waypointSettings.getString(waypointName, "INVALID WAYPOINT"));
	}

	public static boolean hasWaypoint(File waypointFile, String waypointName) {
		Settings waypointSettings = new Settings(waypointFile);
		boolean exists = true;
		if(waypointSettings.getString(waypointName, "INVALID WAYPOINT").equals("INVALID WAYPOINT"))
			exists = false;
		return exists;
	}

	public static List<Waypoint> resolveWaypoints(File waypointFile) {
		Settings waypointSettings = new Settings(waypointFile);
		List<Waypoint> waypoints = new ArrayList<Waypoint>();
		for(String waypointName : waypointSettings.stringPropertyNames()) {
			String waypointData = waypointSettings.getString(waypointName, "INVALID WAYPOINT");
			try {
				waypoints.add(resolveWaypoint(waypointName, waypointData));
			} catch (WaypointException we) {
				System.out.println("Waypoint " + waypointName + " is invalid.");
			}
		}
		return waypoints;
	}

	private static Waypoint resolveWaypoint(String waypointName, String waypointData) throws WaypointException {
		if(waypointData.equals("INVALID WAYPOINT")) {
			System.out.println("Waypoint " + waypointName + " has no data.");
			throw new WaypointException();
		}

		String[] dataArray = waypointData.split(",");
		if(dataArray.length != 5) {
			throw new WaypointException();
		}
		String playerName = dataArray[0];
		int xPos;
		int yPos;
		int zPos;
		int dimension;

		try {
			xPos = Integer.valueOf(dataArray[1]);
			yPos = Integer.valueOf(dataArray[2]);
			zPos = Integer.valueOf(dataArray[3]);
			dimension = Integer.valueOf(dataArray[4]);
		} catch (NumberFormatException nfe) {
			throw new WaypointException();
		}

		return new Waypoint(waypointName, playerName, new Coordinate(xPos, yPos, zPos), dimension);
	}

	public static File getWaypointFile(WWorld world) {
		return new File(world.getWorldDir(), "/waypoints.txt");
	}

}