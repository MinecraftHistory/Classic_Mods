package com.q3hardcore.console.waypoint;

public final class WaypointException extends Exception {

	private static final long serialVersionUID = -2266069809333247367L;

	@Override
	public String getMessage() {
		return "Invalid Waypoint Data";
	}

}