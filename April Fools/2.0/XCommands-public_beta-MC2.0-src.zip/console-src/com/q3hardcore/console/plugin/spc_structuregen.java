package com.q3hardcore.console.plugin;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.wrapper.WMathHelper;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WStructureBoundingBox;
import com.q3hardcore.console.wrapper.WStructureComponent;
import com.q3hardcore.console.wrapper.WStructureStart;
import com.q3hardcore.console.wrapper.WWorld;
import com.q3hardcore.console.wrapper.WWorldType;
import com.q3hardcore.console.wrapper.lists.LComponentScatteredFeature;
import com.q3hardcore.console.wrapper.lists.LStructureStarts;

public class spc_structuregen extends Plugin {

	@Override
	public String getName() {
		return "StructureGen";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
			commands.add("structure");
			return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("structure")) {
			String[] help = new String[]{"Generates structures.", "<STRUCTURE|list>", "village"};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] args) {
		WWorld world = player.getWorld();
		
		if(args != null && args.length >=1) {
			if(!args[0].equalsIgnoreCase("structure")) {
				return false;
			}
		}

		if(args.length > 1) { // Check structure is specified

			if(args[1].equalsIgnoreCase("list")) {
				player.sendMessage("Structures: biomefeature, hut, mineshaft, netherbridge, pyramid, stronghold, temple, village");
				return true;
			}

			final int chunkX = WMathHelper.floor_double(player.getPosX() / 16); // ph.ep.posX
			final int chunkZ = WMathHelper.floor_double(player.getPosZ() / 16); // ph.ep.posZ
			final Random rand = new Random(world.getSeed()); // New random from world seed
			final long rand1 = rand.nextLong() / 2L * 2L + 1L;
			final long rand2 = rand.nextLong() / 2L * 2L + 1L;
			rand.setSeed((long)chunkX * rand1 + (long)chunkZ * rand2 ^ world.getSeed());

			WStructureStart structureStart; // StructureStart
			WStructureBoundingBox boundingBox; // StructureBoundingBox
			boolean villageHack = false;
			boolean flatWorld = world.getWorldInfo().getTerrainType().equals(WWorldType.FLAT); // WorldType
			boolean forceMin = false;

			if(args.length > 2) {
				if(args[2].equalsIgnoreCase("forceflat")) {
					flatWorld = true;
				} else if(args[2].equalsIgnoreCase("forcenormal")) {
					flatWorld = false;
				} else if(args[2].equalsIgnoreCase("forcemin")) {
					forceMin = true;
				}
			}

			if(args[1].equalsIgnoreCase("mineshaft")) {
				structureStart = new LStructureStarts.Mineshaft(world, rand, chunkX, chunkZ); // StructureMineshaftStart
			} else if(args[1].equalsIgnoreCase("netherbridge")) {
				structureStart = new LStructureStarts.NetherBridge(world, rand, chunkX, chunkZ); // StructureNetherBridgeStart
			} else if(args[1].equalsIgnoreCase("biomefeature")) {
				structureStart = new LStructureStarts.BiomeFeature(world, rand, chunkX, chunkZ); // StructureScatteredFeatureStart
			} else if(args[1].equalsIgnoreCase("pyramid")) {
				structureStart = new LStructureStarts.BiomeFeature(world, rand, chunkX, chunkZ); // StructureScatteredFeatureStart
				WStructureComponent pyramid = new LComponentScatteredFeature.DesertPyramid(rand, chunkX * 16, chunkZ * 16);
				setStructureComponent(structureStart, pyramid);
			} else if(args[1].equalsIgnoreCase("temple")) {
				structureStart = new LStructureStarts.BiomeFeature(world, rand, chunkX, chunkZ); // StructureScatteredFeatureStart
				WStructureComponent temple = new LComponentScatteredFeature.JungleTemple(rand, chunkX * 16, chunkZ * 16);
				setStructureComponent(structureStart, temple);
			} else if(args[1].equalsIgnoreCase("hut")) {
				structureStart = new LStructureStarts.BiomeFeature(world, rand, chunkX, chunkZ); // StructureScatteredFeatureStart
				WStructureComponent hut = new LComponentScatteredFeature.SwampHut(rand, chunkX * 16, chunkZ * 16);
				setStructureComponent(structureStart, hut);
			} else if(args[1].equalsIgnoreCase("stronghold")) {
				structureStart = new LStructureStarts.Stronghold(world, rand, chunkX, chunkZ); // StructureStrongholdStart
			} else if (args[1].equalsIgnoreCase("village")) {
				int villageType = 0;

				if(flatWorld) {
					villageType = 1;
				} else {
					villageHack = true;
				}

				structureStart = new LStructureStarts.Village(world, rand, chunkX, chunkZ, villageType); // StructureVillageStart
			} else {
				player.sendError("Invalid structure specified.");
				return true;
			}
			
			player.sendMessage(player.getPrettyPos());

			if(structureStart.isValid()) {
				boundingBox = structureStart.getBoundingBox(); // structureStart.getBoundingBox()
			} else {
				player.sendError("Structure could not be initialized.");
				return true;
			}

			if(!boundingBox.isValid()) {
				player.sendError("Structure has no components.");
				return true;
			}

			if(flatWorld) {
				int oldMinY = boundingBox.getMinY();
				boundingBox.setMinY(world.getTopSolidOrLiquidBlock(WMathHelper.floor_double(player.getPosX()), WMathHelper.floor_double(player.getPosZ())));
				player.sendMessage("Adjusted settings for flat world type.");
				if((boundingBox.getMaxY() - boundingBox.getMinY()) < 10) {
					boundingBox.setMaxY(boundingBox.getMinY() + (boundingBox.getMaxY() - oldMinY));
					player.sendMessage("Expanding bounding box.");
				}
			}

			if(villageHack) {
				boundingBox.setMinY(boundingBox.getMinY() - 1); // boundingBox.minY (Fixes problem of villages/gardens missing first layer of blocks)
				if(boundingBox.getMinX() == boundingBox.getMaxX() - 5
					&& boundingBox.getMinY() == boundingBox.getMaxY() - 15
					&& boundingBox.getMinZ() == boundingBox.getMaxZ() - 5) {
				// boundingBox.minX, boundingBox.maxX, boundingBox.minY, boundingBox.maxY, boudingBox.minZ, boundingBox.maxZ
					player.sendError("Terrain unsuitable for village generation."); // (only well would be generated)
					return true;
				}
				int villageHeight = boundingBox.getMaxY() - boundingBox.getMinY(); // boundingBox.maxY, boundingBox.minY (Get village bounding box height)
				if(villageHeight >= 16 && boundingBox.getMaxY() < 127) {
					player.sendMessage("Expanding bounding box.");
					boundingBox.setMaxY(127); // boundingBox.maxY (Fix for houses having no roof)
				}
			}

			if(forceMin) {
				boundingBox.setMinY(1);
			}

			player.sendMessage("Generating structure.");
			try {
				player.sendMessage("Structure bounding box (min): " + boundingBox.getMinX() + ", " + boundingBox.getMinY() + ", " + boundingBox.getMinZ()); // minX, minY, minZ
				player.sendMessage("Structure bounding box (max): " + boundingBox.getMaxX() + ", " + boundingBox.getMaxY() + ", " + boundingBox.getMaxZ()); // maxX, maxY, maxZ
				structureStart.generateStructure(world, rand, boundingBox); // structureStart.generateStructure()
			} catch (Throwable t) { // Why catch such a broad range?? In case something goes seriously wrong.
				player.sendMessage("Structure generation failed.\n" + t.toString()); // In case player had modified structure classes
			}
		} else {
			player.sendError("Structure not specified.");
		}
		return true;
	}

	private static void setStructureComponent(WStructureStart structure, WStructureComponent component) {
		structure.clearComponents();
		structure.addComponent(component);
		structure.updateBoundingBox();
	}

}
