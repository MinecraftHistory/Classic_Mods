// TODO: re-write for multiple players

// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.plugin;

// Obfuscated references: 0

import java.util.List;
import java.util.ArrayList;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.wrapper.WBlock;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;

public class spc_paint extends Plugin {

	public int paintID = -1;
	public int paintDamage = 0;
	public boolean paint = false;
	private static int cooldown;
	private static final String usage = "Left-click to replace clicked block, right click to" + " place new block.";

	public spc_paint() {
		cooldown = 0;
		setTicking(true);
	}

	@Override
	public String getName() {
		return "Paint";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
			commands.add("paint");
			commands.add("trunksbomb");
			return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("paint")) {
			String[] help = new String[]{"Paints blocks.", "[blockid]", "stone"};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] s) {
		if(s[0].equalsIgnoreCase("trunksbomb")) {
			player.sendMessage("trunksbomb is the greatest.");
			return true;
		} else if(!s[0].equalsIgnoreCase("paint")) {
			return false;
		} else {

			if(!player.isPlayerFirst()) {
				player.sendError("Can only be used by first player.");
				return true;
			}

			// System.out.println("Paint command invoked.");
			if(paint && s.length == 1) {
				paint = false;
				int paintID = -1;
				paintDamage = 0;
				player.sendMessage("No longer painting.");
				return true;
			} else if(s.length <= 1) {
				player.sendError("Not enough parameters for paint command.");
				return true;
			} else {
				int newPaintID = -1;
				try {
					newPaintID = WBlock.getBlockID(s[1]);
				} catch (NullPointerException npe) {
					player.sendError("Couldn't resolve block ID.");
				}
				// System.out.println("Block to paint: " + newPaintID);
				if(newPaintID >= 0) {
					paint = true;
					if(s.length > 2) {
						try {
							paintDamage = Integer.parseInt(s[2]);
							if(paintDamage < 0 || paintDamage > 15) {
								player.sendMessage("Damage value clamped - must be 0-15");
								paintDamage = 0;
							}
						} catch (Exception e) {
							player.sendError("Not a valid damage value.");
						}
					} else {
						paintDamage = 0;
					}

					String blockName;
					if(newPaintID == 0) {
						blockName = "air";
					} else {
						WBlock tempBlock = new WBlock(WBlock.blocksList[newPaintID]);
						blockName = tempBlock.translateBlockName();
						System.out.println("DEBUG: block name - " + blockName);
						if(blockName.endsWith(".name")) {
							if(blockName.equals("tile.null.name")) {
								blockName = ((Integer)newPaintID).toString();
							} else {
								String fullBlockName = tempBlock.getBlockName();
								blockName = fullBlockName.substring(fullBlockName.indexOf(46) + 1);
							}
						}
					}

					paintID = newPaintID;

					String damageString = (paintDamage == 0?".":" with damage " + paintDamage + ".");
					player.sendMessage("Now painting " + blockName + damageString + " " + usage);
				} else {
					player.sendError("Invalid block name or ID");
				}

				return true;
			}
		}
	}

	@Override
	public void handleLeftClick(WPlayer player, WMovingObjectPosition o) {
		if(paint && player.isPlayerFirst()) {
			paintBlocks(player, o.blockx, o.blocky, o.blockz);
		}

	}

	@Override
	public void handleRightClick(WPlayer player, WMovingObjectPosition o) {
		if(paint && player.isPlayerFirst()) {
			paintBlocksRightClick(player, o);
		}

	}

	@Override
	public void atUpdate(WPlayer player) {
		if(!player.isPlayerFirst()) {
			return;
		}
		if(cooldown > 0) {
			cooldown--;
		}
	}

	public void paintBlocksRightClick(WPlayer player, WMovingObjectPosition mop) {
		if(cooldown <= 0) {
			cooldown = 3;

			if(!mop.isValid()) {
				return;
			}

			int side = mop.sidehit;
			int x = mop.blockx;
			int y = mop.blocky;
			int z = mop.blockz;

			if(side == 0) {
				y--;
			}

			if(side == 1) {
				y++;
			}

			if(side == 2) {
				z--;
			}

			if(side == 3) {
				z++;
			}

			if(side == 4) {
				x--;
			}

			if(side == 5) {
				x++;
			}

			paintBlocks(player, x, y, z);
		}
	}

	public void paintBlocks(WPlayer player, int i, int j, int k) {
		if(player.getWorld().getBlockId(i, j, k) != WBlock.getBlockID("bedrock")) { // getBlockId(), Block.bedrock.blockID
			player.getWorld().setBlockWithNotify(i, j, k, paintID); // setBlockWithNotify
		}

		player.getWorld().setBlockAndMetadataWithNotify(i, j, k, paintID, paintDamage); // setBlockAndMetadataWithNotify
	}
}
