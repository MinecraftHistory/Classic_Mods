// TODO: check if enchantments can be combined,
// as done with Minecraft's enchant command
// basically, go thru existing enchants and check canApplyTogether

// TODO: Use EnchantmentHelper for getting current enchants, etc.

package com.q3hardcore.console.plugin;

// From SinglePlayerCommands by simo_415

import java.util.List;
import java.util.ArrayList;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.wrapper.WEnchantment;
import com.q3hardcore.console.wrapper.WItem;
import com.q3hardcore.console.wrapper.WItemStack;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WStringTranslate;

public class spc_enchant extends Plugin {

	@Override
	public String getName() {
		return "Enchant";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
		commands.add("enchant");
		return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("enchant")) {
			String[] help = new String[]{"Enchants the currently selected item", "<list|remove|add TYPE [LEVEL]>", "add protection 10"};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] split) {
		if(split[0].equalsIgnoreCase("enchant")) {
			if(split.length < 2) {
				player.sendError(Helper.ERRMSG_PARAM);
				return true;
			}

			boolean force = true;
			boolean forceAdd = false;
			boolean forceRemove = false;
			if(split[1].equalsIgnoreCase("forceadd")) {
				forceAdd = true;
			} else if(split[1].equalsIgnoreCase("forceremove")) {
				forceRemove = true;
			} else {
				force = false;
			}

			WEnchantment[] enchantmentsList = WEnchantment.getEnchantmentsList();

			if(split[1].equalsIgnoreCase("list")) {
				String enchantmentName = "";

				boolean firstEnchant = false;
				for(int i = 0; i < enchantmentsList.length; i++) {
					if(enchantmentsList[i] != null) {
						WEnchantment tempEnchantment = enchantmentsList[i];
						if(!firstEnchant) {
							firstEnchant = true;
						} else {
							enchantmentName += ", ";
						}
						enchantmentName = enchantmentName + translateToLocal(tempEnchantment.getName()).replace(' ', '_') + " (" + i + ")";
					}
				}

				player.sendMessage("Enchantments [name (id)]:");
				player.sendMessage(enchantmentName);
				return true;
			}

			if(player.getInventory().getCurrentItem() == null) { // getCurrentItem
				player.sendError("No currently selected item");
				return true;
			}

			if(player.getInventory().getCurrentItem().isStackable() && !force) { // getCurrentItem, isStackable
				player.sendError("This item cannot be enchanted"); // note v() is isItemEnchantable
				return true;
			}

			if(split[1].equalsIgnoreCase("remove") || forceRemove) {
				if(player.getInventory().getCurrentItem().isItemEnchanted()) { // getCurrentItem, isItemEnchanted
					player.getInventory().getCurrentItem().setStackTagCompound(null); // stackTagCompound
					player.sendMessage("Enchantment(s) for the current item were removed");
				} else {
					player.sendMessage("Current item doesn\'t have any enchantments");
				}

				return true;
			}

			if(split.length < 3) {
				player.sendError(Helper.ERRMSG_PARAM);
				return true;
			}

			if(!split[1].equalsIgnoreCase("add") && !forceAdd) {
				player.sendError(Helper.ERRMSG_PARSE);
				return true;
			}

			int enchantmentId = -1;
			WEnchantment enchantment = null;

			try {
				enchantmentId = Integer.parseInt(split[2]);
				enchantment = enchantmentsList[enchantmentId];
			} catch (NumberFormatException nfe) {
				;
			} catch (Exception e) {
				player.sendError("Unknown enchantment id " + enchantmentId);
				return true;
			}

			for(int i = 0; i < enchantmentsList.length; i++) {
				WEnchantment tempEnchantment = enchantmentsList[i];
				if(tempEnchantment != null && split[2].equalsIgnoreCase(translateToLocal(tempEnchantment.getName()).replace(' ', '_'))) {
					enchantment = tempEnchantment;
				}
			}

			if(enchantment == null) {
				player.sendError("Could not find specified enchantment: " + split[2]);
				return true;
			}

			int enchantmentLevel = 1;
			if(split.length == 4) {
				try {
					enchantmentLevel = Integer.parseInt(split[3]);
				} catch (Exception e) {
					player.sendError(Helper.ERRMSG_PARSE);
					return true;
				}

				int maxLevel = enchantment.getMaxLevel();
				int minLevel = enchantment.getMinLevel();

				if(forceAdd)
					maxLevel = 127;

				if(enchantmentLevel > maxLevel) {
					player.sendMessage("Enchantment level " + enchantmentLevel + " was too high, clamping to " + maxLevel + ".");
					enchantmentLevel = maxLevel;
				} else if(enchantmentLevel < minLevel) {
					player.sendMessage("Enchantment level " + enchantmentLevel + " was too low, clamping to " + minLevel + ".");
					enchantmentLevel = minLevel;
				}
			}

			WItemStack itemStack = player.getInventory().getCurrentItem();

			if(!forceAdd) {
				WItem item = itemStack.getItem();
				if(item != null && !enchantment.canEnchantItem(item)) {
					player.sendError("Incorrect type of enchantment for item.");
					return true;
				}
			}

			itemStack.addEnchantment(enchantment, enchantmentLevel); // getCurrentItem, addEnchantment
			player.sendMessage("The " + enchantment.getTranslatedName(enchantmentLevel) + " enchantment was added to the current item.");
			return true;
		} else {
			return false;
		}
	}

	// TODO: move to ObfuscationHelper
	private String translateToLocal(String key) {
		return WStringTranslate.getInstance().a(key); // getInstance, translateKey (THIS IS ONLY OBFUSCATED CLASS NAME)
	}

}