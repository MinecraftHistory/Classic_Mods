package com.q3hardcore.console.plugin;

import com.q3hardcore.console.wrapper.WDamageSource;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.raw.RCommandBase;
import java.util.List;
import java.util.ArrayList;

public class spc_killplayer extends Plugin {

	@Override
	public String getName() {
		return "KillPlayer";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
		commands.add("killplayer");
		return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("killplayer")) {
			String[] help = new String[]{"Kills specified player.", "[playername]", "q3hardcore"};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] s) {
		if(!s[0].equalsIgnoreCase("killplayer")) {
			return false;
		} else {
			if(s.length < 2) {
				player.sendMessage("Must specify player.");
				return true;
			}
			WPlayer thePlayer; // EntityPlayerMP
			try {
				// OBFUSC_REF
				thePlayer = new WPlayer(RCommandBase.c(player.getMinecraftPlayer(), s[1])); // CommandBase
			} catch (Exception e) {
				player.sendError("Invalid player specified.");
				return true;
			}
			thePlayer.attackEntityFrom(WDamageSource.outOfWorld, 1000); // attackEntityFrom, DamageSource.outOfWorld
			return true;
		}
	}

}
