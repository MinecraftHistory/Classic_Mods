// From SinglePlayerCommands by simo_415

// SPC Plugin Continuation

package com.q3hardcore.console.plugin;

// Obfuscated references: 0

import java.util.List;

import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Side;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;

public abstract class Plugin {

	private boolean isEnabled = true;
	private boolean isTicking = false;

	@Side(EnumSide.CLIENT)
	private boolean ownerExclusive = false;

	public String getVersion() {
		return Helper.getServerVersion();
	}

	public abstract String getName();

	public boolean handleCommand(WPlayer player, String[] cmd) {
		return false;
	}

	public void handleLeftClick(WPlayer player, WMovingObjectPosition mop) {}

	public void handleRightClick(WPlayer player, WMovingObjectPosition mop) {}

	@Side(EnumSide.CLIENT)
	public void handleCUIEvent(String typeid, String[] parameters) {}

	public void atUpdate(WPlayer player) {}

	public List<String> getCommands() {
		return null;
	}

	public String[] getHelp(String commandname) {
		return null;
	}

	public final void setEnabled(boolean value) {
		isEnabled = value;
	}

	public final boolean getEnabled() {
		return isEnabled;
	}

	public final void setTicking(boolean value) {
		isTicking = value;
	}

	public final boolean getTicking() {
		return isTicking;
	}

	@Side(EnumSide.CLIENT)
	public final void setOwnerExclusive(boolean value) {
		ownerExclusive = value;
	}

	@Side(EnumSide.CLIENT)
	public final boolean getOwnerExclusive() {
		return ownerExclusive;
	}

}
