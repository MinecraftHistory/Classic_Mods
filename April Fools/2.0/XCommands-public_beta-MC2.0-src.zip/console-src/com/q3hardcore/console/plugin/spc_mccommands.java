package com.q3hardcore.console.plugin;
// Times re-obfuscated: 2 (Minecraft 1.4.1, 1.4.3)

import java.util.List;
import java.util.ArrayList;

import com.q3hardcore.console.util.ObfuscationHelper;
import com.q3hardcore.console.wrapper.WCommandBase;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.lists.LCommand;

public class spc_mccommands extends Plugin {

	private WCommandBase expCommand = new LCommand.Exp(); // CommandBase, CommandExp
	private WCommandBase difficultyCommand = new LCommand.Difficulty(); // CommandBase, CommandDifficulty
	private WCommandBase gamemodeCommand = new LCommand.GameMode(); // CommandBase, CommandGameMode
	private WCommandBase gameruleCommand = new LCommand.GameRule(); // CommandBase, CommandGameRule

	@Override
	public String getName() {
		return "MCCommands";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
		commands.add("difficulty");
		commands.add("gamemode");
		commands.add("gamerule");
		commands.add("xp");
		return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname == null) {
			return null;
		} else if (commandname.equals("xp")) {
			String[] help = new String[]{"Gives player specified amount of XP.", "<amount> [player]", "5000"};
			return help;
		} else if (commandname.equals("gamemode")) {
			String[] help = new String[]{"Sets player's gamemode.", "<mode> [player]", "adventure"};
			return help;
		} else if (commandname.equals("difficulty")) {
			String[] help = new String[]{"Sets difficulty level.", "<0-3> [player]", "1"};
			return help;
		} else if (commandname.equals("gamerule")) {
			String[] help = new String[]{"Sets game rules.", "<rule name> [value]", "keepInventory"};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] s) {
		if(s[0].equalsIgnoreCase("xp")) {
			ObfuscationHelper.handleMinecraftCommand(expCommand, player, s);
			return true;
		} else if(s[0].equalsIgnoreCase("gamemode")) {
			ObfuscationHelper.handleMinecraftCommand(gamemodeCommand, player, s);
			return true;
		} else if(s[0].equalsIgnoreCase("difficulty")) {
			ObfuscationHelper.handleMinecraftCommand(difficultyCommand, player, s);
			return true;
		} else if(s[0].equalsIgnoreCase("gamerule")) {
			ObfuscationHelper.handleMinecraftCommand(gameruleCommand, player, s);
			return true;
		} else {
			return false;
		}
	}

}
