// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.plugin;

// Obfuscated references: 0

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.wrapper.WBlock;
import com.q3hardcore.console.wrapper.WMathHelper;
import com.q3hardcore.console.wrapper.WPlayer;

public class spc_path extends Plugin {

	private HashMap<String, int[]> playerConfig = new HashMap<String, int[]>();

	public spc_path() {
		setTicking(true);
	}

	@Override
	public String getName() {
		return "Path";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
			commands.add("path");
			commands.add("paths");
			return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("path")) {
			String[] help = new String[]{"Creates a path.", "<blockid> [radius]", "stone"};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] args) {
		String senderName = player.getSenderName(); 

		if(args[0].equalsIgnoreCase("path")) {
			if(args.length > 1) {
				int block = -1;
				int size = 3;

				try {
					block = WBlock.getBlockID(args[1]);
				} catch (NullPointerException npe) {
					block = -1;
					player.sendError("Couldn't resolve block ID.");
					npe.printStackTrace();
				}

				if(args.length > 2) {
					try {
						size = Integer.parseInt(args[2]);
					} catch (NumberFormatException nfe) {
						size = 3;
					}
				}

				if(size <= 0) {
					player.sendError("Size must be greater than 0.");
					return true;
				}

				if(block > -1) {
					player.sendMessage("Path mode enabled.");
					playerConfig.put(senderName, new int[]{block, size, -1, -1, -1});
				} else {
					player.sendError("Unknown block.");
				}
			} else if(playerConfig.containsKey(senderName) && playerConfig.get(senderName)[0] > -1) {
				player.sendMessage("Path mode disabled.");
				playerConfig.get(senderName)[0] = -1;
			} else {
				player.sendMessage("Must specify block.");
			}

			return true;
		} else if(args[0].equalsIgnoreCase("paths")) {
			Iterator<String> players = playerConfig.keySet().iterator();
			if(!players.hasNext()) {
				player.sendMessage("no one making path!");
				return true;
			}
			while(players.hasNext()) {
				String plrName = players.next();
				player.sendMessage("player: " + plrName + ", who is making path of: " + playerConfig.get(plrName)[0]);
			}
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void atUpdate(WPlayer player) {
		String senderName = player.getSenderName();
		if(playerConfig.containsKey(senderName)) {
			int[] plrData = playerConfig.get(senderName);
			makePath(player, plrData);
		} else {
			return;
		}
	}

	private void makePath(WPlayer player, int[] data) {
		if(data[0] >= 0) { // block
			int x = WMathHelper.floor_double(player.getPosX()); // ph.ep.posX
			int y = WMathHelper.floor_double(player.getPosY()); // ph.ep.posY (used to take away 1)
			int z = WMathHelper.floor_double(player.getPosZ()); // ph.ep.posZ
			if(x != data[2] || y != data[3] || z != data[4]) { // prevx, prevy, prevz
				int start = data[1] * -1 + 1; // size

				for(int i = start; i < data[1]; ++i) {
					for(int j = -1; j < data[1]; ++j) {
						for(int k = start; k < data[1]; ++k) {
							if(j == -1) {
								setBlock(player, x + i, y + j, z + k, data[0]);
							} else {
								setBlock(player, x + i, y + j, z + k, 0);
							}
						}
					}
				}

				data[2] = x;
				data[3] = y;
				data[4] = z;
			}
		}
	}

	private void setBlock(WPlayer player, int i, int j, int k, int type) {
		player.getWorld().setBlockWithNotify(i, j, k, type);
		// new World(sender.getWorld().getRaw()).setBlockWithNotify(i, j, k, type);
		// ph.world.setBlockWithNotify()
	}
}
