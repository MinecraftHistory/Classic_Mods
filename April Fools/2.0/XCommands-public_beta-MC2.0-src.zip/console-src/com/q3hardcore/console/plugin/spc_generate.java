package com.q3hardcore.console.plugin;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.wrapper.WBlock;
import com.q3hardcore.console.wrapper.WMathHelper;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WWorldGenerator;
import com.q3hardcore.console.wrapper.lists.LWorldGen;
import com.q3hardcore.console.util.ObfuscationHelper;

public class spc_generate extends Plugin {
	
	private int[] offset = {0, 1, 0};
	private boolean genThere = true;
	private int treeHeight;
	private boolean invalidHeight = false;
	private int mineableBlock;
	private boolean invalidBlock = false;
	private List<String> structures = new ArrayList<String>();	

	@Override
	public String getName() {
		return "Generate";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
			commands.add("credits");
			commands.add("generate");
			return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("generate")) {
			String[] help = new String[]{"Generates structures.", "[structure]", "well"};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] s) {
		if(s[0].equalsIgnoreCase("credits")) {
			player.sendMessage("Console by q3hardcore");
			player.sendMessage("Special thanks to: simo_415");
			return true;
		} else if(!s[0].equalsIgnoreCase("generate")) {
			return false;
		} else {
			if(s.length <= 1) {
				player.sendError("Not enough parameters for generate command.");
				return true;
			} else {
				
				if(s[1].equalsIgnoreCase("list")) {
					if(structures.size() == 0) {
						System.out.println("Creating structure list.");
						structures.add("bigmushroom, bigmushroom1, bigmushroom2, bigtree, cactus,");
						structures.add("chest, clay, deadbush, dungeon, ferns, flower, foresttree,");
						structures.add("glowstone1, glowstone2, gravel, jungletree, lava, lavalake,");
						structures.add("mineable, mushroombrown, mushroomred, netherfire, netherlava,");
						structures.add("pumpkin, reeds, rose, sand, shrub, spikes, swamptree, ");
						structures.add("taigatree1, taigatree2, tallgrass, tree1, tree2, tree3, vines,");
						structures.add("water, waterlake, waterlily, well");
					}
					player.sendMessage("Structures:");
					for(String line : structures) {
						player.sendMessage(line);
					}
					return true;
				}
	
				int offsetIndex = -1;
				
				if(s[1].equalsIgnoreCase("xoffset")) {
					offsetIndex = 0;
				} else if(s[1].equalsIgnoreCase("yoffset")) {
					offsetIndex = 1;
				} else if(s[1].equalsIgnoreCase("zoffset")) {
					offsetIndex = 2;
				} else if(s[1].equalsIgnoreCase("mode")) {
					if(s.length > 2) {
						if(s[2].equals("0")) {
							genThere = false;
						} else if(s[2].equals("1")) {
							genThere = true;
						} else {
							player.sendError("Invalid generation mode specified.");
							return true;
						}
					}
					player.sendMessage("Generation mode: " + (genThere?"1":"0"));
					return true;
				}
					
				if(offsetIndex != -1) {
					if(s.length > 2) {
						try {
							offset[offsetIndex] = Integer.parseInt(s[2]);
							player.sendMessage("Offset updated.");
						} catch (NumberFormatException nfe) {
							player.sendError("Invalid number.");
						}
						return true;
					}
					
					player.sendMessage("Current offset value: " + offset[offsetIndex]);
					return true;
					
				}
			
				WWorldGenerator antiStructure; // WorldGenerator		
				int[] pos = new int[3];
				
				if(s.length > 4) {
					try {
						pos[0] = Integer.parseInt(s[2]);
						pos[1] = Integer.parseInt(s[3]);
						pos[2] = Integer.parseInt(s[4]);
						player.sendMessage("Using user-specified coordinates.");
					} catch (NumberFormatException nfe) {
						player.sendError("Invalid position specified.");
						return true;
					}
				} else if(genThere == true) {
					WMovingObjectPosition blockPos = player.rayTrace();
					if(blockPos.isValid()) {
						pos[0] = blockPos.blockx;
						pos[1] = blockPos.blocky;
						pos[2] = blockPos.blockz;
					} else {
						player.sendError("Point at a block.");
						return true;
					}
				} else {
					pos[0] = WMathHelper.floor_double(player.getPosX());
					pos[1] = WMathHelper.floor_double(player.getPosY());
					pos[2] = WMathHelper.floor_double(player.getPosZ());
				}
				
				for(int i=0; i < pos.length; i++) {
					if(pos[i] + offset[i] <= Integer.MAX_VALUE && pos[i] + offset[i] >= Integer.MIN_VALUE) {
						pos[i] += offset[i];
					}
				}
				
				int chunkX = pos[0] >> 4;
				int chunkZ = pos[2] >> 4;
								
				Random rand = new Random(player.getWorld().getSeed());
				long rand1 = rand.nextLong() / 2L * 2L + 1L;
				long rand2 = rand.nextLong() / 2L * 2L + 1L;
				rand.setSeed((long)chunkX * rand1 + (long)chunkZ * rand2 ^ player.getWorld().getSeed());

				if(s[1].equalsIgnoreCase("waterlily")) {
					antiStructure = new LWorldGen.Waterlily(); // WorldGenWaterlily
				} else if(s[1].equalsIgnoreCase("bigtree")) {
					antiStructure = new LWorldGen.BigTree(true); // WorldGenBigTree
				} else if(s[1].equalsIgnoreCase("foresttree")) {
					antiStructure = new LWorldGen.Forest(true); // WorldGenForest
				} else if(s[1].equalsIgnoreCase("chest")) {
					// OBFUSC_REF
					antiStructure = new LWorldGen.BonusChest(ObfuscationHelper.getBonusChestContent(), 10); // WorldGeneratorBonusChest
				} else if(s[1].equalsIgnoreCase("cactus")) {
					antiStructure = new LWorldGen.Cactus(); // WorldGenCactus
				} else if(s[1].equalsIgnoreCase("clay")) {
					antiStructure = new LWorldGen.Clay(4); // WorldGenClay
				} else if(s[1].equalsIgnoreCase("deadbush")) {
					antiStructure = new LWorldGen.DeadBush(WBlock.getBlockID("deadbush")); // WorldGenDeadBush
				} else if(s[1].equalsIgnoreCase("well")) {
					antiStructure = new LWorldGen.DesertWells(); // WorldGenDesertWells
				} else if(s[1].equalsIgnoreCase("flower")) {
					antiStructure = new LWorldGen.Flowers(WBlock.getBlockID("flower")); // WorldGenFlowers
				} else if(s[1].equalsIgnoreCase("rose")) {
					antiStructure = new LWorldGen.Flowers(WBlock.getBlockID("rose")); // WorldGenFlowers
				} else if(s[1].equalsIgnoreCase("mushroombrown")) {
					antiStructure = new LWorldGen.Flowers(WBlock.getBlockID("mushroomBrown")); // WorldGenFlowers
				} else if(s[1].equalsIgnoreCase("mushroomred")) {
					antiStructure = new LWorldGen.Flowers(WBlock.getBlockID("mushroomRed")); // WorldGenFlowers
				} else if(s[1].equalsIgnoreCase("shrub")) {
					antiStructure = new LWorldGen.Shrub(3, 0); // WorldGenShrub
				} else if(s[1].equalsIgnoreCase("netherfire")) {
					antiStructure = new LWorldGen.Fire(); // WorldGenFire
				} else if(s[1].equalsIgnoreCase("glowstone1")) {
					antiStructure = new LWorldGen.GlowStone1(); // WorldGenGlowStone1
				} else if(s[1].equalsIgnoreCase("netherlava")) {
					antiStructure = new LWorldGen.HellLava(WBlock.getBlockID("lavaMoving"), false); // WorldGenHellLava
				} else if(s[1].equalsIgnoreCase("bigmushroom")) {
					antiStructure = new LWorldGen.BigMushroom(); // WorldGenBigMushroom
				} else if(s[1].equalsIgnoreCase("bigmushroom1")) {
					antiStructure = new LWorldGen.BigMushroom(0); // WorldGenBigMushroom
				} else if(s[1].equalsIgnoreCase("bigmushroom2")) {
					antiStructure = new LWorldGen.BigMushroom(1); // WorldGenBigMushroom
				} else if(s[1].equalsIgnoreCase("lavalake")) {
					antiStructure = new LWorldGen.Lakes(WBlock.getBlockID("lavaStill")); // WorldGenLakes
				} else if(s[1].equalsIgnoreCase("waterlake")) {
					antiStructure = new LWorldGen.Lakes(WBlock.getBlockID("waterStill")); // WorldGenLakes
				} else if(s[1].equalsIgnoreCase("glowstone2")) {
					antiStructure = new LWorldGen.GlowStone2(); // WorldGenGlowStone2
				} else if(s[1].equalsIgnoreCase("jungletree")) {
					treeHeight = 10 + rand.nextInt(20);
					checkHeightSpecified(player, s);
					antiStructure = new LWorldGen.HugeTrees(true, treeHeight, 3, 3); // WorldGenHugeTrees
				} else if(s[1].equalsIgnoreCase("dungeon")) {
					antiStructure = new LWorldGen.Dungeons(); // WorldGenDungeons
				} else if(s[1].equalsIgnoreCase("mineable")) {
					mineableBlock = WBlock.getBlockID("dirt"); // dirt
					checkBlockSpecified(player, s);
					antiStructure = new LWorldGen.Minable(mineableBlock, 32); // WorldGenMinable
				} else if(s[1].equalsIgnoreCase("taigatree1")) {
					antiStructure = new LWorldGen.Taiga1(); // WorldGenTaiga1
				} else if(s[1].equalsIgnoreCase("pumpkin")) {
					antiStructure = new LWorldGen.Pumpkin(); // WorldGenPumpkin
				} else if(s[1].equalsIgnoreCase("reeds")) {
					antiStructure = new LWorldGen.Reed(); // WorldGenReed
				} else if(s[1].equalsIgnoreCase("sand")) {
					antiStructure = new LWorldGen.Sand(7, WBlock.getBlockID("sand")); // WorldGenSand
				} else if(s[1].equalsIgnoreCase("gravel")) {
					antiStructure = new LWorldGen.Sand(7, WBlock.getBlockID("gravel")); // WorldGenSand
				} else if(s[1].equalsIgnoreCase("spikes")) {
					antiStructure = new LWorldGen.Spikes(WBlock.getBlockID("whiteStone")); // WorldGenSpikes
				} else if(s[1].equalsIgnoreCase("water")) {
					antiStructure = new LWorldGen.Liquids(WBlock.getBlockID("waterMoving")); // WorldGenLiquids
				} else if(s[1].equalsIgnoreCase("lava")) {
					antiStructure = new LWorldGen.Liquids(WBlock.getBlockID("lavaMoving")); // WorldGenLiquids
				} else if(s[1].equalsIgnoreCase("taigatree2")) {
					antiStructure = new LWorldGen.Taiga2(true); // WorldGenTaiga2
				} else if(s[1].equalsIgnoreCase("swamptree")) {
					antiStructure = new LWorldGen.Swamp(); // WorldGenSwamp
				} else if(s[1].equalsIgnoreCase("tallgrass")) {
					antiStructure = new LWorldGen.TallGrass(WBlock.getBlockID("tallgrass"), 1); // WorldGenTallGrass
				} else if(s[1].equalsIgnoreCase("ferns")) {
					antiStructure = new LWorldGen.TallGrass(WBlock.getBlockID("tallgrass"), 2); // WorldGenTallGrass
				} else if(s[1].equalsIgnoreCase("tree1")) {
					antiStructure = new LWorldGen.Trees(true); // WorldGenTrees
				} else if(s[1].equalsIgnoreCase("tree2")) {
					treeHeight = 4 + rand.nextInt(7);
					checkHeightSpecified(player, s);
					antiStructure = new LWorldGen.Trees(false, treeHeight, 3, 3, true); // WorldGenTrees
				} else if(s[1].equalsIgnoreCase("tree3")) {
					treeHeight = 4 + rand.nextInt(7);
					checkHeightSpecified(player, s);
					antiStructure = new LWorldGen.Trees(true, treeHeight, 3, 3, false); // WorldGenTrees
				} else if(s[1].equalsIgnoreCase("vines")) {
					antiStructure = new LWorldGen.Vines(); // WorldGenVines
				} else {
					player.sendError("No such structure.");
					return true;
				}

				if(invalidHeight || invalidBlock) {
					// Don't generate structure if user specified invalid height or block.
					return true;
				}
				
				boolean result = false;
				try {
					result = antiStructure.generate(player.getWorld(), rand, pos[0], pos[1], pos[2]);
					// antiStructure.generate
				} catch (Exception e) {
					e.printStackTrace();
					player.sendError("Failed to generate structure.");
				}
				player.sendMessage("Generated at " + pos[0] + ", " + pos[1] + ", " + pos[2] + "? " + result);
				
				return true;
			}
		}
	}

	public void checkHeightSpecified(WPlayer player, String[] s) {
		invalidHeight = false;
		if(s.length > 2 && s.length != 5) {
			try {
				if(s.length > 5) {
					treeHeight = Integer.parseInt(s[5]);
				} else {
					treeHeight = Integer.parseInt(s[2]);
				}
				player.sendMessage("Using user-specified height.");
			} catch (NumberFormatException nfe) {
				player.sendError("Invalid tree height.");
				invalidHeight = true;
			}
		}
	}

	public void checkBlockSpecified(WPlayer player, String[] s) {
		invalidBlock = false;
		if(s.length > 2 && s.length != 5) {
			if(s.length > 5) {
				mineableBlock = WBlock.getBlockID(s[5]);
			} else {
				mineableBlock = WBlock.getBlockID(s[2]);
			}
			
			if(mineableBlock < 1) {
				player.sendError("Invalid block.");
				invalidBlock = true;
				return;
			}

			player.sendMessage("Using user-specified block.");
		}
	}



}
