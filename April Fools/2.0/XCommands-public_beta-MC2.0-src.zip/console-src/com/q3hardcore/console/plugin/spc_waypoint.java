package com.q3hardcore.console.plugin;

// Obfuscated references: 0

import java.util.AbstractMap.SimpleImmutableEntry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.q3hardcore.console.util.DeathPos;
import com.q3hardcore.console.wrapper.WChunkCoords;
import com.q3hardcore.console.wrapper.WChunkPosition;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.Coordinate;
import com.q3hardcore.console.wrapper.PosKey;

import com.q3hardcore.console.util.FontColour;

public class spc_waypoint extends Plugin {

	private HashMap<String, Coordinate> prevPositions = new HashMap<String, Coordinate>();

	@Override
	public String getName() {
		return "Waypoint";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
			commands.add("deathpositions");
			commands.add("gethome");
			commands.add("getspawn");
			commands.add("home");
			commands.add("markpos");
			commands.add("deathpos");
			commands.add("return");
			commands.add("setspawn");
			commands.add("sethome");
			commands.add("spawnpoint");
			commands.add("stronghold");
			commands.add("tp");
			return commands;
	}

	// TODO: finish documenting commands
	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("setspawn")) {
			String[] help = new String[]{"Set spawn point.", "x y z", "100 64 30"};
			return help;
		} else if(commandname != null && commandname.equals("stronghold")) {
			String[] help = new String[]{"Teleports player to nearest stronghold.", "", ""};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] s) {
		if(s[0].equalsIgnoreCase("setspawn")) {
			int spawnX;
			int spawnY;
			int spawnZ;

			if(s.length == 1) {
				spawnX = (int)player.getPosX(); // ph.ep.posX
				spawnY = (int)player.getPosY(); // ph.ep.posY
				spawnZ = (int)player.getPosZ(); // ph.ep.posZ
			} else {
				if(s.length != 4) {
					player.sendError("Must be in format X Y Z.");
					return true;
				}

				try {
					spawnX = (int)Double.parseDouble(s[1]);
					spawnY = (int)Double.parseDouble(s[2]);
					spawnZ = (int)Double.parseDouble(s[3]);
				} catch (Exception e) {
					player.sendError("Invalid position.");
					return true;
				}
			}

			int oldSpawnX = getSpawnX(player);
			int oldSpawnY = getSpawnY(player);
			int oldSpawnZ = getSpawnZ(player);
			String oldSpawn = "(Previously: " + oldSpawnX + "," + oldSpawnY + "," + oldSpawnZ + ")";

			player.getWorld().getWorldInfo().setSpawnPosition(spawnX, spawnY, spawnZ); // worldInfo.setSpawnPosition
			player.sendMessage("Spawn set at (" + spawnX + "," + spawnY + "," + spawnZ + ") " + oldSpawn);
			return true;
		} else if(s[0].equalsIgnoreCase("getspawn")) {
			int spawnX = getSpawnX(player); // ph.world.worldInfo.getSpawnX()
			int spawnY = getSpawnY(player); // ph.world.worldInfo.getSpawnY()
			int spawnZ = getSpawnZ(player); // ph.world.worldInfo.getSpawnZ()
			player.sendMessage("Current spawn position (" + spawnX + "," + spawnY + "," + spawnZ + ")");
			return true;
		} else if(s[0].equalsIgnoreCase("sethome")) {
			int homeX;
			int homeY;
			int homeZ;

			if(s.length == 1) {
				homeX = (int)player.getPosX(); // ph.ep.posX
				homeY = (int)player.getPosY(); // ph.ep.posY
				homeZ = (int)player.getPosZ(); // ph.ep.posZ
			} else {
				if(s.length != 4) {
					player.sendError("Must be in format X Y Z.");
					return true;
				}

				try {
					homeX = (int)Double.parseDouble(s[1]);
					homeY = (int)Double.parseDouble(s[2]);
					homeZ = (int)Double.parseDouble(s[3]);
				} catch (Exception e) {
					player.sendError("Invalid position.");
					return true;
				}
			}

			WChunkCoords chunkCoords = WChunkCoords.instantiate(homeX, homeY, homeZ);

			player.setSpawnChunk(chunkCoords, true);
			player.sendMessage("Home set at (" + homeX + "," + homeY + "," + homeZ + ")");
			return true;
		} else if(s[0].equalsIgnoreCase("gethome")) {
			WChunkCoords spawnChunk = getSpawnChunk(player); // ChunkCoordinates, ph.ep.getSpawnChunk
			if(spawnChunk.getRaw() == null) { // OBFUSC_REF
				player.sendError("Player has no home.");
				return true;
			}
			int spawnX = spawnChunk.posX; // posX
			int spawnY = spawnChunk.posY; // posY
			int spawnZ = spawnChunk.posZ; // posZ
			player.sendMessage("Current home position (" + spawnX + "," + spawnY + "," + spawnZ + ")");
			return true;
		} else if(s[0].equalsIgnoreCase("spawnpoint")) {
			setCurrentPosition(player);
			int spawnX = getSpawnX(player); // ph.world.worldInfo.getSpawnX()
			int spawnZ = getSpawnZ(player); // ph.world.worldInfo.getSpawnZ()
			int spawnY = player.getWorld().getTopSolidOrLiquidBlock(spawnX, spawnZ); // getTopSolidOrLiquidBlock
			teleportPlayerTo(player, (double)spawnX + 0.5D, (double)spawnY, (double)spawnZ + 0.5D);
			player.sendMessage("Teleported to spawn point.");
			return true;
		} else if(s[0].equalsIgnoreCase("home")) {
			setCurrentPosition(player);
			WChunkCoords spawnChunk = getSpawnChunk(player); // ChunkCoordinates, ph.ep.getSpawnChunk
			if(spawnChunk.getRaw() == null) { // OBFUSC_REF
				player.sendError("Player has no home.");
				return true;
			}
			teleportPlayerTo(player, (double)spawnChunk.posX + 0.5D, (double)spawnChunk.posY + 1.0D, (double)spawnChunk.posZ + 0.5D);
			// ph.ep.setLocationAndAngles((double)spawnChunk.posX + 0.5D, (double)spawnChunk.posY + 1.0D, (double)spawnChunk.posZ + 0.5D, 0.0F, 0.0F); // setLocationAndAngles
			player.sendMessage("Teleported home.");
			return true;
		} else if(s[0].equalsIgnoreCase("markpos")) {
			setCurrentPosition(player);
			player.sendMessage("Current position marked.");
			return true;
		} else if(s[0].equalsIgnoreCase("stronghold")) {
			WChunkPosition strongholdChunk = new WChunkPosition(player.getWorld().getRaw().b("Stronghold", (int)player.getPosX(), (int)player.getPosY(), (int)player.getPosZ())); // OBFUSC_REF
			if(strongholdChunk.y > -1) {
				setCurrentPosition(player);
				teleportPlayerTo(player, strongholdChunk.x, strongholdChunk.y, strongholdChunk.z);
				player.sendMessage("Teleported to nearest stronghold.");
			} else {
				player.sendError("Couldn't find stronghold.");
			}
			return true;
		} else if(s[0].equalsIgnoreCase("return")) {
			if(!prevPositions.containsKey(getPosKey(player))) {
				player.sendError("No position stored.");
				return true;
			}
			Coordinate prevPos = prevPositions.get(getPosKey(player));
			if(prevPos.getY() <= 0.0D) {
				player.sendError("Previous position is at: " + prevPos.toPrettyString());
				return true;
			}
			teleportPlayerTo(player, prevPos.getX(), prevPos.getY(), prevPos.getZ()); // was ph.ep.setPosition()
			setCurrentPosition(player);
			player.sendMessage("Returned to last position.");
			return true;
		} else if(s[0].equalsIgnoreCase("deathpos")) {
			SimpleImmutableEntry<Coordinate, Integer> posEntry = DeathPos.getPos(player.getUsername(), player.getWorld().getName());
			Coordinate deathPos = posEntry.getKey();
			if(deathPos.getY() <= 0.0D) {
				player.sendError("No position stored.");
				return true;
			}
			if(player.getDimension() != posEntry.getValue()) {
				player.sendError("Incorrect dimension!");
				return true;
			}
			setCurrentPosition(player);
			teleportPlayerTo(player, deathPos.getX(), deathPos.getY(), deathPos.getZ()); // was ph.ep.setPosition()
			return true;
		} else if(s[0].equalsIgnoreCase("deathpositions")) {
			HashMap<SimpleImmutableEntry<String, String>, SimpleImmutableEntry<Coordinate, Integer>> deathPositions = DeathPos.getDeathPositions();
			if(deathPositions.isEmpty()) {
				player.sendError("No death positions stored yet.");
				return true;
			}
			Iterator<SimpleImmutableEntry<String, String>> keys = deathPositions.keySet().iterator();
			player.sendMessage2(FontColour.GREEN + "===Death Positions========");
			while(keys.hasNext()) {
				SimpleImmutableEntry<String, String> entry = keys.next();
				String userName = entry.getKey();
				String worldName = entry.getValue();
				SimpleImmutableEntry<Coordinate, Integer> data = deathPositions.get(entry);
				Coordinate pos = data.getKey();
				int dimension = data.getValue();

				player.sendMessage2(FontColour.GREEN + "Player: " + FontColour.WHITE + userName
					+ FontColour.GREEN + " World: " + FontColour.WHITE + worldName);
				player.sendMessage2(FontColour.GREEN + "Dimension: " + FontColour.WHITE + dimension
					+ FontColour.GREEN + " Position: " + FontColour.WHITE + pos.toPrettyString());
				if(keys.hasNext()) {
					player.sendMessage2(FontColour.GREEN + "--------------------------");
				}
			}
			player.sendMessage2(FontColour.GREEN + "==========================");
			return true;
		} else if(s[0].equalsIgnoreCase("tp")) {
			if(s.length > 3) {
				double x;
				double y;
				double z;
				try {
					x = Double.parseDouble(s[1]);
					y = Double.parseDouble(s[2]);
					z = Double.parseDouble(s[3]);
				} catch (Exception e) {
 					player.sendError("Invalid position.");
					return true;
				}
				setCurrentPosition(player);
				teleportPlayerTo(player, x, y, z); // was ph.ep.setPosition()
			} else {
				player.sendError("Position must be in format X Y Z.");
			}
			return true;
		} else {
			return false;
		}
	}

	public static int getSpawnX(WPlayer player) {
		return player.getWorld().getSpawnX();
	}

	public static int getSpawnY(WPlayer player) {
		return player.getWorld().getSpawnY();
	}

	public static int getSpawnZ(WPlayer player) {
		return player.getWorld().getSpawnZ();
	}

	private void teleportPlayerTo(WPlayer player, double x, double y, double z) {
		player.setPositionAndUpdate(x, y, z); // setPositionAndUpdate
	}

	private void setCurrentPosition(WPlayer player) {
		prevPositions.put(getPosKey(player), player.getPosition());
	}

	private WChunkCoords getSpawnChunk(WPlayer player) {
		return player.getSpawnChunk();
	}

	private String getPosKey(WPlayer player) {
		return new PosKey(player.getSender().getCommandSenderName(), player.getWorld().getName(), player.getDimension()).toString();
	}

}
