package com.q3hardcore.console.plugin;

import java.util.List;
import java.util.ArrayList;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.wrapper.WEntity;
import com.q3hardcore.console.wrapper.WEntityLiving;
import com.q3hardcore.console.wrapper.WEntityPlayer;
import com.q3hardcore.console.wrapper.WEntityRenderer;
import com.q3hardcore.console.wrapper.WItemStack;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.lists.LEntities;

public class spc_mobcmds extends Plugin {

	@Override
	public String getName() {
		return "Mob commands";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
		commands.add("lenditem");
		commands.add("lendarmor");
		commands.add("liberatearmor");
		commands.add("liberateitem");
		commands.add("hurtmob");
		return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname == null) {
			return null;
		}
		String[] help;
		if(commandname.equals("liberatearmor")) {
			help = new String[]{"Gives player a copy of mob's armor.", "", ""};
			return help;
		} else if(commandname.equals("liberateitem")) {
			help = new String[]{"Gives player a copy of mob's item.", "", ""};
			return help;
		} else if(commandname.equals("lendarmor")) {
			help = new String[]{"Gives mob a copy of player's armor.", "", ""};
			return help;
		} else if(commandname.equals("lenditem")) {
			help = new String[]{"Gives mob a copy of player's item.", "", ""};
			return help;
		} else if(commandname.equals("hurtmob")) {
			help = new String[]{"Damage mob that player is pointing at.", "[lightning]", ""};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] split) {
		if(split[0].equals("liberateitem")) {
			boolean eraseItems = false;
			if(split.length > 1 && split[1].equals("erase")) {
				eraseItems = true;
			}
			WMovingObjectPosition test = WEntityRenderer.getMouseOver(player, 1.0F);
			if(test.getEntity() != null) {
				// Entity entity = test.getEntity();
				WEntityLiving entityLiving = WEntityLiving.instantiate(test.getEntity());
				if(entityLiving != null) {
					if(entityLiving.getHeldItem() != null) {
						// ItemStack itemStack = new ItemStack(entityLiving.bG());
						WItemStack itemStack = entityLiving.getHeldItem();
						if(!itemStack.isStackable() || itemStack.getStackSize() > itemStack.getMaxStackSize()) {
							player.sendMessage("Limiting stack size.");
							itemStack.setStackSize(1);
						}
						if(itemStack.getStackSize() <= 0) {
							player.sendMessage("Correcting stack size.");
							itemStack.setStackSize(1);
						}
						player.addItemStackToInventory(itemStack.copy());
						if(eraseItems) {
							entityLiving.setCurrentItemOrArmor(0, null);
						}
					} else {
						player.sendError("Mob not holding item.");
					}
				} else {
					player.sendError("Entity cannot hold item.");
				}
			} else {
				player.sendError("Couldn't find entity.");
			}
			return true;
		} else if(split[0].equals("liberatearmor")) {
			boolean eraseItems = false;
			if(split.length > 1 && split[1].equals("erase")) {
				eraseItems = true;
			}
			WMovingObjectPosition test = WEntityRenderer.getMouseOver(player, 1.0F);
			if(test.getEntity() != null) {
				WEntityLiving entityLiving = WEntityLiving.instantiate(test.getEntity());
				if(entityLiving != null) {
					boolean shownMessage = false;
					boolean shownMessage2 = false;
					int emptySlots = 0;
					for(int i = 0; i < 4; i++) {
						if(entityLiving.getCurrentArmor(i) == null) {
							emptySlots++;
							continue;
						}
						WItemStack itemStack = entityLiving.getCurrentArmor(i);
						if(!itemStack.isStackable()) {
							if(!shownMessage) {
								player.sendMessage("Limiting stack sizes.");
								shownMessage = true;
							}
							itemStack.setStackSize(1);
						}
						if(itemStack.getStackSize() <= 0) {
							if(!shownMessage2) {
								player.sendMessage("Correcting stack size.");
								shownMessage2 = true;
							}
							itemStack.setStackSize(1);
						}
						player.addItemStackToInventory(itemStack.copy());
						if(eraseItems) {
							entityLiving.setCurrentItemOrArmor(i + 1, null);
						}
					}
					if(emptySlots == 4) {
						player.sendError("Mob doesn't have armor.");
					}
				} else {
					player.sendError("Entity cannot have armour.");
				}
			} else {
				player.sendError("Couldn't find entity.");
			}
			return true;
		} else if(split[0].equals("lendarmor")) {
			WMovingObjectPosition test = WEntityRenderer.getMouseOver(player, 1.0F);
			if(test.getEntity() != null) {
				WEntityLiving entityLiving = WEntityLiving.instantiate(test.getEntity());
				if(entityLiving != null) {
					int slotOffset = 1;
					if(WEntityPlayer.isEntityInstance(entityLiving)) { // EntityPlayer
						slotOffset = 0;
					}
					for(int i = 0; i < 4; i++) {
						if(!player.getInventory().getArmorInventory()[i].isValid()) {
							continue;
						}
						entityLiving.setCurrentItemOrArmor(i + slotOffset, player.getInventory().getArmorInventory()[i]);
					}
					player.sendMessage("Lent armor to mob.");
				} else {
					player.sendError("Entity cannot have armour.");
				}
			} else {
				player.sendError("Couldn't find entity.");
			}
			return true;
		} else if(split[0].equals("lenditem")) {
			WMovingObjectPosition test = WEntityRenderer.getMouseOver(player, 1.0F);
			if(test.getEntity() != null) {
				WEntityLiving entityLiving = WEntityLiving.instantiate(test.getEntity());
				if(entityLiving != null) {
					if(player.getCurrentItem() != null) {
						if(WEntityPlayer.isEntityInstance(entityLiving)) { // EntityPlayer
							// ((sf)entityLiving).bK.a(player.getCurrentItem().copy().getRaw()); // OBFUSC_REF
							player.sendError("You can't lend an item to another player! ;)");
							return true;
						} else {
							entityLiving.setCurrentItemOrArmor(0, player.getCurrentItem());
						}
						player.sendMessage("Lent item to mob.");
					} else {
						player.sendMessage("No item to lend.");
					}
				} else {
					player.sendError("Entity cannot have item.");
				}
			} else {
				player.sendError("Couldn't find entity.");
			}
			return true;
		} else if(split[0].equals("hurtmob")) {
			boolean lightning = false;
			if(split.length > 1) {
				if(split[1].equals("lightning")) {
					lightning = true;
				}
			}
			WMovingObjectPosition test = WEntityRenderer.getMouseOver(player, 1.0F);
			if(test.getEntity() != null) {
				WEntity mob = test.getEntity();
				// sendMessage("Yay!");
				if(lightning) {
					WEntity entityLightningBolt = new LEntities.LightningBolt(player.getWorld(), mob.getPosX(), mob.getPosY(), mob.getPosZ());
					player.getWorld().addWeatherEffect(entityLightningBolt); // Minecraft.theWorld.addWeatherEffect
				} else {
					mob.kill();
				}
			} else {
				player.sendError("Couldn't find entity.");
			}
			return true;
		} else {
			return false;
		}
	}

}