package com.q3hardcore.console.plugin;

import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.wrapper.WNBTTagCompound;
import com.q3hardcore.console.wrapper.WPlayer;
import java.lang.reflect.Field;
import java.util.List;
import java.util.ArrayList;
import net.minecraft.src.ConsoleHelper;

public class spc_abilities extends Plugin {

	@Override
	public String getName() {
		return "Abilities";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
		commands.add("flyspeed");
		commands.add("mayfly");
		commands.add("walkspeed");
		return commands;
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] split) {
		final WNBTTagCompound playerData = new WNBTTagCompound();
		player.getCapabilities().writeCapabilitiesToNBT(playerData);
		final WNBTTagCompound abilities = playerData.getCompoundTag("abilities");
		if(split[0].equals("mayfly")) {
			final boolean mayFly = !abilities.getBoolean("mayfly");
			abilities.setBoolean("mayfly", mayFly);
			playerData.setTag("abilities", abilities);
			player.getCapabilities().readCapabilitiesFromNBT(playerData);
			player.sendPlayerAbilities();
			player.sendMessage("May fly?: " + (mayFly?"true":"false"));
			return true;
		} else if(split[0].equals("walkspeed")) {
			if(split.length < 2) {
				float walkSpeed = player.getCapabilities().getWalkSpeed();
				player.sendMessage("Current speed: " + walkSpeed);
				return true;
			} else {
				float newSpeed;

				try {
					newSpeed = Float.parseFloat(split[1]);
				} catch (NumberFormatException nfe) {
					if(split[1].equals("default")) {
						newSpeed = 0.1F;
					} else {
						player.sendError("Invalid speed specified.");
						return true;
					}
				}

				if(newSpeed > 1 || newSpeed < -1) {
					player.sendError("Number must be between -1 and 1.");
					return true;
				}
				
				if((newSpeed < 0.1F && newSpeed > 0.0F) || (newSpeed > -0.1F && newSpeed < 0.0F)) {
					player.sendError("Specified value is unsafe.");
					return true;
				}
	
				// Minecraft.getMinecraft().getThePlayer().getCapabilities().b(newSpeed);
				abilities.setFloat("walkSpeed", newSpeed);
				playerData.setTag("abilities", abilities);
				player.getCapabilities().readCapabilitiesFromNBT(playerData);
				// player.getCapabilities().setWalkSpeed(newSpeed);
				player.sendPlayerAbilities();
				player.sendMessage("Speed changed to: " + newSpeed);
				player.sendError("FOV may appear incorrect.");
			}
			return true;
		} else if(split[0].equals("flyspeed")) {
			if(split.length < 2) {
				float flySpeed = player.getCapabilities().getFlySpeed();
				player.sendMessage("Current speed: " + flySpeed);
			} else {
				float newSpeed;

				try {
					newSpeed = Float.parseFloat(split[1]);
				} catch (NumberFormatException nfe) {
					if(split[1].equals("default")) {
						newSpeed = 0.05F;
					} else {
						player.sendError("Invalid speed specified.");
						return true;
					}
				}

				if(newSpeed > 0.5 || newSpeed < -0.5) {
					player.sendError("Number must be between -0.5 and 0.5.");
					return true;
				}

				// Minecraft.getMinecraft().getThePlayer().getCapabilities().b(newSpeed);
				abilities.setFloat("flySpeed", newSpeed);
				playerData.setTag("abilities", abilities);
				player.getCapabilities().readCapabilitiesFromNBT(playerData);
				// player.getCapabilities().setFlySpeed(newSpeed);
				player.sendPlayerAbilities();
				player.sendMessage("Speed changed to: " + newSpeed);
			}
			return true;
		} else {
			return false;
		}
	}

}