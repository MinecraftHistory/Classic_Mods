package com.q3hardcore.console.plugin;

import com.q3hardcore.console.proxy.Proxy;
import com.q3hardcore.console.wrapper.WBlock;
import com.q3hardcore.console.wrapper.WEntityList;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;

import java.util.ArrayList;
import java.util.List;

// Obfuscated class references
import net.minecraft.src.aqt; // TileEntity
import net.minecraft.src.aqn; // TileEntityMobSpawner
// import net.minecraft.src.zm; // AbstractSpawner

public class spc_spawner extends Plugin {

	@Override
	public String getName() {
		return "Spawner";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
			commands.add("spawner");
			return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("spawner")) {
			String[] help = new String[]{"Edits mob spawner.", "[mob]", "Creeper"};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] split) {
		if(split[0].equals("spawner")) {
			if(split.length < 2) {
				player.sendError("No entity specified.");
				return true;
			}
			//SPCObjectHit soh = getObjectHit();
			WMovingObjectPosition soh = player.rayTrace();
			if(soh == null || player.getWorld().getBlockId(soh.blockx, soh.blocky, soh.blockz) == 0) { // getBlockId
				player.sendError("Your cursor needs to be hitting a block.");
				return true;
			}

			if(player.getWorld().getBlockId(soh.blockx, soh.blocky, soh.blockz) != WBlock.getBlockID("mobSpawner")) { // theWorld.getBlockId != Block.mobSpawner.blockID
				player.sendError("Not pointing at a mob spawner block.");
				return true;                    
			}

			int entityID;

			if(WEntityList.getStringtoIDMapping().containsKey(split[1])) { // EntityList.stringToIDMapping
				entityID = WEntityList.getStringtoIDMapping().get(split[1]);
			} else {
				player.sendError("Invalid entity specified.");
				return true;
			}

			if(!WEntityList.entityEggsContainsKey(entityID) && !split[1].equals("SnowMan") && !split[1].equals("VillagerGolem")) { // EntityList.entityEggs
				player.sendError("Entity not allowed.");
				return true;
			}

			aqt tileEntity = player.getWorld().getBlockTileEntity(soh.blockx, soh.blocky, soh.blockz); // TileEntity, getBlockTileEntity
			if ((tileEntity != null) && ((tileEntity instanceof aqn))) { // instanceof TileEntityMobSpawner
				aqn mobSpawner = (aqn)tileEntity; // TileEntityMobSpawner
				mobSpawner.a().a(split[1]); // setMobID
				if(!Proxy.INSTANCE.updateClientSpawner(player, soh, split[1])) {
					player.sendMessage("You will need to disconnect and reconnect to fix spawner.");
				}
				player.sendMessage("Now spawning: " + mobSpawner.a().e()); // mobSpawner.getMobID()
			} else {
				player.sendError("Couldn't change Mob ID.");
			}
			return true;
		} else {
			return false;
		}
	}

}
