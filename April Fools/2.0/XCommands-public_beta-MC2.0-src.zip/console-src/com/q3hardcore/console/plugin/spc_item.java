// TODO: add lore

package com.q3hardcore.console.plugin;

import com.q3hardcore.console.wrapper.WItemStack;
import com.q3hardcore.console.wrapper.WNBTTagCompound;
import com.q3hardcore.console.wrapper.WPlayer;
import java.util.List;
import java.util.ArrayList;

public class spc_item extends Plugin {

	@Override
	public String getName() {
		return "Item Tools";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
		commands.add("item");
		return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		String[] help = null;
		if(commandname == null) {
			System.out.println("Command name was null.");
		} else if(commandname.equals("item")) {
			help = new String[]{"Tools for currently held item.", "[name|clearname|cleartag]", "name Best Sword"};
		}
		return help;
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] split) {
		if(split[0].equals("item")) {
			WItemStack itemstack = player.getCurrentItem(); // ItemStack, getCurrentItem

			if(itemstack == null) {
				player.sendError("No item currently selected.");
				return true;
			}

			if(split.length < 2) {
				String itemInfo = itemstack.getItemID() + "";
				int damage = itemstack.getItemDamage();
				if(damage != 0) {
					itemInfo += " (damage="+damage+")";
				}
				player.sendMessage("Current item ID: " + itemInfo);
			} else {
				if(split[1].equals("name") || split[1].equals("clearname")) {
					boolean clearName = split[1].equals("clearname");
					WNBTTagCompound nbttagcompound = getDisplayTag(itemstack);

					if(split.length < 3 || clearName) {
						if(nbttagcompound.hasKey("Name")) {
							if(clearName) {
								nbttagcompound.removeTag("Name");
								player.sendMessage("Removed name.");
							} else {
								player.sendMessage("Current name: " + nbttagcompound.getString("Name"));
							}
							return true;
						} else {
							player.sendError("Item has no name!");
							return true;
						}
					}
					String newName = split[2];
					if(split.length > 3) {
						for(int i = 3; i < split.length; i++) {
							if(i < split.length) {
								newName += " ";
							}
							newName += split[i];
						}
					}
					nbttagcompound.setString("Name", newName); // setString
					itemstack.getStackTagCompound().setTag("display", nbttagcompound); // stackTagCompound
					player.sendMessage("Set name to: " + newName);
				} else if(split[1].equals("cleartag")) {
					itemstack.setStackTagCompound(null);
					player.sendMessage("Item tag reset.");
				} else {
					player.sendError("Unknown item command.");
					return true;
				}
			}
			return true;
		} else {
			return false;
		}
	}

	private WNBTTagCompound getDisplayTag(WItemStack itemstack) {
		WNBTTagCompound displayTag;
		if(itemstack.getStackTagCompound() != null && itemstack.getStackTagCompound().hasKey("display")) { // stackTagCompound, hasKey
			displayTag = itemstack.getStackTagCompound().getCompoundTag("display"); // getCompoundTag
		} else {
			WNBTTagCompound itemtagcompound = itemstack.getStackTagCompound();
			if(itemtagcompound == null) { // stackTagCompound
				itemtagcompound = WNBTTagCompound.instantiate();
			}
			displayTag = WNBTTagCompound.instantiate();
			itemtagcompound.getRaw().a("display", displayTag.getRaw());
			itemstack.setStackTagCompound(itemtagcompound);
		}
		return displayTag;
	}

}