// Console commands

package com.q3hardcore.console.plugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator; // For commands
import java.util.List;
import java.util.Random; // For spawn
import java.util.Set;

import com.q3hardcore.console.core.CommandList;
import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.core.PluginCommands;
import com.q3hardcore.console.util.ObfuscationHelper;
import com.q3hardcore.console.wrapper.WBlock;
import com.q3hardcore.console.wrapper.WDamageSource;
import com.q3hardcore.console.wrapper.WItem;
import com.q3hardcore.console.wrapper.WEntity;
import com.q3hardcore.console.wrapper.WEntityList;
import com.q3hardcore.console.wrapper.WEntityLiving;
import com.q3hardcore.console.wrapper.WEnumMovingObjectType;
import com.q3hardcore.console.wrapper.WItemStack;
import com.q3hardcore.console.wrapper.WMathHelper;
import com.q3hardcore.console.wrapper.WMinecraftServer;
import com.q3hardcore.console.wrapper.WNBTTagCompound;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WWorldProvider;
import com.q3hardcore.console.wrapper.WEntityRenderer;

public class spc_commands extends Plugin {

	private static final boolean useCoreModule = true;

	@Override
	public String getName() {
		return "Commands";
	}

	@Override
	public List<String> getCommands() {
		List<String> cmds = new ArrayList<String>();
		for(String cmd : CommandList.CMDS.keySet()) {
			cmds.add(cmd);
		}
		return cmds;
	}

	@Override
	public String[] getHelp(String commandName) {
		return CommandList.CMDS.get(commandName);
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] split) {
		String str = "";
		for(int i = 0; i < split.length; i++) {
			str += split[i];
			if(i != split.length-1) {
				str += " ";
			}
		}
		if(useCoreModule) { // Check to see if command should be processed
			split[0] = split[0].toLowerCase();
			if (split[0].equals("oldhelp")) {
				player.sendMessage("~Commands~");
				player.sendMessage("structure [mineshaft, stronghold, netherbridge, village]");
				player.sendMessage("Generates specified structure in current chunk.");
				player.sendMessage("");
				player.sendMessage("give [itemid] <amount> <damage> - gives item specified");
				player.sendMessage("For example, 'give 1 3' gives you 3 stone.");
				player.sendMessage("");
				player.sendMessage("blockid [block] - finds block ID, biome - displays biome");
				player.sendMessage("tp X Y Z - teleports player to specified position");
				player.sendMessage("clearchat - clears messages, pos - prints position");
			} else if(split[0].equals("hunger")) {
				if(split.length == 1) {
					player.sendMessage("Current food level: " + player.getFoodLevel()); // foodStats.getFoodLevel
					return true;
				}

				int foodLevel;

				if(split[1].equalsIgnoreCase("empty")) {
					foodLevel = 0;
				} else if(split[1].equalsIgnoreCase("full")) {
					foodLevel = 20;
				} else if(split[1].equalsIgnoreCase("inf") || split[1].equalsIgnoreCase("infinite")){
					foodLevel = 32768;
				} else {
					try {
						foodLevel = Integer.parseInt(split[1]);
					} catch (Exception e) {
						player.sendError(Helper.ERRMSG_PARSE);
						return true;
					}

				}

				player.setFoodLevel(foodLevel); // foodStats.setFoodLevel
				player.sendMessage("Hunger level set to " + split[1] + "(" + foodLevel + ")");
			} else if(split[0].equals("feed")) {
				if(split.length < 2) {
					player.sendError(Helper.ERRMSG_PARAM);
					return true;
				}

				int feedAmount;

				try {
					feedAmount = Integer.parseInt(split[1]);
				} catch (Exception e) {
					player.sendError(Helper.ERRMSG_PARSE);
					return true;
				}

				player.getFoodStats().addStats(feedAmount, 1.2F);
				// player.setFoodLevel(player.getFoodLevel() + feedAmount); // foodStats.setFoodLevel
				player.sendMessage("Food level set to " + player.getFoodLevel()); // foodStats.getFoodLevel
			} else if(split[0].equals("drops")) {
				player.sendMessage("Item drops enabled: " + Helper.toggleItemDrops());
			} else if(split[0].equals("time")) {
				if(split.length > 1 && split[1].equalsIgnoreCase("get")) {
					player.sendMessage(player.getWorld().getPrettyTime());
				}

				if(split.length > 2) {
					byte type = -1;

					if(split[2].equalsIgnoreCase("day")) {
						type = 2;
					} else if(split[2].equalsIgnoreCase("hour")) {
						type = 1;
					} else if(split[2].equalsIgnoreCase("minute")) {
						type = 0;
					}

					if(type == -1) {
						player.sendError("Invalid time command: " + split[2]);
						return true;
					}

					int day = player.getWorld().getFormattedTime()[2];
					int minute = player.getWorld().getFormattedTime()[0];
					int hour = player.getWorld().getFormattedTime()[1];

					if(split[1].equalsIgnoreCase("get")) {
						player.sendMessage(split[2].toUpperCase() + ": " + player.getWorld().getFormattedTime()[type]);
					} else if(split[1].equalsIgnoreCase("set") && split.length > 3) {
						int val;

						try {
							val = Integer.parseInt(split[3]);
						} catch (Exception e) {
							player.sendError(Helper.ERRMSG_PARSE);
							return true;
						}

						if(val < 0) {
							return true;
						}

						if(type == 0) {
							val = (int)((double)(val % 60) / 60.0D * 1000.0D);
							player.getWorld().setTime((long)(day * 24000 + hour * 1000 + val));
						} else if(type == 1) {
							val = val % 24 * 1000;
							player.getWorld().setTime((long)((double)(day * 24000 + val) + (double)minute / 60.0D * 1000.0D));
						} else {
							if(type != 2) {
								player.sendError("Invalid time command: " + split[2]);
								return true;
							}

							val *= 24000;
							player.getWorld().setTime((long)((double)(val + hour * 1000) + (double)minute / 60.0D * 1000.0D));
						}

						player.sendMessage(player.getWorld().getPrettyTime());
					}
				} else if(split.length == 2) {
					int day = player.getWorld().getFormattedTime()[2];
					if(split[1].equalsIgnoreCase("day")) {
						player.getWorld().setTime((long)((day + 1) * 24000));
						player.sendMessage(player.getWorld().getPrettyTime());
					} else if(split[1].equalsIgnoreCase("night")) {
						player.getWorld().setTime((long)(day * 24000 + 13000));
						player.sendMessage(player.getWorld().getPrettyTime());
					}
				} else {
					player.sendMessage(player.getWorld().getPrettyTime()); // Maybe put this at if statement?
				}
			} else if (split[0].equals("seed")) {
				player.sendMessage("Current seed: " + player.getWorld().getSeed());
			} else if (split[0].equals("togglehellworld")) {
				WWorldProvider provider = player.getWorld().getWorldProvider();
				provider.setHellWorld(!provider.isHellWorld());
				player.sendMessage("Placing water allowed: " + !provider.isHellWorld());
			} else if (split[0].equals("heal")) {
				player.getRaw().b(20); // OBFUSC_REF
			} else if (split[0].equals("kill")) {
				/* NOTES ON KILL COMMAND
					- Can cause game to crash (if we're storing items)
					- Code from CommandKill
				*/
				player.attackEntityFrom(WDamageSource.outOfWorld, 1000); // Method used by Minecraft, DamageSource.outOfWorld, 1000
			} else if (split[0].equals("dimension")) { // Still not really done..
				if(split.length < 2) {
					player.sendMessage("Current dimension: " + player.getWorld().getWorldType()); // theWorld.worldProvider.worldType
				} else {
					int dimension;
					try {
						dimension = Integer.parseInt(split[1]);
					} catch(Exception e) {
						player.sendError("Must specify a number.");
						return true;
					}
					if(WWorldProvider.getProviderForDimension(dimension) == null) { // WorldProvider.getProviderForDimension
						player.sendError("Invalid dimension.");
						return true;
					}
					if(dimension == -1 && player.getWorld().getWorldType() == -1) {
						player.sendError("Already in Nether.");
						return true;
					}
					if(dimension == 0 && player.getWorld().getWorldType() == 0) {
						player.sendError("Already in Overworld.");
						return true;
					}
					if(dimension == 1 && player.getWorld().getWorldType() == 1) {
						player.sendError("Already in End.");
						return true;
					}
					if(dimension == 0 && player.getWorld().getWorldType() == 1) {
						dimension = 1;
						player.sendMessage("Returing to Overworld.");
					}
					player.getMinecraftPlayer().c(dimension); // travelToDimension
				}
			} else if(split[0].equals("serverinfo")) {
				player.sendMessage("Server version: " + WMinecraftServer.getServer().getVersion()); // getServer().getVersion()
			} else if(split[0].equals("reach")) {
				if(split.length < 2) {
					player.sendMessage("Current reach distance: " + player.getReachDistance());
				} else {
					float reachDistance;
					try {
						reachDistance = Float.parseFloat(split[1]);
					} catch (NumberFormatException nfe) {
						player.sendError(Helper.ERRMSG_PARSE);
						return true;
					}
					boolean success = player.setReachDistance(reachDistance);
					player.sendMessage(success?"Reach distance set to " + reachDistance:"Reach distance must be from 4.5 - 255");
					if(success) {
						player.sendClientMessage("REACH", reachDistance);
					}
				}
			} else if(split[0].equals("platform")) {
				final int x = WMathHelper.floor_double(player.getPosX());
				final int y = WMathHelper.floor_double(player.getPosY()) - 1;
				final int z = WMathHelper.floor_double(player.getPosZ());
				player.getWorld().setBlockWithNotify(x, y, z, WBlock.getBlockID("glass"));
				// world.setBlockWithNotify, player.getPosX(), player.getPosY(), player.getPosZ(), Block.glass.blockID (set block below player to glass)
			} else if (split[0].equals("god")) {
				if(player.getCapabilities().getIsCreativeMode()) { // capabilities.isCreativeMode
					player.sendMessage("God mode cannot be toggled in Creative.");
					return true;
				}
				player.getCapabilities().setDisableDamage(!player.getCapabilities().getDisableDamage()); // capabilities.disableDamage
				player.sendPlayerAbilities();
				player.sendMessage("God mode " + (player.getCapabilities().getDisableDamage()?"enabled.":"disabled."));
			} else if(split[0].equals("give")) {
				if(split.length > 1) {
					try {
						// int itemId = Integer.parseInt(split[1]);
						int itemId = WItem.getItemID(split[1]);
						int amount = 1;
						int damageValue = 0;

						if(itemId <= 0) {
							player.sendError("No such item.");
							return true;
						}

						if(split.length > 2) {
							amount = Integer.parseInt(split[2]);
						}

						if(amount < 1) {
							player.sendError("Amount less than 1.");
							return true;
						}

						if(split.length > 3) {
							damageValue = Integer.parseInt(split[3]);
						}

						WItemStack itemstack = WItemStack.instantiate(itemId, amount, damageValue); // ItemStack
						player.addItemStackToInventory(itemstack); // ep.inventory.addItemStackToInventory
					}
					catch(Exception e)
					{
						player.sendError("Incorrect command syntax.");
					}
				} else {
					player.sendError("You must specify an item.");
				}
			} else if(split[0].equals("helmet")) {
				if(split.length > 1) {
					try {
						// int itemId = Integer.parseInt(split[1]);
						int itemId = WItem.getItemID(split[1]);
						int amount = 1;
						int damageValue = 0;

						if(itemId <= 0) {
							player.sendError("No such item.");
							return true;
						}

						if(split.length > 2) {
							damageValue = Integer.parseInt(split[2]);
						}

						if(damageValue < 0) {
							player.sendError("Amount less than 0.");
							return true;
						}

						WItemStack itemstack = WItemStack.instantiate(itemId, amount, damageValue); // ItemStack
						player.getInventory().setArmorSlotContents(3, itemstack); // ep.inventory.addItemStackToInventory
					} catch(Exception e) {
						player.sendError("Incorrect command syntax.");
					}
				} else {
					player.sendError("You must specify an item.");
				}
			} else if(split[0].equals("biome")) {
				// wh currentBiome = world.s().a((int)player.getPosX(), (int)player.getPosZ()); // BiomeGenBase, getWorldChunkManager, getBiomeGenAt
				// world.getWorldChunkManager().getBiomeGenAt((int)player.getPosX(), (int)player.getPosZ())
				player.sendMessage("Current biome: " + player.getWorld().getBiomeGenAt((int)player.getPosX(), (int)player.getPosZ()).getBiomeName()); // biomeName
			} else if(split[0].equals("pos")) {
				player.sendMessage(player.getPrettyPos());
			} else if(split[0].equals("spawnportal")) {
				if(split.length > 1) {
					if(split[1].equalsIgnoreCase("nether")) {
						ObfuscationHelper.createPortal(player);
						player.sendMessage("Spawned a nether portal.");
					} else if (split[1].equalsIgnoreCase("end")) {
						// probably could code this better.
						ObfuscationHelper.createEndPortal(player);
						// Stronghold-style end portals still to be added
						
					} else {
						player.sendError("Invalid type of portal specified.");
					}
				} else {
					player.sendError("You must specify the type of portal to spawn.");
				}
			} else if((split[0].equals("help") || split[0].equals("h"))) {
				if(split.length < 2) {

					Set<String> cmdSet = CommandList.CMDS.keySet();
					Iterator<String> i = cmdSet.iterator();
					String[] cmdsArray = cmdSet.toArray(new String[cmdSet.size()]);
					Arrays.sort(cmdsArray);

					String cmdString = "";
					int cmdIndex = 0;
					for(String cmdName : cmdsArray) {
						cmdString += cmdName;
						if(cmdIndex < cmdsArray.length - 1) {
							cmdString += ", ";
						}
						cmdIndex++;
					}

					player.sendMessage("Commands:");
					player.sendMessage(cmdString);

				} else if(CommandList.CMDS.containsKey(split[1])) {

					String[] msg = CommandList.CMDS.get(split[1]);
					if(msg == null || msg.length != 3) {
						player.sendError("No help exists for specified command.");
						return true;
					}

					Helper.helpMessage(player, split[1], msg[0], split[1] + " " + msg[1], "/" + split[1] + " " + msg[2]);

				} else {
					player.sendError("Specified command doesn't exist.");
				}
			} else if(split[0].equals("remove")) {
				WMovingObjectPosition mop;

				if(split.length > 1) {
					if (split[1].equals("nearest")) {
						mop = WEntityRenderer.getMouseOver(player, 1.0F, 1);
					} else if(split[1].equals("force")) {
						mop = WEntityRenderer.getMouseOver(player, 1.0F, 2);
					} else {
						player.sendError("Valid parameters: force|nearest");
						return true;
					}
				} else {
					mop = WEntityRenderer.getMouseOver(player, 1.0F);
				}

				// IMPORTANT: don't let players remove each other!!

				if(mop.getEntity() == null) {
					player.sendError("No entity found.");
				} else {
					mop.getEntity().setDead();
				}
				return true;
			} else if(split[0].equals("removeblock")) {
				WMovingObjectPosition mop = player.rayTrace();
				if(mop.isValid() && mop.getTypeOfHit() == WEnumMovingObjectType.TILE) {
				// objectMouseOver, objectMouseOver.typeOfHit == EnumMovingObjectType.TILE
					// sendMessage("Removed block at: " + mop.blockx + ", " + mop.blocky + ", " + mop.blockz);
					player.getWorld().setBlock(mop.blockx, mop.blocky, mop.blockz, 0); // setBlock
				} else {
					player.sendError("No block to remove.");
				}
			} else if(split[0].equals("setblock")) {
				if(split.length < 2) {
					player.sendError("Block ID not specified.");
				} else {
					final int blockID = WBlock.getBlockID(split[1]);
					if(blockID == -1) {
						player.sendError("Invalid Block ID.");
						return true;
					} else {
						final int metaData;
						if(split.length > 2) {
							int tempMeta;
							try {
								tempMeta = Integer.parseInt(split[2]);
							} catch (NumberFormatException nfe) {
								tempMeta = -1;
							}
							if(tempMeta < 0 || tempMeta > 15) {
								metaData = 0;
								player.sendMessage("(Using default metadata value)");
							} else {
								metaData = tempMeta;
							}
						} else {
							metaData = 0;
						}
						WMovingObjectPosition mop = player.rayTrace();
						if(mop.isValid() && mop.getTypeOfHit() == WEnumMovingObjectType.TILE) {
							player.getWorld().setBlock(mop.blockx, mop.blocky, mop.blockz, blockID); // setBlock
							if(metaData != 0 && blockID != 0) {
								// player.sendMessage("Updating block metadata");
								player.getWorld().setBlockMetadata(mop.blockx, mop.blocky, mop.blockz, metaData);
							}
						} else {
							player.sendError("No block found.");
						}
					}
				}
			} else if(split[0].equals("togglecheats")) {
				player.getWorld().changeWorldInfo("allowCommands", !player.getWorld().getWorldInfo().areCommandsAllowed()); // canUseCommands
				player.sendMessage("Cheats " + (player.getWorld().getWorldInfo().areCommandsAllowed()?"enabled.":"disabled."));
			} else if(split[0].equals("togglehardcore")) {
				player.getWorld().changeWorldInfo("hardcore", !player.getWorld().getWorldInfo().isHardcore()); // canUseCommands
				player.sendMessage("Hardcore " + (player.getWorld().getWorldInfo().isHardcore()?"enabled.":"disabled."));
			} else if(split[0].equals("skullowner")) {
				WItemStack itemstack = player.getCurrentItem(); // ItemStack, getCurrentItem
				if(itemstack != null && itemstack.getItemID() == 397) { // itemID, item.skull.shiftedid
					if(itemstack.getItemDamage() != 3 || itemstack.getStackSize() > 1) { // damageValue, stackSize
						player.sendError("Must be a head.");
						return true;
					}

					if(split.length > 1) {
						WNBTTagCompound nbttagcompound;
						if(itemstack.getStackTagCompound() != null) {
							nbttagcompound = itemstack.getStackTagCompound();
						} else {
							nbttagcompound = WNBTTagCompound.instantiate();
						}
						nbttagcompound.setString("SkullOwner", split[1]); // setString
						itemstack.setStackTagCompound(nbttagcompound); // stackTagCompound
						player.sendMessage("Set owner to: " + split[1]);
					} else {
						if(itemstack.getStackTagCompound() != null) {
							WNBTTagCompound stackTag = itemstack.getStackTagCompound();
							stackTag.removeTag("SkullOwner");
							player.sendMessage("Cleared skull owner.");
						} else {
							player.sendError("SkullOwner not set.");
							return true;
						}
					}
				} else {
					player.sendError("Must have head selected.");
				}
			} else if(split[0].equals("spawn")) {
				int spawnAmount = 1;
				if(split.length < 2) {
					player.sendError("No entity specified.");
					return true;
				}

				if(split.length > 2) {
					try {
						spawnAmount = Integer.parseInt(split[2]);
					} catch (Exception e) {
						player.sendError("Invalid amount specified.");
						return true;
					}
				}

				if(split[1].equalsIgnoreCase("list")) {
					Iterator<String> entityNames = WEntityList.getStringtoIDMapping().keySet().iterator();
					String nameList = entityNames.next();
					while(entityNames.hasNext()) {
						nameList += ", " + entityNames.next();
					}
					player.sendMessage(nameList);
					return true;
				}

				if(split[1].equals("Fireball") || split[1].equals("WitherSkull") || split[1].equals("FallingSand")
					|| split[1].equals("Painting") || split[1].equals("Monster") || split[1].equals("Item")
					|| split[1].equals("Mob") || split[1].equals("XPOrb") || split[1].equals("SmallFireball")) {
					player.sendError("Specified entity cannot be spawned.");
					return true;
				}

				if(!WEntityList.getStringtoIDMapping().containsKey(split[1])) {
					player.sendError("Invalid entity.");
					return true;
				}

				Random rand = new Random();

				for(int i = 0; i < spawnAmount; i++) {
					// Entity entity = new Entity(lv.a(split[1], player.getWorld().getRaw())); // Entity, EntityList.createEntityByName
					WEntity entity = WEntityList.createEntityByName(split[1], player.getWorld());
					WEntityLiving entityLiving = WEntityLiving.instantiate(entity);
					final double randomizedX = player.getPosX() + (double)rand.nextInt(5);
					final double randomizedZ = player.getPosZ() + (double)rand.nextInt(5);
					entity.setLocationAndAngles(randomizedX, player.getPosY(), randomizedZ, player.getYaw(), 0.0F);
					// setLocationAndAngles, ep.posX, ep.posY, ep.posZ, rotationYaw
					if(entityLiving != null) {
						entityLiving.initCreature();
					}
					player.getWorld().spawnEntityInWorld(entity); // spawnEntityInWorld
					if(entityLiving != null) {
						entityLiving.playLivingSound();
					}
				}

				player.sendMessage("Spawned " + spawnAmount + " entity(s).");
			} else if(split[0].equals("listcolors")) {
				for(int i = 0; i < Helper.colors.length(); i++) {
					player.sendMessage2(Helper.getColor(i) + "Color " + i);
				}
			} else if(split[0].equals("color")) {
				if(split.length > 1) {
					int newColor;
					try {
						newColor = Integer.parseInt(split[1]);
					} catch (Exception e) {
						player.sendError("Invalid color specified.");
						return true;
					}
					if(newColor >= 0 && newColor < Helper.colors.length()) {
						if(split.length > 2 && split[2].equalsIgnoreCase("error")) {
							Helper.errorColor = newColor;
							player.sendMessage(Helper.getColor(Helper.errorColor) + "New error color set.");
						} else {
							Helper.normalColor = newColor;
							player.sendMessage("New color set.");
						}
						Helper.updateColorSettings();
					} else {
						player.sendError("Invalid color specified.");
					}
				} else {
					player.sendError("Color can be 0-15.");
				}
			} else if(split[0].equals("allowfly") || split[0].equals("fly")) {
				player.sendMessage("Flying enabled: " + (player.getCapabilities().setAllowFlying(!player.getCapabilities().getAllowFlying())));
				player.sendPlayerAbilities();
			} else if(split[0].equals("find")) { // Used to be called itemid
				if(split.length > 1) {
					String itemName = split[1];
					player.sendMessage("Finding ID of item: " + itemName);
					int foundIDs = 0;
					for(int i = 0; i < WItem.itemsList.length; i++) {
						String tempString = WItem.resolveID(i);
						if(tempString == null) {
							continue;
						}
						String tempName = tempString.substring(5);
						if(tempName.indexOf(itemName) != -1) {
							foundIDs++;
							WItem tempItem = new WItem(WItem.itemsList[i]);
							if(tempString.startsWith("item.")) {
								player.sendMessage("Item: " + tempName + ", " + tempItem.getItemID());
							} else if(tempString.startsWith("tile.")) {
								player.sendMessage("Block: " + tempName + ", " + tempItem.getItemID());
							} else {
								player.sendMessage("Unknown: " + tempName + ", " + tempItem.getItemID());
							}
							if(foundIDs == 10) {
								player.sendError("Limited to first 10 items.");
								break;
							}
						}
					}
					if(foundIDs == 0) {
						player.sendError("Couldn't find specified item.");
					}
				} else {
					player.sendError("Specify item name.");
				}

			} else if(split[0].equals("resolveid")) {
				if(split.length > 1) {
					int itemId = 0;
					try {
						itemId = Integer.parseInt(split[1]);
					} catch (Exception e) {
						player.sendError("Must specify valid item ID.");
						return true;
					}
					String itemName = WItem.resolveID(itemId);
					if(itemName == null) {
						player.sendError("Couldn't resolve specified ID.");
					} else {
						String[] splitName = new String[]{itemName.substring(0, 4), itemName.substring(5)};
						player.sendMessage(itemId + ", " + splitName[1] + " (" + splitName[0].toUpperCase(java.util.Locale.ENGLISH) + ")");
					}
				} else {
					player.sendError("No item ID specified.");
				}
			} else if(split[0].equals("instantmine")) {
				player.getMinecraftPlayer().setInstantMine(!player.getMinecraftPlayer().getInstantMine());
				player.sendMessage("Instant mining " + (player.getMinecraftPlayer().getInstantMine()?"enabled.":"disabled."));
			} else if(split[0].equals("roll")) {
				int numDice = 1;
				int numSides = 6;
				if(split.length >= 2) {
					boolean invalidAmount = false;
					try {
						numDice = Integer.parseInt(split[1]);
					} catch (NumberFormatException nfe) {
						invalidAmount = true;
					}
					if(invalidAmount || numDice < 1) {
						player.sendError("Invalid amount of dice specified.");
						return true;
					}
				}
				if(split.length >= 3) {
					boolean invalidAmount = false;
					try {
						numSides = Integer.parseInt(split[2]);
					} catch (NumberFormatException nfe) {
						invalidAmount = true;
					}
					if(invalidAmount || numSides < 1) {
						player.sendError("Invalid amount of sides specified.");
						return true;
					}
				}
				Random rand = new Random();
				int result = 0;
				player.sendMessage("Rolling " + numDice + " " + numSides + "-sided dice.");
				while(numDice > 0) {
					int roll = rand.nextInt(numSides) + 1;
					result += roll;
					numDice -= 1;
				}
				WMinecraftServer.getServer().getConfigurationManager().sendChatToAllPlayers(player.getSenderName() + " got a " + result + "!");
			} else {
				player.sendError("Command not available in this version.");
			}
		}
		return true;
	}
}