// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.plugin;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

import com.q3hardcore.console.wrapper.WEntity;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WWorldInfo;
import com.q3hardcore.console.wrapper.lists.LEntities;

public class spc_weather extends Plugin {
	
	public String getName() {
		return "Weather";
	}

	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
			commands.add("weather");
			return commands;
	}

	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equalsIgnoreCase("weather")) {
			String[] help = new String[]{"Sets weather.", "[weather]", "sun"};
			return help;
		} else {
			return null;
		}
	}

	public boolean handleCommand(WPlayer player, String[] split) {
		if(split[0].equalsIgnoreCase("weather")) {
			if(split.length < 2) {
				player.sendMessage("Please specify weather command.");
				return true;
			}

			WWorldInfo worldInfo = player.getWorld().getWorldInfo(); // WorldInfo, ph.world.worldInfo
			String weatherState;

			if(split[1].equalsIgnoreCase("rain")) {
				if(worldInfo.isRaining()) { // isRaining
					weatherState = "off";
					worldInfo.setRaining(false); // setRaining
				} else {
					weatherState = "on";
					worldInfo.setRaining(true); // setRaining
				}

				player.sendMessage("Rain has been turned " + weatherState);
			} else if(split[1].equalsIgnoreCase("thunder")) {
				if(worldInfo.isThundering()) { // isThundering
					weatherState = "off";
					worldInfo.setThundering(false); // setThundering
					worldInfo.setRaining(false); // setRaining
				} else {
					weatherState = "on";
					worldInfo.setThundering(true); // setThundering
					worldInfo.setRaining(true); // setRaining
				}

				player.sendMessage("Thunder has been turned " + weatherState);
			} else if(split[1].equalsIgnoreCase("lightning")) {
				WMovingObjectPosition hitBlock = player.rayTrace();
				if(hitBlock.blocky == -1) {
					player.sendError("Please point at a block.");
					return true;
				}

				WEntity entityLightningBolt = new LEntities.LightningBolt(player.getWorld(), (double)hitBlock.blockx, (double)hitBlock.blocky, (double)hitBlock.blockz);
				//Entity entityLightningBolt = new Entity(new qr(player.getWorld().getRaw(), (double)hitBlock.blockx, (double)hitBlock.blocky, (double)hitBlock.blockz));
				player.getWorld().addWeatherEffect(entityLightningBolt); // Minecraft.theWorld.addWeatherEffect
			} else if(split[1].equalsIgnoreCase("sun")) {
				worldInfo.setThundering(false); // setThundering
				worldInfo.setRaining(false); // setRaining
			} else {
				player.sendError("Unknown weather command: " + split[1]);
			}
			return true;
		} else {
			return false;
		}
	}

}
