package com.q3hardcore.console.plugin;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import com.q3hardcore.console.wrapper.WFurnaceRecipes;
import com.q3hardcore.console.wrapper.WItemStack;
import com.q3hardcore.console.wrapper.WPlayer;

public class spc_inventory extends Plugin {

	private int skippedItems = 0;

	@Override
	public String getName() {
		return "Inventory";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
		commands.add("enderchest");
		commands.add("repair");
		commands.add("superheat");
		return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		String[] help = null;
		if(commandname == null) {
			System.out.println("Command name was null.");
		} else if(commandname.equals("enderchest")) {
			help = new String[]{"Opens enderchest GUI.", "", ""};
		} else if(commandname.equals("repair")) {
			help = new String[]{"Repairs item(s).", "<all|armor>", "all"};
		}
		return help;
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] s) {
		if(s[0].equalsIgnoreCase("enderchest")) {
			player.displayGUIChest(player.getInventoryEnderChest()); // displayGUIChest 
			return true;
		} else if(s[0].equalsIgnoreCase("repair")) {
			skippedItems = 0;
			if(s.length > 1) {
				if(s[1].equalsIgnoreCase("all")) {
					for(int i = 0; i < player.getInventory().getMainInventory().length; i++) {
						resetDamageOnItem(player, i, false);
					}
				} else if(s[1].equalsIgnoreCase("armor")) {
					for(int i = 0; i < player.getInventory().getArmorInventory().length; i++) {
						resetDamageOnItem(player, i, true);
					}
				}
			} else {
				resetDamageOnItem(player, player.getInventory().getCurrentItemID(), false); // currentItem
			}
			if(skippedItems > 0) {
				player.sendMessage(skippedItems + " item(s) were not repaired.");
			}
			return true;
		} else if(s[0].equals("superheat")) {
			Map<Integer, WItemStack> smelt;
			try {
				smelt = WFurnaceRecipes.getSmeltingList();
			} catch (Exception e) {
				player.sendError("*REALLY* could not retrieve smelting list.");
				return true;
			}
			if (smelt == null) {
				player.sendError("Could not retrieve smelting list.");
				return true;
			}

			boolean all = false;
			if (s.length >= 2 && s[1].equalsIgnoreCase("all")) {
				all = true;
			}
			int length = all ? player.getInventory().getMainInventory().length : 1;
			int start = all ? 0 : player.getInventory().getCurrentItemID(); // currentItem

			for (int i = start; i < start + length; i++) {
				// ItemStack oldStack = new ItemStack(player.getInventory().a[i]);
				WItemStack oldStack = player.getInventory().getMainInventory()[i];
				if (!oldStack.isValid()) {
					continue;
				}
				int key = oldStack.getItemID();
				if (smelt.containsKey(key) && smelt.get(key) != null) {
					int amt = oldStack.getStackSize();
					WItemStack temp = smelt.get(key);
					int id = temp.getItemID();
					int damage = temp.getItemDamage();
					WItemStack item = WItemStack.instantiate(id, amt, damage);
					player.getInventory().setInventorySlotContents(i, item);
					// player.getInventory().a[i] = item.getRaw();
				}
			}
			return true;
		} else {
			return false;
		}
	}

	private void resetDamageOnItem(WPlayer player, int slot, boolean isArmor) {
		if(slot < 0 || slot >= 36 || (slot >= 4 && isArmor)) {
			System.out.println("Specified slot out-of-bounds.");
			return;
		}
		WItemStack itemstack;
		if(!isArmor) {
			itemstack = player.getInventory().getMainInventory()[slot]; // ItemStack, mainInventory
		} else {
			itemstack = player.getInventory().getArmorInventory()[slot]; // ItemStack, armorInventory
		}
		if(itemstack.isValid()) {
			if(!itemstack.getHasSubtypes() && itemstack.isItemDamaged()) {
				itemstack.setItemDamage(0); // setItemDamage
			} else {
				System.out.println("Skipping item with ID: " + itemstack.getItemID());
				skippedItems++;
			}
		}
	}

}
