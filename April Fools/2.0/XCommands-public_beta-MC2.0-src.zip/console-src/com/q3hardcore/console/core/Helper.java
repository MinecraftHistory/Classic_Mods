package com.q3hardcore.console.core;

import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Proxy;
import com.q3hardcore.console.proxy.Side;
import com.q3hardcore.console.util.FontColour;
import com.q3hardcore.console.util.Settings;
import com.q3hardcore.console.wrapper.TriState;
import com.q3hardcore.console.wrapper.WMinecraftServer;
import com.q3hardcore.console.wrapper.WPlayer;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import net.minecraft.src.ConsoleHelper;

public final class Helper {

	// Colour code
	public static final String colors = "0123456789abcdef"; // American spelling
	public static int normalColor = 15;
	public static int errorColor = 4;

	// Variables for settings
	private static Settings colorSettings;
	private static Settings consoleSettings;
	protected static boolean dropItems = true;

	public static boolean triedLoadingWorldEdit = false;

	private static TriState hasWorldEdit = TriState.UNDEFINED;

	// Generic error messages from Single Player Commands
	public static String ERRMSG_PARAM = "Invalid number of parameters.";
	public static String ERRMSG_PARSE = "Could not parse input.";
	public static String ERRMSG_NOTSET = "WorldEdit points not set.";
	public static String ERRMSG_OSNOTSUPPORTED = "Your operating system does not support this function.";
	public static String ERRMSG_NPCNOTFOUND = "The specified NPC was not found.";

	@Side(EnumSide.CLIENT)
	public static String ERRMSG_NOTOWNER = "Command can only be used by server owner.";

	private static boolean settingsLoaded = false;

	protected static boolean debug = false;

	@Side(EnumSide.CLIENT)
	public static WPlayer getOwner() { // EntityPlayerMP
		if(WMinecraftServer.getServer() == null) {
			return null;
		}
		String serverOwner = WMinecraftServer.getServer().getServerOwner();
		return WMinecraftServer.getServer().getConfigurationManager().getPlayerForUsername(serverOwner);
	}

	protected static File getWorldEditJar() {
		return new File(getModDir(), "jars/WorldEdit.jar");
	}

	protected static File getRhinoJar() {
		return new File(getModDir(), "jars/rhino.jar");
	}

	public static File getModDir() {
		return new File(getMinecraftDir(), "mods/xcommands");
	}

	public static File getMinecraftDir() {
		try {
			return Proxy.INSTANCE.getMinecraftDir();
		} catch (Throwable t) {
			System.out.println("SPConsole: Unable to get Minecraft directory.");
			return new File(".");
		}
	}

	public static void helpMessage(WPlayer player, String cmdName, String s1, String s2, String s3) {
		
		player.sendMessage2(FontColour.GREEN + "===Help===================");

		player.sendMessage2(FontColour.WHITE + "Help for the " + FontColour.AQUA + cmdName + FontColour.WHITE + " command.");

		if(s1 != null) {
			player.sendMessage2(FontColour.GREEN + "Description: " + FontColour.WHITE + s1);
		}

		if(s2 != null) {
			player.sendMessage2(FontColour.GREEN + "Syntax: " + FontColour.WHITE + s2);
		}

		if(s3 != null) {
			player.sendMessage2(FontColour.GREEN + "Example: " + FontColour.WHITE + s3);
		}

		player.sendMessage2(FontColour.GREEN + "==========================");

	}

	public static String getServerVersion() {
		try {
			return WMinecraftServer.getServer().getVersion();
		} catch (Exception e) {
			return ConsoleHelper.getMinecraftVersion();
		}
	}

	protected static void loadSettings() {
		try {
			consoleSettings = new Settings(new File(getModDir(), "settings.txt"));
			colorSettings = new Settings(new File(getModDir(), "colors.txt"));
			normalColor = colorSettings.getInteger("normalColor", 15);
			errorColor = colorSettings.getInteger("errorColor", 4);
			updateColorSettings();
			debug = consoleSettings.getBoolean("debug", false);
			// dropItems = consoleSettings.getBoolean("itemDrops", true);
			updateConsoleSettings();
			settingsLoaded = true;
		} catch (Exception e) {
			System.err.println("Couldn't load settings for SPConsole.");
			// sendError("Could not load settings.");
		}
	}

	// currently unused
	private static boolean areSettingsLoaded() {
		return settingsLoaded;
	}

	public static void updateColorSettings() {
		if(colorSettings != null) {
			colorSettings.set("normalColor", normalColor);
			colorSettings.set("errorColor", errorColor);
			colorSettings.save("Console Color Settings");
		} else {
			System.out.println("No color settings found.");
		}
	}

	protected static void updateConsoleSettings() {
		if(consoleSettings != null) {
			// consoleSettings.set("itemDrops", dropItems);
			consoleSettings.set("debug", debug);
			consoleSettings.save("Console Settings");
		} else {
			System.out.println("No console settings found.");
		}
	}

	public static boolean createDirs() {
		try {
			if(!getModDir().exists()) {
				System.out.println("SPConsole: Creating mods folder.");
				getModDir().mkdirs();
			}

			File jars = new File(getModDir(), "jars");
			if(!jars.exists()) {
				jars.mkdir();
				System.out.println("SPConsole: Creating jars folder.");
			}

	 		return true;
		} catch (SecurityException se) {
			// t.printStackTrace();
			// sendError("Could not create mod directory.");
 			return false;
		}
	}

	// unknown purpose
	protected static String convertInput(String input) {
		if(input == null) {
			return input;
		} else {
			String[] temp = input.split(" ");
			String newstring = temp[0];

			return (newstring + " " + join(temp, 1, temp.length)).trim();
		}
	}

	// currently unused
	public static String join(String[] args, int beginindex, int endindex) {
		String joined = "";

		for(int i = beginindex; i < endindex || i < args.length; ++i) {
			joined = joined + args[i] + " ";
		}

		return joined.trim();
	}

	public static boolean toggleItemDrops() {
		boolean state = dropItems = !dropItems;
		// updateConsoleSettings();
		return state;
	}

	// used for extracting files from archives
	public static boolean extractFile(File zip, String filename, File destination) {
		try {
			JarFile file = new JarFile(zip);
			ZipEntry entry = file.getEntry(filename);
			File efile = new File(destination, entry.getName());
			BufferedInputStream in = new BufferedInputStream(file.getInputStream(entry));
			BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(efile));
			byte[] buffer = new byte[4096];

			while(true) { // really?
				int bytes = in.read(buffer);
				if(bytes <= 0) {
					out.flush();
					out.close();
					in.close();
					return true;
				}

				out.write(buffer, 0, bytes);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public static String getColor(int colorIndex) {
		if(colorIndex >= 0 && colorIndex < colors.length()) {
			return "\u00a7" + colors.charAt(colorIndex);
		} else {
			System.out.println("Invalid color index specified.");
			return "";
		}
	}

	public static boolean tryLoadingWorldEdit(List<String> messages) {
		if(!getWorldEditJar().exists()) {
			System.out.println("Attemping to locate WorldEdit.jar file.");
			URL jarLocation = Helper.class.getResource("/WorldEdit.jar");
			if(jarLocation != null && jarLocation.toString().startsWith("jar:")) {
				String jarString = jarLocation.toString();
				try {
					URL jarURL = new URL(jarString.substring(4, jarString.lastIndexOf("!")));
					File jarFile = new File(jarURL.toURI());
					boolean success = extractFile(jarFile, "WorldEdit.jar", new File(getModDir(), "jars/"));
					if(success) {
						System.out.println("Extracted WorldEdit.jar");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		if(!addToClasspath(getWorldEditJar())) {
			File oldWEJar = new File(getMinecraftDir(), "/bin/WorldEdit.jar");
			if(oldWEJar.exists()) {
				boolean warnUser = addToClasspath(oldWEJar);
				if(warnUser) {
					messages.add("WARNING: Using WorldEdit.jar from .minecraft/bin");
				}
			}
		}

		if(getRhinoJar().exists()) {
			addToClasspath(getRhinoJar());
		}

		triedLoadingWorldEdit = true;
		
		return getHasWorldEdit();

	}

	public static boolean getHasWorldEdit() {
		if(hasWorldEdit == TriState.ON) {
			return true;
		} else if(hasWorldEdit == TriState.OFF) {
			return false;
		}
		try {
			Helper.class.getClassLoader().loadClass("com.sk89q.worldedit.ServerInterface");
			// ClassLoader.getSystemClassLoader().loadClass("com.sk89q.worldedit.ServerInterface");
                        hasWorldEdit = TriState.ON;
			return true;
		} catch (ClassNotFoundException cnfe) {
			// Console.PH.sendError("WorldEdit not loaded.");
			System.out.println("WorldEdit support not available.");
			hasWorldEdit = TriState.OFF;
			return false;
		}
	}

	// currently unused
	private static boolean getHasForge() {
		try {
			Class.forName("net.minecraftforge.common.MinecraftForge");
			return true;
		} catch (ClassNotFoundException cnfe) {
			return false;
		}
	}

	protected static boolean getHasSPC() {
		try {
			Class.forName("com.sijobe.spc.core.SPCLoader");
			return true;
		} catch (ClassNotFoundException cnfe) {
			return false;
		}
	}

	protected static boolean addToClasspath(File file) {
		if(!file.exists()) {
			System.out.println("File " + file.getName() + " doesn't exist!");
			return false;
		} else {
			URLClassLoader sysloader = (URLClassLoader)Helper.class.getClassLoader();
			// URLClassLoader sysloader = (URLClassLoader)ClassLoader.getSystemClassLoader();
			Class<URLClassLoader> sysclass = URLClassLoader.class;

			try {
				Method t = sysclass.getDeclaredMethod("addURL", new Class<?>[]{URL.class});
				t.setAccessible(true);
				t.invoke(sysloader, new Object[]{file.toURI().toURL()});
				return true;
			} catch (Throwable t) {
				t.printStackTrace();
				return false;
			}
		}
	}

}