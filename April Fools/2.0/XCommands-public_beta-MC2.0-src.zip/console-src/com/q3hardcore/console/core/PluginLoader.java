package com.q3hardcore.console.core;

public final class PluginLoader extends Thread {

	final Console currentInstance;

	public PluginLoader(Console console) {
		currentInstance = console;
	}

	@Override
	public void run() {
		if(Console.PLUGIN_MANAGER == null) {
			long currentTime = System.currentTimeMillis();
			PluginManager pluginManager;
			try {	
				pluginManager = new PluginManager();
				System.out.println("Plugin support available.");
			} catch (Throwable t) {
				t.printStackTrace();
				currentInstance.getPlayer().sendError("Plugin support not available.");
				return;
			}
			try {
				pluginManager.loadPlugins(currentInstance.getPlayer());
			} catch (Throwable t) {
				t.printStackTrace();
			}
			Console.PLUGIN_MANAGER = pluginManager;
			long newTime = System.currentTimeMillis();
			System.out.println("SPConsole: Plugins thread took: " + (newTime - currentTime));
		}
	}

}