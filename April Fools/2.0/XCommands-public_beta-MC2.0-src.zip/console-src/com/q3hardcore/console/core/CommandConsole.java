package com.q3hardcore.console.core;

// Obfuscated references: 0

import net.minecraft.src.ConsoleHelper;
import com.q3hardcore.console.wrapper.WICommandSender;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.raw.RCommandBase;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public final class CommandConsole extends RCommandBase { // extends CommandBase

	private static List<String> commandList;

	@Override
	public String getCommandName() { // getCommandName()
		return "c";
	}

	@Override
	public String getCommandUsage() { // getCommandUsage(), ICommandSender par1
		return "/c [command]";
	}

	@Override
	public void processCommand(WPlayer player, String[] args) { // processCommand(), ICommandSender par1

		if(args.length == 0 || (args.length == 1 && args[0].equals("/"))) {
			player.addChatMessage("Console 7.x, running on Minecraft " + Helper.getServerVersion());
			return;
		}

		Console console = player.getConsole();
		if(console == null) {
			System.out.println("Player cannot use Console commands.");
			return;
		}

		CommandHelper.handleCommand(player, args);

	}

	@Override
	public List<String> addTabCompletionOptions(WICommandSender commandSender, String[] args) { // addTabCompletionOptions, ICommandSender
		if(args.length == 1) {
			setCommandList();
                        if(args[0].equals("/")) {
				return commandList;
			} else {
				List<String> cmdList = new LinkedList<String>();
				for(String cmd : commandList) {
					if(cmd.startsWith(args[0])) {
						cmdList.add(cmd);
					}
				}
				if(cmdList.isEmpty()) {
					return null;
				} else {
					return cmdList;
				}
			}
		} else if(args.length == 2) {

		}
		return null;
	}

	private boolean setCommandList() {
		if(commandList == null) {
			List<String> cmdList = new LinkedList<String>();
			for(String cmd : CommandList.CMDS.keySet()) {
				cmdList.add("/" + cmd);
			}
			if(Console.PLUGIN_MANAGER != null) {
				String[] pluginCmds = Console.PLUGIN_MANAGER.getCommands();
				for(String cmdName : pluginCmds) {
					if(cmdList.contains("/" + cmdName)) {
						// System.out.println("Command " + cmdName + " defined twice.");
					} else {
						cmdList.add("/" + cmdName);
					}
				}
			}
			Collections.sort(cmdList);
			commandList = cmdList;
			return true;
		} else {
			return false;
		}
	}

}
