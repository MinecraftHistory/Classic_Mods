package com.q3hardcore.console.core;

// Obfuscated references: 0

import java.util.Arrays;
import java.util.List;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.raw.RCommandBase;

public final class CommandPlugin extends RCommandBase { // extends CommandBase

	private String commandName;

	public CommandPlugin(String commandName) {
		this.commandName = commandName;
	}

	@Override
	public String getCommandName() { // getCommandName()
		return commandName;
	}

	@Override
	public String getCommandUsage() {
		if(CommandList.CMDS.get(commandName) != null && !CommandList.CMDS.get(commandName)[1].equals("")) {
			return super.getCommandUsage() + " " + CommandList.CMDS.get(commandName)[1];
		} else {
			return super.getCommandUsage();
		}
	}

	@Override
	public void processCommand(WPlayer player, String[] args) { // processCommand(), ICommandSender sender
		if(player.getConsole() == null) {
			System.out.println("no console instance");
			return;
		}

		Console console = player.getConsole();

		CommandHelper.handleCommand(player, getCmdString(args));
	}

	private String[] getCmdString(String[] args) {
		String[] cmdString = new String[args.length + 1];
		cmdString[0] = "/" + this.getCommandName();
		int index = 1;
		for(String argument : args) {
			cmdString[index] = argument;
			index++;
		}
		return cmdString;
	}

}
