package com.q3hardcore.console.core;

import com.q3hardcore.console.wrapper.WCommandHandler;
import com.q3hardcore.console.wrapper.WMinecraftServer;

public final class CommandRegistry {

	protected static boolean registerCommands() {
		final WCommandHandler commandHandler = WMinecraftServer.getServer().getCommandHandler();
		if(commandHandler.isValid() && !commandHandler.doesCommandExist("c")) { // getCommands()
			commandHandler.registerCommand(new CommandConsole()); // CommandHandler, registerCommand
			registerMCCommands();
			return true;
		} else {
			return false;
		}
	}

	private static void registerMCCommands() {
		registerPluginCommand("allowfly");
		registerPluginCommand("biome");
		registerPluginCommand("color");
		registerPluginCommand("dimension");
		registerPluginCommand("drops");
		registerPluginCommand("feed");
		registerPluginCommand("find");
		registerPluginCommand("generate");
		registerPluginCommand("gethome");
		registerPluginCommand("getspawn");
		registerPluginCommand("god");
		registerPluginCommand("hurtmob");
		registerPluginCommand("killplayer");
		registerPluginCommand("lenditem");
		registerPluginCommand("listcolors");
		registerPluginCommand("oldhelp");
		registerPluginCommand("paint");
		registerPluginCommand("plugin");
		registerPluginCommand("removeblock");
		registerPluginCommand("resolveid");
		registerPluginCommand("restorepos");
		registerPluginCommand("return");
		registerPluginCommand("serverinfo");
		registerPluginCommand("skullowner");
		registerPluginCommand("spawner");
		registerPluginCommand("spawnportal");
		registerPluginCommand("structure");
		registerPluginCommand("togglecheats");

		// Don't overwrite SPC commands
		if(!Helper.getHasSPC()) {
			registerPluginCommand("fly");
			registerPluginCommand("helmet");
			registerPluginCommand("hunger");
			registerPluginCommand("item");
			registerPluginCommand("platform");
			// registerPluginCommand("reach");
			registerPluginCommand("repair");
			registerPluginCommand("spawn");
		}
	}

	private static boolean registerPluginCommand(String command) {
		final WCommandHandler commandHandler = WMinecraftServer.getServer().getCommandHandler();
		if(commandHandler.doesCommandExist(command)) {
			System.out.println("Command \"" + command + "\" already registered.");
			return false;
		} else {
			commandHandler.registerCommand(new CommandPlugin(command));
			return true;
		}
	}

	public static String getSecret() {
		return "<INSERT SECRET HERE>";
	}

}