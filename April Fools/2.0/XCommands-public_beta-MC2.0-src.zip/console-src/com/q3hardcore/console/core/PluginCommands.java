// Obfuscated references: 0

package com.q3hardcore.console.core;

import com.q3hardcore.console.plugin.Plugin;
import com.q3hardcore.console.util.FontColour;
import com.q3hardcore.console.wrapper.WPlayer;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class PluginCommands {

	public static boolean processCommand(WPlayer player, String[] split) {

		if(split[0].equalsIgnoreCase("phelp")) {
			if(split.length == 1) {
				String[] commands = Console.PLUGIN_MANAGER.getCommands();

				if(commands.length == 0) {
					player.sendError("Plugin commands unavailable");
					return true;
				}

				String list = "";
				Arrays.sort(commands);
				String[] arr = commands;
				int len = arr.length;

				List<String> cmdList = new ArrayList<String>();

				for(int i = 0; i < len; i++) {
					final String command = arr[i];
					String appendedList = (new StringBuilder()).append(list).append(command).append(", ").toString();
					if(appendedList.length() > 64) {
						list = list.substring(0, list.length() - 2);
						cmdList.add(list);
						list = command + ", ";
					} else {
						list = appendedList;
					}
				}

				if(!list.equals("")) {
					list = list.substring(0, list.length() - 2);
					cmdList.add(list);
				}

				player.sendMessage("Plugin Commands:");
				for(String cmdLine : cmdList) {
					player.sendMessage(cmdLine);
				}
			} else {
				String help[] = Console.PLUGIN_MANAGER.getHelp(split[1]);
				if(help == null) {
					player.sendMessage("Help not available for that command.");
					return true;
				}
				Helper.helpMessage(player, split[1], help[0], (new StringBuilder()).append(split[1]).append(" ").append(help[1]).toString(),
					(new StringBuilder("/c /")).append(split[1]).append(" ").append(help[2]).toString());
			}
			return true;
		} else if(split[0].equalsIgnoreCase("plugin")) {
			if(split.length < 2) {
				player.sendError("Not enough parameters.");
				return true;
			} else if(split[1].equalsIgnoreCase("version")) {
				if(split.length >= 3) { 
					String name = split[2];
					for(int i = 3; i < split.length; i++) {
						name = (new StringBuilder()).append(name).append(" ").append(split[i]).toString();
					}
					Plugin plugins[] = Console.PLUGIN_MANAGER.getPlugin(name);
					if(plugins.length == 0) {
						player.sendError("No such plugin.");
						return true;
					}
					for(int i = 0; i < plugins.length; i++) {
						player.sendMessage(plugins[i].getName() + " " + plugins[i].getVersion());
					}
				} else {
					player.sendMessage("SPC Plugin System - Console edition");
				}
				return true;
			} else if(split[1].equalsIgnoreCase("list")) {
				player.sendMessage2(FontColour.GREEN + "===Plugins================");
				for(Plugin plugin : Console.PLUGIN_MANAGER.getPlugins()) {
					String pName = plugin.getName();
					String pVersion = plugin.getVersion();
					String pEnabled = plugin.getEnabled()?"enabled":"disabled";
					player.sendPrettyMessage(pName + " v" + pVersion + ": " + pEnabled);
				}
				player.sendMessage2(FontColour.GREEN + "==========================");
				return true;
			} else if(split[1].equalsIgnoreCase("enable")) {
				if(split.length < 3) {
					if(!Console.PLUGIN_MANAGER.getEnabled()) {
						Console.PLUGIN_MANAGER.setEnabled(true);
						player.sendMessage("Plugin Manager enabled.");
					} else {
						player.sendError("Plugin Manager already enabled.");
					}
					return true;
				}
				String pluginName = split[2];
				Plugin[] plugins = Console.PLUGIN_MANAGER.getPlugin(pluginName);
				if(plugins.length == 0) {
					player.sendError("Couldn't find specified plugin.");
					return true;
				}
				for(Plugin plugin : plugins) {
					if(!plugin.getEnabled()) {
						plugin.setEnabled(true);
						player.sendMessage("Enabled " + plugin.getName());
					} else {
						player.sendError(plugin.getName() + " is already enabled.");
					}
				}
				return true;
			} else if(split[1].equalsIgnoreCase("disable")) {
				if(split.length < 3) {
					if(Console.PLUGIN_MANAGER.getEnabled()) {
						Console.PLUGIN_MANAGER.setEnabled(false);
						player.sendMessage("Plugin Manager disabled.");
					} else {
						player.sendError("Plugin Manager already disabled.");
					}
					return true;
				}
				String pluginName = split[2];
				Plugin[] plugins = Console.PLUGIN_MANAGER.getPlugin(pluginName);
				if(plugins.length == 0) {
					player.sendError("Couldn't find specified plugin.");
					return true;
				}
				for(Plugin plugin : plugins) {
					if(plugin.getEnabled()) {
						plugin.setEnabled(false);
						player.sendMessage("Disabled " + plugin.getName());
					} else {
						player.sendError(plugin.getName() + " is already disabled.");
					}
				}
				return true;
			} else {
				return false;
			}
		}
		
		boolean isPluginCommand = false;

		try {
			isPluginCommand = Console.PLUGIN_MANAGER.handlePluginCommand(player, split);
			// isPluginCommand = Console.PLUGIN_MANAGER.callPluginMethods2(Console.PLUGIN_HANDLECOMMAND, new Object[]{player, split});
		} catch (Throwable t) {
			t.printStackTrace();
			player.sendError("Unhandled exception caused by command " + split[0]);
			isPluginCommand = true;
		}
		return isPluginCommand;
		
	}

}