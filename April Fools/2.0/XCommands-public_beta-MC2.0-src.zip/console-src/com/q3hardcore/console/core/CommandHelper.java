package com.q3hardcore.console.core;

import com.q3hardcore.console.wrapper.WPlayer;
import net.minecraft.src.ConsoleHelper;

public final class CommandHelper {

	public static boolean handleCommand(WPlayer player, String[] cmd) {
		if(cmd.length == 1 && cmd[0].equals("/!")) {
			player.sendMessage2("This is like an easter egg or something.");
			return true;
		}

		if(!Console.isEnabled) {
			player.sendError("Console disabled.");
			return false;
		}

		if(cmd.length < 1 || (cmd.length > 0 && cmd[0].equals(""))) {
			player.sendMessage("No command specified.");
			return false;
		}

		boolean isPluginCommand = false;

		if(cmd[0].startsWith("/")) {
			cmd[0] = cmd[0].substring(1);
		} else {
			player.sendError("Must prefix command with '/'.");
			return false;
		}

		cmd[0] = cmd[0].toLowerCase();

		try {
			if(Console.getPluginManager() != null) {
				isPluginCommand = PluginCommands.processCommand(player, cmd);
			} else {
				player.sendError("Plugin support currently unavailable.");
			}
		} catch (Throwable t) {
			isPluginCommand = true;
			player.sendError("Command failed.");
		}

		if(isPluginCommand == false) {
			player.sendError("Invalid command.");
			return false;
		} else {
			return true;
		}
	}

}