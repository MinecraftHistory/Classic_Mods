// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.core;

// Obfuscated references: 0

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Proxy;
import com.q3hardcore.console.proxy.Side;
import com.q3hardcore.console.plugin.Plugin;
import com.q3hardcore.console.wrapper.ConsoleException;
import com.q3hardcore.console.wrapper.WPlayer;

public final class PluginManager {

	private Vector<Plugin> plugins;
	private boolean enabled;
	private static PluginManager MANAGER;

	private static boolean jarsLoaded = false;
	private static boolean pluginsLoaded = false;

	public PluginManager() {
		this.plugins = new Vector<Plugin>();
		this.enabled = true;
		MANAGER = this;
	}

	public static PluginManager getPluginManager() {
		return MANAGER;
	}

	public boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean loadPlugins(WPlayer player) {
		String failed = "";
		String skipped = "";

		try {
			String e;
			try {
				e = Console.class.getResource("/ConsoleHelper.class").toString();
			} catch (NullPointerException npe) {
				e = Console.class.getResource("/net/minecraft/src/ConsoleHelper.class").toString();
			}
			String classLocation;
			if(e.toLowerCase().startsWith("jar")) {
				System.out.println("Loading plugins from jar.");
				classLocation = e.replaceAll("jar:", "").split("!")[0];
				JarFile loader = new JarFile(new File((new URL(classLocation)).toURI()));
				Enumeration<JarEntry> u = loader.entries();

				while(u.hasMoreElements()) {
					JarEntry f = u.nextElement(); // Cast to (JarEntry) redundant

					try {
						if(f.getName().toLowerCase().contains("spc_")) {
							if(f.getName().equals("spc_WorldEditCUI.class")) {
								System.out.println("Skipping plugin.");
								continue;
							}
							if(!f.getName().startsWith("com/q3hardcore/console/plugin/")) {
								skipped = skipped + f.getName() + " ";
								continue;
							}
							Package arr$ = net.minecraft.src.ConsoleHelper.class.getPackage();
							if(arr$ != null && arr$.getName().equals("net.minecraft.src")) {
								System.out.println("retroguard environment workaround");
								arr$ = null;
							}
							Plugin len$ = loadPlugin(f.getName(), arr$ == null?null:arr$.getName());
							if(len$ != null) {
								this.plugins.add(len$);
							} else {
								failed = failed + f.getName() + " ";
							}
						}
					} catch (ConsoleException ce) {
						System.out.println("Skipping plugin: " + f.getName());
					} catch (Throwable t) {
						t.printStackTrace();
					}
				}
			} else {
				System.out.println("Loading plugins from folder.");
				// classLocation = Console.class.getName().replace('.', '/') + ".class";
				classLocation = Plugin.class.getName().replace('.', '/') + ".class";
				URLClassLoader loader = (URLClassLoader)Console.class.getClassLoader();
				URL url = loader.getResource(classLocation);
				File[] f = (new File(url.getFile())).getParentFile().listFiles();
				if(f == null) {
					f = (new File(url.toURI())).getParentFile().listFiles();
				}

				for(File temp : f) {
					if(temp.isFile() && temp.getName().toLowerCase().startsWith("spc_")) {
						if(temp.getName().equals("spc_WorldEditCUI.class")) {
							player.sendError("Please report this error. (WorldEditCUI installed incorrectly)");
							System.out.println("Skipping plugin.");
							continue;
						}
						try {
							// Package e1 = Console.class.getPackage();
							Package e1 = Plugin.class.getPackage();
							Plugin plugin = loadPlugin(temp.getName(), e1 == null?null:e1.getName());
							if(plugin != null) {
								this.plugins.add(plugin);
							} else {
								failed = failed + temp.getName() + " ";
							}
						} catch (ConsoleException ce) {
							System.out.println("Skipping plugin: " + temp.toString());
						} catch (Throwable t) {
							System.err.println("Encountered error with: " + temp.toString());
						}
					}
				}
			}
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}

		if(!failed.equalsIgnoreCase("")) {
			player.sendError("Plugin(s) failed to load: " + failed);
			player.sendError("Please refer to installation instructions.");
		}

		if(!skipped.equalsIgnoreCase("")) {
			player.sendError("Skipped plugin(s): " + skipped);
			player.sendError("Please don't report this error.");
		}

		pluginsLoaded = true;
		return true;
	}

	public static Plugin loadPlugin(String plugin, String pack) throws Exception {
		if(!plugin.endsWith(".class")) {
			throw new Exception("Not a plugin.");
		} else {
			plugin = plugin.split("\\.")[0];
			plugin = pack == null?plugin:pack + "." + plugin;
			plugin = plugin.replaceAll("/", ".");

			int classNameIndex = plugin.lastIndexOf(".");
			String shortName;

			if(classNameIndex != -1) {
				try {
					shortName = plugin.substring(classNameIndex + 1);
				} catch (IndexOutOfBoundsException ioobe) {
					System.out.println("Plugin has invalid class name.");
					shortName = plugin;
				}
			} else {
				shortName = plugin;
			}

			System.out.println("Loading plugin: " + shortName);
			URLClassLoader loader = (URLClassLoader)Console.class.getClassLoader();

			Class<?> c;
			try {
				c = loader.loadClass(plugin);
			} catch (Throwable t) {
				t.printStackTrace();
				return null;
			}

			if(c != null && Plugin.class.isAssignableFrom(c)) {
				final Side annotation;
				if((annotation = c.getAnnotation(Side.class)) != null) {
					if(Proxy.INSTANCE.getSide() != EnumSide.CLIENT) {
						if(annotation.value() == EnumSide.CLIENT) {
							throw new ConsoleException("Client-side plugin.");
						}
					}
				}
				try {
					Plugin e = (Plugin)c.newInstance();
					return e != null?e:null;
				} catch (Throwable t) {
					if(!(t instanceof ConsoleException))
						t.printStackTrace();
					String errMsg = t.getMessage();
					if(errMsg != null) {
						System.out.println("ERROR: " + t.getMessage());
					}
					return null;
				}
			} else {
				throw new Exception("Not a plugin.");
			}
		}
	}

	public boolean callPluginMethods(Method m, Object ... args) {
		if(m != null && args != null && this.enabled) {
			boolean found = false;
			Iterator<Plugin> i$ = this.plugins.iterator();

			boolean atUpdate = false;
			if(m == Console.PLUGIN_ATUPDATE) {
				atUpdate = true;
			}

			while(i$.hasNext()) {
				Plugin p = i$.next(); // Cast to (Plugin) redundant

				if(atUpdate && !p.getTicking()) {
					continue;
				}

				if(!p.getEnabled()) {
					continue;
				}

				if(args.length > 0 && args[0] instanceof WPlayer) {
					WPlayer player = ((WPlayer)args[0]);
					if(atUpdate && p.getOwnerExclusive() && !player.isPlayerOwner()) {
						if(Proxy.INSTANCE.getSide() == EnumSide.CLIENT) {
							continue;
						}
					}
				}

				try {
					Object t = m.invoke(p, args);
					if(t instanceof Boolean && ((Boolean)t).booleanValue()) {
						found = true;
					}
				} catch (Throwable t) {
					System.out.println("Plugin failed: " + p.getName());
					t.printStackTrace();
				}
			}

			return found;
		} else {
			return false;
		}
	}

	// Console catches Throwable
	@Deprecated
	public boolean callPluginMethods2(Method m, Object ... args) throws Throwable {
		if(m != null && args != null && this.enabled) {
			boolean found = false;
			Iterator<Plugin> i$ = this.plugins.iterator();

			while(i$.hasNext()) {
				Plugin p = i$.next(); // Cast to (Plugin) redundant

				try {
					Object t = m.invoke(p, args);
					if(t instanceof Boolean && ((Boolean)t).booleanValue()) {
						found = true;
					}
				} catch (Throwable t) {
					throw t;
				}
			}

			return found;
		} else {
			return false;
		}
	}

	public boolean handlePluginCommand(WPlayer player, String[] args) throws Throwable {
		if(!this.enabled) {
			player.sendError("Plugin Manager is disabled.");
			return true;
		}

		if(args.length < 1) {
			return false;
		}

		for(Plugin plugin : plugins) {
			if(plugin.getCommands() != null) {
				if(plugin.getCommands().contains(args[0])) {
					if(!plugin.getEnabled()) {
						player.sendError("Plugin is disabled.");
						return true;
					}
					if(!plugin.handleCommand(player, args)) {
						player.sendError("Plugin does not have command " + args[0] + ".");
					}
					return true;
				}
			}
		}

		return false;
	}

	public String[] getCommands() {
		Vector<List<String>> vector = new Vector<List<String>>();
		int count = 0;

		for(Plugin plugin : plugins) {
			List<String> temp = plugin.getCommands();
			if(temp != null) {
				count += temp.size();
				vector.add(temp);
			}
		}

		String[] allHelp = new String[count];
		int index = 0;
		Iterator<List<String>> vectorIterator = vector.iterator();

		while(vectorIterator.hasNext()) {
			Iterator<String> pluginCmds = vectorIterator.next().iterator();
			while (pluginCmds.hasNext()) {
				allHelp[index] = pluginCmds.next();
				index++;
			}
		}

		return allHelp;
	}

	public String[] getHelp(String command) {
		if(command != null && !command.equalsIgnoreCase("")) {
			Iterator<Plugin> e1 = this.plugins.iterator();

			Plugin plugin;
			String[] help;
			do {
				if(!e1.hasNext()) {
					return null;
				}

				plugin = e1.next(); // Cast to (Plugin) redundant
				help = null;
			} while((help = plugin.getHelp(command)) == null);

			return help;
		} else {
			return null;
		}
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public Plugin[] getPlugin(String name) {
		Vector<Plugin> temp = new Vector<Plugin>();
		Iterator<Plugin> i$ = this.plugins.iterator();

		while(i$.hasNext()) {
			Plugin plugin = i$.next(); // Cast to (Plugin) redundant
			if(plugin.getName() != null && plugin.getName().equalsIgnoreCase(name)) {
				temp.add(plugin);
			}
		}

		return temp.toArray(new Plugin[temp.size()]); // Cast to (Plugin[]) redundant
	}

	public static void loadJars() {

		// this is not actually possible :)
		if(jarsLoaded) {
			System.out.println("Jars already loaded!");
			return;
		}

		try {
			File e = new File(Helper.getModDir(), "jars");
			if(!e.exists()) {
				throw new ConsoleException("SPConsole: Jars folder missing.");
			} else {
				File[] bin = e.listFiles();
				Vector<String> ignore = new Vector<String>();
				ignore.add("minecraft.jar");
				ignore.add("lwjgl.jar");
				ignore.add("lwjgl_util.jar");
				ignore.add("jinput.jar");
				ignore.add("WorldEdit.jar");
				File[] arr$ = bin;
				int len$ = bin.length;

				for(int i$ = 0; i$ < len$; ++i$) {
					File temp = arr$[i$];
					String name = temp.getName();
					if(!ignore.contains(name) && name.endsWith(".jar")) {
						System.out.println("Adding " + name + " to classpath.");
						Helper.addToClasspath(temp);
					} else {
						System.out.println("Ignoring " + name + ".");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		jarsLoaded = true;

	}

	static { loadJars(); }

}
