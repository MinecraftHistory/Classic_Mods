// Obfuscated version
package com.q3hardcore.console.core;

// Required for plugins to work
import java.lang.reflect.Method;
import org.lwjgl.input.Mouse;
import com.q3hardcore.console.plugin.Plugin;
import java.util.List;

// Wrappers
import com.q3hardcore.console.command.Loader;
import com.q3hardcore.console.wrapper.WMinecraftServer;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;

// Utilities
import com.q3hardcore.console.util.ObfuscationHelper;

public final class Console {

	public static final boolean isEnabled = true;
	private final WPlayer player;

	// Plugin methods
	protected static PluginManager PLUGIN_MANAGER;
	protected static Method PLUGIN_HANDLECOMMAND;
	protected static Method PLUGIN_HANDLELEFTCLICK;
	protected static Method PLUGIN_HANDLERIGHTCLICK;
	protected static Method PLUGIN_ATUPDATE;
	public static Method PLUGIN_HANDLECUIEVENT;

	// Already loaded?
	private static boolean isInitialized = false;

	// Update status?
	private static boolean updateStatus = false;

	// Load 'native commands'?
	private static boolean loadCmds = false;

	public Console(WPlayer entityPlayer) {

		System.out.println("Console instance for player: " + entityPlayer.getUsername());

		player = entityPlayer;

		// load settings
		Helper.loadSettings();

		// register commands
		if(CommandRegistry.registerCommands()) {
			loadCmds = true;
		}

		// Display status if applicable
		displayStatus();
		isInitialized = true;

		// Initialize plugins
		new PluginLoader(this).start();

		player.sendMessage2("\u00a77\u00a7o[XCommands: Checking for XCommands on client]");

	}

	private void displayStatus() {
		if(!isEnabled) {
			if(!updateStatus) {
				player.sendMessage("Console disabled.");
				updateStatus = true;
			}
		} else if(!isInitialized || updateStatus) {

			player.sendMessage2("XCommands by q3hardcore, running on Minecraft " + Helper.getServerVersion()); // Dynamically get version
		}
	}

	protected WPlayer getPlayer() {
		return player;
	}

	public void afterUpdate() {
		if(isEnabled) {
			if(loadCmds) {
				if(!Helper.getHasSPC()) {
					new Loader().start();
				} else {
					System.out.println("Skipping Loader (SPC installed)");
				}
				loadCmds = false;
			}
			if(PLUGIN_MANAGER != null) {
				List<WPlayer> players = WMinecraftServer.getServer().getConfigurationManager().getPlayerEntityList();
				for(int i = 0; i < players.size(); i++) {
					PLUGIN_MANAGER.callPluginMethods(PLUGIN_ATUPDATE, new Object[]{players.get(i)});
				}
			}
			if(!Helper.dropItems) {
				removeItemDrops();
			}
		}
	}

	private void removeItemDrops() {
		ObfuscationHelper.removeItemDrops(player, 128);
	}

	public void sendDebug(String dbg) {
		if(Helper.debug) {
			player.sendMessage2("DEBUG: " + dbg);
		}
	}

	public void printDebug(String dbg) {
		if(Helper.debug) {
			System.out.println("DEBUG: " + dbg);
		}
	}

	public void handleLeftClick(int blockX, int blockY, int blockZ, int side) {
		try {
			WMovingObjectPosition mop = player.rayTrace(player.getBlockReachDistance(), 1.0F);
			PLUGIN_MANAGER.callPluginMethods(PLUGIN_HANDLELEFTCLICK, new Object[]{player, mop});
		} catch (Throwable t) {
			System.out.println("Couldn't handle left click.");
		}

	}

	public void handleRightClick(int blockX, int blockY, int blockZ, int side) {
		try {
			WMovingObjectPosition mop = player.rayTrace(player.getBlockReachDistance(), 1.0F);
			PLUGIN_MANAGER.callPluginMethods(PLUGIN_HANDLERIGHTCLICK, new Object[]{player, mop});
		} catch (Throwable t) {
			System.out.println("Couldn't handle right click.");
		}

	}

	static {

		try {
			PLUGIN_HANDLECOMMAND = Plugin.class.getDeclaredMethod("handleCommand", new Class<?>[]{WPlayer.class, String[].class});
			PLUGIN_HANDLELEFTCLICK = Plugin.class.getDeclaredMethod("handleLeftClick", new Class<?>[]{WPlayer.class, WMovingObjectPosition.class});
			PLUGIN_HANDLERIGHTCLICK = Plugin.class.getDeclaredMethod("handleRightClick", new Class<?>[]{WPlayer.class, WMovingObjectPosition.class});
			PLUGIN_ATUPDATE = Plugin.class.getDeclaredMethod("atUpdate", new Class<?>[]{WPlayer.class});
			PLUGIN_HANDLECUIEVENT = Plugin.class.getDeclaredMethod("handleCUIEvent", new Class<?>[]{String.class, String[].class});
		} catch (Throwable t) {
			System.out.println("Some methods not found.");
		}

	}

	public static PluginManager getPluginManager() {
		return PLUGIN_MANAGER;
	}

}