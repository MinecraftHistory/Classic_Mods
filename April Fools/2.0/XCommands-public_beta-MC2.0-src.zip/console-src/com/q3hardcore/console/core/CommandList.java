package com.q3hardcore.console.core;

// Obfuscated references: 0

import java.util.HashMap;

public final class CommandList {

	// New Help System
	public static final HashMap<String, String[]> CMDS;

	static {
		CMDS = new HashMap<String, String[]>();
		CMDS.put("allowfly", new String[]{"Toggles ability to fly.", "", ""});
		// CMDS.put("autogod", new String[]{"Toggles god mode being auto-enabled.", "", ""});
		CMDS.put("biome", new String[]{"Displays current biome.", "", ""});
		// CMDS.put("clearchat", new String[]{"Clears console messages.", "", ""});
		// CMDS.put("clearwater", new String[]{"Toggles clear water.", "", ""});
		CMDS.put("color", new String[]{"Sets text color.", "<1-15> [error]", "4 error"});
		CMDS.put("dimension", new String[]{"Changes dimension.", "[end|nether|normal]", "normal"});
		CMDS.put("drops", new String[]{"Toggles item drops.", "", ""});
		CMDS.put("feed", new String[]{"Feed specified amount.", "[amount]", "15"});
		CMDS.put("find", new String[]{"Finds ID for specified item.", "[itemname]", "stone"});
		CMDS.put("fly", new String[]{"Toggles ability to fly.", "", ""});
		CMDS.put("give", new String[]{"Gives item with specified id.", "<itemid> [quantity] [damage]", "1"});
		CMDS.put("god", new String[]{"Toggles god mode.", "", ""});
		CMDS.put("heal", new String[]{"Restores health.", "", ""});
		CMDS.put("helmet", new String[]{"Allows player to set helmet item.", "itemid [damage]", "86"});
		CMDS.put("help", new String[]{"List commands, or give help for a specific command.", "[command]", "spawnportal"});
		CMDS.put("hunger", new String[]{"Sets hunger level.", "[empty|full|inf] | [0-20]", "full"});
		CMDS.put("instantmine", new String[]{"Toggles instant mining.", "", ""});
		CMDS.put("resolveid", new String[]{"Tells you the name of a block from it's ID.", "[itemid]", "1"});
		CMDS.put("kill", new String[]{"Kills player (survival only).", "", ""});
		CMDS.put("listcolors", new String[]{"Lists valid text colors.", "", ""});
		CMDS.put("oldhelp", new String[]{"Old help command.", "", ""});
		CMDS.put("phelp", new String[]{"Lists help for plugins.", "<pluginname>", "paint"});
		CMDS.put("platform", new String[]{"Places block of glass beneath player.", "", ""});
		CMDS.put("plugin", new String[]{"Provides plugin information and useful utilities", "<list|enable [MODNAME]|disable [MODNAME]|version [MODNAME]>", "version"});
		CMDS.put("pos", new String[]{"Displays current position.", "", ""});
		// CMDS.put("restoreitems", new String[]{"Restore items player had on death.", "", ""});
		CMDS.put("reach", new String[]{"Change reach distance.", "distance", "64"});
		CMDS.put("remove", new String[]{"Removes selected entity.", "[nearest|force]", ""});
		CMDS.put("removeblock", new String[]{"Removes selected block.", "", ""});
		CMDS.put("roll", new String[]{"Simulates rolling dice.", "[numDice] [sides]", "1 6"});
		CMDS.put("seed", new String[]{"Displays world seed.", "", ""});
		CMDS.put("setblock", new String[]{"Sets selected block.", "[blockid]", "dirt"});
		CMDS.put("serverinfo", new String[]{"Displays integrated server version.", "", ""});
		// CMDS.put("showchat", new String[]{"Displays chat GUI - bound to ~ by default.", "", ""});
		CMDS.put("skullowner", new String[]{"Set the SkullOwner tag on a head.", "playername", "q3hardcore"});
		CMDS.put("spawn", new String[]{"Spawns specified entity.", "[<entityname> [amount]] | list", "boat"});
		// CMDS.put("spawner", new String[]{"Changes entity spawned by mob spawner.", "[entityname]", "SnowMan"});
		CMDS.put("spawnportal", new String[]{"Spawns a portal.", "[nether|end]", "end"});
		CMDS.put("time", new String[]{"Set and get the time within Minecraft.", "[day|night|[set|get [minute|hour|day [TIME]]]]", "set hour 16"});
		CMDS.put("togglecheats", new String[]{"Toggles whether you can use Minecraft's cheats.", "", ""});
		CMDS.put("togglehardcore", new String[]{"Toggles hardcore mode.", "", ""});
		CMDS.put("togglehellworld", new String[]{"Toggles whether you can place water.", "", ""});

		System.out.println("Number of core commands with help: " + CMDS.size());
	}

}