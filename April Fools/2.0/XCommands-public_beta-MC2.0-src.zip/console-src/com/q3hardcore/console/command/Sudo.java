package com.q3hardcore.console.command;

import com.q3hardcore.console.wrapper.WICommandSender;
import com.q3hardcore.console.wrapper.WMinecraftServer;
import com.q3hardcore.console.wrapper.WPlayer;

public class Sudo extends StandardCommand {

	public Sudo() {
		setPlayerCommand(false);
	}

	@Override
	public String getCommandName() {
		return "sudo";
	}

	@Override
	public String getDescription() {
		return "Allows you to run any command as the specified player";
	}

	
	@Override
	public void processCommand(WICommandSender sender, String[] args) {
		if(args.length < 2) {
			sender.sendChatToPlayer("Must specify playername and command.");
			return;
		} else {
			final String playerName = args[0];
			WPlayer player = new WPlayer(c(sender, playerName)); // OBFUSC_REF
			String cmd = args[1];
			if(args.length > 2) {
				for(int i = 2; i < args.length; i++) {
					cmd += " " + args[i];
				}
			}
			WMinecraftServer.getServer().getCommandHandler().executeCommand(player, cmd);
		}
	}

}
