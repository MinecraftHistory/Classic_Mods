package com.q3hardcore.console.command;

import com.q3hardcore.console.wrapper.raw.RCommandBase;

/**
 * Default class to extend to use Multiple commands per class rather than the 
 * standard single class. The way it works is by creating a separate instance 
 * of the class for every command that is in the class. The commands that are 
 * in the class are specified by the getCommands() method and the current 
 * instances command name is accessed using the getName() method. 
 *
 * @see MultipleCommands#getCommands()
 * @see MultipleCommands#getName()
 * @author simo_415
 * @version 1.0
 */
public abstract class MultipleCommands extends RCommandBase {

   /**
    * The name of the command 
    */
   private final String name;
   
   /**
    * Default constructor initialises the instance using the specified command 
    * name. 
    * 
    * @param name - The command name
    */
   public MultipleCommands(String name) { 
      this.name = name;
   }
   
   /**
    * @see com.sijobe.spc.wrapper.CommandBase#getName()
    */
   @Override
   public final String getCommandName() {
      return name;
   }
   
   /**
    * Gets an array containing all of the commands that this class contains. 
    * This array is used to initialise instances of the class.
    * 
    * @return An array of command names
    */
   public abstract String[] getCommands();

}
