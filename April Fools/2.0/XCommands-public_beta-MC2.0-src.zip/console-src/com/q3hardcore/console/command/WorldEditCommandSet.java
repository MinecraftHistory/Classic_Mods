package com.q3hardcore.console.command;

import com.q3hardcore.console.command.MultipleCommands;
import com.q3hardcore.console.wrapper.Coordinate;
import com.q3hardcore.console.wrapper.WMinecraftServer;
import com.q3hardcore.console.wrapper.WPlayer;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Proxy;
import com.q3hardcore.console.worldedit.ConsoleLocalPlayer;
import com.q3hardcore.console.worldedit.ConsoleServerInterface;
import com.q3hardcore.console.worldedit.ConsoleLocalConfiguration;

import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.WorldVector;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * The class that provides connection to WorldEdit. 
 *
 * @author simo_415
 * @version 1.1
 */
public final class WorldEditCommandSet extends MultipleCommands {

	/**
	 * The WorldEdit object that the class communicates to WorldEdit with
	 */
	public static WorldEdit WORLDEDIT;
	/**
	 * The server interface that WorldEdit is using
	 */
	public static ConsoleServerInterface SERVER; 
	/**
	 * The configuration that WorldEdit is using
	 */
	public static ConsoleLocalConfiguration CONFIGURATION;

	/**
	 * Stores the last instance of this class that was created
	 */
	private static WorldEditCommandSet INSTANCE;

	private static boolean isLoaded = false;

	private static final HashMap<Integer, ConsoleLocalPlayer> cachedPlayers = new HashMap<Integer, ConsoleLocalPlayer>();
	private static int worldHashCode = -1;

	public WorldEditCommandSet(String name) {
		super(name);

		if(!isLoaded) {
			File workingDirectory = Helper.getMinecraftDir();
			File configurationFile = new File(Helper.getModDir(), "worldedit.properties");
			CONFIGURATION = new ConsoleLocalConfiguration(workingDirectory, configurationFile);
			if(configurationFile.exists()) {
				CONFIGURATION.load();
			}

			SERVER = new ConsoleServerInterface(null);
			WORLDEDIT = new WorldEdit(SERVER, CONFIGURATION);
			INSTANCE = this;

			isLoaded = true;
		}
	}

	public static boolean isLoaded() {
		return isLoaded;
	}

	public static boolean hasCommand(String cmd) {
		return WORLDEDIT.getCommands().keySet().contains(cmd);
	}

	public static String getCommandDesc(String cmd) {
		return WORLDEDIT.getCommands().get(cmd);
	}

	// UNUSED
	@Deprecated
	public static String[] getWECommands() {
		return WORLDEDIT.getCommands().keySet().toArray(new String[0]);
	}

	public static boolean hasWorldEdit() {
		return Helper.getHasWorldEdit() && WORLDEDIT != null;
	}

	/**
	 * Gets the currently constructed instance of the class. This allows reuse 
	 * of the same class by multiple implementing classes without having to 
	 * create new instances and deal with that.
	 * 
	 * @return The current instance of this class
	 */
	public static WorldEditCommandSet getCurrentInstance() {
		return INSTANCE;
	}

	@Override
	public String[] getCommands() {
		return WORLDEDIT.getCommands().keySet().toArray(new String[]{});
	}

	@Override
	public String getDescription() {
		return WORLDEDIT.getCommands().get(getCommandName());
	}

	@Override
	public void processCommand(WPlayer player, String[] args) {
		String[] cmdString = new String[args.length + 1];
		cmdString[0] = "/" + this.getCommandName();
		int index = 1;
		for(String argument : args) {
			cmdString[index] = argument;
			index++;
		}
		handleCommand(player, cmdString);
	}

	// there is no real reason to cache player instances
	private static ConsoleLocalPlayer getCachedPlayer(WPlayer player) {
		// if the world has changed, clear player cache
		if(worldHashCode != player.getWorld().rawHashCode()) {
			cachedPlayers.clear();
			worldHashCode = player.getWorld().rawHashCode();
		}
		
		ConsoleLocalPlayer localPlayer;

		// check if player is already cached
		if(cachedPlayers.containsKey(player.rawHashCode())) {
			localPlayer = cachedPlayers.get(player.rawHashCode());
			// if inventory hash code changed, player has respawned
			if(localPlayer.player.inventoryHashCode() != player.inventoryHashCode()) {
				// System.out.println("Updating cached player");
				localPlayer = new ConsoleLocalPlayer(SERVER, player);
				cachedPlayers.put(player.rawHashCode(), localPlayer);
			}
		} else {
			localPlayer = new ConsoleLocalPlayer(SERVER, player);
			cachedPlayers.put(player.rawHashCode(), localPlayer);
		}

		return localPlayer;
	}

	/**
	 * Handles a command that is sent to a WorldEdit command
	 * 
	 * @param player - The player that executed the command
	 * @param command - The arguments (command) that the player sent
	 */
	public static void handleCommand(WPlayer player, String command[]) {
		final ConsoleLocalPlayer localPlayer = getCachedPlayer(player);

		if(Proxy.INSTANCE.getSide() == EnumSide.CLIENT) {
			if(localPlayer.getName().equals(WMinecraftServer.getServer().getServerOwner())) {
				WORLDEDIT.getSession(localPlayer).setCUISupport(true);
				WORLDEDIT.getSession(localPlayer).dispatchCUISetup(localPlayer);
			}
		}
		boolean handled = WORLDEDIT.handleCommand(localPlayer, command);
		if(!handled) {
			System.out.println("Invalid WE command.");
		}
	}

	public static void handleMouseButtonDown(WPlayer spcplayer, int blockx, int blocky, int blockz, int side, boolean isLeft) {

		if(!hasWorldEdit()) {
			// System.out.println("Can't handle click.");
			return;
		}

		if(blocky < 0) {
			System.out.println("SPConsole/WE: Player hit invalid position");
			return;
		}

		try {
			final ConsoleLocalPlayer player = getCachedPlayer(spcplayer);

			if(Proxy.INSTANCE.getSide() == EnumSide.CLIENT) {
				if(player.getName().equals(WMinecraftServer.getServer().getServerOwner())) {
					WORLDEDIT.getSession(player).setCUISupport(true);
					WORLDEDIT.getSession(player).dispatchCUISetup(player);
				}
			}

			WorldVector vector = new WorldVector(player.getWorld(), blockx, blocky, blockz);
			boolean updatePrevBlock = false;

			final boolean notPrevBlock;
			if(!isLeft) {
				notPrevBlock = (blockx != player.blockrightx || blocky != player.blockrighty || blockz != player.blockrightz);
			} else {
				notPrevBlock = (blockx != player.blockleftx || blocky != player.blocklefty || blockz != player.blockleftz);
			}

			if(!isLeft) {
				if(side != -1) {
					WORLDEDIT.handleRightClick(player);
				}
				if(notPrevBlock) {
					WORLDEDIT.handleBlockRightClick(player, vector);
					updatePrevBlock = true;
				}
			} else {
				if(side != -1) {
					WORLDEDIT.handleArmSwing(player);
				}
				if(notPrevBlock) {
					WORLDEDIT.handleBlockLeftClick(player, vector);
					updatePrevBlock = true;
				}
			}

			if(updatePrevBlock) {
				if(!isLeft) {
					player.blockrightx = blockx;
					player.blockrighty = blocky;
					player.blockrightz = blockz;
				} else {
					player.blockleftx = blockx;
					player.blocklefty = blocky;
					player.blockleftz = blockz;
				}
			}
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
