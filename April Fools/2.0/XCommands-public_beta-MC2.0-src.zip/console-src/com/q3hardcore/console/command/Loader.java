// Ported from SinglePlayerCommands
// This is used to load commands

package com.q3hardcore.console.command;

import com.q3hardcore.console.wrapper.WCommandHandler;
import com.q3hardcore.console.wrapper.WMinecraftServer;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class Loader extends Thread {

	private static URLClassLoader CLASSLOADER;
	final WCommandHandler commandHandler;

	public Loader() {
		commandHandler = WMinecraftServer.getServer().getCommandHandler();
	}

	/**
	 * Get classloader for this class
	 */
	public static URLClassLoader getClassLoader() {
		if (CLASSLOADER == null) {
			CLASSLOADER = (URLClassLoader)Loader.class.getClassLoader();
		}
		return CLASSLOADER;
	}

	@Override
	public void run() {
		long oldTime = System.currentTimeMillis();
		if(commandHandler.isValid()) {
			loadCommands();
		} else {
			System.err.println("SPConsole: Not loading 'native' commands.");
			return;
		}
		long newTime = System.currentTimeMillis();
		System.out.println("SPCommands: Native commands thread took: " + (newTime - oldTime));
	}

	@SuppressWarnings("unchecked")
	private void loadCommands() {
		System.out.println("Loading commands.");
		List<Class<?>> commands = getCommands();
		for (Class<?> clazz : commands) {
			if(clazz == null) {
				System.out.println("Report this!");
				continue;
			}
			if(StandardCommand.class.isAssignableFrom(clazz)) {
				if(!loadStandardCommand((Class<StandardCommand>)clazz))
					continue;
			} else if(MultipleCommands.class.isAssignableFrom(clazz)) {
				if(!loadMultipleCommands((Class<MultipleCommands>)clazz))
					continue;
			} else {
				if(clazz.toString().contains("com.q3hardcore.console.command")) {
					String className = clazz.toString();
					int packageIndex = className.lastIndexOf(46);
					if(packageIndex != -1) {
						className = className.substring(packageIndex + 1);
					}
					System.out.println("Skipping class: " + className + " (non-command)");
				}
				continue;
			}
		}
	}

	private boolean loadStandardCommand(Class<StandardCommand> command) {
		try {
			String shortName = command.toString();
			int shortNameIndex = shortName.lastIndexOf(46);
			if(shortNameIndex != -1) {
				shortName = shortName.substring(shortNameIndex + 1);
			}
			if (Modifier.isAbstract(command.getModifiers())) {
				System.out.println("Skipping class: " + shortName + " (abstract)");
				return false;
			}
			System.out.println("Loading class: " + shortName);
			StandardCommand cmd = command.newInstance();
			if (!cmd.isEnabled()) {
				System.out.println("Command not enabled.");
				return false;
			}
			if (commandHandler.doesCommandExist(cmd.getCommandName())) { // TODO: review this
				System.out.println("Overwriting existing command named: " + cmd.getCommandName());
			} else {
				System.out.println("Registering command: " + cmd.getCommandName());
			}
			commandHandler.registerCommand(cmd);
			return true;
		} catch (Exception e) {
			System.err.println("There was an issue initialising class " + command.getName() + ". Verify that the class is setup correctly.");
			e.printStackTrace();
			return false;
		}
	}

	private boolean loadMultipleCommands(Class<MultipleCommands> command) {
		String shortName = command.toString();
		int shortNameIndex = shortName.lastIndexOf(46);
		if(shortNameIndex != -1) {
			shortName = shortName.substring(shortNameIndex + 1);
		}
		if (Modifier.isAbstract(command.getModifiers())) {
			System.out.println("Skipping class: " + shortName + " (abstract class)");
			return false;
		}
		System.out.println("Loading class: " + shortName);
		try {
			Constructor<MultipleCommands> constructor = command.getConstructor(String.class);
			MultipleCommands instance = constructor.newInstance((String)null);
			String commandNames[] = instance.getCommands();
			if (commandNames == null) {
				return false;
			}
			
			for (String name : commandNames) {
				MultipleCommands cmd = constructor.newInstance(name);
				if (!cmd.isEnabled()) {
					System.out.println("Command not enabled.");
					return false;
				}
				if (commandHandler.doesCommandExist(cmd.getCommandName())) {
					System.out.println("Overwriting existing command named: " + cmd.getCommandName());
				}
				// System.out.println("Registering command: " + cmd.getCommandName());
				commandHandler.registerCommand(cmd);
			}
			return true;
		} catch (Throwable e) {
			System.err.println("Failed to load " + command.getName());
			// e.printStackTrace();
			return false;
		}
	}

	/**
	 * Loads only command classes if running from folder, otherwise all classes
	 * 
	 * @return A List containing the relevant classes is returned
	 */
	private List<Class<?>> getCommands() {
		String classname = Loader.class.getName();
		int depth = classname.split("\\.").length;
		classname = classname.split("\\.")[depth - 1];
		String location = Loader.class.getResource(classname + ".class").toString();
		if (location.startsWith("jar")) {
			try {
				// System.out.println("old location: " + location);
				location = location.replaceAll("jar:", "").split("!")[0];
				// System.out.println("new location: " + location);
				File root = (new File((new URL(location)).toURI())); 
				return loadClassesFromJAR(root);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		} else {
			try {
				File root = (new File((new URL(location)).toURI()));
				root = root.getParentFile();
				String rootPath = root.toString();
				int packageIndex = rootPath.indexOf("com" + File.separator + "q3hardcore");
				if(packageIndex != -1) {
					rootPath = rootPath.substring(packageIndex);
					rootPath = rootPath.replace(File.separatorChar, '.');
				}
				System.out.println("Command package: " + rootPath);
				return loadClassesFromDirectory(root, "com/q3hardcore/console/command");
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	/**
	 * Loads all the classes within the specified directory
	 * 
	 * @param directory - The directory to load all of the classes from
	 * @return A Vector containing all of the loaded classes is returned
	 */
	public static List<Class<?>> loadClassesFromDirectory(File directory) {
		return loadClassesFromDirectory(directory,"");
	}

	/**
	 * Loads all the classes within the specified directory
	 * 
	 * @param directory - The directory to load all of the classes from
	 * @param parent - The path of the parent directory(s). This parent is used
	 * as the package name of the classes that are loaded.
	 * @return A Vector containing all of the loaded classes is returned
	 */
	public static List<Class<?>> loadClassesFromDirectory(File directory, String parent) {
		Vector<Class<?>> classes = new Vector<Class<?>>();
		try {
			File files[] = directory.listFiles();
			for (File file : files) {
				try {
					if (file.isFile()) {
						classes.add(loadClass(file.getName(),parent));
					} else {
						classes.addAll(loadClassesFromDirectory(file,parent + file.getName() + "/"));
					}
				} catch (Exception e) {
				}
			}
		} catch (Exception e) {
			return null;
		}
		return classes;
	}

	/**
	 * Loads all of the classes that are contained within the specified JAR 
	 * file.
	 * 
	 * @param jar - The location of the JAR file
	 * @return A Vector containing all of the classes that are part of this JAR
	 * that were loaded
	 */
	public static List<Class<?>> loadClassesFromJAR(File jar) {
		Vector<Class<?>> classes = new Vector<Class<?>>();
		try {
			JarFile jf = new JarFile(jar);
			Enumeration<JarEntry> em = jf.entries();

			while (em.hasMoreElements()) {
				JarEntry je = em.nextElement();
				try {
					classes.add(loadClass(je.getName(), null));
				} catch (Throwable t) {
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return classes;
	}

	/**
	 * Loads a single class onto the system classpath. As this method is 
	 * intended for use by classes dynamically loading content from the file 
	 * system the clazz parameter should be the filename on the system - ie: 
	 * CLASSNAME.class - the .class is the important part. The pack parameter is
	 * the package that the class belongs to.
	 * 
	 * @param clazz - The name of the class with a .class extension
	 * @param pack - The name of the package
	 * @return The Class object that was loaded based on the parameters
	 * @throws Exception When the specified class is not a .class
	 */
	public static Class<?> loadClass(String clazz, String pack) throws Exception {
		if (!clazz.endsWith(".class")) {
			throw new Exception("'" + clazz + "' is not a class.");
		}
		if(pack == null && !clazz.startsWith("com/q3hardcore/console/command")) {
			throw new Exception("Skipping class (wrong package)");
		}
		clazz = clazz.split("\\.")[0];
		if (pack != null) {
			pack = pack.endsWith("/") ? pack.substring(0, pack.length() - 1) : pack;
		}
		clazz = pack == null ? clazz : pack + "." + clazz;
		clazz = clazz.replaceAll("/", ".");

		if(clazz.startsWith(".")) {
			clazz = clazz.substring(1);
		}

		URLClassLoader loader = getClassLoader();
		Class<?> c;
		//System.out.print(clazz + " loading... ");
		try {
			c = loader.loadClass(clazz);
		} catch (Throwable e) {
			System.out.println("Couldn't load " + clazz);
			e.printStackTrace();
			return null;
		}
		//System.out.println("loaded.");	
		return c;
	}

}