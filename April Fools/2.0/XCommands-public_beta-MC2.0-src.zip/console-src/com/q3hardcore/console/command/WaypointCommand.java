package com.q3hardcore.console.command;
// Times re-obfuscated: 0

import java.io.File;
import java.util.List;
import java.util.ArrayList;
import com.q3hardcore.console.command.StandardCommand;
import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.waypoint.*;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WWorldProvider;

public class WaypointCommand extends StandardCommand {

	@Override
	public String getCommandName() {
		return "waypoint";
	}

	@Override
	public String getDescription() {
		return "Provides tools for managing waypoints";
	}

	@Override
	public void processCommand(WPlayer player, String[] args) {
		if(args.length == 0) {
			player.addChatMessage("Waypoint commands: add, del, info, goto, list");
			return;
		}

		File waypointFile = WaypointHelper.getWaypointFile(player.getWorld());

		if(args[0].equals("list")) {
			if(!waypointFile.exists()) {
				player.addChatMessage("No waypoints for this world.");
			} else {
				List<Waypoint> waypoints = WaypointHelper.resolveWaypoints(waypointFile);
				if(waypoints.size() == 0) {
					player.addChatMessage("No waypoints added yet.");
					return;
				}
				for(Waypoint waypoint : waypoints) {
					player.addChatMessage(waypoint.getName() + " created by " + waypoint.getPlayerName());
				}
			}
		} else if(args[0].equals("add")) {
			if(args.length > 1) {
				WaypointHelper.addWaypoint(waypointFile, new Waypoint(args[1], player.getUsername(), player.getPosition(), player.getDimension()));
				player.addChatMessage("Added waypoint.");
			} else {
				player.addChatMessage("Must specify waypoint name.");
				return;
			}
		} else if(args[0].equals("goto")) {
			if(args.length > 1) {
				if(!WaypointHelper.hasWaypoint(waypointFile, args[1])) {
					player.addChatMessage("Waypoint doesn't exist.");
					return;
				} else {
					Waypoint waypoint;
					try {
						waypoint = WaypointHelper.getWaypoint(waypointFile, args[1]);
					} catch (WaypointException we) {
						player.addChatMessage("Invalid waypoint data.");
						return;
					}
					int dimension = waypoint.getDimension();
					if(player.getDimension() != dimension) {
						if(WWorldProvider.getProviderForDimension(dimension) == null) { // WorldProvider.getProviderForDimension
							player.addChatMessage("Waypoint is located in invalid dimension.");
							return;
						}
						player.addChatMessage("Waypoint located in dimension " + dimension + ".");
						return;
					}
					player.setPositionAndUpdate(waypoint.getCoordinate());
					player.addChatMessage("Now at waypoint.");
				}
			} else {
				player.addChatMessage("Must specify waypoint name.");
				return;
			}
		} else if(args[0].equals("del")) {
			if(args.length > 1) {
				if(!WaypointHelper.hasWaypoint(waypointFile, args[1])) {
					player.addChatMessage("Waypoint doesn't exist.");
					return;
				} else {
					WaypointHelper.removeWaypoint(waypointFile, args[1]);
					player.addChatMessage("Removed waypoint " + args[1] + ".");
				}
			} else {
				player.addChatMessage("Must specify waypoint name.");
				return;
			}
		} else if(args[0].equals("info")) {
			if(args.length > 1) {
				if(!WaypointHelper.hasWaypoint(waypointFile, args[1])) {
					player.addChatMessage("Waypoint doesn't exist.");
					return;
				} else {
					Waypoint waypoint;
					try {
						waypoint = WaypointHelper.getWaypoint(waypointFile, args[1]);
					} catch (WaypointException we) {
						player.addChatMessage("Invalid waypoint data.");
						return;
					}
					player.addChatMessage("Waypoint '" + waypoint.getName() + "', created by: " + waypoint.getPlayerName() + ".");
					player.addChatMessage("Position: " + waypoint.getCoordinate().toString() + " Dimension: " + waypoint.getDimension());
				}
			} else {
				player.addChatMessage("Must specify waypoint name.");
				return;
			}
		} else {
			player.addChatMessage("Unknown waypoint command.");
		}
	}

}
