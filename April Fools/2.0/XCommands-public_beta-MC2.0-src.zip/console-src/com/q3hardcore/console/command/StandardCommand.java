package com.q3hardcore.console.command;

import com.q3hardcore.console.wrapper.raw.RCommandBase;

// TODO: add some functions

public abstract class StandardCommand extends RCommandBase {

	// currently unused
	public boolean requiresForge() {
		return false;
	}

	// currently unused
	public boolean nativeCommand() {
		return true;
	}

}