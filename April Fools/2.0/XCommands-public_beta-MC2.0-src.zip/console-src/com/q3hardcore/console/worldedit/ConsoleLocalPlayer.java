// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.worldedit;

import com.sk89q.worldedit.LocalPlayer;
import com.sk89q.worldedit.LocalWorld;
import com.sk89q.worldedit.ServerInterface;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.WorldVector;
import com.sk89q.worldedit.bags.BlockBag;
import com.sk89q.worldedit.blocks.BaseItemStack;
import com.sk89q.worldedit.cui.CUIEvent;

import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.PluginManager;
import com.q3hardcore.console.wrapper.WItemStack;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Proxy;

public final class ConsoleLocalPlayer extends LocalPlayer {

	public WPlayer player;

	public int blockrightx;
	public int blockrighty;
	public int blockrightz;
	public int blockleftx;
	public int blocklefty;
	public int blockleftz;

	public boolean hide = false;

	public ConsoleLocalPlayer(ServerInterface server, WPlayer player) { // EntityPlayerMP
		super(server);
		this.player = player;
	}

	// TODO: this should return permission groups
	@Override
	public String[] getGroups() {
		return new String[0];
	}

	@Override
	public BlockBag getInventoryBlockBag() {
		return null;
	}

	@Override
	public int getItemInHand() {
		WItemStack itemstack = this.player.getCurrentItem(); // ItemStack, ph.inventory.getCurrentItem()
		return itemstack == null?0:itemstack.getItemID(); // itemID
	}

	@Override
	public String getName() {
		return this.player.getUsername(); // username
	}

	@Override
	public double getPitch() {
		return (double)this.player.getPitch();
	}

	@Override
	public WorldVector getPosition() {
		return new WorldVector(this.getWorld(), player.getPosX(), player.getPosY() - 1.0D, player.getPosZ());
	}

	@Override
	public LocalWorld getWorld() {
		return new ConsoleLocalWorld(this.player.getWorld()); // worldObj
	}

	@Override
	public double getYaw() {
		return (double)this.player.getYaw();
	}

	@Override
	public void giveItem(int type, int amt) {
		WItemStack itemStack = WItemStack.instantiate(type, amt, 0); // ItemStack
		player.addItemStackToInventory(itemStack); // inventory.addItemStackToInventory
	}

	// TODO: check if player has permission
	@Override
	public boolean hasPermission(String perm) {
		return true;
	}

	@Override
	public void print(String arg0) {
		if(arg0.contains("position set to") && hide) {
			return;
		}
		this.player.sendMessage(arg0);
	}

	@Override
	public void printError(String arg0) {
		this.player.sendError(arg0);
	}

	@Override
	public void printRaw(String arg0) {
		this.player.sendMessage2(arg0);
	}

	@Override
	public void printDebug(String text) {
		this.player.getConsole().sendDebug(text);
	}

	@Override
	public void setPosition(Vector pos, float pitch, float yaw) {
		player.setRotation(yaw, pitch);
		player.setPositionAndUpdate(pos.getX(), pos.getY(), pos.getZ());
		//System.out.println("DEBUG: we update pos");
		//this.player.setLocationAndAngles(pos.getX(), pos.getY() + 2.0D, pos.getZ(), yaw, pitch); // setPositionAndRotation
	}

	@Override
	public WorldVector getBlockTrace(int range) {
		WMovingObjectPosition soh = this.player.rayTrace((double)range, 1.0F);
		return new WorldVector(this.getWorld(), soh.blockx, soh.blocky, soh.blockz); // blockX, blockY, blockZ
	}

	@Override
	public WorldVector getSolidBlockTrace(int range) {
		return this.getBlockTrace(range);
	}

	@Override
	public void dispatchCUIEvent(CUIEvent event) {
		if(Proxy.INSTANCE.getSide() == EnumSide.SERVER) {
			return;
		}

		try {
			PluginManager.getPluginManager().callPluginMethods(Console.PLUGIN_HANDLECUIEVENT, new Object[]{event.getTypeId(), event.getParameters()});
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}
}
