// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.worldedit;

// Obfuscated references: 0

import com.sk89q.worldedit.BiomeTypes;
import com.sk89q.worldedit.ServerInterface;

import com.q3hardcore.console.wrapper.WWorld;

public final class ConsoleServerInterface extends ServerInterface {

	public WWorld world; // World
	private BiomeTypes biomes;

	public ConsoleServerInterface(WWorld world) { // World
		this.world = world;
		this.biomes = new ConsoleBiomeTypes();
	}

	@Override
	public boolean isValidMobType(String arg0) {
		return false; // EntityList.stringToClassMapping.containsKey
	}

	@Override
	public int resolveItem(String arg0) {
		return 0; // why does this do nothing?
	}

	@Override
	public void reload() {}

	@Override
	public BiomeTypes getBiomes() {
		return this.biomes;
	}

}
