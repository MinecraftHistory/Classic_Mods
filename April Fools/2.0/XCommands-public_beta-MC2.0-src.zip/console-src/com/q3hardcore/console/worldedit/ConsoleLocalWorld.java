// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.worldedit;

import com.sk89q.worldedit.BiomeType;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.EntityType;
import com.sk89q.worldedit.LocalWorld;
import com.sk89q.worldedit.MaxChangedBlocksException;
import com.sk89q.worldedit.Vector;
import com.sk89q.worldedit.Vector2D;
import com.sk89q.worldedit.blocks.BaseBlock;
import com.sk89q.worldedit.blocks.BaseItemStack;
import com.sk89q.worldedit.regions.Region;
import java.util.List;
import java.util.Random;

import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.proxy.Proxy;
import com.q3hardcore.console.wrapper.WAxisAlignedBB;
import com.q3hardcore.console.wrapper.WBlock;
import com.q3hardcore.console.wrapper.WBiome;
import com.q3hardcore.console.wrapper.WChunk;
import com.q3hardcore.console.wrapper.WDamageSource;
import com.q3hardcore.console.wrapper.WEntity;
import com.q3hardcore.console.wrapper.WEntityLiving;
import com.q3hardcore.console.wrapper.WEntityPlayer;
import com.q3hardcore.console.wrapper.WIInventory;
import com.q3hardcore.console.wrapper.WItemStack;
import com.q3hardcore.console.wrapper.WMinecraftServer;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WWorld;
import com.q3hardcore.console.wrapper.WWorldGenerator;
import com.q3hardcore.console.wrapper.lists.LEntities;
import com.q3hardcore.console.wrapper.lists.LWorldGen;

public final class ConsoleLocalWorld extends LocalWorld {

	public WWorld world; // World
	public Random random;

	public ConsoleLocalWorld(WWorld world) { // World
		this.world = world;
		this.random = new Random();
	}

	@Override
	public boolean equals(Object object) {
		if(object instanceof ConsoleLocalWorld) {
			return world.equalTo(((ConsoleLocalWorld)object).world);
		} else {
			return false;
		}
	}

	@Override
	@Deprecated
	public boolean generateTree(EditSession session, Vector pos) {
		WWorldGenerator tree = new LWorldGen.Trees(true); // WorldGenTrees
		return tree.generate(this.world, this.random, pos.getBlockX(), pos.getBlockY(), pos.getBlockZ()); // generate
	}


	@Override
	@Deprecated
	public boolean generateBigTree(EditSession session, Vector pos) {
		WWorldGenerator bigtree = new LWorldGen.BigTree(true); // WorldGenBigTree
		return bigtree.generate(this.world, this.random, pos.getBlockX(), pos.getBlockY(), pos.getBlockZ()); // generate
	}


	@Override
	@Deprecated
	public boolean generateBirchTree(EditSession session, Vector pos) throws MaxChangedBlocksException {
		return (new LWorldGen.Forest(true)).generate(this.world, this.random, pos.getBlockX(), pos.getBlockY(), pos.getBlockZ()); // WorldGenForest, generate
	}

	@Override
	@Deprecated
	public boolean generateRedwoodTree(EditSession session, Vector pos) throws MaxChangedBlocksException {
		return (new LWorldGen.Taiga1()).generate(this.world, this.random, pos.getBlockX(), pos.getBlockY(), pos.getBlockZ()); // WorldGenTaiga1, generate
	}

	@Override
	@Deprecated
	public boolean generateTallRedwoodTree(EditSession session, Vector pos) throws MaxChangedBlocksException {
		return (new LWorldGen.Taiga2(true)).generate(this.world, this.random, pos.getBlockX(), pos.getBlockY(), pos.getBlockZ()); // WorldGenTaiga2, generate
	}

	@Override
	public int getBlockData(Vector pos) {
		return this.world.getBlockMetadata(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ());
	}

	@Override
	public int getBlockType(Vector pos) {
		return this.world.getBlockId(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ());
	}

	@Override
	public int hashCode() {
		return world.hashCode();
	}

	@Override
	@Deprecated
	@SuppressWarnings("unchecked")
	public int killMobs(Vector pos, int radius) {
		List<WEntity> entities = this.world.getEntitiesWithinAABBExcludingEntity(null,
			WAxisAlignedBB.getBoundingBox(pos.getX() - (double)radius, pos.getY() - (double)radius, pos.getZ() - (double)radius,
			pos.getX() + (double)radius, pos.getY() + (double)radius, pos.getZ() + (double)radius));
		int count = 0;
		for(WEntity entity : entities) {
			WEntityLiving entityLiving = WEntityLiving.instantiate(entity);
			if(entityLiving != null) {
				if(WEntityPlayer.isEntityInstance(entityLiving)) {
					continue;
				}
				entityLiving.damageEntity(WDamageSource.causePlayerDamage(new WEntityPlayer(null)), Integer.MAX_VALUE);
				try {
					String firstPlayer = WMinecraftServer.getServer().getFirstPlayerName();
					WPlayer player = WMinecraftServer.getServer().getConfigurationManager().getPlayerForUsername(firstPlayer);
					player.getMinecraftPlayer().g.add(entityLiving.getEntityID()); // destroyedItemsNetCachem, entityId
				} catch (Exception e) {}
				count++;
			}
		}
		return count;
	}

	@Override
	@Deprecated
	public void setBlockData(Vector pos, int data) {
		this.world.setBlockMetadataWithNotify(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ(), data);
	}

	@Override
	@Deprecated
	public boolean setBlockType(Vector pos, int type) {
		return this.world.setBlockWithNotify(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ(), type);
	}

	@Override
	@SuppressWarnings("deprecation")
	public void dropItem(Vector pos, BaseItemStack item) {
		WItemStack itemstack = WItemStack.instantiate(item.getType(), item.getAmount(), item.getDamage()); // ItemStack
		LEntities.Item entityitem = new LEntities.Item(this.world, pos.getX(), pos.getY(), pos.getZ(), itemstack); // EntityItem
		this.world.spawnEntityInWorld(entityitem); // spawnEntityInWorld
	}

	@Override
	public boolean clearContainerBlockContents(Vector pos) {
		try {
			WIInventory tileEntity = WIInventory.instantiate(this.world.getBlockTileEntity(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ())); // IInventory, getBlockTileEntity

			for(int j = 0; j < tileEntity.getSizeInventory(); j++) { // getSizeInventory
				tileEntity.setInventorySlotContents(j, null); // setInventorySlotContents, ItemStack
			}

			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public boolean copyFromWorld(Vector pos, BaseBlock block) {
		block.setData(this.world.getBlockMetadata(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ()));
		block.setType(this.world.getBlockId(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ()));
		return true;
	}

	@Override
	public boolean copyToWorld(Vector pos, BaseBlock block) {
		return this.world.setBlockAndMetadataWithNotify(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ(), block.getType(), block.getData());
	}

	@Override
	public boolean regenerate(Region arg0, EditSession arg1) {
		return false; // TODO: code this
	}

	@Override
	public int removeEntities(EntityType arg0, Vector arg1, int arg2) {
		return 1; // used to be 0
	}

	@Override
	public int getBlockLightLevel(Vector pos) {
		return this.world.getBlockLightValue(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ()); // getBlockLightValue
	}

	@Override
	@Deprecated
	public int killMobs(Vector arg0, int arg1, boolean arg2) {
		if(arg2 == false) {
			return killMobs(arg0, arg1);
		}
		return 0;
	}

	@Override
	public boolean isValidBlockType(int type) {
		return type == 0?true:(type > -1 && type < WBlock.blocksList.length?WBlock.blocksList[type] != null:false);
	}

	@Override
	public String getName() {
		return this.world.getName();
	}

	@Override
	@Deprecated
	public void setBlockDataFast(Vector pos, int type) {
		this.world.setBlock(pos.getBlockX(), pos.getBlockY(), pos.getBlockZ(), type);
	}

	@Override
	public void simulateBlockMine(Vector pt) {
		int x = pt.getBlockX();
		int y = pt.getBlockY();
		int z = pt.getBlockZ();

		WBlock block = new WBlock( WBlock.blocksList[world.getBlockId(x, y, z)] );
		byte metadata = (byte)world.getBlockMetadata(x, y, z);

		if(block.isValid()) {
			block.dropBlockAsItemWithChance(world, x, y, z, metadata, 1.0F, 0);
		}
	}

	@Override
	public BiomeType getBiome(Vector2D arg0) {
		WBiome biome = this.world.getBiomeGenAt(arg0.getBlockX(), arg0.getBlockZ()); // world.getWorldChunkManager().getBiomeGenAt
		try {
			return ConsoleBiomeType.valueOf(biome.getBiomeName().toUpperCase(java.util.Locale.ENGLISH)); // name
		} catch(IllegalArgumentException e) {
			return BiomeType.UNKNOWN;
		} 
	}

	@Override
	public void setBiome(Vector2D arg0, BiomeType arg1) {

		if(arg1 instanceof ConsoleBiomeType) {
			int biomeId = ((ConsoleBiomeType) arg1).getBiomeID();

			int x = arg0.getBlockX();
			int z = arg0.getBlockZ();

			if(this.world.blockExists(x, 0, z)) { // blockExists
				WChunk chunk = this.world.getChunkFromBlockCoords(x, z); // Chunk, getChunkFromBlockCoords
				if(chunk.isValid()) {
					byte[] biomevals = chunk.getBiomeArray(); // getBiomeArray
					biomevals[((z & 0xF) << 4 | x & 0xF)] = (byte)biomeId;
					Proxy.INSTANCE.updateClientBiomeArray(x, z, biomevals);
				}
			}
		}

	}

}
