package com.q3hardcore.console.worldedit;

// Obfuscated references: 0

import java.lang.reflect.Field;
import java.util.HashMap;
import com.sk89q.worldedit.BiomeType;
import com.q3hardcore.console.wrapper.WBiome;

public class ConsoleBiomeType implements BiomeType {
	private WBiome biome;

	private static final HashMap<String, BiomeType> cachedValues = new HashMap<String, BiomeType>();

	public ConsoleBiomeType(WBiome biome) {
		this.biome = biome;
	}

	@Override
	public String getName() {
		return this.biome.getBiomeName();
	}

	public int getBiomeID() {
		return biome.getBiomeID();
	}

	public static BiomeType valueOf(String name) throws IllegalArgumentException {
		updateValues();
		if(name == null) {
			throw new IllegalArgumentException("Name specified was null");
		}
		final String lowercaseName = name.toLowerCase();
		if(cachedValues.containsKey(lowercaseName)) {
			return cachedValues.get(lowercaseName);
		} else {
			throw new IllegalArgumentException("Unknown biome name specified");
		}
	}

	public static BiomeType[] values() {
		updateValues();
		return cachedValues.values().toArray(new BiomeType[0]);
	}

	private static void updateValues() {
		if(cachedValues.isEmpty() || cachedValues.size() != WBiome.getBiomeList().length) {
			System.out.println("SPConsole/WE: Loading biome type pairings");
			cachedValues.clear();
			final WBiome[] biomeList = WBiome.getBiomeList();
			for(WBiome biome : biomeList) {
				if(biome == null) {
					continue;
				}
				cachedValues.put(biome.getBiomeName().toLowerCase(), new ConsoleBiomeType(biome));
			}
		}
	}

}