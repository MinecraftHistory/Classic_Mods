// From SinglePlayerCommands by simo_415

package com.q3hardcore.console.worldedit;

// Obfuscated references: 0

import com.sk89q.worldedit.util.PropertiesConfiguration;
import java.io.File;

public final class ConsoleLocalConfiguration extends PropertiesConfiguration {

	public File mcdir;

	public ConsoleLocalConfiguration(File mcdir, File configurationFile) {
		super(configurationFile);
		this.mcdir = mcdir;
	}

	@Override
	public File getWorkingDirectory() {
		return this.mcdir;
	}

}
