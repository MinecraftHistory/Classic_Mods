package com.q3hardcore.console.proxy;

import java.io.File;

public final class TestProxy extends BaseProxy {

	@Override
	public EnumSide getSide() {
		return EnumSide.UNKNOWN;
	}

	@Override
	public File getMinecraftDir() {
		File file = new File("./console-dev/");
		if(!file.exists()) {
			try {
				file.mkdirs();
			} catch (SecurityException se) {
				se.printStackTrace();
			}
		}
		return file;
	}

	@Override
	public void sendMessage(String msg) {
		System.out.println(msg);
	}

	@Override
	public void postInit() {
		System.out.println("Using experimental proxy");
	}

}