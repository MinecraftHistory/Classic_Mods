package com.q3hardcore.console.proxy;

import net.minecraft.src.t; // ChunkCoords
import net.minecraft.src.jc; // EntityPlayerMP
import net.minecraft.src.jd; // ItemInWorldManager
import net.minecraft.src.mg; // DeathSource
import net.minecraft.src.sp; // EntityPlayer
import net.minecraft.src.wm; // ItemStack
import net.minecraft.src.zv; // ChunkCoordIntPair
import net.minecraft.src.aac; // World
import net.minecraft.src.aco; // WorldProvider
import net.minecraft.src.apd; // Block

public class BaseForgeHelper {

	public boolean isEventCanceled(Object event) {
		return true;
	}

	public t getRandomizedSpawnPoint(aco worldProvider) {
		return worldProvider.a.I();
	}

	public void watchChunk(zv chunkCoordIntPair, jc entityPlayerMP) {}

	public void destroyPlayerItem(jc entityPlayerMP, wm itemStack) {}

	public Object handleBlockClicked(jd itemInWorldManager, int x, int y, int z, int side) {
		return null;
	}

	public float allowBlockClicked(jd itemInWorldManager, Object forgeEvent, int blockID, int x, int y, int z, int side) {
		return -1.0F;
	}

	public boolean onLivingDeath(jc entityPlayerMP, mg deathSource) {
		return false;
	}

	public void clearDrops(jc entityPlayerMP) {}

	public void captureDrops(jc entityPlayerMP, mg deathSource, int recentlyHit) {}

	public boolean removeBlockByPlayer(apd block, aac world, jc entityPlayerMP, int x, int y, int z) {
		return false;
	}

	public boolean onBlockStartBreak(wm itemStack, int x, int y, int z, jc entityPlayerMP) {
		return false;
	}

	public boolean canHarvestBlock(apd block, jc entityPlayerMP, int metaData) {
		return false;
	}

	public boolean activateBlockOrUseItem(jd itemInWorldManager, sp entityPlayer, aac world,
		wm itemStack, int x, int y, int z, int side, float xOffset, float yOffset, float zOffset) {
		return false;
	}

	public String handleChat(jc player, String old, String chat) {
		return "";
	}

	public boolean allowUseItem(jc player) {
		return false;
	}

}