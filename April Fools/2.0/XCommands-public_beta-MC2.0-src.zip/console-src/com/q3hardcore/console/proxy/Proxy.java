package com.q3hardcore.console.proxy;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.wrapper.WMinecraftServer;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

import net.minecraft.src.ConsoleHelper;

public final class Proxy {

	public static final BaseProxy INSTANCE;
	public static final String MC_VERSION;
	public static final BaseForgeHelper FORGE_HELPER;

	private static final String forgeHelperName = "com.q3hardcore.console.proxy.ForgeHelper";

	static {
		MC_VERSION = ConsoleHelper.getMinecraftVersion();
		INSTANCE = getProxy();
		System.out.println("Console " + INSTANCE.getSide() + " Mode. (Minecraft " + MC_VERSION + ")");
		FORGE_HELPER = getForgeHelper();
		Helper.createDirs();
		INSTANCE.postInit();
	}

	private static BaseForgeHelper getForgeHelper() {

		BaseForgeHelper forgeHelper = new BaseForgeHelper();	

		try {
			Class.forName("net.minecraftforge.common.MinecraftForge");
			Class<? extends BaseForgeHelper>  forgeHelperClass =
				Class.forName(forgeHelperName).asSubclass(BaseForgeHelper.class);
			forgeHelper = forgeHelperClass.newInstance();
		} catch (Throwable t) {
			System.out.println("SPConsole/Proxy: Not using Forge Helper.");
		}

		return forgeHelper;

	}

	private static BaseProxy getProxy() {

		boolean useClientProxy = false;

		final WMinecraftServer server = WMinecraftServer.getServer();

		if(server == null) {
			System.out.println("No server?");
			useClientProxy = true;
		} else if(server.isSinglePlayer()) {
			useClientProxy = true;
		}

		BaseProxy proxyInstance = new BaseProxy();

		if(useClientProxy) {
			String clientProxyName;
			boolean magicLauncher = false;

			try {
				clientProxyName = BaseProxy.class.getPackage().getName() + ".ClientProxy";
			} catch (NullPointerException npe) {
				clientProxyName = "com.q3hardcore.console.proxy.ClientProxy";
				magicLauncher = true;
			}

			try {
				Class<? extends BaseProxy> clientProxy =
					Class.forName(clientProxyName).asSubclass(BaseProxy.class);
				proxyInstance = clientProxy.newInstance();
				if(magicLauncher) {
					proxyInstance.sendMessage("Q3 Says: Don't use MagicLauncher kids ;)");
				}
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}

		if(proxyInstance == null) {
			proxyInstance = new TestProxy();
		}

		return proxyInstance;

	}

}