package com.q3hardcore.console.proxy;

public enum EnumSide {
	CLIENT,
	SERVER,
	UNKNOWN;
}