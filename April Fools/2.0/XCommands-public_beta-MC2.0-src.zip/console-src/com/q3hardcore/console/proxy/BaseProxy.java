package com.q3hardcore.console.proxy;

import com.q3hardcore.console.wrapper.WMinecraftServer;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;
import java.io.File;

public class BaseProxy {

	public EnumSide getSide() {
		return EnumSide.SERVER;
	}

	public File getMinecraftDir() {
		return new File(".");
	}

	public void sendMessage(String msg) {
		final WMinecraftServer server = WMinecraftServer.getServer();
		server.getConfigurationManager().sendChatMsg(msg);
	}

	public boolean updateClientSpawner(WPlayer player, WMovingObjectPosition mop, String mob) {
		return false;
	}

	public void setClientNoclip(boolean val) {}

	public void updateClientBiomeArray(int x, int z, byte[] biomeArray) {}

	public void postInit() {
	}

}