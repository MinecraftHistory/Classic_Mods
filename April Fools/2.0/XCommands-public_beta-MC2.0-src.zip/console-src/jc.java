package net.minecraft.src;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.server.MinecraftServer;

/* <Forge>--------------------------------------------------------------- */
import com.q3hardcore.console.proxy.Proxy;
/* </Forge>-------------------------------------------------------------- */

/* <SPC>----------------------------------------------------------------- */
import com.sijobe.spc.core.HookManager;
import com.sijobe.spc.core.IPlayerMP;
import com.sijobe.spc.overwrite.ONetServerHandler;
/* </SPC>---------------------------------------------------------------- */

/* <Console>------------------------------------------------------------- */
import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.wrapper.WPlayer;
@SuppressWarnings({"unchecked", "rawtypes"})
/* </Console>------------------------------------------------------------ */

public class jc extends sp implements tp {

   private StringTranslate cm = new StringTranslate("en_US");
   public jh a;
   public MinecraftServer b;
   public jd c;
   public double d;
   public double e;
   public final List f = new LinkedList();
   public final List g = new LinkedList();
   private int cn = -99999999;
   private int co = -99999999;
   private boolean cp = true;
   private int cq = -99999999;
   private int cr = 60;
   private int cs = 0;
   private int ct = 0;
   private boolean cu = true;
   private int cv = 0;
   public boolean h;
   public int i;
   public boolean j = false;

   /* <Console>------------------------------------------------------------- */
   public final Console ph;
   private final WPlayer consolePlayer; // was protected, for ItemInWorldManager
   public float reachDistance = 4.5F;
   public final List<String> pendingMessages = new LinkedList<String>();
   public boolean clientHasXCommands = false;
   /* </Console>------------------------------------------------------------ */

   /* <Forge>--------------------------------------------------------------- */
   private static final boolean HAS_FORGE = ConsoleHelper.getHasForge();
   /* </Forge>-------------------------------------------------------------- */

   /* <SPC>----------------------------------------------------------------- */
   private final Object player;
   private static Object HOOK_MANAGER;
   private static String SERVER_ID;
   private boolean instantMine = false;
   public static final boolean HAS_SPC = ConsoleHelper.getHasSPC();
   /* </SPC>---------------------------------------------------------------- */

   public jc(MinecraftServer var1, aac var2, String var3, jd var4) {
      super(var2);
      var4.b = this;
      this.c = var4;
      this.cs = var1.ad().o();

      /* <Forge>--------------------------------------------------------------- */
      final t var5;
      if(HAS_FORGE) {
         var5 = Proxy.FORGE_HELPER.getRandomizedSpawnPoint(var2.t); // provider
      } else {
         var5 = var2.I();
      }
      /* </Forge>-------------------------------------------------------------- */

      int var6 = var5.a;
      int var7 = var5.c;
      int var8 = var5.b;

      /* <Forge>--------------------------------------------------------------- */
      if(!HAS_FORGE) {
         if(!var2.t.f && var2.L().r() != aak.d) {
            int var9 = Math.max(5, var1.ak() - 6);
            var6 += this.ab.nextInt(var9 * 2) - var9;
            var7 += this.ab.nextInt(var9 * 2) - var9;
            var8 = var2.i(var6, var7);
         }
      }
      /* </Forge>-------------------------------------------------------------- */

      this.b = var1;
      this.Y = 0.0F;
      this.bT = var3;
      this.N = 0.0F;
      this.b((double)var6 + 0.5D, (double)var8, (double)var7 + 0.5D, 0.0F, 0.0F);

      while(!var2.a((mp)this, this.E).isEmpty()) {
         this.b(this.u, this.v + 1.0D, this.w);
      }

      /* <Console>------------------------------------------------------------- */
      consolePlayer = ConsoleHelper.instantiatePlayer(this);
      if(consolePlayer == null) {
         System.out.println("Console disabled.");
         ph = null;
      } else {
         ph = ConsoleHelper.instantiateConsole(consolePlayer);
      }
      /* </Console>------------------------------------------------------------ */

      /* <SPC>----------------------------------------------------------------- */
      if(HAS_SPC) {
         player = new com.sijobe.spc.wrapper.Player(this);
      } else {
         player = null;
      }
      /* </SPC>---------------------------------------------------------------- */

   }

   public void a(bs var1) {
      super.a(var1);
      if(var1.b("playerGameType")) {
         this.c.a(aak.a(var1.e("playerGameType")));
      }

   }

   public void b(bs var1) {
      super.b(var1);
      var1.a("playerGameType", this.c.b().a());
   }

   public void a(int var1) {
      super.a(var1);
      this.cq = -1;
   }

   public void d_() {
      this.bN.a((tp)this);

      /* <Console>------------------------------------------------------------- */
      if(pendingMessages.size() > 0) {
         for(String msg : pendingMessages) {
            b(msg);
         }
         pendingMessages.clear();
      }
      /* </Console>------------------------------------------------------------ */

   }

   protected void e_() {
      this.N = 0.0F;
   }

   public float e() {
      return 1.62F;
   }

   public void l_() {

      /* <SPC>----------------------------------------------------------------- */
      if(HAS_SPC) {
         if(getPlayerHooks().size() < 5) {
            System.err.println("Server ID invalidated.");
            SERVER_ID = "INVALIDATED";
         }
         for (IPlayerMP hook : getPlayerHooks()) {
            if (hook.isEnabled()) {
               hook.onTick((com.sijobe.spc.wrapper.Player)player);
            }
         }
      }
      /* </SPC>---------------------------------------------------------------- */

      this.c.a();
      --this.cr;
      this.bN.b();

      while(!this.g.isEmpty()) {
         int var1 = Math.min(this.g.size(), 127);
         int[] var2 = new int[var1];
         Iterator var3 = this.g.iterator();
         int var4 = 0;

         while(var3.hasNext() && var4 < var1) {
            var2[var4++] = ((Integer)var3.next()).intValue();
            var3.remove();
         }

         this.a.b(new ep(var2));
      }

      if(!this.f.isEmpty()) {
         ArrayList var6 = new ArrayList();
         Iterator var7 = this.f.iterator();
         ArrayList var8 = new ArrayList();

         while(var7.hasNext() && var6.size() < 5) {
            zv var9 = (zv)var7.next();
            var7.remove();
            if(var9 != null && this.q.f(var9.a << 4, 0, var9.b << 4)) {
               var6.add(this.q.e(var9.a, var9.b));
               /* <Forge>--------------------------------------------------------------- */
               if(HAS_FORGE) {
                  var8.addAll(((iz)this.q).c(var9.a * 16, 0, var9.b * 16, var9.a * 16 + 15, 256, var9.b * 16 + 15));
               } else {
                  var8.addAll(((iz)this.q).c(var9.a * 16, 0, var9.b * 16, var9.a * 16 + 16, 256, var9.b * 16 + 16));
               }
               /* </Forge>-------------------------------------------------------------- */
            }
         }

         if(!var6.isEmpty()) {
            this.a.b(new dv(var6));
            Iterator var11 = var8.iterator();

            while(var11.hasNext()) {
               aqt var5 = (aqt)var11.next();
               this.b(var5);
            }

            var11 = var6.iterator();

            while(var11.hasNext()) {
               abx var10 = (abx)var11.next();
               this.o().p().a(this, var10);

               /* <Forge>--------------------------------------------------------------- */
               if(HAS_FORGE) {
                  Proxy.FORGE_HELPER.watchChunk(var10.l(), this);
               }
               /* </Forge>-------------------------------------------------------------- */

            }
         }
      }

   }

   public void b(int var1) {
      super.b(var1);
      Collection var2 = this.cp().a(arr.f);
      Iterator var3 = var2.iterator();

      while(var3.hasNext()) {
         ari var4 = (ari)var3.next();
         this.cp().a(this.am(), var4).a(Arrays.asList(new sp[]{this}));
      }

   }

   public void g() {
      try {
         super.l_();

         for(int var1 = 0; var1 < this.bL.j_(); ++var1) {
            wm var5 = this.bL.a(var1);
            if(var5 != null && wk.f[var5.c].f() && this.a.e() <= 5) {
               ei var6 = ((vd)wk.f[var5.c]).c(var5, this.q, this);
               if(var6 != null) {
                  this.a.b(var6);
               }
            }
         }

         if(this.aX() != this.cn || this.co != this.bO.a() || this.bO.e() == 0.0F != this.cp) {
            this.a.b(new fb(this.aX(), this.bO.a(), this.bO.e()));
            this.cn = this.aX();
            this.co = this.bO.a();
            this.cp = this.bO.e() == 0.0F;
         }

         if(this.ch != this.cq) {
            this.cq = this.ch;
            this.a.b(new fa(this.ci, this.ch, this.cg));
         }

         /* <Console>------------------------------------------------------------- */
         if(ph != null && consolePlayer.isPlayerFirst()) {
            ph.afterUpdate();
         }
         /* </Console>------------------------------------------------------------ */

      } catch (Throwable var4) {
         CrashReport var2 = CrashReport.a(var4, "Ticking player");
         m var3 = var2.a("Player being ticked");
         this.a(var3);
         throw new u(var2);
      }
   }

   public void a(mg var1) {

      /* <Console>------------------------------------------------------------- */
      if(consolePlayer != null) {
         ConsoleHelper.storeDeathPosition(consolePlayer);
      }
      /* </Console>------------------------------------------------------------ */

      /* <Forge>--------------------------------------------------------------- */
      if(HAS_FORGE) {
         if(Proxy.FORGE_HELPER.onLivingDeath(this, var1)) {
            return;
         }
      }
      /* </Forge>-------------------------------------------------------------- */

      this.b.ad().k(this.bu.b());
      if(!this.q.M().b("keepInventory")) {

         /* <Forge>--------------------------------------------------------------- */
         if(HAS_FORGE) {
		Proxy.FORGE_HELPER.clearDrops(this);
         }
         /* </Forge>-------------------------------------------------------------- */

         this.bL.m();

         /* <Forge>--------------------------------------------------------------- */
         if(HAS_FORGE) {
		Proxy.FORGE_HELPER.captureDrops(this, var1, this.bm); // recentlyHit
         }
         /* </Forge>-------------------------------------------------------------- */

      }

      Collection var2 = this.q.V().a(arr.c);
      Iterator var3 = var2.iterator();

      while(var3.hasNext()) {
         ari var4 = (ari)var3.next();
         ark var5 = this.cp().a(this.am(), var4);
         var5.a();
      }

      ng var6 = this.bN();
      if(var6 != null) {
         var6.c(this, this.aN);
      }

   }

   public boolean a(mg var1, int var2) {
      if(this.aq()) {
         return false;
      } else {
         boolean var3 = this.b.T() && this.b.X() && "fall".equals(var1.o);
         if(!var3 && this.cr > 0 && var1 != mg.i) {
            return false;
         } else {
            if(var1 instanceof mh) {
               mp var4 = var1.i();
               if(var4 instanceof sp && !this.a((sp)var4)) {
                  return false;
               }

               if(var4 instanceof sr) {
                  sr var5 = (sr)var4;
                  if(var5.c instanceof sp && !this.a((sp)var5.c)) {
                     return false;
                  }
               }
            }

            return super.a(var1, var2);
         }
      }
   }

   public boolean a(sp var1) {
      return !this.b.X()?false:super.a(var1);
   }

   public void c(int var1) {
      if(this.ar == 1 && var1 == 1) {
         this.a((ka)jv.C);
         this.q.e((mp)this);
         this.j = true;
         this.a.b(new dp(4, 0));
      } else {
         if(this.ar == 1 && var1 == 0) {
            this.a((ka)jv.B);
            t var2 = this.b.a(var1).l();
            if(var2 != null) {
               this.a.a((double)var2.a, (double)var2.b, (double)var2.c, 0.0F, 0.0F);
            }

            var1 = 1;
         } else {
            this.a((ka)jv.x);
         }

         this.b.ad().a(this, var1);
         this.cq = -1;
         this.cn = -1;
         this.co = -1;
      }

   }

   private void b(aqt var1) {
      if(var1 != null) {
         ei var2 = var1.m();
         if(var2 != null) {
            this.a.b(var2);
         }
      }

   }

   public void a(mp var1, int var2) {
      super.a(var1, var2);
      this.bN.b();
   }

   public sq a(int var1, int var2, int var3) {
      sq var4 = super.a(var1, var2, var3);
      if(var4 == sq.a) {
         dm var5 = new dm(this, 0, var1, var2, var3);
         this.o().p().a((mp)this, (ei)var5);
         this.a.a(this.u, this.v, this.w, this.A, this.B);
         this.a.b(var5);
      }

      return var4;
   }

   public void a(boolean var1, boolean var2, boolean var3) {
      if(this.bz()) {
         this.o().p().b(this, new ct(this, 3));
      }

      super.a(var1, var2, var3);
      if(this.a != null) {
         this.a.a(this.u, this.v, this.w, this.A, this.B);
      }

   }

   public void a(mp var1) {
      super.a(var1);
      this.a.b(new fe(this, this.o));
      this.a.a(this.u, this.v, this.w, this.A, this.B);
   }

   protected void a(double var1, boolean var3) {}

   public void b(double var1, boolean var3) {
      super.a(var1, var3);
   }

   private void cr() {
      this.cv = this.cv % 100 + 1;
   }

   public void b(int var1, int var2, int var3) {
      this.cr();
      this.a.b(new dg(this.cv, 1, "Crafting", 9, true));
      this.bN = new ts(this.bL, this.q, var1, var2, var3);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void a(int var1, int var2, int var3, String var4) {
      this.cr();
      this.a.b(new dg(this.cv, 4, var4 == null?"":var4, 9, var4 != null));
      this.bN = new tt(this.bL, this.q, var1, var2, var3);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void c(int var1, int var2, int var3) {
      this.cr();
      this.a.b(new dg(this.cv, 8, "Repairing", 9, true));
      this.bN = new ug(this.bL, this.q, var1, var2, var3, this);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void a(lt var1) {
      if(this.bN != this.bM) {
         this.h();
      }

      this.cr();
      this.a.b(new dg(this.cv, 0, var1.b(), var1.j_(), var1.c()));
      this.bN = new tq(this.bL, var1);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void a(aqm var1) {
      this.cr();
      this.a.b(new dg(this.cv, 9, var1.b(), var1.j_(), var1.c()));
      this.bN = new ty(this.bL, var1);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void a(rl var1) {
      this.cr();
      this.a.b(new dg(this.cv, 9, var1.b(), var1.j_(), var1.c()));
      this.bN = new ty(this.bL, var1);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void a(aqk var1) {
      this.cr();
      this.a.b(new dg(this.cv, 2, var1.b(), var1.j_(), var1.c()));
      this.bN = new tw(this.bL, var1);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void a(aqg var1) {
      this.cr();
      this.a.b(new dg(this.cv, var1 instanceof aqh?10:3, var1.b(), var1.j_(), var1.c()));
      this.bN = new um(this.bL, var1);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void a(aqb var1) {
      this.cr();
      this.a.b(new dg(this.cv, 5, var1.b(), var1.j_(), var1.c()));
      this.bN = new tm(this.bL, var1);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void a(aqa var1) {
      this.cr();
      this.a.b(new dg(this.cv, 7, var1.b(), var1.j_(), var1.c()));
      this.bN = new tk(this.bL, var1);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
   }

   public void a(zq var1, String var2) {
      this.cr();
      this.bN = new ud(this.bL, var1, this.q);
      this.bN.d = this.cv;
      this.bN.a((tp)this);
      uc var3 = ((ud)this.bN).e();
      this.a.b(new dg(this.cv, 6, var2 == null?"":var2, var3.j_(), var2 != null));
      zs var4 = var1.b(this);
      if(var4 != null) {
         try {
            ByteArrayOutputStream var5 = new ByteArrayOutputStream();
            DataOutputStream var6 = new DataOutputStream(var5);
            var6.writeInt(this.cv);
            var4.a(var6);
            this.a.b(new dk("MC|TrList", var5.toByteArray()));
         } catch (IOException var7) {
            var7.printStackTrace();
         }
      }

   }

   public void a(tj var1, int var2, wm var3) {
      if(!(var1.a(var2) instanceof uk)) {
         if(!this.h) {
            this.a.b(new dj(var1.d, var2, var3));
         }
      }
   }

   public void a(tj var1) {
      this.a(var1, var1.a());
   }

   public void a(tj var1, List var2) {
      this.a.b(new dh(var1.d, var2));
      this.a.b(new dj(-1, -1, this.bL.o()));
   }

   public void a(tj var1, int var2, int var3) {
      this.a.b(new di(var1.d, var2, var3));
   }

   public void h() {
      this.a.b(new df(this.bN.d));
      this.j();
   }

   public void i() {
      if(!this.h) {
         this.a.b(new dj(-1, -1, this.bL.o()));
      }
   }

   public void j() {
      this.bN.b((sp)this);
      this.bN = this.bM;
   }

   public void a(ka var1, int var2) {
      if(var1 != null) {
         if(!var1.f) {
            while(var2 > 100) {
               this.a.b(new cu(var1.e, 100));
               var2 -= 100;
            }

            this.a.b(new cu(var1.e, var2));
         }

      }
   }

   public void k() {
      if(this.n != null) {
         this.n.a((mp)this);
      }

      if(this.cb) {
         this.a(true, false, false);
      }

   }

   public void l() {
      this.cn = -99999999;
   }

   public void b(String var1) {
      StringTranslate var2 = StringTranslate.a();
      String var3 = var2.a(var1);
      this.a.b(new cw(var3));
   }

   protected void m() {
      this.a.b(new dn(this.k, (byte)9));
      super.m();
   }

   public void a(wm var1, int var2) {
      super.a(var1, var2);
      if(var1 != null && var1.b() != null && var1.b().b_(var1) == xp.b) {
         this.o().p().b(this, new ct(this, 5));
      }

   }

   public void a(sp var1, boolean var2) {
      super.a(var1, var2);
      this.cq = -1;
      this.cn = -1;
      this.co = -1;
      this.g.addAll(((jc)var1).g);

      /* <SPC>----------------------------------------------------------------- */
      if(HAS_SPC) {
         if(a instanceof ONetServerHandler) { // playerNetServerHandler
            jh oldInstance = ((ONetServerHandler)a).getOldInstance(); // NetServerHandler, playerNetServerHandler
            if(oldInstance != null) {
               System.out.println("Creating new NetServerHandler");
               a = new jh(MinecraftServer.D(), oldInstance.a, this);
            }
         }
      }
      /* </SPC>---------------------------------------------------------------- */

   }

   protected void a(ml var1) {
      super.a(var1);
      this.a.b(new fq(this.k, var1));
   }

   protected void b(ml var1) {
      super.b(var1);
      this.a.b(new fq(this.k, var1));
   }

   protected void c(ml var1) {
      super.c(var1);
      this.a.b(new eq(this.k, var1));
   }

   public void a(double var1, double var3, double var5) {
      this.a.a(var1, var3, var5, this.A, this.B);
   }

   public void b(mp var1) {
      this.o().p().b(this, new ct(var1, 6));
   }

   public void c(mp var1) {
      this.o().p().b(this, new ct(var1, 7));
   }

   public void n() {
      if(this.a != null) {
         this.a.b(new ek(this.cf));
      }
   }

   public iz o() {
      return (iz)this.q;
   }

   public void a(aak var1) {
      this.c.a(var1);
      this.a.b(new dp(3, var1.a()));
   }

   public void a(String var1) {
      this.a.b(new cw(var1));
   }

   public boolean a(int var1, String var2) {
      return "seed".equals(var2) && !this.b.T()?true:(!"tell".equals(var2) && !"help".equals(var2) && !"me".equals(var2)?this.b.ad().e(this.bT):true);
   }

   public String p() {
      String var1 = this.a.a.c().toString();
      var1 = var1.substring(var1.indexOf("/") + 1);
      var1 = var1.substring(0, var1.indexOf(":"));
      return var1;
   }

   public void a(cz var1) {
      if(this.cm.b().containsKey(var1.d())) {
         this.cm.a(var1.d(), false);
      }

      int var2 = 256 >> var1.f();
      if(var2 > 3 && var2 < 15) {
         this.cs = var2;
      }

      this.ct = var1.g();
      this.cu = var1.h();
      if(this.b.I() && this.b.H().equals(this.bT)) {
         this.b.c(var1.i());
      }

      this.b(1, !var1.j());
   }

   public StringTranslate r() {
      return this.cm;
   }

   public int t() {
      return this.ct;
   }

   public void a(String var1, int var2) {
      String var3 = var1 + "\u0000" + var2;
      this.a.b(new dk("MC|TPack", var3.getBytes()));
   }

   public t b() {
      return new t(kx.c(this.u), kx.c(this.v + 0.5D), kx.c(this.w));
   }

   /* <SPC>----------------------------------------------------------------- */
   public List<IPlayerMP> getPlayerHooks() {
      if (!MinecraftServer.D().toString().equals(SERVER_ID)) { // getServer
         HOOK_MANAGER = new HookManager();
         ((HookManager)HOOK_MANAGER).loadHooks(IPlayerMP.class);
         SERVER_ID = MinecraftServer.D().toString(); // getServer
      }
      return ((HookManager)HOOK_MANAGER).getHooks(IPlayerMP.class);
   }
    
   /**
    * Gets the movement forward. This is a value between -1 and 1. -1 is when
    * the player is moving backward, 1 is that player moving forward. The value
    * of the float is the percentage of speed the player is moving. 
    * 
    * @return The movement forward percentage
    */
   public float getMovementForward() {
      return this.bE; // moveForward
   }
   
   /**
    * Gets the movement strafe. This is a value between -1 and 1. -1 is when
    * the player is moving right, 1 is that player moving left. The value
    * of the float is the percentage of speed the player is moving. 
    * 
    * @return The movement strafe percentage
    */
   public float getMovementStrafe() {
      return this.bD; // moveStrafing
   }

   /**
    * Based upon Zombe's noclip implementation
    */
   @Override
   public boolean S() { // isEntityInsideOpaqueBlock
      if(this.Z) { // noClip
         return false;
      } else {
         return !this.cb && super.S(); // sleeping, isEntityInsideOpaqueBlock
      }
   }

   /**
    * Gets the value of instantMine
    *
    * @return boolean value of instantMine
    */
   public boolean getInstantMine() {
      return instantMine;
   }

   /**
    * Sets the value of instantMine
    */
   public void setInstantMine(boolean val) {
      instantMine = val;
   }


   @SuppressWarnings("deprecation")
   @Override
   public float a(apd block, boolean bool) { // getCurrentPlayerStrVsBlock, Block
      if(instantMine) {
         return 1000000.0F; // 1 million
      } else {
         return super.a(block, bool);
      }
   }

   @Override
   public boolean a(apd block) { // canHarvestBlock, Block
      if(instantMine) {
         return true;
      } else {
         return super.a(block);
      }
   }

   static {
      if(HAS_SPC) {
         HOOK_MANAGER = new HookManager();
      }
   }
   /* </SPC>---------------------------------------------------------------- */

}
