package net.minecraft.src;

public final class ConsoleEntityHelper {

	private final mp entity;

	public ConsoleEntityHelper(final mp entity) {
		this.entity = entity;
	}

	public void kill() {
		entity.B();
	}

	public void setRotation(float yaw, float pitch) {
		entity.b(yaw, pitch);
	}

	public void setImmuneToFire(boolean immune) {
		entity.ag = immune; // isImmuneToFire
	}

}