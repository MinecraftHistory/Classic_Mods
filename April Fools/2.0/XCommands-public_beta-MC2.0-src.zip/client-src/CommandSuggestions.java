package Shar_Console;

import Shar_Console.util.TextColors;
import com.q3hardcore.console.command.WorldEditCommandSet;
import com.q3hardcore.console.core.CommandList;
import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.wrapper.client.raw.RGuiScreen;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class CommandSuggestions extends RGuiScreen
{
  private TextColors c;
  public ArrayList<String> commands = new ArrayList<String>();
  public String[] com = new String[commands.size()];

  public ArrayList<String> commandSuggestions = new ArrayList<String>();
  public String[] comSug = new String[commandSuggestions.size()];

  public void loadCommands() {
    System.out.println("Loading commands for Console GUI");
    HashMap<String, String> consoleCmds = new HashMap<String, String>();

    for(String cmd : CommandList.CMDS.keySet()) {
      String[] cmdDesc = CommandList.CMDS.get(cmd);
      String formattedDesc = cmd;
      if(cmdDesc[1] != "") {
        formattedDesc += " " + cmdDesc[1];
      }
      formattedDesc += " - " + cmdDesc[0];
      consoleCmds.put(cmd, formattedDesc);
    }

    if(Console.getPluginManager() != null) {
      String[] pluginCmds = Console.getPluginManager().getCommands();
      for(String cmdName : pluginCmds) {
        if(consoleCmds.containsKey(cmdName)) {
          // System.out.println("Command " + cmdName + " defined twice.");
        } else {
          String[] pluginHelp = Console.getPluginManager().getHelp(cmdName);
          if(pluginHelp != null) {
            String formattedDesc = cmdName;
            if(pluginHelp[1] != "") {
              formattedDesc += " " + pluginHelp[1];
            }
            formattedDesc += " - " + pluginHelp[0];
            consoleCmds.put(cmdName, formattedDesc);
          } else {
            consoleCmds.put(cmdName, cmdName);
          }
        }
      }
    }

    for(String command : consoleCmds.keySet()) {
      add(command, consoleCmds.get(command));
    }

    // vanilla commands
    add("!debug", "!debug [start:stop] - Starts or stops debug profiling.");
    add("!defaultgamemode", "!defaultgamemode <mode> - Switches the world's default gamemode to Adventure, Creative, or Survival.");
    add("!difficulty", "!difficulty <new difficulty> - Switches the world's difficulty between Peaceful, Easy, Normal or Hard.");
    add("!gamemode", "!gamemode <mode> [player] -  Switches the current game mode to Survival, Creative, or Adventure.");
    add("!gamerule", "!gamerule <rule name> [value] - Allows the player to adjust several base settings.");
    add("!give", "!give <player> <block id> [amount] [data value] - Gives item/block of specified amount, using specified data value (doesn't work to give entities).");
    add("!help", "!help [page:command name] - Displays all available commands and how to use them.");
    add("!?", "!? [page:command name] - Displays all available commands and how to use them.");
    add("!kill", "!kill - Suicide.");
    add("!me", "!me <actiontext> - Sends a narrative message to the other players.");
    add("!publish", "!publish - Opens your single-player game for LAN friends to join.");
    add("!say", "!say <message> - Sends a message as the \"Server\".");
    add("!seed", "!seed - Displays the current seed for the world.");
    add("!spawnpoint", "!spawnpoint [player] [x] [y] [z] - Sets the spawnpoint of the target player to the current or entered destination.");
    add("!time", "!time <set:add> <value> - Sets time to specified integer - 0 is dawn, 6000 is midday, 12000 is dusk, and 18000 is midnight.");
    add("!toggledownfall", "!toggledownfall - Toggles rain/snow.");
    add("!tp", "!tp [target player] <destination player>, <x> <y> <z> - Teleports target player to entered destination.");
    add("!weather", "!weather <clear:rain:thunder> [duration in seconds] - Sets the weather.");
    add("!xp", "!xp <amount> [player] - Grants experience of the specified amount");
    add("!clear", "!clear <player> [item] [data] - Clears a player's current inventory or specific blocks/items.");

    com = commands.toArray(com);
    comSug = commandSuggestions.toArray(comSug);
  }

  private void add(String a, String b)
  {
    commands.add(a);
    commandSuggestions.add(colorize(b));
  }

  private String colorize(String s)
  {
    String newString = s;
    String variableColor = "\u00A7f";
    String descriptionColor = "\u00A77";

    newString = newString.replaceAll("\\[", "\u00A72" + "[" + variableColor);
    newString = newString.replaceAll("\\]", "\u00A72" + "]" + variableColor);
    newString = newString.replaceAll("<", "\u00A72" + "<" + variableColor);
    newString = newString.replaceAll(">", "\u00A72" + ">" + variableColor);
    newString = newString.replaceAll(":", "\u00A72" + ":" + variableColor);
    newString = newString.replaceFirst("-", "\u00A72" + "-" + descriptionColor);
    newString = "\u00A7d" + newString;
    return newString;
  }
}