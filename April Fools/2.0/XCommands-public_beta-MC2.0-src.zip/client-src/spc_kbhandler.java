package com.q3hardcore.console.plugin;

import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Side;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.util.KeyListener;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import org.lwjgl.input.Keyboard;

@Side(EnumSide.CLIENT)
public class spc_kbhandler extends Plugin {

	public static final long DELAY = 10L;
	private static spc_kbhandler KEYBOARD;
	private boolean listening = false;
	private List<Integer> keys = new CopyOnWriteArrayList<Integer>();
	private List<Integer> pressed = new CopyOnWriteArrayList<Integer>();
	private Map<Integer, List<KeyListener>> registeredPressed = new ConcurrentHashMap<Integer, List<KeyListener>>();
	private Map<Integer, List<KeyListener>> registeredReleased = new ConcurrentHashMap<Integer, List<KeyListener>>();

	public spc_kbhandler() {
		setTicking(true);
		setOwnerExclusive(true);
		KEYBOARD = this;
	}

	@Override
	public String getName() {
		return "KeyboardHandler";
	}

	@Override
	public void atUpdate(WPlayer sender) {

		if(!Keyboard.isCreated()) {
			return;
		}

		try {
			if(this.listening) {
				Iterator<Integer> e = this.pressed.iterator();

				Integer key;
				while(e.hasNext()) {
					key = e.next();
					if(!Keyboard.isKeyDown(key)) {
						this.keyReleased(key);
					}
				}

				e = this.keys.iterator();

				while(e.hasNext()) {
					key = e.next();
					if(Keyboard.isKeyDown(key) && !this.pressed.contains(key)) {
						try {
							this.keyPressed(key);
						} catch (Throwable t) {
							t.printStackTrace();
						}

					}
				}
			}
		} catch (Throwable t) {
			t.printStackTrace();
			this.listening = false;
		}

	}

	public static spc_kbhandler getInstance() {
		return KEYBOARD;
	}

	private void keyPressed(int key) {
		this.pressed.add(key);
		if(this.registeredPressed.get(key) != null) {
			Iterator<KeyListener> i$ = this.registeredPressed.get(key).iterator();

			while(i$.hasNext()) {
				KeyListener listener = i$.next();
				listener.keyPressed(key);
			}

		}
	}

	private void keyReleased(int key) {
		this.pressed.remove((Object)key);
		if(this.registeredReleased.get(key) != null) {
			Iterator<KeyListener> i$ = this.registeredReleased.get(key).iterator();

			while(i$.hasNext()) {
				KeyListener listener = i$.next();
				listener.keyReleased(key);
			}

		}
	}

	public void stopListening() {
		this.listening = false;
	}

	public boolean addKeyPressedListener(int key, KeyListener listener) {
		return this.addListener(key, listener, this.registeredPressed);
	}

	public boolean addKeyReleasedListener(int key, KeyListener listener) {
		return this.addListener(key, listener, this.registeredReleased);
	}

	private boolean addListener(int key, KeyListener listener, Map<Integer, List<KeyListener>> internal) {
		if(Keyboard.getKeyName(key) == null) {
			return false;
		} else {
			List<KeyListener> keylist = internal.get(key);
			if(keylist == null) {
				keylist = new CopyOnWriteArrayList<KeyListener>();
				internal.put(key, keylist);
			}

			keylist.add(listener);
			if(this.keys.indexOf(key) == -1) {
				this.keys.add(key);
			}

			if(!this.listening) {
				this.listening = true;
			}

			return true;
		}
	}

	public void removeKeyPressedListener(int key, KeyListener listener) {
		this.removeListener(key, listener, this.registeredPressed);
	}

	public void removeKeyReleasedListener(int key, KeyListener listener) {
		this.removeListener(key, listener, this.registeredReleased);
	}

	private void removeListener(int key, KeyListener listener, Map<Integer, List<KeyListener>> internal) {
		if(this.keys.contains(key)) {
			List<KeyListener> list = internal.get(key);
			if(list != null) {
				list.remove(listener);
			}

			this.checkKeyUsage(key);
		}
	}

	private void checkKeyUsage(int key) {
		List<KeyListener> pressed = this.registeredPressed.get(key);
		boolean pressedEmpty = false;
		if(pressed != null && pressed.size() == 0) {
			this.registeredPressed.remove(key);
			pressedEmpty = true;
		}

		List<KeyListener> released = this.registeredReleased.get(key);
		boolean releasedEmpty = false;
		if(released != null && released.size() == 0) {
			this.registeredReleased.remove(key);
			releasedEmpty = true;
		}

		if(pressedEmpty && releasedEmpty) {
			this.keys.remove(key);
			pressed.remove(key);
		}

	}

	public static int getKeyCode(String key) {
		return key == null?-1:(Keyboard.getKeyIndex(key.toUpperCase()) == 0?-1:Keyboard.getKeyIndex(key.toUpperCase()));
	}

}