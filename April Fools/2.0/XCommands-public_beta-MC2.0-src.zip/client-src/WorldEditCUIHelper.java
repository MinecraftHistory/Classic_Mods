package com.q3hardcore.console.util;

import com.mumfrey.liteloader.LiteMod;
import com.mumfrey.liteloader.core.LiteLoader;
import com.q3hardcore.console.wrapper.client.WMinecraft;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import wecui.WorldEditCUI;
import wecui.event.CUIEvent;

public class WorldEditCUIHelper {

	private static int failures = 0;

	public static void handleCUIEvent(LiteMod WorldEditCUIMod, String type, String[] params) throws Throwable {
		WorldEditCUI controller;
		Class<?> modClass = Class.forName("wecui.LiteModWorldEditCUI");
		Field modController = modClass.getDeclaredField("controller");
		modController.setAccessible(true);
		controller = (WorldEditCUI)modController.get(WorldEditCUIMod);
		if(controller != null) {
			controller.getEventManager().callEvent(new CUIEvent(controller, type, params));
		} else {
			if(failures > 5) {
				return;
			}
			try {
				final Object minecraft = WMinecraft.getMinecraft().getRaw();
				final Class<?> mcClass = minecraft.getClass().getSuperclass();
				final Class<?>[] methodArgs = new Class<?>[]{mcClass, LiteLoader.class};
				Method method = modClass.getMethod("onInitCompleted", methodArgs);
				method.invoke(WorldEditCUIMod, new Object[]{minecraft, LiteLoader.getInstance()});
				System.out.println("Finished initializing WorldEditCUI.");
			} catch (Throwable t) {
				System.err.println("Failed to initialize WorldEditCUI.");
				if(failures == 0) {
					t.printStackTrace();
				}
				failures++;
			}
		}
	}

	public static String getVersion() {
		return WorldEditCUI.getVersion();
	}

}