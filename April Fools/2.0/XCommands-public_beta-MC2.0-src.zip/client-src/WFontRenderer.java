package com.q3hardcore.console.wrapper.client;

import net.minecraft.src.awz;

public class WFontRenderer {

	private final awz fontRenderer;

	public WFontRenderer(final awz fontRenderer) {
		this.fontRenderer = fontRenderer;
	}

	public int getStringWidth(String string) {
		return fontRenderer.a(string);
	}

	public String trimStringToWidth(String string, int length) {
		return fontRenderer.a(string, length);
	}

	public awz getRaw() {
		return fontRenderer;
	}

}