package com.q3hardcore.console.plugin;
// Obfuscated references: 0

import java.util.List;
import java.util.ArrayList;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Side;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.client.WMinecraft;

@Side(EnumSide.CLIENT)
public class spc_clientcmds extends Plugin {

	@Override
	public String getName() {
		return "ClientCommands";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
			commands.add("clearchat");
			commands.add("noclip");
			return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("light")) {
			String[] help = new String[]{"Clears chat.", "", ""};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] s) {
		if(s[0].equalsIgnoreCase("clearchat")) {
			if(!player.isPlayerOwner()) {
				player.sendError(Helper.ERRMSG_NOTOWNER);
				return true;
			}
			WMinecraft.getMinecraft().clearChatMessages();
			return true;
		} else if(s[0].equalsIgnoreCase("noclip")) {
			if(!player.isPlayerOwner()) {
				player.sendError(Helper.ERRMSG_NOTOWNER);
				return true;
			}
			boolean noclipState = !player.getNoclip();
			player.setNoclip(noclipState);
			WMinecraft.getMinecraft().getThePlayer().setNoclip(noclipState);
			player.sendMessage("Noclip " + (noclipState?"enabled.":"disabled."));
			return true;	
		} else {
			return false;
		}
	}

}
