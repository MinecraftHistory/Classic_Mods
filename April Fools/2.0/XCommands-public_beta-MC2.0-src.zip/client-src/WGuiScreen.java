package com.q3hardcore.console.wrapper.client;

import net.minecraft.src.axv;

public class WGuiScreen {

	private final axv screen;

	public WGuiScreen(axv screen) {
		this.screen = screen;
	}

	public void setWorldAndResolution(WMinecraft mc, int width, int height) {
		screen.a(mc.getRaw(), width, height);
	}

	public axv getRaw() {
		return screen;
	}

	public boolean isValid() {
		return screen != null;
	}

}