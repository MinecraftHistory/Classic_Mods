package net.minecraft.src;

import net.minecraft.client.Minecraft;

/* <Console>------------------------------------------------------------- */
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.util.ClientHelper;
import com.q3hardcore.console.wrapper.WMinecraftServer;
/* </Console>------------------------------------------------------------ */

/* <SPC>----------------------------------------------------------------- */
import java.util.List;
import com.sijobe.spc.core.HookManager;
import com.sijobe.spc.core.IPlayerSP;
import com.sijobe.spc.wrapper.Player;
/* </SPC>---------------------------------------------------------------- */

public class beb extends bfp {

   public bdq a;
   private double cn;
   private double co;
   private double cp;
   private double cq;
   private float cr;
   private float cs;
   private boolean ct = false;
   private boolean cu = false;
   private boolean cv = false;
   private int cC = 0;
   private boolean cD = false;

   /* <SPC>----------------------------------------------------------------- */
   private final Object player;
   private static Object HOOK_MANAGER;
   private static String CLIENT_ID;
   private static final boolean HAS_SPC = ConsoleHelper.getHasSPC();
   /* </SPC>---------------------------------------------------------------- */

   /* <Console>------------------------------------------------------------- */
   public double clientReach = -1.0D;
   /* </Console>------------------------------------------------------------ */

   public beb(Minecraft var1, aac var2, awj var3, bdq var4) {
      super(var1, var2, var3, 0);
      this.a = var4;

      /* <SPC>----------------------------------------------------------------- */
      if(HAS_SPC) {
         player = new Player(this);
      } else {
         player = null;
      }
      /* </SPC>---------------------------------------------------------------- */

      /* <Console>------------------------------------------------------------- */
      if(ConsoleHelper.hasConsole()) {
         ClientHelper.registerChatHelper();
      }
      /* </Console>------------------------------------------------------------ */

   }

   public boolean a(mg var1, int var2) {
      return false;
   }

   public void j(int var1) {}

   public void l_() {

      /* <SPC>----------------------------------------------------------------- */
      if(HAS_SPC) {
         if(getPlayerHooks().size() < 3) {
            System.err.println("Client ID invalidated.");
            CLIENT_ID = "INVALIDATED";
         }
         for (IPlayerSP hook : getPlayerHooks()) {
            try {
               if (hook.isEnabled()) {
                  hook.onTick((Player)player);
               }
            } catch (Throwable t) {
               System.err.println("Hook " + hook.toString() + " caused unhandled exception.");
               //t.printStackTrace();
            }
         }
      }
      /* </SPC>---------------------------------------------------------------- */

      if(this.q.f(kx.c(this.u), 0, kx.c(this.w))) {
         super.l_();
         this.d();
      }
   }

   public void d() {
      boolean var1 = this.ah();
      if(var1 != this.cv) {
         if(var1) {
            this.a.c(new em(this, 4));
         } else {
            this.a.c(new em(this, 5));
         }

         this.cv = var1;
      }

      boolean var2 = this.ag();
      if(var2 != this.cu) {
         if(var2) {
            this.a.c(new em(this, 1));
         } else {
            this.a.c(new em(this, 2));
         }

         this.cu = var2;
      }

      double var3 = this.u - this.cn;
      double var5 = this.E.b - this.co;
      double var7 = this.w - this.cq;
      double var9 = (double)(this.A - this.cr);
      double var11 = (double)(this.B - this.cs);
      boolean var13 = var3 * var3 + var5 * var5 + var7 * var7 > 9.0E-4D || this.cC >= 20;
      boolean var14 = var9 != 0.0D || var11 != 0.0D;
      if(this.o != null) {
         this.a.c(new eg(this.x, -999.0D, -999.0D, this.z, this.A, this.B, this.F));
         var13 = false;
      } else if(var13 && var14) {
         this.a.c(new eg(this.u, this.E.b, this.v, this.w, this.A, this.B, this.F));
      } else if(var13) {
         this.a.c(new ef(this.u, this.E.b, this.v, this.w, this.F));
      } else if(var14) {
         this.a.c(new eh(this.A, this.B, this.F));
      } else {
         this.a.c(new ee(this.F));
      }

      ++this.cC;
      this.ct = this.F;
      if(var13) {
         this.cn = this.u;
         this.co = this.E.b;
         this.cp = this.v;
         this.cq = this.w;
         this.cC = 0;
      }

      if(var14) {
         this.cr = this.A;
         this.cs = this.B;
      }

   }

   public rg a(boolean var1) {
      int var2 = var1?3:4;
      this.a.c(new el(var2, 0, 0, 0, 0));
      return null;
   }

   protected void a(rg var1) {}

   public void d(String var1) {

      /* <SPC>----------------------------------------------------------------- */
      if(HAS_SPC) {
         if (this.c.B()) { // mc.isSinglePlayer
            if (!var1.startsWith("/")) {
               var1 = "/" + var1;
            }
         }
      }
      /* </SPC>---------------------------------------------------------------- */

      this.a.c(new cw(var1));
   }

   public void bK() {
      super.bK();
      this.a.c(new ct(this, 1));
   }

   public void cd() {
      this.a.c(new cy(1));
   }

   protected void d(mg var1, int var2) {
      if(!this.aq()) {
         this.b(this.aX() - var2);
      }
   }

   public void h() {
      this.a.c(new df(this.bN.d));
      this.f();
   }

   public void f() {
      this.bL.b((wm)null);
      super.h();
   }

   public void x(int var1) {
      if(this.cD) {
         super.x(var1);
      } else {
         this.b(var1);
         this.cD = true;
      }

   }

   public void a(ka var1, int var2) {
      if(var1 != null) {
         if(var1.f) {
            super.a(var1, var2);
         }

      }
   }

   public void b(ka var1, int var2) {
      if(var1 != null) {
         if(!var1.f) {
            super.a(var1, var2);
         }

      }
   }

   public void n() {
      this.a.c(new ek(this.cf));
   }

   public boolean ce() {
      return true;
   }

   /* <SPC>----------------------------------------------------------------- */
   public List<IPlayerSP> getPlayerHooks() {
      if (!this.c.toString().equals(CLIENT_ID)) { // mc
         HOOK_MANAGER = new HookManager();
         ((HookManager)HOOK_MANAGER).loadHooks(IPlayerSP.class);
         CLIENT_ID = this.c.toString(); // mc
      }
      return ((HookManager)HOOK_MANAGER).getHooks(IPlayerSP.class);
   }
    
   @Override
   public void a(float f, float f1, float f2) { // moveFlying
      super.a(f, f1, f2); // moveFlying
      if(HAS_SPC) {
         for (IPlayerSP hook : getPlayerHooks()) {
            try {
               if (hook.isEnabled()) {
                  hook.movePlayer((Player)player, f, f1, f2);
               }
            } catch (Throwable t) {
               t.printStackTrace();
            }
         }
      }
   }
   
   /**
    * Gets the movement forward. This is a value between -1 and 1. -1 is when
    * the player is moving backward, 1 is that player moving forward. The value
    * of the float is the percentage of speed the player is moving. 
    * 
    * @return The movement forward percentage
    */
   public float getMovementForward() {
      return this.bE; // moveForward
   }
   
   /**
    * Gets the movement strafe. This is a value between -1 and 1. -1 is when
    * the player is moving right, 1 is that player moving left. The value
    * of the float is the percentage of speed the player is moving. 
    * 
    * @return The movement strafe percentage
    */
   public float getMovementStrafe() {
      return this.bD; // moveStrafing
   }

   /**
    * Based upon Zombe's noclip implementation
    */
   @Override
   public boolean S() { // isEntityInsideOpaqueBlock
      if(this.Z) { // noClip
         return false;
      } else {
         return !this.cb && super.S(); // sleeping, isEntityInsideOpaqueBlock
      }
   }

   /**
    * Based upon Zombe's noclip implementation
    */
   @Override
   protected boolean i(double par1, double par3, double par5) { // pushOutOfBlocks
      if(this.Z) { // noClip
         return false;
      } else {
         return super.i(par1, par3, par5); // pushOutOfBlocks
      }
   }

   @Override
   public are a(double distance, float partialTickTime) {
      if(clientReach > 4.5D) {
         distance = clientReach;
      }
      return super.a(distance, partialTickTime);
   }

   static {
      if(HAS_SPC) {
         HOOK_MANAGER = new HookManager();
      }
   }
   /* </SPC>---------------------------------------------------------------- */

}
