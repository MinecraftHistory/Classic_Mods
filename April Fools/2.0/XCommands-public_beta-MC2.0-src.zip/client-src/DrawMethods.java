package Shar_Console;

import com.q3hardcore.console.wrapper.client.WTessellator;
import org.lwjgl.opengl.GL11;

public class DrawMethods
{
  public static void drawRectWithSetOpacity(int par0, int par1, int par2, int par3, int par4, float opacity)
  {
    if (par0 < par2)
    {
      int var5 = par0;
      par0 = par2;
      par2 = var5;
    }

    if (par1 < par3)
    {
      int var5 = par1;
      par1 = par3;
      par3 = var5;
    }

    float var10 = (par4 >> 24 & 0xFF) / 255.0F;
    float var6 = (par4 >> 16 & 0xFF) / 255.0F;
    float var7 = (par4 >> 8 & 0xFF) / 255.0F;
    float var8 = (par4 & 0xFF) / 255.0F;
    WTessellator var9 = WTessellator.getInstance();
    GL11.glEnable(3042);
    GL11.glDisable(3553);
    GL11.glBlendFunc(770, 771);
    GL11.glColor4f(var6, var7, var8, opacity);
    var9.startDrawingQuads();
    var9.addVertex(par0, par3, 0.0D);
    var9.addVertex(par2, par3, 0.0D);
    var9.addVertex(par2, par1, 0.0D);
    var9.addVertex(par0, par1, 0.0D);
    var9.draw();
    GL11.glEnable(3553);
    GL11.glDisable(3042);
  }

  public static void drawRectOutline(int par0, int par1, int par2, int par3, int par4)
  {
    if (par0 < par2)
    {
      int var5 = par0;
      par0 = par2;
      par2 = var5;
    }

    if (par1 < par3)
    {
      int var5 = par1;
      par1 = par3;
      par3 = var5;
    }

    float var10 = (par4 >> 24 & 0xFF) / 255.0F;
    float var6 = (par4 >> 16 & 0xFF) / 255.0F;
    float var7 = (par4 >> 8 & 0xFF) / 255.0F;
    float var8 = (par4 & 0xFF) / 255.0F;
    WTessellator var9 = WTessellator.getInstance();
    GL11.glEnable(3042);
    GL11.glDisable(3553);
    GL11.glBlendFunc(770, 771);
    GL11.glColor4f(var6, var7, var8, var10);
    var9.startDrawing(2);
    var9.addVertex(par0, par3, 0.0D);
    var9.addVertex(par2, par3, 0.0D);
    var9.addVertex(par2, par1, 0.0D);
    var9.addVertex(par0, par1, 0.0D);
    var9.draw();
    GL11.glEnable(3553);
    GL11.glDisable(3042);
  }

  public static void drawRectOutlineWithoutTop(int par0, int par1, int par2, int par3, int par4)
  {
    if (par0 < par2)
    {
      int var5 = par0;
      par0 = par2;
      par2 = var5;
    }

    if (par1 < par3)
    {
      int var5 = par1;
      par1 = par3;
      par3 = var5;
    }

    float var10 = (par4 >> 24 & 0xFF) / 255.0F;
    float var6 = (par4 >> 16 & 0xFF) / 255.0F;
    float var7 = (par4 >> 8 & 0xFF) / 255.0F;
    float var8 = (par4 & 0xFF) / 255.0F;
    WTessellator var9 = WTessellator.getInstance();
    GL11.glEnable(3042);
    GL11.glDisable(3553);
    GL11.glBlendFunc(770, 771);
    GL11.glColor4f(var6, var7, var8, var10);
    var9.startDrawing(3);
    var9.addVertex(par0, par3, 0.0D);
    var9.addVertex(par0, par1, 0.0D);
    var9.addVertex(par2, par1, 0.0D);
    var9.addVertex(par2, par3, 0.0D);

    var9.draw(); // a
    GL11.glEnable(3553);
    GL11.glDisable(3042);
  }
}