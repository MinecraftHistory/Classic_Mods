// From SinglePlayerCommands by simo_415

// Obfuscated references: 0

package com.q3hardcore.console.util;

public interface KeyListener {

	void keyPressed(int keyIndex);

	void keyReleased(int keyIndex);
}
