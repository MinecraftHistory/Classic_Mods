package Shar_Console;

import Shar_Console.util.TextColors;
import com.q3hardcore.console.command.WorldEditCommandSet;
import com.q3hardcore.console.core.CommandHelper;
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.plugin.spc_sharconsole;
import com.q3hardcore.console.wrapper.WChatAllowedCharacters;
import com.q3hardcore.console.wrapper.client.WMinecraft;
import com.q3hardcore.console.wrapper.client.raw.RGuiScreen;
import java.io.PrintStream;
import java.util.ArrayList;
import org.lwjgl.input.Keyboard;

public class GuiConsole extends CommandSuggestions
{
  private static GuiConsole instance;
  private DrawMethods draw;
  private TextColors c;
  private int updateCounter;
  public static int y = 0;
  private final String allowedCharacters;
  public static String msg; // was protected
  protected static String selection;
  public static boolean hist;
  public static boolean selected = false;

  public ArrayList<String> commandHistory = new ArrayList<String>();
  public String[] comHist = new String[commandHistory.size()];

  public ArrayList<String> actualCommandHistory = new ArrayList<String>();
  public String[] actComHist = new String[commandHistory.size()];

  public static final String BRANDING = "q3hardcore";

  public GuiConsole() {
    msg = "";
    allowedCharacters = WChatAllowedCharacters.getAllowedCharacters();
    updateCounter = 0;
    loadCommands();
  }

  @Override
  public void initGui() {
    Keyboard.enableRepeatEvents(true);
  }

  public static GuiConsole getInstance()
  {
    if (instance == null) {
      System.out.println("Initializing Console GUI.");
      instance = new GuiConsole();
      msg = "/";
    }
    return instance;
  }

  @Override
  public void onGuiClosed() {
    Keyboard.enableRepeatEvents(false);
  }

  @Override
  public void updateScreen() {
    updateCounter += 1;
  }

  public void processCommand(String s)
  {
    if (s.startsWith("/"))
    {
      if(s.length() < 2)
      {
        return;
      }
      if(s.length() > 2 && s.indexOf("!") == 1) {
        String cmdString = s.replaceFirst("!", "");
        WMinecraft.getMinecraft().sendChatMessage(cmdString);
      }
      else
      {
        String[] cmdArray = s.split(" ");
        String cmd = cmdArray[0].toLowerCase().substring(1);
        CommandHelper.handleCommand(Helper.getOwner(), cmdArray);
      }
      commandHistory.add(new StringBuilder().append("> ").append(s).toString());
      actualCommandHistory.add(s);
    }
    else
    {
      WMinecraft.getMinecraft().sendChatMessage(WChatAllowedCharacters.filterAllowedCharacters(s));
      return;
    }

    comHist = commandHistory.toArray(comHist);
    actComHist = actualCommandHistory.toArray(actComHist);
  }

  @Override
  public void keyTyped(char c, int i) {
    if (i == 35 && Keyboard.isKeyDown(29)) {
      hist = !hist;
    }
    else if (i == 1) {
      if (selected)
      {
        selected = false;
      }
      else if (!msg.equals(""))
      {
        msg = "";
        y = 0;
      }
      else
      {
        y = 0;
        WMinecraft.getMinecraft().displayGuiScreen((RGuiScreen)null);
      }

    }
    else if (i == 28) {
      if (msg.length() > 0)
      {
        processCommand(msg);
      }
      y = 0;
      msg = "";
      WMinecraft.getMinecraft().displayGuiScreen((RGuiScreen)null); 
      return;
    }
    if ((i == 200) && (actualCommandHistory.size() > 0) && (actComHist.length - y != 0)) {
      y += 1;

      // BUGFIX 
      try {
        msg = actComHist[(actComHist.length - y)];
      } catch (ArrayIndexOutOfBoundsException aioobe) {
        printChatMessageFromConsole("Previous command invalid. (Command history cleared)");
        actualCommandHistory.clear();
        return;
      }
    }
    if ((i == 208) && (actualCommandHistory.size() > 0) && (y != 1)) {
      y -= 1;

      // BUGFIX
      try {
        msg = actComHist[(actComHist.length - y)];
      } catch (ArrayIndexOutOfBoundsException aioobe) {
        printChatMessageFromConsole("Next command invalid. (Command history cleared)");
        actualCommandHistory.clear();
        return;
      }
    }
    if ((i == 14) && (msg.length() > 0) && (!selected)) {
      msg = msg.substring(0, msg.length() - 1);
      y = 0;
    }
    else if ((i == 14) && (selected))
    {
      msg = "";
      selected = false;
    }
    if ((i != 41) && (allowedCharacters.indexOf(c) >= 0) && (msg.length() < 100)) {
      y = 0;
      if (selected) {
        msg = new StringBuilder().append("").append(c).toString();
        selected = false;
      }
      else {
        msg = new StringBuilder().append(msg).append(c).toString();
      }

    }

    if ((Keyboard.isKeyDown(29)) && (!msg.equals("")))
    {
      if (i == 30  && Keyboard.isKeyDown(29))
      {
        selection = msg;
        selected = true;
      }
      if (selected)
      {
        if (i == 45  && Keyboard.isKeyDown(29))
        {
          selected = false;
          setClipboardString(selection);

          msg = "";
        }
        else if (i == 46  && Keyboard.isKeyDown(29))
        {
          selected = false;
          setClipboardString(selection);
        }

      }

      // is this meant to undo?
      if ((i == 44) && 
        (i != 21));
    }

    if (i == 47 && Keyboard.isKeyDown(29))
    {
      if (selected)
        msg = getClipboardString();
      else
        msg = new StringBuilder().append(msg).append(getClipboardString()).toString(); 
    }
  }

  @Override
  public void mouseClicked(int a, int b, int c)
  {
    super.mouseClicked(a, b, c);
    selected = false;
  }

  // why is this here?
  public void checkKeyTyped()
  {
  }

  @Override
  public void drawScreen(int a, int b, float f)
  {
    String title = new StringBuilder().append("\u00A7cMCC: ").append(getVersion()).append("> \u00A7f").append(msg).append(updateCounter / 6 % 2 != 0 ? "" : "|").toString();
    String titleActual = new StringBuilder().append("MCC: ").append(getVersion()).append(">").toString();
    if (msg.length() >= 1)
      titleActual = new StringBuilder().append("MCC: ").append(getVersion()).append(">").append(getFontRenderer().getStringWidth(msg.substring(0, 1))).toString();
    int margin = 12;
    int marginB = 3;
    int TITLE_LENGTH = getFontRenderer().getStringWidth(titleActual) + margin;
    int MESSAGE_LENGTH = getFontRenderer().getStringWidth(msg);
    int height = 0;
    int heightText = 0;
    boolean subs = false;
    boolean hasDash = false;
    int var1 = TITLE_LENGTH;
    int var2 = TITLE_LENGTH - marginB;
    int var3 = TITLE_LENGTH + getFontRenderer().getStringWidth("/");
    int var4 = TITLE_LENGTH + getFontRenderer().getStringWidth("/") - marginB;

    if (msg.startsWith("/")) {
      hasDash = true;
    }
    drawRect(margin, 14, getWidth() - margin, 2, -2147483648);
    DrawMethods.drawRectOutline(margin, 14, getWidth() - margin, 2, -2130706433);
    drawString(getFontRenderer(), title, 14, 4, 16777215);

    if (selected)
    {
      int extra = getFontRenderer().getStringWidth(msg.substring(0, 1)); 
      if (hasDash)
        drawRect(var2, 13, MESSAGE_LENGTH + var3, 3, -2147483440);
      else {
        drawRect(var4 - extra, 13, MESSAGE_LENGTH + var4, 3, -2147483440);
      }
    }

    int h = 0;
    boolean history = false;
    if (hist)
    {
      if (comHist.length != 0)
      {
        history = true;
      }
      if (history)
      {
        for (int i = comHist.length - 1; i >= 0; i--)
        {
          history = true;
          h += 12;
          String output = comHist[i];
          drawRect(margin, 14 + h, getWidth() - 12, 2 + h, -2147483648);
          DrawMethods.drawRectOutlineWithoutTop(margin, 26, getWidth() - 12, 2 + h, -2130706433);
          drawString(getFontRenderer(), output, 14, 4 + h, 16777215);
        }
        DrawMethods.drawRectOutlineWithoutTop(margin, 14 + h, getWidth() - 12, 14, -2130706433);
      }
      else
      {
        drawRect(margin, 26, getWidth() - 12, 14, -2147483648);
        DrawMethods.drawRectOutlineWithoutTop(margin, 26, getWidth() - 12, 14, -2130706433);
        drawCenteredString(getFontRenderer(), "No command history.", getWidth() / 2, 16, 16777215);
      }
    }

    for (int i = 0; i < com.length; i++) {
      /*msg = msg.toLowerCase()*/;
      String msgA = "";

      if (msg.startsWith("/"))
      {
        msgA = msg.substring(1)/*.toLowerCase()*/;
      }
      else
      {
        return;
      }

      String[] array = com;

      String oldSuggestion = comSug[i];

      boolean isWECommand = false;
      if(WorldEditCommandSet.isLoaded())
      {
        if(msg.length() > 2 && msg.indexOf("!") == 1)
        {
          String[] split = msg.split(" ");
          String weCommand = split[0].substring(1).replaceFirst("!", "");
          if(WorldEditCommandSet.hasCommand(weCommand))
          {
            array = new String[]{split[0].substring(1)};
            comSug[i] = split[0].substring(1) + " " + WorldEditCommandSet.getCommandDesc(weCommand);
            isWECommand = true;
          }
        }
      }

      if ((array[i].toLowerCase().startsWith(msg)) && (!msg.equals("")) && (!array[i].toLowerCase().equals(msg)))
      {
        subs = true;
        heightText += 12;
        height += 12;
        String output = array[i];
        String selection = output.substring(0, msg.length());
        String rest = output.substring(msg.length());
        output = new StringBuilder().append("\u00A74").append(selection).append("\u00A7f").append(rest).toString();
        if (hist)
          DrawMethods.drawRectWithSetOpacity(var2, 14 + height, getWidth() - 12, 2 + height, -2147483648, 0.8F);
        else
          drawRect(var2, 14 + height, getWidth() - 12, 2 + height, -2147483648);
        drawString(getFontRenderer(), output, var1, 4 + heightText, 16777215);
        DrawMethods.drawRectOutlineWithoutTop(var2, 14 + height, getWidth() - 12, 2 + height, -2130706433);
      }
      else if (msg.toLowerCase().startsWith(array[i]))
      {
        subs = true;
        heightText += 12;
        height += 12;

        String output = getFontRenderer().trimStringToWidth(comSug[i], getWidth() - var1 - margin);
        if (!output.startsWith(comSug[i]))
          output = new StringBuilder().append(output.substring(0, output.length() - 3)).append("...").toString();
        if (hist)
          DrawMethods.drawRectWithSetOpacity(var4, 14 + height, getWidth() - 12, 2 + height, -2147483648, 0.8F);
        else
          drawRect(var2, 14 + height, getWidth() - 12, 2 + height, -2147483648);
        drawString(getFontRenderer(), output, var1, 4 + heightText, 16777215);
        DrawMethods.drawRectOutlineWithoutTop(var2, 14 + height, getWidth() - 12, 2 + height, -2130706433);
      }

      if ((array[i].toLowerCase().startsWith(msgA)) && (!msgA.equals("")) && (!array[i].toLowerCase().equals(msgA)))
      {
        subs = true;
        heightText += 12;
        height += 12;
        String output = array[i];
        String selection = output.substring(0, msgA.length());
        String rest = output.substring(msgA.length());
        output = new StringBuilder().append("\u00A74").append(selection).append("\u00A7f").append(rest).toString();
        if (hist)
          DrawMethods.drawRectWithSetOpacity(var4, 14 + height, getWidth() - 12, 2 + height, -2147483648, 0.8F);
        else
          drawRect(var4, 14 + height, getWidth() - 12, 2 + height, -2147483648);
        drawString(getFontRenderer(), output, var3, 4 + heightText, 16777215);
        DrawMethods.drawRectOutlineWithoutTop(var4, 14 + height, getWidth() - 12, 2 + height, -2130706433);
      }
      else if (msgA.toLowerCase().startsWith(array[i]))
      {
        subs = true;
        heightText += 12;
        height += 12;
        String output = comSug[i];
        output = getFontRenderer().trimStringToWidth(comSug[i], getWidth() - var3 - margin);
        if (!output.startsWith(comSug[i]))
          output = new StringBuilder().append(output.substring(0, output.length() - 3)).append("...").toString();
        if (hist)
          DrawMethods.drawRectWithSetOpacity(var4, 14 + height, getWidth() - 12, 2 + height, -2147483648, 0.8F);
        else
          drawRect(var4, 14 + height, getWidth() - 12, 2 + height, -2147483648);
        drawString(getFontRenderer(), output, var3, 4 + heightText, 16777215);
        DrawMethods.drawRectOutlineWithoutTop(var4, 14 + height, getWidth() - 12, 2 + height, -2130706433);
      }

      if (isWECommand)
      {
        comSug[i] = oldSuggestion;
        break;
      }

    }

    super.drawScreen(a, b, f);
  }

  public void printChatMessageFromConsole(String s) {
    WMinecraft.getMinecraft().printChatMessage(new StringBuilder().append("\u00A74").append("[Console]: ").append("\u00A7f").append(s).toString());
  }

  @Override
  public boolean doesGuiPauseGame()
  {
    return false;
  }

  public String getVersion()
  {
    return spc_sharconsole.VERSION;
  }
}