// Dependencies: ModLoader (or Forge) + WorldEditCUI

package com.q3hardcore.console.plugin;

import com.mumfrey.liteloader.LiteMod;
import com.mumfrey.liteloader.core.LiteLoader;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Side;
import com.q3hardcore.console.util.WorldEditCUIHelper;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

@Side(EnumSide.CLIENT)
public class spc_WorldEditGUI extends Plugin {

	private static boolean hasWorldEditCUI;
	private static boolean hasLiteLoader;
	private static boolean loadedWorldEditCUI = false;
	private static boolean doChecks = true;
	private static LiteMod WorldEditCUIMod = null;

	@Override
	public String getVersion() {
		if(hasWorldEditCUI) {
			return WorldEditCUIHelper.getVersion();
		} else {
			return super.getVersion();
		}
	}

	@Override
	public String getName() {
		return "WorldEditGUI";
	}

	@Override
	public void handleCUIEvent(String type, String[] params) {

		if(doChecks) {
			try {
				checkPrerequisites();
			} catch (Throwable t) {
				t.printStackTrace();
				hasWorldEditCUI = false;
				hasLiteLoader = false;
				doChecks = false;
			}
		}

		if(!hasLiteLoader || !hasWorldEditCUI) {
			return;
		}

		if(loadedWorldEditCUI && WorldEditCUIMod == null) {
			System.out.println("Please report this error.");
			return;
		}

		try {
			if(WorldEditCUIMod == null && !getWorldEditCUILiteLoader()) {
				return;
			}			

			WorldEditCUIHelper.handleCUIEvent(WorldEditCUIMod, type, params);		
		} catch (Throwable t) {
			System.out.println("Something went wrong.");
			t.printStackTrace();
		}

	}

	private void checkPrerequisites() {

		try {
			Class.forName("com.mumfrey.liteloader.core.LiteLoader");
			hasLiteLoader = true;
			System.out.println("LiteLoader is installed.");
		} catch (NoSuchMethodError nsme) {
			hasLiteLoader = true;
			System.out.println("LiteLoader is installed. (MCP)"); // this was for ModLoader
		} catch (Exception e) {
			hasLiteLoader = false;
			System.out.println("LiteLoader not installed.");
		}

		try {
			Class.forName("wecui.LiteModWorldEditCUI");
			hasWorldEditCUI = true;
			System.out.println("WorldEditCUI is installed.");
		} catch (Exception e) {
			hasWorldEditCUI = false;
			System.out.println("WorldEditCUI not installed.");
		}

		doChecks = false;

	}

	@SuppressWarnings("unchecked")
	private boolean getWorldEditCUILiteLoader() {

		loadedWorldEditCUI = true;
		
		List<LiteMod> liteMods = new LinkedList<LiteMod>();
		

		try {
			Field field = LiteLoader.class.getDeclaredField("mods");
			field.setAccessible(true);
			Object object = field.get(LiteLoader.getInstance());
			liteMods = (List<LiteMod>)object;
			for(LiteMod liteMod : liteMods) {
				if(liteMod.getName().startsWith("WorldEditCUI by yetanotherx")) {
					WorldEditCUIMod = liteMod;
					return true;
				}
			}
		} catch (Throwable t) {
			t.printStackTrace();
		}

		System.out.println("WorldEditCUI not loaded.");
		WorldEditCUIMod = null;
		return false;

	}

}