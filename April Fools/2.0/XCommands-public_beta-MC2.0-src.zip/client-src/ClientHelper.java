package com.q3hardcore.console.util;

import com.q3hardcore.console.wrapper.client.WGuiScreen;
import com.q3hardcore.console.wrapper.client.WMinecraft;
import java.lang.reflect.Field;
import net.minecraft.src.awn; // GuiChat
import net.minecraft.src.ConsoleChatHelper;
import org.lwjgl.input.Keyboard;

public class ClientHelper {

	private static final String[] persistantChatGUI = new String[]{"persistantChatGUI", "e", "field_73840_e"};

	public static void displayChatGUI(WMinecraft mc, int openKey) {
		WGuiScreen chatGUI = new WGuiScreen(new awn("/c /"));
		chatGUI.setWorldAndResolution(mc, -1, -1); // setWorldAndResolution
		int pressTime = 50;
		while(Keyboard.isKeyDown(openKey) && pressTime > 0) {
			pressTime--;
			mc.displayGuiScreen(chatGUI); // mc.displayGuiScreen((GuiScreen)(new GuiChat()))
		}
	}

	public static void registerChatHelper() {
		try {
			WMinecraft mc = WMinecraft.getMinecraft();
			Class<?> clazz = mc.getRaw().w.getClass();
			Field field = ReflectionHelper.getFinalField(persistantChatGUI, clazz);
			field.set(mc.getRaw().w, new ConsoleChatHelper(mc.getRaw()));
			System.out.println("Console Chat Helper enabled.");
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

}