package com.q3hardcore.console.wrapper.client;

import com.q3hardcore.console.wrapper.WEntityPlayer;
import com.q3hardcore.console.wrapper.WWorld;
import com.q3hardcore.console.wrapper.client.raw.RGuiScreen;

import java.io.File;

import net.minecraft.client.Minecraft;

public class WMinecraft {

	private final Minecraft minecraft;

	public WMinecraft(Minecraft minecraft) {
		this.minecraft = minecraft;
	}

	public static File getMinecraftDir() {
		return Minecraft.b();
	}

	public static WMinecraft getMinecraft() {
		WMinecraft wrappedMC = new WMinecraft(Minecraft.x());
		if(!wrappedMC.isValid()) {
			return null;
		} else {
			return wrappedMC;
		}
	}

	public void clearChatMessages() {
		minecraft.w.b().a(); // mc.ingameGUI.getChatGUI().clearChatMessages()
	}

	public void printChatMessage(String msg) {
		minecraft.w.b().a(msg); // ingameGUI.getChatGUI().printChatMessage()
	}

	public void sendChatMessage(String msg) {
		minecraft.g.d(msg);
	}

	public void updateReach(String reach) {
		try {
			minecraft.g.clientReach = Double.parseDouble(reach);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public WGuiScreen getCurrentScreen() {
		WGuiScreen screen = new WGuiScreen(minecraft.s);
		if(!screen.isValid()) {
			return null;
		} else {
			return screen;
		}
	}

	public void displayGuiScreen(WGuiScreen screen) {
		minecraft.a(screen.getRaw());
	}

	public void displayGuiScreen(RGuiScreen guiScreen) {
		minecraft.a(guiScreen);
	}

	public WEntityPlayer getThePlayer() {
		return new WEntityPlayer(minecraft.g);
	}

	public WWorld getTheWorld() {
		return new WWorld(minecraft.e);
	}

	public boolean isSinglePlayer() {
		return minecraft.B();
	}

	public boolean isValid() {
		return minecraft != null;
	}

	public Minecraft getRaw() {
		return minecraft;
	}

}