package com.q3hardcore.console.plugin;

// From SinglePlayerCommands by simo_415

// Obfuscated references: 0

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.lwjgl.input.Keyboard;

import com.q3hardcore.console.core.CommandHelper;
import com.q3hardcore.console.core.Console;
import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Side;
import com.q3hardcore.console.util.ClientHelper;
import com.q3hardcore.console.util.FontColour;
import com.q3hardcore.console.util.KeyListener;
import com.q3hardcore.console.util.Settings;
import com.q3hardcore.console.wrapper.WCommandHandler;
import com.q3hardcore.console.wrapper.WMinecraftServer;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.client.WMinecraft;
import Shar_Console.GuiConsole;

@Side(EnumSide.CLIENT)
public class spc_bind extends Plugin implements KeyListener {

	private static Settings BINDINGS = new Settings(new File(Helper.getModDir(), "bindings.properties"));
	private static final String[] BIND_PARAMS = new String[]{"Binds key", "[key] [command]", "g /c /god"};
	private static final String[] BINDID_PARAMS = new String[]{"Binds key", "[keyid] [command]", "g /c /god"};
	private static final String[] UNBIND_PARAMS = new String[]{"Unbinds key", "[key]", "g"};
	private static final String[] LISTBINDINGS_PARAMS = new String[]{"Displays current key bindings", "", ""};
	private boolean autobind;
	private Console ph;
	private boolean initialized = false;
	private static final List<Integer> reservedKeys;

	public spc_bind() {
		setTicking(true);
		setOwnerExclusive(true);
	}

	@Override
	public String getName() {
		return "Bind";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
		commands.add("autobind");
		commands.add("bind");
		commands.add("unbind");
		commands.add("bindid");
		commands.add("unbindid");
		commands.add("listbindings");
		return commands;
	}

	@Override
	public void atUpdate(WPlayer player) {
		if(spc_kbhandler.getInstance() != null) {
			initialized = true;
			this.addKeyListeners();
			if(BINDINGS.getString("41", "0").equals("0") && autobind) {
				player.sendMessage("Console GUI can be opened by pressing '~'.");
				this.bind(41);
				BINDINGS.set(41 + "", "/showchat");
				BINDINGS.save();
			}
			setTicking(false);
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] s) {

		if(getCommands().contains(s[0]) && !player.isPlayerOwner()) {
			player.sendError(Helper.ERRMSG_NOTOWNER);
			return true;
		}

		if ((s[0].equalsIgnoreCase("bind")) || (s[0].equalsIgnoreCase("bindid"))) {
			if(s.length < 3) {
				player.sendError("Must specify key and command.");
				return true;
			}

			int keycode;
			String keyname;

			if (s[0].equalsIgnoreCase("bind")) {
				String key = s[1];
				keycode = Keyboard.getKeyIndex(key.toUpperCase());
			} else {
				try {
					keycode = Integer.parseInt(s[1]);
					Keyboard.getKeyName(keycode);
				} catch (NumberFormatException nfe) {
					keycode = 0;
				} catch (ArrayIndexOutOfBoundsException aioobe) {
					keycode = 0;
				}
			}

			keyname = Keyboard.getKeyName(keycode);

			if (keycode == 0) {
				player.sendError("Unknown keycode " + s[1]);
				return true;
			}

			String command = "";
			for(int i=2; i<s.length; i++) {
				command += (s[i] + " ");
			}
			command = command.trim();

			if(BINDINGS.get(keycode + "") != null) {
				if(BINDINGS.get(keycode + "").equals(command)) {
					player.sendError("Key is already bound to specified command.");
					return true;
				}
			}

			if(command.equals("/showchat")) {
				if(reservedKeys.contains(keycode)) {
					player.sendError("Cannot bind selected key. (Reserved for Console GUI)");
					return true;
				} else if(keycode != 41) {
					player.sendMessage("You will need to use CTRL+" + keyname + " to open Console GUI.");
				}
			}

			if(BINDINGS.get(keycode + "") == null) {
				this.bind(keycode);
			}

			BINDINGS.set(keycode + "", command.trim());
			BINDINGS.save();
			player.sendMessage2("Key " + FontColour.AQUA + s[1] + FontColour.WHITE + " was successfully bound.");
			return true;
		} else if ((s[0].equalsIgnoreCase("unbind")) || (s[0].equalsIgnoreCase("unbindid"))) {
			if(s.length < 2) {
				player.sendError("Must specify key.");
				return true;
			}
			int keycode = 0;
			if (s[0].equalsIgnoreCase("unbind")) {
				String key = s[1];
				if (key.equalsIgnoreCase("all")) {
					BINDINGS.clear();
					BINDINGS.save();
					player.sendMessage("All bindings removed.");
					return true;
				}
				keycode = Keyboard.getKeyIndex(key.toUpperCase());
			} else {
				try {
					keycode = Integer.parseInt(s[1]);
				} catch (Exception e) {
				}
			}

			if (keycode == 0) {
				player.sendError("Unknown keycode " + s[1]);
				return true;
			}

			this.unbind(keycode);
			if (BINDINGS.remove(keycode + "") == null) {
				player.sendError("No binding was found for key " + FontColour.AQUA + s[1]);
				return true;
			}
			BINDINGS.save();
			player.sendMessage2("Binding " + FontColour.AQUA + s[1] + FontColour.WHITE + " was successfully removed.");
			return true;
		} else if (s[0].equalsIgnoreCase("autobind")) {
			boolean autobindCurrent = BINDINGS.getBoolean("autobind", true);
			autobind = autobindCurrent ^ true;
			BINDINGS.set("autobind", autobind);
			BINDINGS.save();
			player.sendMessage("Autobinding " + (autobind?"enabled.":"disabled."));
			return true;
		} else if(s[0].equalsIgnoreCase("listbindings")) {
			if(BINDINGS.keySet().isEmpty()) {
				player.sendError("No bindings.");
				return true;
			}
			player.sendMessage2(FontColour.GREEN + "===Key Bindings===========");
			for(Object o : BINDINGS.keySet()) {
				String keyName;
				try {
					int key = Integer.parseInt(o.toString());
					keyName = Keyboard.getKeyName(key);
				} catch (NumberFormatException nfe) {
					keyName = o.toString();
				} catch (ArrayIndexOutOfBoundsException aioobe) {
					player.sendError("Key binding " + o.toString() + " invalid.");
					continue;
				}
				player.sendPrettyMessage(keyName + ": " + BINDINGS.get(o));
			}
			player.sendMessage2(FontColour.GREEN + "==========================");
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String[] getHelp(String commandName)
	{
		if(commandName == null) {
			return null;
		}

		if (commandName.equalsIgnoreCase("bind"))
			return BIND_PARAMS;
		if (commandName.equalsIgnoreCase("unbind"))
			return UNBIND_PARAMS;
		if (commandName.equalsIgnoreCase("bindid")) {
			return BINDID_PARAMS;
		}

		if (commandName.equalsIgnoreCase("listbindings")) {
			return LISTBINDINGS_PARAMS;
		}

		return null;
	}

	private void addKeyListeners() {
		Iterator<?> i = BINDINGS.keySet().iterator();
		boolean hasAutoBind = false;

		while(i.hasNext()) {
			Object key = i.next();

			try {
				// System.out.println("key: " + key.toString());
				String keyString = (String)key;
				if(keyString.equals("autobind")) {
					autobind = BINDINGS.getBoolean("autobind", true);
					hasAutoBind = true;
					continue;
				}
				this.bind(Integer.parseInt(keyString));
			} catch (Exception e) {
				System.err.println("Invalid key specified in bindings: " + key);
				BINDINGS.remove(key);
			}
		}

		if(!hasAutoBind) {
			autobind = true;
		}
   	}

	private void bind(int key) {
		if(!spc_kbhandler.getInstance().addKeyPressedListener(key, this)) {
			System.err.println("Invalid key specified in bindings: " + key);
			BINDINGS.remove(Integer.valueOf(key));
		}

	}

	private void unbind(int key) {
		spc_kbhandler.getInstance().removeKeyPressedListener(key, this);
	}

	@Override
	public void keyPressed(int key) {

		final WMinecraft mc = WMinecraft.getMinecraft();
		String cmdString = BINDINGS.getString(key + "", "");

		if(mc != null && mc.getCurrentScreen() != null) {
			// System.out.println("GUI currently open.");
			if((mc.getCurrentScreen().getRaw() instanceof GuiConsole) && (cmdString.equals("/showchat"))) { // OBFUSC_REF
				// do nothing
			} else {
				return;
			}
		}

		final WPlayer owner = Helper.getOwner();

		if(cmdString.startsWith("!")) {
			cmdString = cmdString.substring(1);
			WCommandHandler commandHandler = WMinecraftServer.getServer().getCommandHandler();
			if(commandHandler.isValid()) {
				commandHandler.executeCommand(owner, cmdString);
			} else {
				System.out.println("(Console: ignoring key press)");
			}
			return;
		}

		if(cmdString.equals("/showchat")) {
			Plugin[] plugins = Console.getPluginManager().getPlugin("SharConsole");
			if(plugins.length > 0 && plugins[0] instanceof spc_sharconsole) {
				spc_sharconsole sharConsole = (spc_sharconsole)plugins[0];
				if(sharConsole.getEnabled()) {
					spc_sharconsole.showConsole(key);
					return;
				}
			}
			// spc_sharconsole.showConsole(key);
			System.out.println("Not opening console.");
			return;
		}

		final String[] split = cmdString.trim().split(" ");
		CommandHelper.handleCommand(owner, split);

   	}


	@Override
	public void keyReleased(int key) {}

	static {
		reservedKeys = new ArrayList<Integer>();
		reservedKeys.add(Keyboard.KEY_ESCAPE);
		reservedKeys.add(Keyboard.KEY_BACK);
		reservedKeys.add(Keyboard.KEY_RETURN);
		reservedKeys.add(Keyboard.KEY_LCONTROL);
		reservedKeys.add(Keyboard.KEY_A);
		reservedKeys.add(Keyboard.KEY_H);
		reservedKeys.add(Keyboard.KEY_X);
		reservedKeys.add(Keyboard.KEY_C);
		reservedKeys.add(Keyboard.KEY_V);
		reservedKeys.add(Keyboard.KEY_UP);
		reservedKeys.add(Keyboard.KEY_DOWN);
	}

}