package net.minecraft.src;

import com.q3hardcore.console.wrapper.client.WMinecraft;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

public class ConsoleChatHelper extends awl { // GuiNewChat

	private final WMinecraft mc;

	public ConsoleChatHelper(Minecraft mc) {
		super(mc);
		this.mc = new WMinecraft(mc);
	}

	public void a(String msg) { // printChatMessage
		if(msg.equals("\u00a77\u00a7o[XCommands: Checking for XCommands on client]")) {
			mc.sendChatMessage("\u00A7cXCOMMANDS////CHECK////TRUE");
			return;
		}
		String[] split = msg.split("////");
		if(split.length == 3 && split[0].equals("\u00A7cXCOMMANDS")) {
			if(split[1].equals("REACH")) {
				System.out.println("XCommands: Updating client reach");
				mc.updateReach(split[2]);
				return;
			}
			System.out.println("XCommands: " + msg + " was unexpected.");
			return;
		} else {
			this.a(msg, 0);
		}
	}

}
