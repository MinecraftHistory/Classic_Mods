package com.q3hardcore.console.wrapper.client;

import net.minecraft.src.bgj;

public final class WTessellator {

	private final bgj tessellator;

	private WTessellator(final bgj tessellator) {
		this.tessellator = tessellator;
	}

	public static WTessellator getInstance() {
		return new WTessellator(bgj.a);
	}

	public void draw() {
		tessellator.a();
	}

	public void startDrawingQuads() {
		tessellator.b();
	}

	public void startDrawing(int drawMode) {
		tessellator.b(drawMode);
	}

	public void addVertex(double x, double y, double z) {
		tessellator.a(x, y, z);
	}

}