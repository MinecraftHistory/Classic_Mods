package com.q3hardcore.console.plugin;

import Shar_Console.GuiConsole;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Side;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.client.WMinecraft;
import com.q3hardcore.console.wrapper.client.raw.RGuiScreen;
import java.util.List;
import java.util.ArrayList;
import org.lwjgl.input.Keyboard;

@Side(EnumSide.CLIENT)
public class spc_sharconsole extends Plugin {

	// constants
	public static final String VERSION = "1.3.3";

	@Override
	public String getName() {
		return "SharConsole";
	}

	@Override
	public String getVersion() {
		return VERSION;
	}

	protected static void showConsole(int openKey) {

		try {
			String branding = GuiConsole.class.getField("BRANDING").get(null).toString();
			if(branding != "q3hardcore") {
				return;
			}
		} catch (Throwable t) {
			t.printStackTrace();
			return;
		}

		if(!Keyboard.isKeyDown(29) && openKey != 41) {
			return;
		}

		if ((WMinecraft.getMinecraft().getCurrentScreen() == null) || (WMinecraft.getMinecraft().getCurrentScreen().getRaw() == GuiConsole.getInstance())) { // OBFUSC_REF
			final boolean hasCurrentScreen = WMinecraft.getMinecraft().getCurrentScreen() != null;
			if ((!hasCurrentScreen)) {
				int pressTime = 50;
				GuiConsole.msg = "/";
				GuiConsole.getInstance().setWorldAndResolution(WMinecraft.getMinecraft(), -1, -1);
				while(Keyboard.isKeyDown(openKey) && pressTime > 0) {
					pressTime--;
					WMinecraft.getMinecraft().displayGuiScreen(GuiConsole.getInstance());
				}
			} else if ((hasCurrentScreen) && (WMinecraft.getMinecraft().getCurrentScreen().getRaw() == GuiConsole.getInstance())) {
				WMinecraft.getMinecraft().displayGuiScreen((RGuiScreen)null);
				GuiConsole.hist = false;
				GuiConsole.msg = "";
				GuiConsole.y = 0;
			}
		}
	}

}