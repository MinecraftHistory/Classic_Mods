package com.q3hardcore.console.proxy;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.util.ReflectionHelper;
import com.q3hardcore.console.wrapper.WChunk;
import com.q3hardcore.console.wrapper.WEntityPlayer;
import com.q3hardcore.console.wrapper.WMovingObjectPosition;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WTileEntity;
import com.q3hardcore.console.wrapper.WTileEntityMobSpawner;
import com.q3hardcore.console.wrapper.client.WMinecraft;

import java.io.File;
import java.lang.reflect.Field;

public final class ClientProxy extends BaseProxy {

	private static final String[] spawnedMobMappings = new String[]{"j", "field_98291_j", "spawnedMob"};

	@Override
	public EnumSide getSide() {
		return EnumSide.CLIENT;
	}

	@Override
	public File getMinecraftDir() {
		return WMinecraft.getMinecraftDir();
	}

	@Override
	public void sendMessage(String msg) {
		final WMinecraft client = WMinecraft.getMinecraft();
		client.printChatMessage(msg);
	}

	@Override
	public boolean updateClientSpawner(WPlayer player, WMovingObjectPosition mop, String mob) {
		if(!player.isPlayerOwner()) {
			System.out.println("Not owner ;)");
			return false;
		}
		WEntityPlayer clientPlayer = WMinecraft.getMinecraft().getThePlayer();
		WTileEntity te = clientPlayer.getWorld().getBlockTileEntity2(mop.blockx, mop.blocky, mop.blockz);
		try {
			WTileEntityMobSpawner ms = WTileEntityMobSpawner.instantiate(te.getRaw());
			Object logic = ms.getLogic();
			Class<?> clazz = logic.getClass().getSuperclass();
			Field spawnedMob = ReflectionHelper.getField(spawnedMobMappings, clazz);
			spawnedMob.set(logic, null);
			ms.setMobID(mob);
			return true;
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	@Override
	public void setClientNoclip(boolean val) {
		WMinecraft.getMinecraft().getThePlayer().setNoclip(val);
	}

	@Override
	public void updateClientBiomeArray(int x, int z, byte[] biomeArray) {
		WChunk chunk = WMinecraft.getMinecraft().getThePlayer().getWorld().getChunkFromBlockCoords(x, z);
		if(chunk.isValid()) {
			chunk.setBiomeArray(biomeArray);
		}
	}

	@Override
	public void postInit() {
	}

}