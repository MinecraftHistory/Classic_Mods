package com.q3hardcore.console.wrapper.client.raw;

import com.q3hardcore.console.wrapper.client.WFontRenderer;
import com.q3hardcore.console.wrapper.client.WMinecraft;
import net.minecraft.src.axv;
import net.minecraft.client.Minecraft;

public class RGuiScreen extends axv {

	public final WFontRenderer getFontRenderer() {
		return new WFontRenderer(WMinecraft.getMinecraft().getRaw().q);
	}

	public final int getWidth() {
		return g;
	}

	public final void drawRect(int x1, int x2, int y1, int y2, int color) {
		a(x1, x2, y1, y2, color);
	}

	public final void drawString(WFontRenderer fontRenderer, String string, int x, int y, int color) {
		b(fontRenderer.getRaw(), string, x, y, color);	
	}

	public final void drawCenteredString(WFontRenderer fontRenderer, String string, int x, int y, int color) {
		a(fontRenderer.getRaw(), string, x, y, color);	
	}

	@Override
	public final void a(int par1, int par2, float par3) {
		drawScreen(par1, par2, par3);
	}

	public void drawScreen(int par1, int par2, float par3) {
		super.a(par1, par2, par3);
	}

	@Override
	public final void a(int par1, int par2, int par3) {
		mouseClicked(par1, par2, par3);
	}

	public void mouseClicked(int par1, int par2, int par3) {
		super.a(par1, par2, par3);
	}

	@Override
	public final void b() {
		onGuiClosed();
	}

	public void onGuiClosed() {
		super.b();
	}

	@Override
	public final void c() {
		updateScreen();
	}

	public void updateScreen() {
		super.c();
	}

	@Override
	public final boolean f() {
		return doesGuiPauseGame();
	}

	public boolean doesGuiPauseGame() {
		return super.f();
	}

	@Override
	public final void a(char c, int i) {
		keyTyped(c, i);
	}

	public void keyTyped(char c, int i) {
		super.a(c, i);
	} 

	@Override
	public final void A_() {
		initGui();
	}

	public void initGui() {
		super.A_();
	}

	public static final String getClipboardString() {
		return l();
	}

	public static final void setClipboardString(String string) {
		d(string);
	}

	@Override
	public final void a(Minecraft mc, int width, int height) {
		setWorldAndResolution(new WMinecraft(mc), width, height);
	}

	public void setWorldAndResolution(WMinecraft mc, int width, int height) {
		super.a(mc.getRaw(), width, height);
	}

}