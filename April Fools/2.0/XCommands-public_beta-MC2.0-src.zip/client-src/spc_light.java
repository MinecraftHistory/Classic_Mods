package com.q3hardcore.console.plugin;
// Obfuscated references: 0

import java.util.List;
import java.util.ArrayList;

import com.q3hardcore.console.core.Helper;
import com.q3hardcore.console.proxy.EnumSide;
import com.q3hardcore.console.proxy.Side;
import com.q3hardcore.console.wrapper.WPlayer;
import com.q3hardcore.console.wrapper.WWorldProvider;
import com.q3hardcore.console.wrapper.client.WMinecraft;

@Side(EnumSide.CLIENT)
public class spc_light extends Plugin {

	public static boolean isLit = false;
	public static int litWorld = 0;

	@Override
	public String getName() {
		return "Light";
	}

	@Override
	public List<String> getCommands() {
		List<String> commands = new ArrayList<String>();
			commands.add("light");
			return commands;
	}

	@Override
	public String[] getHelp(String commandname) {
		if(commandname != null && commandname.equals("light")) {
			String[] help = new String[]{"Lights world.", "", ""};
			return help;
		} else {
			return null;
		}
	}

	@Override
	public boolean handleCommand(WPlayer player, String[] s) {
		if(!s[0].equalsIgnoreCase("light")) {
			return false;
		} else {
			if(!player.isPlayerOwner()) {
				player.sendError(Helper.ERRMSG_NOTOWNER);
				return true;
			}

			if(player.getWorld().rawHashCode() != litWorld) {
				isLit = false;
			}

			WWorldProvider worldProvider = WMinecraft.getMinecraft().getThePlayer().getWorld().getWorldProvider();
			// WorldProvider worldProvider = Minecraft.getMinecraft().getTheWorld().getWorldProvider();

			if(!isLit) {
				player.sendMessage("Lighting world");
				float[] lightBrightnessTable = worldProvider.getLightBrightnessTable();
				for(int i = 0; i < lightBrightnessTable.length; i++) {
					lightBrightnessTable[i] = 1.0F;
				}
				litWorld = player.getWorld().rawHashCode();
				isLit = true;
			} else {
				player.sendMessage("Restoring defaults");
				worldProvider.generateLightBrightnessTable(); // generateLightBrightnessTable
				isLit = false;
			}
			return true;
		}
	}

}
