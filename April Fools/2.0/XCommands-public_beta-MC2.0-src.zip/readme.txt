XCommands [public beta]
=======================
For Minecraft 2.0

Written by q3hardcore

Code is used from:
* Minecraft Forge (various authors)
* Single Player Commands by simo_415
* WorldEdit by sk89q, et al.

Includes WorldEdit by sk89q.

Tools used:
* FernFlower decompiler
* Finder (by me) - source included
* Java Decompiler by Emmanuel Dupuy
* RetroGuard (MCP Version)

Note
====
If you want to use this source code in your own mod,
please contact me before releasing it,
so that I can confirm with the above people whose code is used.

* = not included in snapshot versions

Command			Description
-------			-----------
Loader			- loads custom commands
MultipleCommands	- base class for adding multiple commands
StandardCommand		- base class of custom commands
Sudo			- command to run commands as another player
WaypointCommand		- command for waypoint management
WorldEditCommandSet	- WorldEdit's command set, ported from SPC

Client			Description
------			-----------
ClientHelper		- client helper class
ClientProxy		- client proxy class
GuiScreen		- wrapper for GuiScreen instance
Minecraft		- wrapper for Minecraft instance
Light			- light command ported from new SPC
spc_bind		- plugin for key binding support
spc_clientcmds		- plugin containing client-only commands
spc_kbhandler		- handles key presses
spc_light		- plugin for lighting world

Core			Description
----			-----------
CommandConsole		- layer between Console and Minecraft's inbuilt console
CommandHelper		- Processes Console commands
CommandList		- a list of available commands, includes help
CommandPlugin		- fake command for plugging Console commands into Minecraft
CommandRegistry		- registers 'native' commands
Console			- core functions
Helper			- common functions and fields
PluginCommands		- commands for managing plugins
PluginLoader		- thread for loading plugins
PluginManager		- plugin manager

Helpers			Description
-------			-----------
ConsoleHelper		- generic helper class, core class for obfuscated references
ConsoleEntityHelper	- used for access to protected Entity fields/methods

Minecraft		Description
---------		-----------
EntityPlayerMP		- player class, used for onUpdate
ItemInWorldManager	- used for parsing mouse clicks on to WorldEdit

Plugins			Description
-------			-----------
Command			- class for adding commands (via annotations)
Plugin			- base plugin class
spc_abilities		- plugin for manipulating player abilities
spc_commands		- plugin containing main commands
spc_enchant		- plugin for enchanting items
spc_generate		- plugin for 'anti-structure' generation
spc_inventory		- plugin for inventory commands
spc_item		- plugin for modifying currently help item
spc_killplayer		- plugin for killing other players
spc_mccommands		- plugin allowing use of some inbuilt commands
spc_mobcmds		- plugin for mob-related commands
spc_paint		- paint plugin from SinglePlayerCommands
spc_path		- path plugin from SinglePlayerCommands
spc_spawner		- plugin for manipulating mob spawners
spc_structuregen	- plugin for structure generation
spc_waypoint		- plugin for teleporting, etc.
spc_weather		- plugin for weather commands
spc_WorldEditGUI *	- plugin for WorldEditCUI compatibility

Proxy			Description
----			-----------
BaseProxy		- base proxy class (server)
EnumSide		- proxy sides
Proxy			- proxy instance handler
Side			- side annotation

Utilities		Description
---------		-----------
DeathPos		- stores positions players died, for /restorepos command
FontColour		- font Colour helper
ForgeHelper *		- required for Minecraft Forge compatbility
KeyListener		- interface for key binding
ObfuscationHelper	- used for classes requiring obfuscated references
Settings		- used for storing and retrieving settings
WorldEditCUIHelper *	- required for WorldEditCUI support

Waypoint		Description
--------		------------
Waypoint		- class for storing a single waypoint
WaypointException	- exception thrown if waypoint invalid
WaypointHelper		- adds, removes and loads waypoints

WorldEdit		Description
---------		-----------
ConsoleBiomeType	- biome types for WorldEdit
ConsoleBiomeTypes	- class for managing biome types
ConsoleLocalPlayer	- local player class for WorldEdit
ConsoleLocalWorld	- local word class for WorldEdit
ConsoleServerInterface	- server interface for WorldEdit
LocalConfiguration	- stores WorldEdit configuration

Wrappers		Description
--------		-----------
AxisAlignedBB		- wrapper for obfuscated Axis-Aligned Bounding Box class
Biome			- used for WorldEdit biome support
Block			- helper for obfuscated Block class
ChunkCoords		- used for managing chunk coordinates
ChunkPosition		- used for managing chunk positions
CommandBase		- used as non-obfuscated layer for adding commands
CommandHandler		- registers commands for use in Minecraft
ConsoleException	- wrapper for exceptions
Coordinate		- used for managing positionss
DamageSource		- used for managing damage sources
Enchantment		- used for managing item enchantments
Entity			- used for managing entity
EntityList		- used to access obfuscated EntityList class
EntityLiving		- wrapper for EntityLiving class, i.e. mobs
EntityPlayer		- wrapper for EntityPlayer class
EntityRenderer		- used for getting entity player is looking at
FurnaceRecipes		- wrapper for FurnaceRecipes class
ICommandSender		- non-obfuscated layer for ICommandSender
InventoryPlayer		- wrapper for player's inventory
Item			- helper for obfuscated Item class
ItemStack		- helper for obfuscated ItemStack class
MathHelper		- wrapper for MathHelper class
MovingObjectPosition	- used for managing Moving Object Positions
NBTTagCompound		- helper for obfuscated NBTTagCompound class
Player			- used for managing EntityPlayerMP
StringTranslate		- used for getting instance of string translator
Vec3D			- wrapper for three-dimensional vectors
World			- used for managing world instance
WorldGenDungeons	- used for dungeon generation
WorldInfo		- used as non-obfuscated layer for WorldInfo class
WorldProvider		- used for managing world provider instance
WorldType		- non-obfuscated class of world types
... etc			- various

Misc			Description
----			-----------
WorldEdit.jar		- WorldEdit (place in .minecraft/bin)