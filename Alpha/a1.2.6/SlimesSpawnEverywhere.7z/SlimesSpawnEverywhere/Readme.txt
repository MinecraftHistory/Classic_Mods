Slimes Everywhere v.1.0.
By ChocolateySyrup and Vib_Rib

This mod will allow slimes to spawn in any place and at any time that a normal monster (skeleton, creeper, etc.) could regularly spawn. This means in dark caves, aboveground at night, etc. They will be about as common as the other mobs now.

This mod will require that you have installed Risugami's ModLoader v.1.2.6v2 which can be found in its official topic at: http://www.minecraftforum.net/viewtopic.php?f=25&t=80246

To install:
Put these two class files inside your minecraft.jar (not in a subfolder). Make sure META-INF is deleted from your minecraft.jar as well.