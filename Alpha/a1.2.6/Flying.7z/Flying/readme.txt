
This mod enables flying (SP and MP)

PS. In MP, fall distance is server side - do not land on ground when you have fallen/moved down considerably.
    Land in water or disable health damage on the server.

Installation:
* find minecraft.jar and open it (WinRar or similar)
* delete the folder META-INF from within if you have not deleted it already
* add the .class files to it (overwriting what was there before)
* copy the folder "mods" with all its contents to ".minecraft" folder (just outside of the "bin" folder you found minecraft.jar)

Default keys:
F - fly
U - un fly
E - up
Q - down
Shift - increases movement speed
Normal movement keys - as you would expect

NB! Ensure you have not assigned thous keys to something else (ex: F-fog setting, Shift-crouch, Q-drop item).

NB! You can also change the keys and some other options by editing the file "mods/zombe/fly.txt".
