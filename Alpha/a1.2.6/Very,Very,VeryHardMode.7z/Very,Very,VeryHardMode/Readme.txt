Very, Very, Very Hard Mode v.1.1
by ChocolateySyrup and Vib_Rib

This mod comes in parts. 
To install, just figure out which parts you want, then put the .class file for that part into your minecraft.jar (not in any subfolders).
The parts whose names start with "mod_" will require that you have installed Risugami's ModLoader v.1.2.6v2 which can be found in its official topic at: http://www.minecraftforum.net/viewtopic.php?f=25&t=80246
Be sure to delete the META-INF folder from your minecraft.jar if you haven't already.

********************************************
THE PARTS AND WHAT THEY DO WHEN INSTALLED
********************************************

========
NIGHTMARE OVERWORLD:
========
**ef.class**
--
All monsters can now spawn in sunlight! Be very careful when venturing across the overworld.
Areas lit by torches are still safe, and areas in both sunlight and torchlight will also still be safe.
You MUST add the next two classes (dh.class and nt.class) as well, or you'll get a lot of creatures spawning in sunlight that immediately catch fire and die. AND THAT WOULD BE VERY SILLY.
Please note that this affects ALL creatures that are considered mobs, so packs that add new monsters will also have them spawn in sunlight. Also, if you have the Slimes Everywhere mod, they will spawn overland and in daylight as well.

**dh.class**
--
Skeletons will no longer burn up in sunlight.
(IF YOU ARE USING FANCYPACK, PLEASE USE THE dh.class FILE FOUND IN THE FANCYPACK SUBFOLDER INSTEAD OF THE MAIN ONE. IT STILL GOES DIRECTLY INTO MINECRAFT.JAR.)

**nt.class**
--
Zombies will no longer burn up in sunlight.

========
NETHER RIFT:
========
**mod_GhastsEverywhere.class**
--
Ghasts will now spawn in the overworld, not just the nether. Even if you don't have ef.class installed, they will be able to spawn in sunlight as wella s darkness. Beware!
Ghasts will not set any blocks on fire except hellstone/bloodstone.

**mod_PigZombiesEverywhere.class**
--
Pig Zombies will infest the overworld. They can spawn in sunlight or darkness. Don't make them mad.

**spawnlist.class**
--
303's spawnlist utility. This is required to be added if you use either of the above mods (mod_GhastsEverywhere.class and/or mod_PigZombiesEverywhere.class).

========
NIGHTMARE CREEPERS:
========
**dq.class**
--
Creepers will not die when they explode. They can detonate multiple times and must be killed before they are fully dealt with.

********************************************
TROUBLESHOOTING:
********************************************
Every part should be able to work together. Parts that replace an existing class may conflict only with other mods that also edit that part. So if you have a mod that changes creepers, and affects the class for creepers, it will probably conflict with the part of this mod that changes creepers. Pick one or the other!
There is a specific problem with Mo Creatures but it WILL NOT break the game or your world. The problem is that wraiths will be able to spawn in the daylight, but will not be immune to daylight. As a result you will sometimes find wraiths spawning in the surface that immediately catch fire and die. There is no way to fix this without actually editing the wraiths themselves, so if you use .

Thanks to 303 for his impressive spawnlist utility, and to Risugami for his improved ModLoader.


HISTORY:
V.1.0
Initial Release
V.1.1
Fixed some bugs and compatibility issues