Humans+ v0.9

INSTALL:
Open the downloaded .rar file with your archiver of choice and drag the class files into your minecraft.jar
Copy the images in the "mob" folder to the respective "mob" folder located in the minecraft.jar

DELETE META-INF

Copy the files in the Modloader&spawnlist folder if you do not already have these mods installed

Big thanks to Club559, _303, HarryPitFall and Risugami for helping me troubleshoot some problems.

VERSIONS:
0.1 - Initial release.
0.2 - Custom Behaviours added.
0.3 - Mob Bandit added.
0.4 - condensed code, fixed spawning issues, 2 mobs added.
0.5 - More mobs added and alot of tweaks to others.
0.6 - All mobs improved, 2 mobs added, fixed archer fire glitch issue.
0.7 - Even more improvements, random skins and Just Humans download available.