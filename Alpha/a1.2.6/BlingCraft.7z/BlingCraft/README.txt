BlingCraft 1.0
For Minecraft Alpha 1.2.6 (other versions probably will not work.)
To Install, you must have Risagumi's Modified Modloader for 1.2.6 installed into your bin/minecraft.jar (or for advanced users, whatever jar file you use.)
Unzip the contents of this zip file to a directory.
Open the [appdatadir]/.minecraft/bin/minecraft.jar with a program like WinRar, click 'add', browse to the directory you unzipped this mod into, and select all of the contents except for this file.

WARNING: BACK UP BOTH YOUR SAVES AND YOUR MINECRAFT.JAR BEFORE USING THIS MOD FOR GOD'S SAKE MAN


