Sound Mod Enabler v2.2
======================
Normally, if you make any changes to the files in the resources directory,
Minecraft will re-download the default sounds and overwrite your custom files.
This mod allows you to stop that from happening.

Compatibility
-------------
Minecraft v1.2.6

Installation
------------
1. Make sure you have a backup of your minecraft.jar file!!!
2. Open your minecraft.jar file with a program like WinRAR or 7zip.
3. Delete the META-INF folder from the archive.
4. Drag the class file into the open archive.
5. Enjoy! :)

Usage
-----
To enable the mod:
	Create a text file named "DO_NOT_UPDATE" and put it in the resources folder.
	Minecraft will no longer overwrite your changes!
To disable the mod:
	Simply remove the DO_NOT_UPDATE file.
	Minecraft will now overwrite any changes to the resources folder.

Changelog
---------
v2.2:
	v1.2.6 compatibility

v2.1:
	Updated to work with v1.2.2

v2.0:
	Updated to work with v1.2.0_02 (Halloween Update)
	Check for DO_NOT_UPDATE.txt
