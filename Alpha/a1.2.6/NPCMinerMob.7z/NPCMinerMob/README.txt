Install instructions:
1. Press Windows + R and type in %appdata%
2. Find .minecraft and go to bin.
3. Open minecraft.jar in Winrar or 7Zip and delete META-INF folder
4. Paste the .class files to minecraft.jar
5. Play and enjoy!

Note: You must have ModLoader and Spawnlist to install this.

Made by MikkoK
Credits:
Maker of Minecraft Coder Pack
Club559 for the tutorial of making a simple mob
Everyone at #mcp in irc.esper.net for helping me