package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


final class StepSoundSand extends StepSound
{

    StepSoundSand(String s, float f, float f1)
    {
        super(s, f, f1);
    }

    public String func_1146_a()
    {
        return "step.gravel";
    }
}
