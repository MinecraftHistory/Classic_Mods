package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


class WorldBlockPositionType
{

    public WorldBlockPositionType(WorldClient worldclient, int i, int j, int k, int l, int i1)
    {
        field_1203_g = worldclient;
        field_1202_a = i;
        field_1201_b = j;
        field_1207_c = k;
        field_1206_d = 80;
        field_1205_e = l;
        field_1204_f = i1;
    }

    int field_1202_a;
    int field_1201_b;
    int field_1207_c;
    int field_1206_d;
    int field_1205_e;
    int field_1204_f;
    final WorldClient field_1203_g; /* synthetic field */
}
