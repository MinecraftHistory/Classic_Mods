Minecraft Extended Music Mod v0.6

Current compatibility: Minecraft SSP v1.2.6

Biome Music currently works as follows:
When the game decides to play some background music, it will check to see if you
have specified custom music files for it to play based on the biome that you are
presently standing in.  If you have, it will pick one of those files.  If you
haven't, it will use the default store.

Things that still need some work for Biome Music:
1.) Allowing further customization of the music parameters involving how often
    music plays, as well as things such as whether or not it should loop.

Battle Music currently works as follows:
When a mob begins to "pursue" you, check the "pursuit" counter.  If it is 0,
increment it and start playing music.  When a mob stops "pursuing" you, decrement
the "pursuit" counter. If the counter gets to 0 (i.e. no mobs following you),
then it will wait 5 seconds, if after 5 seconds no new mobs are following you,
then the music will fade out over 5 seconds.

As for "pursuit", it is interpreted as follows:  A mob will begin pursuit if you
are within 16 blocks of it and it can "see" you (i.e. line-of-sight).  They stop
pursuing you if you get at least 32 blocks away (ignoring line-of-sight), as by
then they have stopped following you.  Pursuit also ends if the mob dies
(obviously).

Things that still need some work for Battle Music:
1.) Pursuit isn't detected upon striking a docile spider, though i'm not sure if
    it should as they give up pursuit fairly rapidly.
2.) Ghasts/ZPigs haven't been worked on at all yet.

Installation:
1.) BACKUP YOUR EXISTING minecraft.jar!!!
2.) Open minecraft.jar
3.) Delete the META-INF folder
4.) Copy the contents of the bin/ directory (within this archive) into the root of
    the jar (will overwrite/create some files).
5.) Save the jar and close it.
6.) Copy any biome/battle music files to resources/streaming/, and place them in
    the config.

Customization (BiomeMusic.ini):
Upon first run of this mod, the file config/BiomeMusic.ini will be created in your
minecraft folder.  This is used to configure the following options:
playCustomMusic - enables or disables custom per-biome music
musicFileName - the name of the music file to play, for example, if you place
                "mybiomesong" here, then it will use all files of the form
                "mybiomesong[#].ogg" for default/biome-specific music
nextMusicLenMin - minimum number of ticks to run before starting another random
                  background music song
nextMusicLenMax - maximum number of ticks to run before starting another random
                  background music song
forceStartMusicOnNewBiome - whether or not ticks until next song should be
                            counted while music is playing if you are in a
                            different biome than you were in when the music
                            started.  if music is still playing when the tick
                            counter reaches 0, then the current music will
                            fade out and new music will fade in

It is expected that these options be under a [default] section to specify global
values.  Note, however, that you can also override the defaults for specific mobs
under their own sections.  For example, by default when a new config file is created
there is a section [creeper] that shuts off battle music for creepers.  Valid section
names are [rainforest], [swampland], [seasonal forest], [forest], [savanna],
[shrubland], [taiga], [desert], [plains], [ice desert], [tundra], [hell].

Customization (BattleMusic.ini):
Upon first run of this mod, the file config/BattleMusic.ini will be created in your
minecraft folder.  This is used to configure the following options:
playBattleMusic - enables or disables battle music by default or for a specific mob
musicFileName - the name of the music file to play, for example, if you place
                "mybattlesong" here, then it will use all files of the form
                "mybattlesong[#].ogg" for default/mob-specific music
startPursuitDistance - the distance at which a mob begins pursuit
stopPursuitDistance - the distance at which a mob ends pursuit
stopDelay - amount of time (in milliseconds) to wait after the last pursuing mob
            drops pursuit before beginning the fade-out on the battle music
fadeOutLength - amount of time (in milliseconds) over which to fade out the battle
                music

It is expected that these options be under a [default] section to specify global
values.  Note, however, that you can also override the defaults for specific mobs
under their own sections.  For example, by default when a new config file is created
there is a section [creeper] that shuts off battle music for creepers.  Valid section
names are [creeper], [spider], [zombie], and [skeleton].

If in doubt, look at the auto-generated config file for an example of how this works.

NOTE: THIS MOD DOES NOT REQUIRE A SOUND-ENABLER MOD SUCH AS SOUNDMOD!  IT WILL
      NOT FUNCTION WITH ONE AS IT REQUIRES ITS OWN CUSTOM DERIVATIVE OF
      SOUNDMOD IN ORDER TO ADD ADDITIONAL MUSIC RESOURCES.

Source code is included under the src/ directory.
