Mo' Creatures Mod 1.6.4

by DrZhark 
http://www.minecraftforum.net/viewtopic.php?f=25&t=86929
compatible with minecraft 1.2.6

It adds the following creatures to Minecraft:
-Lion (plus female lions)
-Bear
-Polar Bear
-Wolf
-Wraith
-Flame Wraith
-Ogre
-Fire Ogre
-Cave Ogre a.k.a. cyclops
-Duck
-Boar
-Horse, Unicorn, Pegasus


The mod does not change any classes in the game, maximum compatibility!

To install: 
please install Modloader and AudioMod first and then:

1. Make a backup of your minecraft.jar file
2. Open your minecraft.jar file using winrar or similar
2. Add contents of the folder "\files to inject to minecraft.jar\" to the root of the minecraft.jar file (where all the .class files are)
3. Add the png files located in the folder "\files to add to minecraft.jar\mob", to the folder \mob inside the minecraft.jar (you will see other png files there)
4. Delete the META-INF folder of minecraft.jar
5. Close and save your minecraft.jar

6. locate the .minecraft\resources\ (where you have installed minecraft)
7. look inside the "\folders to add to resources\", copy the \mod folder with all its contents and add it to the folder .minecraft\resources\ (make sure you are not adding this to the minecraft.jar file). Your minecraft \resources\folder should have then a new folder called '\mod\sound' and inside you should have the new .ogg files
8. Play (don't get too close to the lions)
9. Beware of the Ogre!

F.A.Q.

    Q.: I get a black screen when installing the mod
    A.: Did you forget to delete the META-INF folder as in step 4?

    Q.: The lions and bears are bipeds!!
    A.: You either did not install the 303 Mod Loader or you installed another mod that conflicted with mine (i.e. a non Mod Loader mod)

    Q.: How to install Audiomod?
    A.: put all the contents of the Audiomod In the root folder of minecraft.jar.  
        Make sure it is overwriting the files (some mac users will have trouble with files not being overwritten).

    Q.: How to install ModLoader?
    A.: put all the contents of ModLoader (files and folders) in the root folder of minecraft.jar. same as above

    Q.: My game crashes when a get near a lion/bear/wolf/wraith
    A.: please ensure that you installed the (.ogg) sound files correctly 


ChangeLog:
Changes in version 1.6.4
-Increased attack range of lioness
-Lioness is more aggressive than the Lion
-Fire Ogres and Flame Wraiths will only spawn in Hard difficulty. Both will also spawn in Hell
-Decreased pyromany of Fire Ogres. They still burn whole forests, tho.
-Added Boars: attack only prey smaller than them (including bunnies!). Boars will also attack you if you get really close.
-Added Horses including Unicorns and Pegasus
-For every horse you find, there is a 7% chance of finding a Unicorn and only a 4% chance of finding a Pegasus... so good luck!
-Added craftable Horse Saddles.  You will require a horse saddle to ride your horse. The normal saddles that you find randomly in dungeons only work for pigs. 
-Quick guide on how to tame horses: The faster/rarer the horse, the harder to tame. This is what they require to be as docile as possible before you mount them. Even after making them happy, you will have to break/ride them until they accept you.  To make them docile you will need to give:
- Light horses (1 bread or 4 wheat)
- Brown Horses (2 bread or 8 wheat)
- Black horses (3 bread or 12 wheat)
- Unicorns (4 bread or 16 wheat)
- Pegasus (5 bread or 20 wheat)

Changes in version 1.6.3
-split mod in groups to mix and match
-added female lions
-Male lions will not attack female lions
-female lions are less aggresive towards player
-added ducks (using dorino1 quack sounds plus painterly pack's duck texture)


Changes in version 1.6.2
-Using 303's spawnlist, the mod no longer modifies the gg.class
-Green ogres don't burn on sunlight, they become docile unless attacked.
-Fire ogres now spawn on Normal difficulty
-Tweaked blast radius for ogres, depending on difficulty level, in hard the blast radius is bigger
-Changed drops for Fire Ogres and Cyclops to the intended drops
-Minor tweaks to the hunters behavior
-Ogres no longer destroy ores or mobspawners

changes in version 1.6.1
-Ogres area of destruction reduced

Changes in version 1.6
-Lions, Bears and Wolves wont hunt in peaceful difficulty
-decreased hunting range from 16 to 8
-decreased 'hunger' of hunters to 1/10
-added Ogres (normal, fire and cave): spawn on Normal or harder difficulty, destroy blocks, can smell players 24blocks apart, will destroy blocks in their path to their target
-Ogres won't destroy obsidian


Changes in version 1.5:
-Major changes to A.I:
-Lions will now attack other animals, including other lions and bears
-Bears won't attack lions, but they will attack any other animals
-Wolves will attack pigs, chickens and sheep, in addition to players during night
-reduced Bear spawn rate to 1/3

Changes in version 1.4:
-made it compatible with Minecraft 1.2.5
-reduced the attack range of the lion in Hard difficulty from 16 to 6, and in Normal difficulty from 6 to 4
-decreased Lion spawn rate to 1/3
-reduced wraith spawn rate to 1/2

