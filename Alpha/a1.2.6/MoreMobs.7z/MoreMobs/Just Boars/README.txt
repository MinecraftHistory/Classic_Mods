Mo' Creatures Mod - Boar

by DrZhark 
http://www.minecraftforum.net/viewtopic.php?f=25&t=86929
compatible with minecraft 1.2.6

It adds the following creatures to Minecraft:
-Boar


The mod does not change any classes in the game, maximum compatibility!

To install: 
please install Modloader and AudioMod first and then:

1. Make a backup of your minecraft.jar file
2. Open your minecraft.jar file using winrar or similar
2. Add contents of the folder "\files to inject to minecraft.jar\" to the root of the minecraft.jar file (where all the .class files are)
3. Add the png files located in the folder "\files to add to minecraft.jar\mob", to the folder \mob inside the minecraft.jar (you will see other png files there)
4. Delete the META-INF folder of minecraft.jar
5. Close and save your minecraft.jar

6. locate the .minecraft\resources\ (where you have installed minecraft)
7. look inside the "\folders to add to resources\", copy the \mod folder with all its contents and add it to the folder .minecraft\resources\ (make sure you are not adding this to the minecraft.jar file). Your minecraft \resources\folder should have then a new folder called '\mod\sound' and inside you should have the new .ogg files
8. Play (don't get too close to the lions)
9. Beware of the Ogre!

F.A.Q.

    Q.: I get a black screen when installing the mod
    A.: Did you forget to delete the META-INF folder as in step 4?

    Q.: The lions and bears are bipeds!!
    A.: You either did not install the 303 Mod Loader or you installed another mod that conflicted with mine (i.e. a non Mod Loader mod)

    Q.: How to install Audiomod?
    A.: put all the contents of the Audiomod In the root folder of minecraft.jar.  
        Make sure it is overwriting the files (some mac users will have trouble with files not being overwritten).

    Q.: How to install ModLoader?
    A.: put all the contents of ModLoader (files and folders) in the root folder of minecraft.jar. same as above

    Q.: My game crashes when a get near a lion/bear/wolf/wraith
    A.: please ensure that you installed the (.ogg) sound files correctly 


Credits go to:
-Macaque for the boar texture