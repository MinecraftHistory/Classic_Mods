
Half Step Variant mod :: Ayutashi~
----------------------------------

This simple mod is a variant on the Smooth Stone Half Step blocks.

The normal Double Half Step is completely replaced with an
Inverted Half Step block.  Meaning, instead of two half steps,
you get a top half only!

The Inverted Half Step blocks are not craftable, nor are they
created by stacking two half blocks.  Instead, there's a new
on-click function that iterates between the two types.

To get your Inverted Half Step, place a regular Half Step, then
left- or right-click on the step while holding -nothing- in hand.
Make sure you're not holding anything in the current inventory
slot, or it work at all!  I made it this way so they're not so
slippery to destroy with your Pickaxe ^^;

You can continue to click to toggle back and forth as you wish!

There's a safety precaution embedded as well.  If you're standing
on top of the block while clicking, you'd normally fall through
if the block reappears inverted.  I've make the blocks slightly
more intelligent, so that if you're doing this, you get bumped
up before the block is replaced, so you won't fall!


-----------
OTHER NOTES
-----------

Installation's simple as always!  Only a single file to worry about here.

However, there are currently two standard versions, and a variant variant!

I had noticed that the Inverted Half Step block leaves an ugly black shadow
underneath it due to the default light options.  Thus, I felt obligated to
create a couple versions depending on your tastes!

"HighOpacity" : Lets much light pass through the block.  Same light opacity
    as Leaf blocks.  Creates hardly any shadow at all.  Handy, and nicer
    to look at from underneath, but obvious flaws.

"LowOpacity" : Lets very little light pass through the block.  This makes
    the shadow reappear, but it's not completely black!  This is better
    if you don't want to abuse light sources.

----------

Aside from this, there's another file in the "MiniElevator" folder!
This is a bit more "fun", as well as mechanical.

This separates the left-click and right-click functions to allow for
a more interesting effect.

Left-Click  : Raise the Half Step by a half block.
Right-Click : Lower the Half Step by a half block.

Again, standing on top while "riding" this block will automatically
adjust your vertical location for you :3  Also, the block will "search"
for other blocks above and below, so no worries about suffocating!
Just... don't drive the block down into lava.  It'll let you, but
I really don't recommend it!  :D