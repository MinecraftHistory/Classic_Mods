To install:
1.Locate your .minecraft folder in your appdata/roaming
2.Open the .bin folder 
3.Locate minecraft.jar
4.Right click and open it with Winrar/7zip
5.Drag in the designated files
6.Delete the META-INF folder.
7.Close and enjoy!
