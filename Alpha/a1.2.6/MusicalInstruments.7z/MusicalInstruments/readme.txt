Musical Instruments 1.2
by Cryect
At the moment, this mod won't mesh well with other mods that add items.  In the future, if I get a chance I will make it ModLoader compatible.  The basic idea of this mod is you can make musical instruments and play music off of signs.

Installation
With a fresh install of Minecraft goto where your minecraft.jar is located and open it up with a program that can manipulate JARs.  Delete the meta-inf folder and copy in all the class files from this mod and the image file into the gui directory for the instrument icons.

Specifying Music on Signs
You can specify notes from A to G by using upper case letters. If you want a flat or sharp note then add a 'b' or '#' after the note.  Any spaces get interpreted as a pause.  If you want to decrease the octave you can add a - and then a + to go back to the upper octave (only 2 octaves due to limitations with pitch adjustment with the sound library).  You are unable to specify the duration of notes.

Instruments
Harp
GGG
SG
G

G = Gold Bar
S = String

Bass Guitar
  S
PP
PP

S = Stick
P = Wood Planks

Snare Drum
 P
PLP
 p

P = Wood Planks
L = Leather


The guitar icon is from the Fugue Icon pack by Yusuke Kamiyamane. http://p.yusukekamiyamane.com/

History
V1.2 - Ratios were slightly off and needed to all be fixed.
V1.1 - Turns out the notes included with Minecraft are F# so adjusted the code to take that into account
V1.0 - Original Release