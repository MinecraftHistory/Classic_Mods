MINECRAFT FANCYPACK 1.2
By ChocolateySyrup and Vib Rib

How to Install
--------
0. Before you do anything else, download and extract ModLoader somewhere you can find it.
1. Open minecraft.jar with WinRAR or other archive program.
2. Delete the META-INF folder from inside minecraft.jar.
3. Add all the class files from ModLoader into your minecraft.jar.
4. Add all the class files from the CORE directory in this pack into your minecraft.jar. Make sure you are adding the class files, AND the folder inside called "fancypack", but not the CORE folder itself! There are many optional mods within the FancyPack, but the CORE class files and the /fancypack/ texture folder in the core directory are necessary for the mod to work at all, period!
5. Add all the optional class files from the "Installation" directory that you want to activate. 
6. Once you have added all the sets of class files you desire, lose minecraft.jar.
7. Run Minecraft normally and enjoy!

A black screen means you did not install all the class files in the specific packs you are using, or you did not install all the CORE files, or you did not delete the META-INF folder from your minecraft.jar.
If the game freezes just after entering the world, it probably means the external textures are not loading right. Make sure that inside your minecraft.jar is the /fancypack/ folder containing all the new textures. If not, you can find this folder in the core install directory.

IF YOU GET CONFUSED, JUST READ THE TEXT FILES IN THE INSTALLATION DIRECTORY FOR MORE SPECIFIC HELP!

Optional Mods: What do you want to install?
--------
In the "Installation" folder you will find several more folders. Each folder contains a set of class files that make up an optional mod in FancyPack. The CORE folder contains all the files you NEED to play FancyPack. Make sure you use these! 
You can play with just the CORE files if you want, or you can add as many of the optional sets that you want. The optional sets can be found in the other folders in the Installation directory (the ones not marked "CORE"), and each one comes with a readme telling you what the set does, and what conflicts it might have.


Texture Packs
--------
The FancyPack uses lots of new graphics for both items and blocks. 
Fortunately, these textures are all external, which means they are automatically imported by the ModLoader over your existing texture pack while they're being used. This way, they can work with any texture pack!

If you want to change the way the new icons or blocks look, it's very easy. Just go into your /fancypack/ directory, found in the core install directory of the FancyPack, and look for the files you want to edit. They're all named for easy reference! Then once you've changed them, make sure they end up with all the other textures in the /fancypack/ folder inside your minecraft.jar.
That's all you have to do!


Multiplayer Mode?
--------
At the moment, FancyPack is a singleplayer-only mod. So sorry!


Mod Conflicts
--------
FancyPack has been optimized to work with ModLoader, so conflicts will be few. However, some will still exist. Specifically, mods that affect the RenderBlocks class, namely MrMMods BetterLights and Ambient Occlusion mods, will not currently work with FancyPack -- but we are working on a fix! Any mods that add entirely new block shapes will also conflict.
The core mod pack should not alter any other existing classes, so that should be it for conflicts.
Optional mods within the FancyPack alter other existing classes. Refer to each mod for a reference of what might conflict.


Recipes
--------
You can find a full list of all the new recipes in recipes.txt in this RAR.

Credits
--------
Vib Rib and ChocolateySyrup, mod creators, for primary new coding, some new art assets, and the creation of this mod.
bbcisdabomb, for generous webhosting space.
Kas/Rhodox, for his fantastic work on the Minecraft Painterly Pack textures, from which most graphics are derived or copied (with permission), as well as suggestions and ideas.
The creators of the Minecraft Mod Creator Pack. Without your decompiling and de-obfuscation this would never be possible! Extra thanks are necessary for all your work helping with this project and providing great feedback and support.
Valance, for his amazing work on the Colorizer class and methods first showcased in his popular Paint Your Blocks mod, which made the FancyPack dyes possible! And extra thanks for letting us know how to separate all the new textures into their own files.
Lilyo for the Quandary adaptation, and ExtraNoise for creating the fabulous Quandary pack in the first place.
Evil_Greven for smacking me upside the head with common sense and helping me fix the road block speedbug.
A million thanks to Professor Mobius, Club559, 303, Risugami, and many more for their assistance and guidance in adapting this mod for ModLoader compatibility.
Risugami and 303 for making the fantastic ModLoader.
Seronis, for debugging help and making the final hurdle into ModLoader compatibility.
SomethingAwful, for support, suggestions, and ideas that helped shape this mod into what it is.
And of course, Notch, for creating Minecraft in the first place!


VERSION HISTORY
--------
1.00
Initial Release

1.01
Removed new furnace recipes, but fixed broken furnaces

1.02 
Added speed limit to roads to prevent bunnyhopping and railgunning
Re-introduced furnace recipes without breaking furnaces
Fixed plants not growing
Removed chunk generation changes to improve compatibility with existing mods
Added graphics options for Quandary (September version) and Default texture packs.

1.02b
Fixed furniture not returning the right amount when crafting.
Fixed table recipe.
Adjusted furniture resistance to allow them to be disassembled more quickly.

1.1
Converted to ModLoader!
 -Compatibility with other mods greatly increased.
Split mods into optional packages, allowing users to pick and choose which features they want.
Decaying Leaves mod integrated, courtesy of desbones. Thanks!
Minor fixes and tweaks.

1.2
Just like 1.1, but this time it should actually work.

1.3 
Greatly condensed all 