World Teleporter Mod v0.2

Compliance: Minecraft SSP v1.2.6

NOTE: I RECOMMEND BACKING UP YOUR SAVES PRIOR TO RUNNING THIS MOD, AS THERE
      IS A CHANCE THAT YOU MAY WANT TO REVERT BACK IF SOMETHING GOES WRONG

====================== Summary: =======================

The World Teleporter Mod is a mechanism by which you can now use Nether portals
to teleport between dimensions whether they be a.) the main world (surface),
b.) the nether (nether), c.) other save files, d.) new dimensions.

=================== How it works: =====================

1.) Load into your main world.

2.) Create a nether portal.

3.) Place a sign NEAR the portal (note, it does not have to be ON the portal)
    with one of the following formats:

LINE1: ""
LINE2: "Dimension:"
LINE3: "<dimname>"
LINE4: ""

LINE1: "Dimension:"
LINE2: "<dimname>"
LINE3: "Position:"
LINE4: "(<x>, <y>, <z>)"

LINE1: "<dimname>"
LINE2: "<x>"
LINE3: "<y>"
LINE4: "<z>"

<dimname> is the desired name of the dimension (note: NETHER and SURFACE
are reserved dimensional names related to the Nether and the main game save
world).  <dimname> refers to one of three things:
  a.) a dimensional world directory name that will be created or used within
      your main save directory (similar to how the nether's directory is DIM-1).
  b.) a save directory name such as "World1", "World2", etc. (references a
      directory under the main minecraft saves folder.
  c.) a save world name as defined in "name.txt" (used in my World Namer mod
      and seronis' Worlds Omega mod to name worlds)
Note: when giving names that are referencing directory names, the matching is
      case-insensitive and all non-alphanumeric characters in the dimname will
      be replaced with underscores ('_').

<x>,<y>,<z>, if specified, are the X, Y, Z coordinates in the new dimension
that you would want the player to be warped to.  If the X, Y, Z coordinates
are not specified, then they will be determined based on standard portal
mechanics (namely: no change from dim -> dim, no change from nether -> nether,
*8 from nether -> dim, /8 from dim -> nether).  Note that you can safely
specify any values here, as the standard portal mechanisms will be sure to
place the corresponding exit portal in a valid location.

4.) Walk into the portal - when the portal activates, all signs that you have
    placed within a 10x10x10 cube (with the center of your head as the center
    of cube) will be scanned for valid teleport information.  If any are found,
    it will find out which one is the closest to the center of your head and
    use that one as the determinant of the teleport.

5.) And you're off!

================== Installation: ======================

1.) BACKUP YOUR EXISTING minecraft.jar!!!
2.) Open minecraft.jar
3.) Delete the META-INF folder
4.) Copy the contents of the bin/ directory (within this archive) into the root of
    the jar (will overwrite/create some files).
5.) Save the jar and close it.

============== Making saves accessable ================

So let's talk about the most exciting part of this mod: BEING ABLE TO MOVE
BETWEEN WORLDS!!!

Keep in mind that when accessing dimensions you specify on the sign posts, that
it will replace anything that isn't a letter or number with an underscore ('_')
and uppercase all of the letters.  It will then perform a search for that
dimension based on this new "standardized" name.

Since v0.2 saves can be accessed directly WITHOUT the need for any extra work!
Just specify the save name on your sign and away you go! (Note: saves may be
referenced either by directory name or names as specified in "name.txt" within
the world's save folder).

======= Specifying a Seed on Dimension Creation =======

When specifying a dimension to warp to, you can also specify a seed to be used
by that dimension (note: this seed is ONLY used if the dimension is being created,
and will not overwrite a currently defined dimension/world seed).

Simply place a second sign near the portal you intend to use, and specify it as such:

LINE1: "Seed:"
LINE2-4: <seed>

The 2nd through 4th lines of the sign will be concatinated together and used as
the level seed.  Hence, if you wanted to use the seed "-834728351935235", you
could specify it in a sign as such:

LINE1: "Seed:"
LINE2: "-8347283"
LINE3: "51935235"
LINE4: ""

Note: after traveling into this dimension, the seed will be permanently saved for
      it and you can safely remove the "Seed:" sign.

==================== Other Notes ======================

Using portals without signs:
  Portals without signs will work as you would usually expect.  A non-nether
  dimension will send you to the Nether, and the nether will send you back.
  Currently, if you leave the nether through an unsigned portal, it will send
  you back to the dimension that you last entered the nether from.

Nethers:
  There is only ONE nether.  All dimensions will lead you to the same nether,
  regardless of whether old saves had their own nether data.

Spawn:
  Upon death, you will spawn in the last dimension you were located in,
  at the X, Y, Z coordinates corresponding to the spawn point in your
  original SURFACE world.  Hence, you will have a spawn point in every
  surface dimension and which one you end up at will depend on which dimension
  you die in.  If you die in the nether, you will spawn in the dimension that
  you were last in prior to entering the nether.

World interaction:
  Interacting with another world is done at a chunk level.  Hence, any changes
  you make physically to the world or place in the world will be altered
  accordingly and reflected if you were to go back into that world (after copying
  the folder back of course).  Inventory/Player position are not overwritten, as
  they are stored and managed in the level.dat of the original save that is seen
  as the "source" save.  The only time another world's level.dat is read is in
  order to get the seed value such that level generation will work properly.

Seeds:
  Level seeds (the magick stuff that makes levels random and unique) are loaded
  depending on the situation at hand.  The core level as well as the nether use
  the seed from the source level.dat file.  When loading an alternate dimension,
  first the dimension's folder is queried for a level.dat file.  If one exists
  (because it is a previous save), then the seed is loaded from it in order to
  maintain smoothness if more chunks are generated.  If no level.dat exists, then
  it looks for a file called SEED.txt, which my mod creates to allow dimensions
  to each have their own unique seed (and therefore their own terrain).  If it
  doesn't exist it creates it and bam you have a new unique dimension to work in!

BiomeTerrainMod:
  At present this does not work with BiomeTerrainMod, as both mods modify some
  of the same world generation classes.  Hopefully a merged version can be made
  in the near future.
