This mod enables user customizable crafting recipes (SP and MP)

Installation:
* find minecraft.jar and open it (WinRar or similar)
* delete the folder META-INF from within if you have not deleted it already
* add the .class files to it (overwriting what was there before)
* copy the folder "mods" with all its contents to ".minecraft" folder (just outside of the "bin" folder you found minecraft.jar)

All recipes are defined in "mods/zombe/recipes.txt" - basic instructions are also in it.
For your convinience all vanilla recipes are already defined.

PS. "mods/zombe/recipes-example.txt" is an example recipeset.

DEBUGGING: When something does not work right then looking into recipes-log.txt file might help. It is located in the same folder
as minecraft.jar is - under "mods/zombe". In there you will find all the errors minecraft encountered in your last session when
you tried to craft something (recipes are loaded and checked for errors the moment you open player inventory or crafting bench).

Additional info for advanced users: [NAMEMAP], [RECIPES] and [IGNORE] tags tell how minecraft should interpret the lines that
follow - until told otherwise by another tag. [NAMEMAP] is for defining names for blocks and items. [RECIPES] is for defining
crafting recipes. [IGNORE] is for disabling large sections of definitions. All tags may be present multiple times in any order.
However, you can use only thous names in recipes that you have define earlier in the file.
