When you empty one of the item slots in your quickbar, this mod will automatically refill the slot with a stack of the same item from your inventory.


Installation Instructions (Windows)

1) Open %appdata%/.minecraft/bin
2) Make a backup of minecraft.jar
3) Open minecraft.jar with WinRAR
   - Drag and drop all .class files into the archive
   - Delete the META-INF folder if it exists
4) Close WinRAR


Version History

v1
- Initial release compatible with Minecraft version 1.2.6
