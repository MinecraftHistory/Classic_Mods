Version: 2.2
Released: 11/12/10
Made for Alpha 1.2.6 or 0.2.8
Single Player & Multiplayer!

Installation:

Choose the correct folder for the installation. Single player clients should use the single player versions. Multiplayer servers shoud use the multiplayer version.

Use the Minecraft Mod installer (http://minecraft.codeplex.com/releases/view/52403) or manually merge the new source files into your Minecraft.jar package manually.

Manual Installation (Windows) For Single Player:

1) Open up %appdata%, if you don't know how to do this, start>run, then type in %appdata%
2) Browse to .minecraft/bin
3) Open up minecraft.jar with WinRAR or 7zip.
4) Drag and drop the necessary files into the jar.
5) Delete the META-INF folder in the jar. 
6) Run Minecraft, enjoy!

Manual Installation (Windows) For Multiplayer:

1.) Download the Hey0 mod
2.) Add MinecartMania to the plugin list in server.properties
3.) Copy the MinecartMania.jar to the Hey0/bin/plugins folder
4.) Launch the server
5.) Play!


Report any Comments, Ideas, or Bugs to http://www.minecraftforum.net/viewtopic.php?f=25&t=67683

Source Code available on request.

Enjoy!
Afforess