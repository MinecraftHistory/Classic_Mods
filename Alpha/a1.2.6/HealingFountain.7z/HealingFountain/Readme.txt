You should backup your minecraft.jar before installing any mod, in case something goes wrong.

EASY INSTALL INSTRUCTIONS
If your META-INF folder is deleted already, you can copy the files HealingFountain.class, mod_HealingFountain.class, installHealingFountain.bat
and the folder healingFountain directly into the folder where you have your minecraft.jar (/bin), and then double click intallHealingFountain.bat.
That's it. If this doesnt work, install as specified in the normal installing instructions.

NORMAL INSTALLING INSTRUCTIONS
This is installed as every other mod, delete the META-INF folder in minecraft.jar, and then add the files supplied. 
Requires ModLoader to work. Make sure to copy the folder called healingFountain into your minecraft.jar as well. The entire folder goes straight into minecraft.jar.
Some extra textures are supplied, use whatever you think is best. Just copy the desired texture into the folder healingFountain before you put it into minecraft.jar.
The names of the textures have to be exactly the same as the textures in healingFountain (fountainSides.png, fountainTop.png and healingWater.png).

WARNING:
A world that has blocks from this mod placed somewhere in it, is unusable without this mod. 
This is because then the world contains blocks that unmodded Minecraft doesn't know what to do with.
If you don't have this mod installed and try to open a world that contains placed redblock, Minecraft will crash. 
Redblock in chests are fine though, as long as you don't open the chests. Install at own risk. 
When Minecraft is updated, this mod will most likely stop to function properly, and then the world is unusable until this mod is updated. 
The blocks can be removed with software like MCEdit. Sometimes Minecraft corrupts save files. 
I strongly suggest to make backups of your worlds regularly.
