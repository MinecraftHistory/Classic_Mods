
This mod adds customizable tombstone- and dungeon treasures.

Tombstone: a double-half-step with a sign on it (what class of person
  is buried there) - under it you will find some random treasure.
With current config - there are 7 person classes : Warrior, Alchemist, Citizen, Wanderer, King, Miner and Explorer.
NB! Ground matters (at least with my default configuration) - for example, Kings are rarely buried in beach sand ;)

NB! This is an experimental mod - using it with your main world is not
    advised (altough i have not encountered any problems).

Installation:
* add all the .class files minecraft.jar and DELETE the META-INF folder from it!
* mods folder with all its contents goes to ".minecraft" folder

Config files:
* names.txt    - contains namedefinitions (anyone who has used my recipe mod should be familiar with it)
* treasure.txt - contains configurable options (like 25% chance that there is no treasure chest below tombstone, etc)
* bags.txt     - defines all the loot ... prepare for headache if you are easely confused
