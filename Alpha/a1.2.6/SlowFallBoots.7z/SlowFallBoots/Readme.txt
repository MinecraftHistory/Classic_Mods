Created by dougbenham @ minecraftforum.net

This mod adds Hermes Boots to the game, obtainable by a crafting recipe. Hermes Boots will let you float down to the ground when you've fallen from a dangerous height. Their durability is affected more greatly when you fall from greater heights.