Equivalent Exchange v0.6 ~ Ayutashi


::Install Notes::

eg.class - Bookshelf fix (bookshelves drop bookshelf blocks)
dd.class - Glass fix (glass drops glass blocks)

qh.class - NEW! Drops two single half-steps when a double step is broken!!
	   (Thanks to wolfkun for the unintentionally brilliant idea! :3)

ig.class - New! Ice Block variant.  This one lets Ice drop Ice Blocks in
	   addition to the usual "melting" function.  A bit messy,
	   considering you create MORE water every time you break it :\
	   Check out the variant below!



::OPTIONAL FILES::
(These are optional builds of the .class files above.  They are in separate
 folders, so you shouldn't need to worry about confusing them!)

waterless_ice/ig.class - WATERLESS variant of the Ice Block mod!  This one just drops Ice
	   blocks, without releasing any water whatsoever.  It's "cleaner"
	   than the first solution, but I consider it a more drastic change,
	   so I included it as a variant instead.

better_glass/dc.class - A small merge for Valance's BetterGlass mod.
           You'll need to install BetterGlass -FIRST-, then copy this
           dc.class file into the .jar afterwards.  This just allows
           the glass to drop while using his mod.


Just open your minecraft.jar with WinRAR, then drag and drop the mods you want!
These mods don't conflict with each other, so feel free to choose!
Make sure you don't try to use -BOTH- variants of a single mod...
that's just silly!  xD

Don't forget to delete the META-INF folder from minecraft.jar, and enjoy!  :3


::Version Notes::

0.6 - Updated for 1.2.3
0.5 - Updated for 1.2.2 NOV release!
0.4 - Updated New Smooth Half-steps fix + Two Ice Block variants!
0.3 - Added Smooth Half-steps temporary fix + ModLoader recipes
0.2 - Added Glass fix!
0.1 - Bookshelf fix update for Halloween