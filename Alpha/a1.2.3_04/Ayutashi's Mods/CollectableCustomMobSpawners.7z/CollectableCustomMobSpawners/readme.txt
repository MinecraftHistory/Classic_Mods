Custom Mob Spawner ~ Ayutashi
------------------------------

Updated for 1.2.3_04!


::Installation::

Open minecraft.jar with WinRAR and place
"bl.class", "br.class", "fp.class" & "bl_CMS.class"into minecraft.jar.

Make sure to delete the META-INF folder inside as well!

To customize your spawners, go to your .minecraft folder.
Place the "mods" folder found inside the .rar here.

You should end up seeing a path like this ::

.minecraft/mods/CustomMobSpawner/CustomMobSpawner.properties

--OPTIONAL--

There's a folder named "DungeonSpawner" as well.
If you look inside, you can drag "co.class" & "co_CMS.class"
inside your minecraft.jar to enable customizable dungeon
spawners, too!

There's an additional .properties file for this,
"CustomDungeonSpawner.properties", and it works independantly
of CustomMobSpawner.



::What it Does::

This mod allows you to break and pick up Mob Spawners!

By default, placing them back down results in not Pigs,
but rather Zombies, Skeletons and Spiders spawning from them.
(The way dungeons randomly choose normally)

If you look inside the .properties file, however, you'll see
a list of every mob in the game.

If you want to add a new type of mob to spawn from hand-placed
spawners, increase the number beside it to enable it.  The numbers
generate "weight", so the higher the number compared to others,
the more likely it will spawn.

The defaults (according to the original dungeon generator) are ::

Zombie=10
Skeleton=5
Spider=5

This causes Zombies to be trapped inside a spawner 10 out of 20 times.
Twice as often as Skeletons and Spiders.


--About Dungeon Spawners--

There's a second .properties file for "naturally occuring"
spawners you find in dungeons.  If you installed this function,
and edit the .properties file, you can change the types and
frequencies of mobs for these as well!

It works the same way as placable spawners, and the defaults
remain the same.


--About the "Random" Setting--

There is a setting in each .properties file (for both hand-placed &
dungeon spawners) named "Random", default value of 0.

If set to 1, this option will randomize the mob spawned from the
newly-placed spawner EACH TIME it spawns a mob!  This means the
same spawner can spawn a zombie, then a spider, then another zombie,
perhaps with some skeletons thrown in for good measure.

These should always pull from your current settings files, so
be careful.  If you make a Random Spawner, then it will change
what spawns from it every time you edit the .properties file.

This is due to the fact it never "saves" the list of mobs it
can spawn, just the fact that it's random.

However, if you set "Random=0", the Random Spawners should
-still- stay random until broken.  Any -new- spawners you set
at this point will be static, with a single mob inside.


::Notes & Tips::

Spawners will always keep the same mob trapped inside them until
they're broken apart.  This remains true even if you change the
.properties file and disable the mob later!

You can edit the .properties files at any time while playing
Minecraft, and it should update them when necessary.  You should
no longer need to restart the client completely!

Farm / Friendly mobs are listed in the .properties file, as well!
They're disabled by default, so 

Unfortunately, Slimes, while they can spawn during daylight, seem
to not want to spawn in many chunks.  I have yet to actually see
any spawn from one of my Custom Spawners.  However, I left it in
the entity list so you guys can try it if you'd like!

Giants are much the same way -- While they still exist within the
game, I'm unsure what causes them to not spawn.  Again, they are
merely listed for completeness sake.

If you want to make your own, special traps & dungeons easily, try
changing the .properties file to all 0s, and set a single mob as 1.
This way you'll always get the mob you want!  It's easy to keep the
.properties file open in Notepad and change them on the fly :3
