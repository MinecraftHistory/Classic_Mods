Use at your own risk, always backup your saves & jar, not responsible for anything, etc.
Thanks to 303 for the coding help.

1.  Download and install 303's Mod Loader @ http://www.minecraftforum.net/viewtopic.php?f=25&t=61032
2.  Backup your minecraft.jar.  To find your minecraft.bin open Windows Explorer and type the following 
into the address bar: %appdata%\.minecraft\bin
3.  Using 7zip, WinRAR, or the archiver of your choice, open minecraft.jar (no need to unpack/decrompress) 
and drag the mod_SpeedTest.class from the download zip into your minecraft.jar.
4.  Delete the META-INF folder in minecraft.jar.  You should have done this already when installing 303's 
Mod Loader.
5.  [OPTIONAL] Create a text file named SpeedTest.properties in %appdata%\.minecraft\mods\SpeedTest\  
Use this file to modify the hotkeys and display properties.  You can copy and paste these defaults into 
the file and change them as you please:

SpeedUp = W
SlowDown = S
Display = R
ShowSpeed = Yes
ShowGroundSpeed = Yes
ShowMomentum = Yes
ShowAxisSpeed = Yes
ShowPosition = Yes
ShowRotation = Yes

