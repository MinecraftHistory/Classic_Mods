This is installed as every other mod, delete the META-INF folder in minecraft.jar, and then add the files supplied. 
Requires ModLoader to work. The items.png goes into the gui folder, terraing.png goes right into minecraft.jar. 
the folders 16x16 and 32x32 is where the textures are. If you are using Marble, I have provided a terrain.png with both redblock and marble textures.
It's inside 16x16, in the folder "terrain with marble".
To use the overlays, open up your current textures in an image editor (not paint). Open up and select the entire desired overlay (remember to
select all of it, not just the part where the image is, CTRL+A works will select everything) , and paste it to your texture (in a new layer). 
The texture for the new items/blocks should now be in the right place. Then merge the layers together. Personally I use Paint.net, nice and easy.

WARNING:
A world that has blocks from this mod placed somewhere in it, is unusable without this mod. 
This is because then the world contains blocks that unmodded Minecraft doesn't know what to do with.
If you don't have this mod installed and try to open a world that contains placed redblock, Minecraft will crash. 
Redblock in chests are fine though, as long as you don't open the chests. Install at own risk. 
When Minecraft is updated, this mod will most likely stop to function properly, and then the world is unusable until this mod is updated. 
The blocks can be removed with software like MCEdit. Sometimes Minecraft corrupts save files. 
I strongly suggest to make backups of your worlds regularly.
