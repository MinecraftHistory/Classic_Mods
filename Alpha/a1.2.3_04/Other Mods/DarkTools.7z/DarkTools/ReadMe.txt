		_--===Akmin Mods===--_
		====================
		|		         |
		|  Modder In The Making  |
		|		         |
		=====================

			How To
		======================

1. Open "Run"  (For Vista Search It , XP It's In The Right Side Of Menu) (Unsure For Mac....Sorry)

2. Type in "%appdata%/.minecraft" and click OK

3. Open The Folder Called "bin"

4. Right-click the minecraft.jar and open it with WinRaR  ( It May Work With 7-Zip )  ----Unsure

5. Drag the mods ( em.class & dw.class ) into you'r minecraft.jar

=====(Easy Way Non-Custom Texture Packs Supported)=====

6a. Now WAIT! Before you close the .jar out you need to go into the gui folder

7a. Drag the items.png From the mod folder in there and your Ready!

8a. Run and Enjoy You'r New Items In Minecraft!

=======(Hard Way Custom Texture Packs Supported)=======

6b. Now open you'r custom texture packs .zip from the texturepacks folder

7b. Once opened you have to open the DarkItems.png from the mod folder

8b. Add a new layer to the items.png in the custom texture pack and paste the Dark Items.png there.

9b. Run and Enjoy You'r New Items In Minecraft!

==========\Recipes/===========
Key: D = Diamond, B = Blood Dust, BS = BloodStone, S = Stick, E = Empty Slot, F = Flint, U = Any UnEnchanted Item

Blood Dust

BS BS BS
BS BS BS
BS BS BS

BloodStone

B B E
E E E
E E E

UnEnchanted Pickaxe

F F F
E S E
E D E

UnEnchanted Axe

E F F
E S F
E D E

UnEnchanted Shovel

E F E
E S E
E D E

UnEnchanted Hoe

E F F
E S E
E D E

UnEnchanted Sword

E F E
S S S
E D E

Blood Level-Up

B B B
B U B
B B B

=============================


If you have ANY problems please tell me and i will try my best to help you!

==============================================================================