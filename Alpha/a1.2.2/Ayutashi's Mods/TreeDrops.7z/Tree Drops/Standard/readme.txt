TreeDrops (& variants) v0.3 ~ Ayutashi

Updated for 1.2.2 NOV release!

Simply compiled these all together into one download.


::Notes::

/ki.class - original version; leaves/sticks/saplings/apples/golden apples

/TreeDropsLite/ki.class - leaves/saplings/apples

/TreeDropsLeafless/ki.class - sticks/saplings/apples/golden apples

/TreeDropsMin/ki.class - leaves/saplings

/TreeDropsApple/ki.class - saplings/apples


Enjoy~!