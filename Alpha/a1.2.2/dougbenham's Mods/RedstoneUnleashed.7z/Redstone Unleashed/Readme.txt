Created by dougbenham @ minecraftforum.net

This mod makes it so you can have infinite redstone.