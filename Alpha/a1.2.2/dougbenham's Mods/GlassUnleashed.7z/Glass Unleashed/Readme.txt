Created by dougbenham @ minecraftforum.net

This mod allows redstone circuitry to work on glass surfaces. You can also place ladders, doors, tracks, torches, switches, and buttons.
This mod also includes the drop fix (drop glass when glass is destroyed).