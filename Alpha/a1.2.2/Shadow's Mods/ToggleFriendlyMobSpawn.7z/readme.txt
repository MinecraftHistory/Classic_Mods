With this mod, you can turn off or on animals (non hostile mobs) spawning, in singleplayer version of Minecraft.

options.txt is in .minecraft folder.

If you want enable animals spwaning, add next text to options.txt

allowAnimals:true 

or if you want disable animals spawning:

allowAnimals:false 



