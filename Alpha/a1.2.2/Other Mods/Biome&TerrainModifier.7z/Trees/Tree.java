package Trees;

public class Tree {
	public int[] trunkDiameters;
	public int[][] treeMinHeights;
	public int[][] treeHeightVariations;
	public int[][] canopyMinStart;
	public int[][] canopyStartVariations;
	public int[] growableLand;
	public int [][][][][] trunkBasePattern;
	public int [][][][][] trunkPattern;
	public int [][][][][] canopyPattern;
	public int [][][][][] canopyTopPattern;
}
