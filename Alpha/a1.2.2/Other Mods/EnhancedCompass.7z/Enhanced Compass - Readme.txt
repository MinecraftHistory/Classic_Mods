Enhanced Compass Mod v2.1
=========================
This mod allows you to configure the default compass to:
* Make the compass point toward your spawn point, North or both.
* Change the color of the needles
* Change the draw order of the needles (when using both)

In addition, the mod can be used with xau's HD texture fix which you
can find here: http://www.minecraftforum.net/viewtopic.php?f=25&t=46173

Compatibility
-------------
Minecraft v1.2.2

Installation
------------
A. If you plan to use the HD texture fix, apply the patch BEFORE installing this mod!
1. Make sure you have a backup of your minecraft.jar file!!!
2. Open your minecraft.jar file with a program like WinRAR or 7zip.
3. Delete the META-INF folder from the archive.
4. Drag the class file into the open archive.
5. Close the minecraft.jar file.
6. (Optional) Put the compass_config.txt file in the .minecraft directory.
7. (Optional) Edit the compass_config.txt file as you see fit.

Configuration
-------------
The compass_config.txt file is located in the .minecraft directory.
If the file is missing, it will be created the next time you start Minecraft.
The config file is in the format: option = value.
Lines that begin with # are ignored.

The current options are:
* compassType: Determines which way the compass will point.
	Valid values are:
		1 = Spawn compass
		2 = North compass
		3 = Both
	Default: compassType = 3

* drawOrder: Determines the order in which the needles will be drawn.
	Valid values are:
		1 = Spawn needle on top
		2 = North needle on top
	Default: drawOrder = 1

* spawnNeedleColor: Sets the color of the needle that points to spawn.
	Format: Red,Green,Blue
	Default: spawnNeedleColor = 230,20,20

* northNeedleColor: Sets the color of the needle that points North.
	Format: Red,Green,Blue
	Default: northNeedleColor = 230,230,230

Changelog
---------
v2.1:
	v1.2.2 compatiblity

v2.0:
	(Almost) complete re-write
	Added HD texture fix compatibility

v1.2:
	Added drawOrder option

v1.1:
	Fixed v1.2.1_01 compatibility

v1.0:
	Merged North-Pointing & Dual Compass Mods
	Added config. system
