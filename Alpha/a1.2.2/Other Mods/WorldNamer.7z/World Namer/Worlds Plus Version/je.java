import java.io.File;
import net.minecraft.client.Minecraft;

public class je extends kz
{
  public je(bp parambp)
  {
    super(parambp);
    this.h = "Delete world";
    this.setEmpty = false;
  }

  public void j()
  {
  }

  public void c(int paramInt) {
    String str = getWorldName(paramInt);
    if (str != null)
    {
      this.b.a(new kj(this, "Are you sure you want to delete this world?", "'" + str + "' will be lost forever!", paramInt));
    }
  }

  public void a(boolean paramBoolean, int paramInt) {
    if (paramBoolean) {
      File localFile = Minecraft.b();
      cw.b(localFile, d(paramInt));
    }
    this.b.a(this.a);
  }
}
