import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;
import java.io.StreamTokenizer;
import java.util.HashMap;
import java.util.List;
import net.minecraft.client.Minecraft;
import org.apache.commons.io.FileUtils;

public class kz extends bp
{
  private static int MAX_WORLD_NAME_LEN = 20;
  private static String WORLD_NAME_FILE = "name.txt";
  private static String WORLD_SIZE_CALC_FILE = "calculate_size.txt";
  private static HashMap<String, Long> WORLD_SIZE_CALC_CACHE = new HashMap<String, Long>();

  protected bp a;
  protected String h = "Select World";
  protected String strFile = "WorldsPlus.ini";
  private boolean i = false;

  protected boolean setEmpty = true;
  public boolean enableXYNames = true;
  public boolean showSize = true;
  public int btnCols = 3;
  public int btnRows = 5;
  public int btnWidth = 110;
  public int btnHeight = 16;
  public int btnWGap = 2;
  public int btnHGap = 2;
  public int nWorlds = this.btnCols * this.btnRows;

  public kz(bp parambp)
  {
    this.a = parambp;
    LoadConfig();
  }

  private void SaveConfig()
  {
    try
    {
      File configPath = new File(Minecraft.b().getPath() + "/config/");
      if (!configPath.exists())
        configPath.mkdir();
    }
    catch (Exception e)
    {
      System.out.println("Could not create /config directory!");
    }

    try
    {
      FileOutputStream Output = new FileOutputStream(Minecraft.b().getPath() + "/config/" + this.strFile);
      PrintStream file = new PrintStream(Output);

      file.println("WorldsRows " + this.btnRows);
      file.println("WorldsColumns " + this.btnCols);
      file.println("buttonWidth " + this.btnWidth);
      file.println("buttonHeight " + this.btnHeight);
      file.println("btnGapWidth " + this.btnWGap);
      file.println("btnGapHeight " + this.btnHGap);
      file.println("enableXYNames " + this.enableXYNames);
      file.println("showSize " + this.showSize);
    }
    catch (Exception e)
    {
      System.out.println("Could not load file!");
    }
  }

  public void LoadConfig()
  {
    try {
      File opFile = Minecraft.b();
      Reader rdr = new BufferedReader(new FileReader(opFile.getPath() + "/config/" + this.strFile));
      StreamTokenizer stok = new StreamTokenizer(rdr);
      stok.parseNumbers();

      for (stok.nextToken(); stok.ttype != -1; stok.nextToken())
      {
        if (stok.ttype == -2)
          continue;
        if (stok.sval.equals("WorldsRows")) {
          stok.nextToken();
          this.btnRows = (int)stok.nval;
          this.nWorlds = (this.btnRows * this.btnCols);
        }
        else if (stok.sval.equals("WorldsColumns")) {
          stok.nextToken();
          this.btnCols = (int)stok.nval;
          this.nWorlds = (this.btnRows * this.btnCols);
        }
        else if (stok.sval.equals("buttonWidth")) {
          stok.nextToken();
          this.btnWidth = (int)stok.nval;
        }
        else if (stok.sval.equals("buttonHeight")) {
          stok.nextToken();
          this.btnHeight = (int)stok.nval;
        }
        else if (stok.sval.equals("btnGapWidth")) {
          stok.nextToken();
          this.btnWGap = (int)stok.nval;
        }
        else if (stok.sval.equals("btnGapHeight")) {
          stok.nextToken();
          this.btnHGap = (int)stok.nval;
        }
        else if (stok.sval.equals("showSize")) {
          stok.nextToken();
          if (stok.ttype == -2) {
            if (stok.nval == 0.0D)
              this.showSize = false;
            else
              this.showSize = true;
          }
          else if (stok.sval.equals("true"))
            this.showSize = true;
          else {
            this.showSize = false;
          }
        }
        else if (stok.sval.equals("enableXYNames")) {
          stok.nextToken();
          if (stok.ttype == -2) {
            if (stok.nval == 0.0D)
              this.enableXYNames = false;
            else
              this.enableXYNames = true;
          }
          else if (stok.sval.equals("true"))
            this.enableXYNames = true;
          else {
            this.enableXYNames = false;
          }
        }

      }

    }
    catch (IOException localIOException)
    {
    }

    MAX_WORLD_NAME_LEN = (btnWidth / 7) - (showSize ? 8 : 0);

    SaveConfig();
  }

  protected int getYBtnOffset(int row) {
    int retVal = this.d / 4 - 60;
    return retVal + 20 * row;
  }
  protected int getXBtnOffset(int col, int col_max) {
    return getXBtnOffset(col, col_max, 202);
  }
  protected int getXBtnOffset(int col, int col_max, int btnWidth) {
    int btnWGap = 2;

    int retVal = this.c / 2 - (btnWidth / 2 + (btnWidth + btnWGap) / 2 * (col_max - 1));
    return retVal + (btnWidth + btnWGap) * col;
  }
  protected int getXTxtOffset(int col, int col_max) {
    return getXBtnOffset(col, col_max, 202) + 1;
  }
  protected int getYTxtOffset(int row) {
    return getYBtnOffset(row) + 6;
  }

  private String getFileName(int val) {
    return "World" + (val + 1);
  }
  private String getFileNameXY(int val) {
    return "World" + (val / this.btnRows + 1) + "_" + (val % this.btnRows + 1);
  }

  public void a() {
    File localFile = Minecraft.b();
    File saves_dir = new File(localFile, "saves");

    int x = this.c / 2 - (this.btnWidth / 2 + (this.btnWidth + this.btnWGap) / 2 * (this.btnCols - 1));

    int count = 0;
    for (int k = 0; k < this.btnCols; k++) {
      for (int j = 0; j < this.btnRows; count++, j++) {
        int y = this.d / 6 + (this.btnHeight + this.btnHGap) * j;

	File world_dir = null;

        in localin;
        if (this.enableXYNames) {
          localin = cw.a(localFile, getFileNameXY(count));
          if (localin == null) {
            localin = cw.a(localFile, getFileName(count));
            if (localin == null) {
              ge gEmpty = new ge(count, x, y, this.btnWidth, this.btnHeight, "- empty -");
              gEmpty.g = this.setEmpty;
              this.e.add(gEmpty);
              continue;
            } else {
              world_dir = new File(saves_dir, getFileName(count));
            }
          } else {
            world_dir = new File(saves_dir, getFileNameXY(count));
          }
        } else {
          localin = cw.a(localFile, getFileName(count));
          if (localin == null) {
            localin = cw.a(localFile, getFileNameXY(count));
            if (localin == null) {
              ge gEmpty = new ge(count, x, y, this.btnWidth, this.btnHeight, "- empty -");
              gEmpty.g = this.setEmpty;
              this.e.add(gEmpty);
              continue;
            } else {
              world_dir = new File(saves_dir, getFileNameXY(count));
            }
          } else {
            world_dir = new File(saves_dir, getFileName(count));
          }
        }

        String str = getWorldName(world_dir);

        if (str == null) {
          str = getFileName(count);
        }

        if (this.showSize) {
          long l = getWorldSizeOnDisk(world_dir);

          if (l <= 0) {
            l = localin.f("SizeOnDisk");
          }

          str = str + ": " + (float)(l / 1024L * 100L / 1024L) / 100.0F + "MB";
        }

        this.e.add(new ge(count, x, y, this.btnWidth, this.btnHeight, str));
      }

      x = x + this.btnWidth + this.btnWGap;
    }

    j();
    j2();
  }

  protected String d(int paramInt) {
    File localFile = Minecraft.b();
    if (this.enableXYNames) {
      return 
        getFileName(paramInt) != null ? getFileName(paramInt) : cw.a(localFile, getFileNameXY(paramInt)) != null ? 
        getFileNameXY(paramInt) : 
        null;
    }
    return 
      getFileNameXY(paramInt) != null ? getFileNameXY(paramInt) : cw.a(localFile, getFileName(paramInt)) != null ? 
      getFileName(paramInt) : 
      null;
  }

  protected String d_2(int paramInt)
  {
    File localFile = Minecraft.b();
    if (this.enableXYNames) {
      return 
        getFileName(paramInt) != null ? getFileName(paramInt) : cw.a(localFile, getFileNameXY(paramInt)) != null ? 
        getFileNameXY(paramInt) : 
        getFileNameXY(paramInt);
    }
    return 
      getFileNameXY(paramInt) != null ? getFileNameXY(paramInt) : cw.a(localFile, getFileName(paramInt)) != null ? 
      getFileName(paramInt) : 
      getFileName(paramInt);
  }

  public void j()
  {
    int y1 = this.d / 6 + (this.btnHeight + this.btnHGap) * this.btnRows + this.btnHeight;
    this.e.add(new ge(-2, this.c / 2 - 100, y1, "Delete world..."));
  }
  public void j2() {
    int y2 = this.d / 6 + (this.btnHeight + this.btnHGap) * this.btnRows + this.btnHeight + 20 + this.btnHGap;
    this.e.add(new ge(-1, this.c / 2 - 100, y2, "Cancel"));
  }

  protected void a(ge paramge) {
    if (!paramge.g) return;
    if (paramge.f >= 0)
      c(paramge.f);
    else if (paramge.f == -2)
      this.b.a(new je(this));
    else if (paramge.f == -1)
      this.b.a(this.a);
  }

  public void c(int paramInt)
  {
    this.b.a((bp)null);
    if (this.i) return;
    this.i = true;
    this.b.b = new jd(this.b);

    this.b.b(d_2(paramInt));
    this.b.a((bp)null);
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    i();

    a(this.g, this.h, this.c / 2, 20, 16777215);

    super.a(paramInt1, paramInt2, paramFloat);
  }

  protected String getWorldName(int worldNumber)
  {
    File localFile = Minecraft.b();
    String str = d(worldNumber);

    if (str != null) {
      File saves_dir = new File(localFile, "saves");
      File world_dir = new File(saves_dir, str);

      String name = getWorldName(world_dir);

      if (name != null) {
        str = name;
      }
    }

    return str;
  }

  private String getWorldName(File world_dir)
  {
    File name_file = new File(world_dir, WORLD_NAME_FILE);
    String name = null;

    if (name_file.exists()) {
      try {
        BufferedReader in = new BufferedReader(new FileReader(name_file));

        name = in.readLine();
        in.close();

        // if we got a name, truncate it if need be
        if (name != null && name.length() > MAX_WORLD_NAME_LEN) {
          name = name.substring(0, MAX_WORLD_NAME_LEN);
        }
      } catch (Exception e) {
        name = null;
      }
    }

    return name;
  }

  private long getWorldSizeOnDisk(File world_dir)
  {
    File calc_file = new File(world_dir, WORLD_SIZE_CALC_FILE);

    long bytes = 0;

    if (calc_file.exists()) {
      if (WORLD_SIZE_CALC_CACHE.containsKey(world_dir.getAbsolutePath())) {
        bytes = WORLD_SIZE_CALC_CACHE.get(world_dir.getAbsolutePath());
      } else {
        try {
          bytes = FileUtils.sizeOfDirectory(world_dir);
        } catch (Exception e) {
          bytes = 0;
        }

        WORLD_SIZE_CALC_CACHE.put(world_dir.getAbsolutePath(), bytes);
      }
    }

    return bytes;
  }
}
