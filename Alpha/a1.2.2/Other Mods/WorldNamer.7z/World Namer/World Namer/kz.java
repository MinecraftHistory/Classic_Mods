import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import net.minecraft.client.Minecraft;
import org.apache.commons.io.FileUtils;

public class kz extends bp
{
  private static int MAX_WORLD_NAME_LEN = 20;
  private static String WORLD_NAME_FILE = "name.txt";
  private static String WORLD_SIZE_CALC_FILE = "calculate_size.txt";
  private static HashMap<String, Long> WORLD_SIZE_CALC_CACHE = new HashMap<String, Long>();

  protected bp a;
  protected String h = "Select world";
  private boolean i = false;

  public kz(bp parambp)
  {
    this.a = parambp;
  }

  public void a() {
    File localFile = Minecraft.b();
    File saves_dir = new File(localFile, "saves");

    for (int j = 0; j < 5; j++) {
      in localin = cw.a(localFile, "World" + (j + 1));
      if (localin == null) {
        this.e.add(new ge(j, this.c / 2 - 100, this.d / 6 + 24 * j, "- empty -"));
      }
      else {
        File world_dir = new File(saves_dir, "World" + (j + 1));
        String str = getWorldName(world_dir);
        long l = getWorldSizeOnDisk(world_dir);

        // use default world name if something went wrong or
        // name wasn't provided
        if (str == null) {
          str = "World " + (j + 1);
        }

        // use "SizeOnDisk" anyway if something went wrong or
        // disk size wasn't calculated
	if(l <= 0) {
          l = localin.f("SizeOnDisk");
        }

        str = str + " (" + (float)(l / 1024L * 100L / 1024L) / 100.0F + " MB)";

        this.e.add(new ge(j, this.c / 2 - 100, this.d / 6 + 24 * j, str));
      }
    }

    j();
  }

  protected String d(int paramInt) {
    File localFile = Minecraft.b();
    return cw.a(localFile, "World" + paramInt) != null ? "World" + paramInt : null;
  }

  public void j() {
    this.e.add(new ge(5, this.c / 2 - 100, this.d / 6 + 120 + 12, "Delete world..."));
    this.e.add(new ge(6, this.c / 2 - 100, this.d / 6 + 168, "Cancel"));
  }

  protected void a(ge paramge) {
    if (!paramge.g) return;
    if (paramge.f < 5)
      c(paramge.f + 1);
    else if (paramge.f == 5)
      this.b.a(new je(this));
    else if (paramge.f == 6)
      this.b.a(this.a);
  }

  public void c(int paramInt)
  {
    this.b.a((bp)null);
    if (this.i) return;
    this.i = true;
    this.b.b = new jd(this.b);

    this.b.b("World" + paramInt);
    this.b.a((bp)null);
  }

  public void a(int paramInt1, int paramInt2, float paramFloat)
  {
    i();

    a(this.g, this.h, this.c / 2, 20, 16777215);

    super.a(paramInt1, paramInt2, paramFloat);
  }

  protected String getWorldName(int worldNumber)
  {
    File localFile = Minecraft.b();
    String str = d(worldNumber);

    if (str != null) {
      File saves_dir = new File(localFile, "saves");
      File world_dir = new File(saves_dir, "World" + worldNumber);

      String name = getWorldName(world_dir);

      if (name != null) {
        str = name;
      }
    }

    return str;
  }

  private String getWorldName(File world_dir)
  {
    File name_file = new File(world_dir, WORLD_NAME_FILE);
    String name = null;

    if (name_file.exists()) {
      try {
        BufferedReader in = new BufferedReader(new FileReader(name_file));

        name = in.readLine();
        in.close();

        // if we got a name, truncate it if need be
        if (name != null && name.length() > MAX_WORLD_NAME_LEN) {
          name = name.substring(0, MAX_WORLD_NAME_LEN);
        }
      } catch (Exception e) {
        name = null;
      }
    }

    return name;
  }

  private long getWorldSizeOnDisk(File world_dir)
  {
    File calc_file = new File(world_dir, WORLD_SIZE_CALC_FILE);

    long bytes = 0;

    if (calc_file.exists()) {
      if (WORLD_SIZE_CALC_CACHE.containsKey(world_dir.getAbsolutePath())) {
        bytes = WORLD_SIZE_CALC_CACHE.get(world_dir.getAbsolutePath());
      } else {
        try {
          bytes = FileUtils.sizeOfDirectory(world_dir);
        } catch (Exception e) {
          bytes = 0;
        }

        WORLD_SIZE_CALC_CACHE.put(world_dir.getAbsolutePath(), bytes);
      }
    }

    return bytes;
  }
}
