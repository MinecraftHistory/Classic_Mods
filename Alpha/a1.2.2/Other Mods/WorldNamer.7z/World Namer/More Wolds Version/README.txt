World Namer v0.4 (More Worlds Edition)

Works with: Minecraft v1.2.2_p1

1.) Installation: 
Standard, just copy the *.class files and the "org" directory into your minecraft.jar, and delete the META-INF folder

2.) How it works (the good stuff):
After applying the patch, go into your save folder (i.e. ~/.minecraft/saves/World1/) and create a file called "name.txt"
This mod will read the first line of that text file and use it as the name for that world.
Also, due to length constrictions, it will truncate any name longer than 20 characters.

Also, if you create a file named "calculate_size.txt" in your world folder, the system will calculate the proper size
of the world directory.

3.) Notes for "WorldsPlus" edition:
Because WorldsPlus implements the ability to resize the buttons, the world name will be truncated according to the
WorldsPlus settings provided.  Essentially, the formula is truncate to floor(btnWidth / 10).  An additional 8
characters are permitted if you have showSize = false.  For example, with the default 110 btnWidth and showSize = true,
world names will be truncated at floor(110/10) = 11 characters.  I've played around with these values and they seem to
work really well at accommidating button sizes.
