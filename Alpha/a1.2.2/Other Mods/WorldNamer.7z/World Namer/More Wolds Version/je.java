import java.io.File;
import java.util.List;
import net.minecraft.client.Minecraft;

public class je extends kz
{
  public je(bp parambp)
  {
    super(parambp);
    this.h = "Delete world";
  }

  public void j() {
    this.e.add(new ge(6, this.c / 2 - 100, this.d / 6 + 168, "Cancel"));
  }

  public void c(int paramInt) {
    String str = getWorldName(paramInt);
    if (str != null)
    {
      this.b.a(new kj(this, "Are you sure you want to delete this world?", "'" + str + "' will be lost forever!", paramInt));
    }
  }

  public void a(boolean paramBoolean, int paramInt) {
    if (paramBoolean) {
      File localFile = Minecraft.b();
      cw.b(localFile, d(paramInt));
    }
    this.b.a(this.a);
  }
}
