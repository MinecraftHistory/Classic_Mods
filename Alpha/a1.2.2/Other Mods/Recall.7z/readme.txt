-------------------
Zenith's Recall Mod|
-------------------

Note: In order to keep your minecraft.jar root folder clean, you can delete the recall folder 
in it if it's there. The textures there have been reassigned to come from your /mods/ folder 
in the .jar

Usage: Right click with a bindston to save your location. Right click with a recall scroll 
of the same color to teleport to the location bound with that stone (even across dimensions). 
(i.e. red scroll teleports to red bind location, etc.)


Forum thread: http://www.minecraftforum.net/viewtopic.php?f=25&t=81297

Requires 303's updated ModLoader. You can find it here:
http://www.minecraftforum.net/viewtopic.php?f=25&t=61032


Recipes:

W = bucket of water
b = empty bowl
C = Cobblestone
S = scroll
/ = stick
r = redstone dust
y = yellow dust
u = cactus
c = coal

P = paper
B = bowl of water
I = Ink

----------
Making Ink|
----------

 W 
bbb 	=> 6 bowls of water
bbb

r    y     u    c
B or B	or B or B => Red, yellow, blue, or black ink, respectively

	    R    Y
RY or YR or Y or R => 2 orange ink

	    R    B
RB or BR or B or R => 2 purple ink

	    B    Y
BY or YB or Y or B => 2 green ink
	    

-----------------
Making Bindstones|
-----------------



CCC
CIC => Bindstone of appropriate color
CCC

--------------
Making Scrolls|
--------------

/
P => blank scroll
/

I
S => Recall scroll of appropriate color

