Mo' Creatures Mod for Minecraft

by DrZhark 
http://www.minecraftforum.net/viewtopic.php?f=25&t=86929


This mod Add more creatures to the vanilla Minecraft
Currently this only works with a non-modified minecraft client, it breaks other mods that access the same classes

The mod changes the following existing classes: bn, fo, gd, mi
And Creates 12 more classes

To install: 

0. Make a backup of your minecraft.jar file

1. Open your minecraft.jar file using winrar or similar
2. Add contents of the folder "\files to add to minecraft.jar\" to the root of the minecraft.jar file (where all the .class files are)
3. Add the png files located in the folder "\files to add to minecraft.jar\mob", to the folder \mob inside the minecraft.jar (you will see other png files there)
4. Delete the META-INF folder of minecraft.jar
5. Close and save your minecraft.jar

6. locate the .minecraft\resources\newsound folder (where you have installed minecraft)
7. look inside the "\folder to add to newsound\", copy the \mod folder with all its contents and add it to the folder .minecraft\resources\newsound (make sure you are not adding this to the minecraft.jar file). Your minecraft \resources\newsound should have then a new folder called '\mod'
8. Play (don't get too close to the lions)

if the game crashes after you approach a creature, it is because you are not doing step 7. properly