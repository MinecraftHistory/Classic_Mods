Zenith's Sammiches Mod
----------------------

Sprites by jumpAlice

Requires 303's updated ModLoader. You can find it here:
http://www.minecraftforum.net/viewtopic.php?f=25&t=61032

Recipes:
B = Bread
M = cooked pork
S = Sandwich
P = Pile (stackable sandwiches)

B
M  -> one sandwich
B

S -> Pile

SS  or 	S
      	S   -> 2 Pile

	S
SSS or	S  -> 3 Pile
	S

SS
SS -> 4 Pile

SSS	SS
SSS or	SS -> 6 pile
	SS

SSS
SSS -> 9 Pile
SSS

P -> Sandwich

For speed, you can also do this:

BB
MM -> 2 Piles
BB

BBB
MMM  -> 3 Piles
BBB

You cannot eat a sandwiches pile. You'll have to convert it back.