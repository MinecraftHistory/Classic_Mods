Corosus's Pet Mod 1.4 + Nightmare mode for Single Player including thevdudes more zombies mod

unchanged readme from 1.1...

Pet Mod Features
----------------

- PETS!!! Hostiles or animals, ghasts not so much just yet.
- THEY DONT DESPAWN!!!! Keep your pets FOREVER, or until something kills them. Coming soon, resurrect!
- Healthbars above them to know what's your pet as well. (ea.class adds this, optional to copy over)
- Tame pets with the Domination Rod, recipe is http://i.imgur.com/AksFC.png , left click takes control, right click gives commands.
- Cycle through issue-able AI commands with the 'E' key (configurable), so far options are: Follow, Wander, Hold Position
- Heal your pets by using left click on them when holding the healing item
- Pets get 30 health by default when you tame them (configurable)



Nightmare Mod Features
----------------------

- All hostiles range incrased from 16 to 80, watch out for creeper armies
- Hostiles, except creepers, will attack animals in the world
- Hostiles ignore line of sight and come right for you, unless it sees an animal
- Mob Spawner Activation range increased to 80 from 16 blocks, as well as spawn area size doubled, be carefull!



Instructions
------------

BACK UP YOUR SAVES!!!!!!
I'm 99% sure this will never corrupt your save, it does add new data to the saves and your save SHOULD still work after removing the pet mod, but lets play it safe people.
BACK UP YOUR SAVES!!!!!!

Requires the Modified Modloader: http://www.minecraftforum.net/viewtopic.php?f=25&t=61032

Installation:

1. open %AppData%\Roaming\.minecraft\bin\minecraft.jar with winrar or 7zip
2. Drag all the files from the modloader package into the open winrar with minecraft.jar
3. Then drag all the files that are inside the 'Pet Mod' folder to winrar as well.
4. Delete the META-INF folder from minecraft.jar within winrar

The mod defaults to just pets mode, no nightmare mode. To set that up, keep reading.

Optional Custom Configuration Installation (Over 20 configurable options!):

5. In %AppData%\Roaming\.minecraft\ , add a "mods" folder, and inside that folder, add an "AIManager" folder
6. If you  want nightmare mode on with pets, copy the 'AIManager.properties' from 'Pets+Nightmare Mode' in the 'Settings' folder, and copy it into the AIManager folder you just recently created, or use the 'Just Pets' one to only have pets on.

7. Have fun!


I Highly recommended you install 303s grappling hook/gravity gun from the modloader link above to move your pets around better. helps a lot when setting pets in position.

Also I recommend installing Seronis' better food mod for stackable food to heal your pets easier: 
http://www.minecraftforum.net/viewtopic.php?f=25&t=54593