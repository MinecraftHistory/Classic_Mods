Mobs Killer Block v1.3 for Minectaft 1.2.3

If you want your block kill only enemy mobs, choose "Mobs" folder.
If you want your block kill only friendly animals, choose "Animals" folder.
If both are true, choose "Mobs + Animals" folder.