TreeDrops ~ Ayutashi
-------------------------

Updated to 1.2.4!

Thanks to desbones for his Decaying Leaves mod!
I've replicated part of his code here, as a merge.


::Installation::

Open minecraft.jar with WinRAR, and place
"kl.class" & "kl_TreeDrops.class" into minecraft.jar

If you want desbone's Decaying Leaves to work, you
might add "fd.class" as well! (Not sure what it does,
to be honest, but I pulled it straight from his pack!)

If you want to customize your settings, also
place the "mods" folder inside your .minecraft folder!

(The end result should be: 
  .minecraft/mods/TreeDrops/TreeDrops.properties)



::What it Does::

Changes what various items Leaf blocks drop upon breaking.

Nothing ~50%
Leaf block ~30%
Sapling ~10%
Stick ~10%
Apple ~2%
GoldenApple ~0.1%

If you're unhappy about these numbers.. change them!
TreeDrops now comes with an optional properties file.

Open the properties file and change the values based
on the "weight" you want them to bear.  The higher
the number, the more often it'll drop!

The numbers -must- be integers!  That is to say...

3
72
100000

Are fine,
but decimals...

0.3
7.2
100.00

Are -NOT-!

The numbers don't need to add up to anything specific,
but they're totaled for the random number generator.
(Nothing=500 is 500 chances out of 1021 on default,
  after you add the other items in)


::Decay Merge Info::

There's also a new Properties file line named "Decay".
If you leave it at 0, it will turn desbone's Decaying Leaves off.
If you change it to any number greater than 0 (1 should suffice)
 it will turn Decaying Leaves on!


::Important Notes::

You can now change the .properties file while
"paused" on Minecraft, and it will update
the settings in-game as long as you save the
.properties file.  (You no longer have to
restart the client completely!)

Please don't try to alter the -types of items-
that drop, or change the names at all. If they
don't show up in the .properties file exactly
as written above, the items won't appear (and
may even Black Screen your game until it's
changed back).

If you have any trouble, try deleting the
properties file and grab a fresh copy from
this .rar.
