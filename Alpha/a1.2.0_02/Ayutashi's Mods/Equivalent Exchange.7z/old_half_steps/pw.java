/*    */ import java.util.Random;
/*    */ 
/*    */ public class pw extends ne
/*    */ {
/*    */   private boolean a;
/*    */ 
/*    */   public pw(int paramInt, boolean paramBoolean)
/*    */   {
/* 14 */     super(paramInt, 6, gt.d);
/* 15 */     this.a = paramBoolean;
/*    */ 
/* 17 */     if (!paramBoolean)
/*    */     {
/* 19 */       a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
/*    */     }
/* 21 */     d(255);
/*    */   }
/*    */ 
/*    */   public int a(int paramInt)
/*    */   {
/* 26 */     if (paramInt <= 1) return 6;
/* 27 */     return 5;
/*    */   }
/*    */ 
/*    */   public boolean a()
/*    */   {
/* 32 */     return this.a;
/*    */   }
/*    */ 
/*    */   public void a(cu paramcu, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*    */   {
/* 37 */     if (this != ne.al) return;
/*    */   }
/*    */ 
/*    */   public void e(cu paramcu, int paramInt1, int paramInt2, int paramInt3)
/*    */   {
/* 59 */     if (this != ne.al) super.e(paramcu, paramInt1, paramInt2, paramInt3);
/* 60 */     int i = paramcu.a(paramInt1, paramInt2 - 1, paramInt3);
/*    */ 
/* 62 */     if (i == al.bi)
/*    */     {
/* 64 */       paramcu.d(paramInt1, paramInt2, paramInt3, 0);
/* 65 */       paramcu.d(paramInt1, paramInt2 - 1, paramInt3, ne.ak.bi);
/*    */     }
/*    */   }
/*    */ 
/*    */   public int a(int paramInt, Random paramRandom)
/*    */   {
	     if (this.a) {
		return ne.ak.bi;
	     }
             return ne.al.bi;
/*    */   }
/*    */ 
/*    */   public boolean b()
/*    */   {
/* 76 */     return this.a;
/*    */   }
/*    */ 
/*    */   public boolean b(ox paramox, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*    */   {
/* 81 */     if (this != ne.al) super.b(paramox, paramInt1, paramInt2, paramInt3, paramInt4);
/* 82 */     if (paramInt4 == 1) return true;
/* 83 */     if (!super.b(paramox, paramInt1, paramInt2, paramInt3, paramInt4)) return false;
/* 84 */     if (paramInt4 == 0) return true;
/* 85 */     return paramox.a(paramInt1, paramInt2, paramInt3) != this.bi;
/*    */   }
/*    */ }

/* Location:           C:\minecraft_dev\temp\minecraft\
 * Qualified Name:     pw
 * JD-Core Version:    0.6.0
 */