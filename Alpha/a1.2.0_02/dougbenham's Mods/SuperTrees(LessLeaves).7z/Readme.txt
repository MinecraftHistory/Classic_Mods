Created by dougbenham @ minecraftforum.net

ed.class -- Instant generation of trees
pn.class -- Super tall trees

This mod makes it so you can put a sapling down and walk away a bit, then come back in less than a minute and there will be a tree. No need to wait several nights.

Note: Obviously don't include the pn.class if you don't want your trees to be super tall.