World Namer + More Worlds v0.2

Works with: Minecraft v1.2.0_02

Installation: 
Standard, just copy ks.class and the "org" directory into your minecraft.jar, and delete the META-INF folder

How it works (the good stuff):
After applying the patch, go into your save folder (i.e. ~/.minecraft/saves/World1/) and create a file called "name.txt"
This mod will read the first line of that text file and use it as the name for that world.
Also, due to length constrictions, it will truncate any name longer than 20 characters.

Also, if you create a file named "calculate_size.txt" in your world folder, the system will calculate the proper size
of the world directory.

NOTE: be wary of other mods that use ks.class as well (for instance More Worlds), as this will not work with them!
