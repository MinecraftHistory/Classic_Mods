MRMESSIAH'S MINECRAFT MODS
==========================
Ambient Occlusion v1.0 - NEW!!!
BetterGrass v0.4 plugin for Minecraft (disabled temporarily)
SimpleMap v0.91 plugin for Minecraft
SMChat v0.1 plugin for Minecraft
===================================

by MrMessiah (mrmessiah@gmail.com)

Adds a simple minimap to Minecraft, which gives you an overhead view 
of the immediately surrounding area (a 64x64 block area centered on the 
player, or 2 chunks in each direction if you want to think of it that way.)

INSTALLATION
------------

Extract the contents of this file to your minecraft folder. Under windows,
this is %appdata%\.minecraft    On a Mac, this is somewhere
under Application Support I think.

PLEASE NOTE: This goes in the .minecraft folder NOT the .minecraft/bin folder

You should see that this creates a new folder under .minecraft called "mods"
and in there all the config files and artwork for my mods will live - currently
only SimpleMap has a config file called "SimpleMap.properties", and a bunch 
of artwork.

RUNNING THE PATCHER
-------------------

First things first: Though this patcher makes its own backups, I strongly 
advise you to make your own backup of minecraft.jar first. That way, if anything
goes wrong, you can go back easily to where you were.

The patcher is "MrMPatcher.jar" which is a runnable java archive. You should
be able to run it just by double clicking on it, but if you have .jar archives
set up to open with a different application or you're just on one of those
operating systems that work differently you can also run it from the command
line by typing "java -jar MrMPatcher.jar"

The patcher is based off xau's texture patcher and works similarly, but you 
have to be careful what you do with it. When it runs, it tries to find your
copy of minecraft.jar, it then creates a backup of this called 
minecraft.mrmbackup.jar. This should install it alongside any mods you are 
currently running. If you want to apply this to a different .jar file for 
any reason, you can choose it in the top box.

You also need to tell the patcher what to save the modded jar file as, in the
bottom box. For this, I would again select minecraft.jar. This replaces the
original minecraft.jar with the patched version.

UNINSTALLING
------------

To uninstall, restore your backed up minecraft.jar.

Ambient Occlusion v1.0
----------------------
Modifies the lighting system to add a subtle Ambient Occlusion effect that simulates
real world light. 

BetterGrass v0.4
----------------

I've had to disable this temporarily - stuff's changed in the last update that's
going to take some looking at. 

SimpleMap v0.9
--------------

- The overlay, or "frame" of the map can be customised to fit in with whatever
UI theme you've got going on. Just edit "overlay.png" under .minecraft/mods/SimpleMap
- The colours of the map can be customised to fit in with whatever texture pack you've
got going on. The colours for each game block are in "mmcolors.png" and installation
is the same as with the overlay. Each pixel, starting from the top left, going to the 
bottom right represents one block type - the id's of all the block types in Minecraft
can be found all over the net but particularly on the Minecraft wiki.
- Easy configuration file (.minecraft/mods/SimpleMap/SimpleMap.properties)  Here you
can tweak settings for the map - currently there are two.
	showCoords - setting this to true gives you a coordinate display while you're moving
		around showing you where you are. This is meant to make creative stuff easier but
		I can see how not everyone wants it so that's why it's disabled by default
	up - You can customise which way up on the map points. Default is east, but north,
		west and south also work. I still say up is east, but I don't judge you ;p
- If you install the optional SMChat, you can command SimpleMap via chat commands
	- /ui map on - shows the map
	- /ui map off - hides it
	- /ui map east|north|south|west - makes "up" on the map one of the four cardinal directions.
		
SMChat v0.1
-----------

This is the chat stuff that were missing from v0.8. It's currently a bit simpler than
that was - I'm working on it. REQUIRES SIMPLEMAP TO WORK.

- Hit tab to reply to the last person that messaged you. No more typing out /msg foo blah
every few seconds
- Lets you control SimpleMap via text commands