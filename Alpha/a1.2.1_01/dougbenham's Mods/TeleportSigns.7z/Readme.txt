Created by dougbenham @ minecraftforum.net

mw.class -- [x, y, z] teleport and [LOC] functionality
pi.class -- Enables signs to have infinite lettering.
pp.class -- Necessary also for infinite lettering.

This mod makes it so you have the ability to [b]right-click[/b] on a sign and it will instantly teleport you to a location you specify. There is also another function that will make it so signs will tell you what their position is.

Firstly, the [x, y, z] coordinates must be on the 4th line of your sign and they must have brackets surrounding the coordinates and there must be commas separating each. The values can have decimals, so long as they stay on 1 line. After creating the sign, simply right-click on the sign and you are teleported to your destination.

Secondly, the [LOC] functionality can be put on any line of the sign. After creating the sign, simply right-click on the sign and it will replace [LOC] (must be upper-case with brackets surrounding it), with the current location of that sign. Note that if you are placing the sign on the ground (not wall-mounted), you need to account for the fact that the coordinates that it gives you are precisely at that ground-level. So if you are creating a teleport sign, you should increase the y coordinate by about 1.8 (this is about how tall you are). If any of this doesn't make sense or if you want to see a video demonstration, just ask and I'll get around to it.