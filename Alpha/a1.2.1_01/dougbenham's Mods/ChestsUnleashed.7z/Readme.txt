Created by dougbenham @ minecraftforum.net

This mod makes it so you can open chests even when they have blocks above them.