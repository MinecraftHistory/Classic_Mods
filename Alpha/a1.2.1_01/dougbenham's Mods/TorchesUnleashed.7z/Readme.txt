Created by dougbenham @ minecraftforum.net

This mod makes it so you can put torches underwater and on glass, ladders, tracks, other torches, and fences.