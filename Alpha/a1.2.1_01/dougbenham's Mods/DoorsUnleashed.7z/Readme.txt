Created by dougbenham @ minecraftforum.net

This mod makes it so you can put doors on glass.