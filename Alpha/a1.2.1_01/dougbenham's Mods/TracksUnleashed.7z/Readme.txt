Created by dougbenham @ minecraftforum.net

This mod makes it so you can put tracks on glass and fences.