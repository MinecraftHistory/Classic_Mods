HOW TO INSTALL:
Open [appdatafolder]/.minecraft/bin/minecraft.jar in WinRar and add the included files to
the file (just drag them in!). Then, delete the folder META-INF, and just run minecraft!

HOW TO USE:
Well, you'll know if it's working when you're in, but here are the controls:

O - Minus one stack
P - Plus one stack
K - Change stack block (type)
L - Apply the stack

HIT THE BLOCK IN THE DIRECTION YOU WANT THE STACK TO GO BEFORE PRESSING L!


This is my first mod, so enjoy!