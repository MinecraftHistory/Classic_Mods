This is installed as every other mod, delete the META-INF folder in minecraft.jar, and then add the files supplied. 
Requires ModLoader to work. The items.png goes into the gui folder. 
If you want the recipe for gunpowder as well, add the file located in the folder
"with gunpwder recipe".
the folders 16x16 and 32x32 is where the textures are.
