-------------------
Zenith's Recall Mod|
-------------------

Usage: Right click with a bindston to save your location. Right click with a recall scroll 
of the same color to teleport to the location bound with that stone (even across dimensions). 
(i.e. red scroll teleports to red bind location, etc.)


Forum thread: http://www.minecraftforum.net/viewtopic.php?f=25&t=81297

Requires 303's updated ModLoader. You can find it here:
http://www.minecraftforum.net/viewtopic.php?f=25&t=61032


Recipes:

W = bucket of water
b = empty bowl
C = Cobblestone
S = scroll
/ = stick
r = redstone dust
y = yellow dust

P = paper
B = bowl of water
R = red ink
Y = yellow ink
O = orange ink


----------
Making Ink|
----------

 W 
bbb 	=> 6 bowls of water
bbb

r    y    
B or B	=> Red ink or yellow ink, respectively

	    R    Y
RY or YR or Y or R => 2 orange ink
	    

-----------------
Making Bindstones|
-----------------

CCC    CCC    CCC
CRC or CYC or COC => Bindstone of appropriate color
CCC    CCC    CCC

--------------
Making Scrolls|
--------------

/
P	=> blank scroll
/

R    Y    O
S or S or S	=> Recall Scroll of appropriate color

