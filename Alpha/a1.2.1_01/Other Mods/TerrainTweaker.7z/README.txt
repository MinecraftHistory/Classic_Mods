Terrain Tweaker SP Mod v1.3
	by: ckarper@shadoware.com

Description:
--------------------------------------------------------------------------------
Want to tweak the settings in the terrain generator, but don't know where 
to start?  Ever wanted to play on a mostly flooded world?  How about having 
the new Nexus blocks mineable as ore in the real world?  Muddy swamps?

All these things are possible for you now, with some text settings in 
a mapgen.properties file. (Created in your .minecraft data folder, the same place
where your options.txt is)

Settings (Shown with defaults):
--------------------------------------------------------------------------------
waterLevel=64
----------------------------------------
This is the first level that will be clear of oceanic water and ice.  74 makes 
a pretty watery world, 100 makes Wind Waker style worlds.   Anything below 
about 50 makes a water free world.

biomeSize=1.5
----------------------------------------
This is a number used in the biome generation to determine the size of the biome
areas.  Larger numbers make larger biomes. 

insertHellBlocks=false
----------------------------------------
This will add blocks from the Nexus into the regular world with the same
frequency table as gold.

safetiesOff=false
----------------------------------------
This replaces the adminium on the bottom of the map with mineable obsidian,
so you can open up holes to the void, if you wish.

dryDeserts=false
----------------------------------------
This will fill in all water blocks with sand in desert biomes.  No more deserts 
under the ocean.  Makes a seriously bleak area.

muddySwamps=false
----------------------------------------
There's a mud block, there's a swamp biome.  The two go together like PB & 
Chocolate.   Except it sucks when you're stuck in it, bad.

biomeTrees=false
----------------------------------------
Get custom tree types based on biome.  Pine trees sprinkled about, and in 
boreal forests.  Shrubs in the shrubland.  Tumbleweeds in the desert.

flatBedrock
----------------------------------------
Moves all Adminium to the bottom level of the map.  This "smooths" the level 
floor.  (From OreVeins/Cadde's Mod)

guaranteeBedrock
----------------------------------------
Fills holes in the bedrock, so you never have to worry about falling through.
(From OreVeins/Cadde's Mod)

alternateOreDistribution
----------------------------------------
Uses Cadde's OreVeins Mod ore distribution model.  This gives you fewer pockets 
of ore in the world,but they are distributed more "realistically".  Larger 
pockets as you go deeper, etc.   
(From OreVeins/Cadde's Mod)

undergroundLakes
----------------------------------------
Adds pockets of water in the stone.
(From OreVeins/Cadde's Mod)
 
--------------------------------------------------------------------------------
You can also set these options for each world separately by using the format:
"world#"."setting"

Example:  To get high water in your world 3, set
world3.waterLevel=110

My recommended settings for normal play are:
	world5.biomeSize=5.0
	world5.safetiesOff=true
	world5.dryDeserts=true
	world5.muddySwamps=true
	world5.biomeTrees=true

--------------------------------------------------------------------------------
Pics: http://imgur.com/a/eZ9bj/terraintweaker
--------------------------------------------------------------------------------

Donations Appreciated!
https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=4PAZQH4YNMACW


Installation Instructions:
--------------------------------------------------------------------------------

	* Download terraintweakersp.jar from
		http://www.shadoware.com/minecraft/terraintweakersp.jar
    * Locate your minecraft.jar file. On Windows 7, it's at : 
    		C:\Users\You\AppData\Roaming\.minecraft\bin\minecraft.jar
    * Open it in a zip utility such as WinRar.
    * Copy all of the files from the terraintweakersp.jar file 
    		(Open it in WinRar or equivalent) to the minecraft.jar file
    * DO NOT SKIP: Open the META-INF folder in the minecraft.jar file and 
    		delete MOJANG_C.DSA and MOJANG_C.SF

Change Log:
--------------------------------------------------------------------------------
v1.0: [11/04/2010] Initial Release
v1.1: [11/06/2010] SP version created, added dry desert and muddy swamps
v1.2: [11/07/2010] Added biome based trees
v1.3: [11/09/2010] Added OreVeins mod support (flatBedrock, guaranteeBedrock,
				   alternateOreDistribution, undergroundLakes)

Credits:
--------------------------------------------------------------------------------
CokeFL: Partner in decoding crime.  A *huge* help in tracking down what is what.
Chuck: Map Deleter/Pine Tree algorithm.  Thanks a ton for supplying the source!
dougbenham: Used tree growing notes to get me started with tree generation.  
Bucyruss: Used your SP biome notes as a springboard for my own research, 
		thanks for digging in there so quickly and effectively.
Cadde: Absorbed your OreVeins mod source. Thanks for releasing it for use!
