Equivalent Exchange v0.4 ~ Ayutashi


::Install Notes::

eb.class - Bookshelf fix (bookshelves drop bookshelf blocks)
da.class - Glass fix (glass drops glass blocks)

pw.class - NEW! Drops two single half-steps when a double step is broken!!
	   (Thanks to wolfkun for the unintentionally brilliant idea! :3)

hz.class - New! Ice Block variant.  This one lets Ice drop Ice Blocks in
	   addition to the usual "melting" function.  A bit messy,
	   considering you create MORE water every time you break it :\
	   Check out the variant below!



::OPTIONAL FILES::
(These are optional builds of the .class files above.  They are in separate
 folders, so you shouldn't need to worry about confusing them!)

pw.class - OLD HALF-STEP FIX!
	This drops a single half-step block when a single step is broken,
	or it drops a -double- half-step block when two steps are broken.

mod_EXchangeRecipes.class - Recipes to complement the OLD pw.class just above.
	Adds a recipe to change Double Half-steps into two Single Half-steps,
	as well as a reverse recipe ("X", "X"; single step above single step)
	to create a single Double Half-step.
	NOTE::REQUIRES RISUGAMI'S MOD LOADER!!

hz.class - WATERLESS variant of the Ice Block mod!  This one just drops Ice
	   blocks, without releasing any water whatsoever.  It's "cleaner"
	   than the first solution, but I consider it a more drastic change,
	   so I included it as a variant instead.


Just open your minecraft.jar with WinRAR, then drag and drop the mods you want!
These mods don't conflict with each other, so feel free to choose!
Make sure you don't try to use -BOTH- variants of a single mod...
that's just silly!  xD

Don't forget to delete the META-INF folder from minecraft.jar, and enjoy!  :3


::Version Notes::

0.4 - Updated New Smooth Half-steps fix + Two Ice Block variants!
0.3 - Added Smooth Half-steps temporary fix + ModLoader recipes
0.2 - Added Glass fix!
0.1 - Bookshelf fix update for Halloween