/*    */ import java.util.Random;
/*    */ 
/*    */ public class hz extends fq
/*    */ {
/*    */   public hz(int paramInt1, int paramInt2)
/*    */   {
/* 10 */     super(paramInt1, paramInt2, gt.r, false);
/* 11 */     this.bu = 0.98F;
/* 12 */     b(true);
/*    */   }
/*    */ 
/*    */   public int c() {
/* 16 */     return 1;
/*    */   }
/*    */ 
/*    */ 

/*    */   public int a(Random paramRandom)
/*    */   {
/* 31 */     return 1;
/*    */   }

	   public int a(int paramInt, Random paramRandom)
	   {
	     return ne.aU.bi;
	   }

/*    */ 
/*    */ }

/* Location:           C:\minecraft_dev\temp\minecraft\
 * Qualified Name:     hz
 * JD-Core Version:    0.6.0
 */