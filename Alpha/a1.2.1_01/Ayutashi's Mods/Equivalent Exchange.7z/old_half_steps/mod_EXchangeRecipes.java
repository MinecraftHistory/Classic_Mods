import java.util.Map;

public class mod_EXchangeRecipes extends BaseMod
{

  public void AddRecipes(eh recipes) {

    recipes.a(new fi(ne.al, 2), new Object[] { "X", Character.valueOf('X'), ne.ak });
    recipes.a(new fi(ne.ak, 1), new Object[] { "X", "X", Character.valueOf('X'), ne.al });

  }
}