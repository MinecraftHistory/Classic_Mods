Mod : Pokeball
Version : 1.0
Author : Apox159
Additional Mods required: 
	-Modloader	: http://www.minecraftforum.net/viewtopic.php?t=80246
Used BlockID	: none
Used ItemID		: 1159
Original Minecraft classes modified : none


This mod add 1 new Item to the game.
	Pokeball
		-Recipe	:	https://photos-1.dropbox.com/pi/xl/2sajhbrIvWHWaroz9CRoviX_jf93JEvBvBRdX-njWqs/6811482/1299502800/a6943df
		-Comment:	This is a pokeball, you can catch, store and fight(Hostile+ground only) with any mobs in the game !(works with Humans+ and maybe other mods !)
					The recipe looks a bit expensive but you will never lose a pokeball (Except if you throw it in lava... -_-)

This is the first release, so there may be some bugs.

If you want you can leave comments and suggestions :
http://www.minecraftforum.net/viewtopic.php?f=25&t=196429

INSTALLATION :

Put all .class files + pokeball.png in the Minecraft.jar (Don't forget to install Modloader)