StainedGlass v.1.1

How to Install
--------
ALWAYS back up your worlds! ALWAYS!

0. Before you do anything else, download and extract ModLoader somewhere you can find it. Modloader can be found here: http://www.minecraftforum.net/viewtopic.php?f=25&t=80246
1. Open minecraft.jar with WinRAR or other archive program.
2. Delete the META-INF folder from inside minecraft.jar.
3. Add all the class files from ModLoader into your minecraft.jar.
4. Add the entire folder (including the folder itself) labeled "StainedGlass" into your minecraft.jar. This is the folder that contains the new glass textures.
5. Close minecraft.jar.
6. Run Minecraft normally and enjoy!

A black screen means you did not install modloader, did not add all the class files, or you did not delete the META-INF folder from your minecraft.jar.


ABOUT THE MOD
--------
Stained Glass is simple! Just combine any of the existing dyes with glass to produce brightly-colored stained glass, which acts like normal glass except for its color.
To change the appearance of the stained glass, just edit the texture files in the /stainedglass/ folder. The files are named glass1.png, glass2.png, etc.


CREDITS
--------
Vib and ChocolateySyrup, for creating the mod.
Special thanks to Risugami and 303 for their awesome modloader, the entire team at MCP for creating an accessible tool, and all the countless people who helped us work out the bugs along the way.

VERSION HISTORY
-------
1.0
Relase
1.1
Version Update