Baby Animals v1.4.1

Other required mods (thanks to Risugami and 303): 
- AudioMod
- ModLoader v5 (reported to work with v4 as well)
- Spawnlist

Instructions:
1.Back up your minecraft.jar! It wouldn't hurt to back up your save too, if you're paranoid ;)
2.Add ModLoader following it's instructions.
3.Add spawnlist.class to minecraft.jar.
4.Add AudioMod following it's instructions.
5.Drop the mod folder into the .minecraft/resources folder
6.Drop the .png files from mob into the mob folder in minecraft.jar (you could also put them in the mob folder of your favorite 16p texture pack)
7.Drop the class files into the root of minecraft.jar

Changelog
-v1.4.1 Added using lightstone dust as 'medicine'. Eggs only spawn chicks, babies are born tamed.
-v1.4 Fixed not despawning issue, added ability to make babies into adults and have more babies
_v1.3.1 Fixed bodies staying behind after animals die, re-added audio files.
-v1.3 Fixed despawning issue, added visible indicator for taming, added un-taming, lambs now drop bones if killed
-v1.2 Added following and taming capabilities (babies won't despawn if tamed)
-v1.1 Added ModLoader and Spawnlist compatibility
-v1.0 First release