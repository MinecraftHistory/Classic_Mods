Backup your minecraft.jar

Instructions:
1. Put all the files in the "Files" folder into your minecraft.jar.
2. Move the tent.properties into your /.minecraft
3. ((Optional) If you have a 32x32 texture pack, move the PNG from 32x32 folder into the "camping_mod" folder in your minecraft.jar.
NOTE: DO NOT USE 32x32 IF YOU USE DEFAULT TEXTURES OR A 16x16 TEXTURE PACK (eg. Painterly.)

Please post bugs or ideas you may have on this mod :)

currently looking for ideas on tent designs (: