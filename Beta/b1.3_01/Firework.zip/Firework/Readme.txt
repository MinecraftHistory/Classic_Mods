=====================================================================
Firework Mod Version 1.1
=====================================================================

Install Instructions:
1. Download & install Risugami's Modloader V4
2. Copy all .class files + the "mods* folder into your minecraft.jar
3. Delete META-INF
4. ???
5. Profit

---------------------------------------------------------------------

Recipe:
# = Paper
X = Redstone
R = TNT


#X#
#R#
###

--> see Recipe.png
---------------------------------------------------------------------

Thanks for using my mod and have fun.

tedman0674

Changelog:
V1.1
-Changed the Recipe--Instead of Gunpowder, you have to use TNT
-Decreased motionY of the first Entity from 1.6D to 1.45D, so you can see the Particles better.
=====================================================================

=====================================================================