
MoreCreeps AND Weirdos v1.83
----------------------------

For MineCraft version BETA 1.3_01

This mod adds MORE CREEPS and WEIRDOS to your MineCraft world!




CREEPS and WEIRDOS
------------------

*** FLOOBS ***
Dangerous aliens who arrive in their Floob Ships and shoot Ray Guns at you! Destory their ships quickly, or your world will be overrun with RayGun shooting Floobs!

*** EVIL SCIENTIST ***
Added Evil Scientist who builds towers, conducts experiments and uleashes his mutations: Evil Creatures, Evil Pigs and Evil Chickens

*** MANDOG ***
A passive creature who growls and can be tamed with cooked meat. He will then fetch frisbees thrown by the player. Frisbees can be crafted with Lapis Lazuli and Clay.

*** PYRAMIDS ***
These Mummy Tombs will appear randomly on your landscape. If you are feeling brave, explore the labryinth to recover the valuable Mummy Treasure!

*** GOO GOAT ***
A rather peaceful animal that munches on grass and fills up with slime. You can see him fill up and grow as he strips the landscape of grass. Killing it will yeild Goo Donuts dependent on his size and slime capacity.

*** BLORP ***
A herbivorous creature that grows as it eats leaves. You may want to kill it before it gets too big! Blorps are hostile toward other Blorps, and drop a refreshing drink called BlorpCola. The bigger the Blorp, the more cola you get. Or, you could just leave it alone to eat in peace. The choice is yours.

*** BABY MUMMY ***
These ripening youths [only hundreds of years old instead of thousands] are a mischevious bunch who love to play with humans. If you step on sand, watch out! These little creeps will try to bury you in their sand traps. They do appear during the day, but will burn up at high noon. 

*** PREACHER ***
Sometimes you just need a good sacrifice. It's a good thing that the world of Minecraft has so many sheep and pigs just wandering about, making them the perfect offering to the Gods of Minecraft*. These holy dudes may be loaded with donations, but they will also perform the ritual on you if you try to take it from them. Repent!

*** HUNCHBACK ***
This poor fellow is desperate for some delicious, fresh cake. If you can bake a cake for this Hunchback, he will become your loyal servant. This is where the fun begins, because if you throw him a bone, he will raise a skeleton army to wreak havok on the land. They are an uncontrollable and temporary band of hoodlums. Watch them kick some serious butt.

*** DESERT LIZARDS ***
Creeping around in the hot sun, these rowdy reptiles are always looking for a little something to munch on. Are you a little something? They shoot mini fireballs at a distance, and leap on you when close.


*** SNOW DEVILS ***
These double-headed devils are fearsome beasts which live primarily in the Ice Desert regions. If you kill them, they will drop pure ice, which can be used to build or as a source of portable water. They have a fearsome bite, but can be tamed if you throw snowballs at close range. But beware! They make very dangerous pets! Also, for whatever reason, these Snow Devils do not like the night and burn accordingly.


*** THIEVES ***
Keep a watchful eye for these scumbags of Minecraft, for they are out to steal your valuables. But don't worry, you can recover your stolen goods if you kill the pesky fellows or if they meet thier untimely demise in other ways.


*** DIRTY BUMS ***
These unfortunate fellows wander around looking for a kind soul such as yourself to offer them iron, gold or diamonds. If you treat these rotten bums nicely, you will be rewarded! The more generous your gift, the better the reward.


*** GUINEA PIGS ***
These delightful creatures just love to explore the world of Minecraft. They will follow you around on your adventures if you feed them enough apples or wheat. Apples are much more effective than wheat. If you tame them, they will fight [and die] for you. Each guinea pig has it's own name and unique personality, and will tell you when it is wounded. Feeding it more apples or wheat will heal your pigs. You can equip your pigs with armor and it will increase their attack and health.


*** MUMMY ***
The Mummies are slightly quick but not that powerful. They drop mostly sand and cloth. Mummies can also be found in Pyramids, which contain heavily guarded Mummy Treasure!


*** BLACK SOUL ***
The evil Black Souls are sluggish in movement, but they have a powerful attack and can take a lot of damage.
They drop coal - harvested from the souls of fallen miners. 
Also, there is a small chance they will drop the soul of an innocent miner who was never tempted by mineral deposits. This rare drop is a diamond.


*** INVISIBLE MAN ***
This dapper fellow wanders around delighted with the world around him. For many of his journeys, he takes only a delicious red apple and his walking stick.
However, sometimes he brings along a little extra ice cream money and you may find gold bars. If you attack him, he reveals himself in order to seek revenge.


*** ROCK MONSTER ***
Rock Monster's spawn during the day and are peaceful unless disturbed. Do so at your own peril, as these lapidarian lunks spring to life seeking revenge if provoked.
They are composed mostly of rock and gravel, but some of these beasts possess an iron will and will drop such a covetous prize upon their untimely demise.




FUTURE PLANS:
-------------

*Gods of Minecraft - upcoming mod

Rock Monster Daddy - huge - almost done!

Properties file for Guinea Pig names

Guinea Pigs level up as they gain experience

Black Soul levitates and throws player to the ground.

More Creeps AND Weirdos!!!




INSTALL:
--------

Copy the contents of  "MINECRAFT-JAR" folder into your minecraft.jar

Copy the contents of "RESOURCES" into your RESOURCES folder

Copy the contents of "MINECRAFT-FOLDER" into your .minecraft folder. This is the properties file which allows you to choose the creeps that you don't want. Simply put a '#' in front of any creep that you don't want and save the file.

You must have Risugami's Modloader and AudioMod and 303's SpawnList installed for MoreCreeps to function.

http://www.minecraftforum.net/viewtopic.php?f=25&t=80246

Do not forget to delete the META-INF folder in your minecraft.jar or no mods will ever run.

This mod is compatible with all mods, but Charlotte doesn't like tame Guinea Pigs and will try to kill them.





TROUBLESHOOTING
----------------

CANT SEE ANYTHING - You have probably taken the textures out of the creeps folder! Just copy all of the content of the MINECRAFT-JAR folder and drag them to your MINECRAFT.JAR. The textures must be in a folder called CREEPS which is INSIDE the MOB folder in your minecraft.jar

CAN'T HEAR ANYTHING - You have either not installed AudioMod correctly, or have removed the sounds from the CREEPSOUNDS directory! All of the hideous and wacky sounds must remain in the CREEPSOUNDS folder, which should be located to your RESOURCES/MOD/SOUND directory. Check to make sure that there is a CREEPSOUNDS folder in that SOUND directory. Double-check that you installed AudioMod correctly - IBXM, PAULSCODE and tm.class should all be dropped into your minecraft.jar

NO CREEPS SPAWN - Make sure that you have installed 303's Spawnlist.class file to your minecraft.jar. Reset the spawns by playing on peaceful and then crank the difficulty to hard.

PROPERTIES FILE NOT WORKING - The MoreCreeps.properties file must be located in your .minecraft directory. This directory contains other directories called BIN, MODS and RESOURCES. If Minecraft cannot locate this properties file, the mod will use default values and turn every creep on.




VERSION NOTES:
--------------

v1.90
-----





v1.83
-----
ADDED: Pyramid Guardian - kill him to break the curse - removes bedrock, reveals central tomb
ADDED: Floobship explosions toggled on/off in properties
ADDED: Pyramid rarity adjustable in properties: Default is 700. Range is between 200 (more chance)  - 1000 (less chance)
FIXED: Pyramids should not get cut in half
FIXED: Evil Scientist towers should not cut into geometry
FIXED: Guinea Pig level up message no longer one level behind
FIXED: Level 20 Guinea Pig shouldn't crash minecraft! A bit too powerful!
FIXED: Evil Scientists will only build towers above ground and will not remove non-existant towers. Dummy Evil Scientists, what were they thinking?
TWEAK: Preachers will only use anti-cheat protection on player
TWEAK: Desert Lizards fire less frequently
TWEAK: Desert Lizard range reduced to 30 blocks
TWEAK: Floobships spawn less Floobs. Pitiful EARTHLINGS!
TWEAK: Weakened Floobs slightly to compensate for puny humans punarity.



v1.82
-----
ADDED: RayGun melt blocks on/off in properties file
FIXED: Guinea Pig infinite pork bug


v1.81
-----
ADDED: Floob sounds! Prepare for takeover!
ADDED: RayGun fire now set with properties file - to Burn or not to Burn
ADDED: Pyramids toggle on/off with properties file
FIXED: Pyramids spawn on sand, don't overlap and don't obstruct world geometry
FIXED: Can't hit large Goo Goats. Bounding Box size fixed 
FIXED: Infinite Goo Donuts bug
FIXED: SnowDevils now die when tamed and killed
FIXED: ManDog not despawning
FIXED: RayGun missing its RAY!
FIXED: RayGun stacksize is now 1 - infinite RayGun bug
TWEAK: Goo Goats get stronger with size
TWEAK: Pyarmids appear less frequently
TWEAK: BlackSoul attack
TWEAK: Floobships and Evil Scientist appear less frequently
TWEAK: Goo Donuts now dissolve in water instead of dissapear
TWEAK: ManDog facing what he is chasing - somewhat
TWEAK: SnowDevils drop more snow  instead of ice


v1.8
-----
NEW CREEP! Added Floobs, aliens who arrive in their Floob Ships and shoot Ray Guns at you!
NEW CREEP! Added Evil Scientist who conducts experiments and uleashes his mutations: Evil Creatures, Evil Pigs and Evil Chickens
NEW CREEP! Added ManDog, who growls and can be tamed with cooked meat. He will then fetch frisbees thrown by the player.
Added Frisbee, which can be crafted with Lapis Lazuli and Clay
Added Mummy Pyramids, which contain randomly generated mazes leading to buried treasure!
Preachers are better protected against Goo Donuts, but will still take some damage
Preachers will toss heathens and sacrifices around
Preachers will make sure that heathens atone for sins with anti-cheat powers
Added a few more Preacher sounds
Guinea Pigs can level up! Brave pigs increase attack strength and health up to level 20!
Guinea Pig code optimized - less lag
Guinea Pigs - less squealing when fighting
Mounted Guinea Pigs will not squawk
Guinea Pigs no longer attack tamed Hunchbacks
Goo Donuts handling improved. More bouncy and more fun!
Bums save exploit fixed - No longer can you cheat the dirty Bums
Improved the attacks of Goo Goats, Desert Lizards and Black Souls










v1.7
-----
Added Goo Goat which feeds on grass and fills up with slime. Killing it will yeild Goo Donuts dependent on the size of the Goo Goat
Added Goo Donuts which explode if you throw them
Made Baby Mummy traps a bit harder on the player
Mummies now drop bandages which heal the player
Mummies also drop sandstone
Snow Devils now survive the night if they are on snow or ice. Keep your pet in cage with a snow or ice floor
Snow Devil spawn rate increased slightly
Fixed Invisible Man not attacking when angry
Hunchback that is caked up will now take small damage from you, but will still thank you


v1.6
-----
Simple update to new Minecraft Beta 1.3_01


v1.5
-----
Added Blorp which grows as it eats leaves and drops BlorpCola, the most refreshing drink you've ever had!
Adjusted Hunchback Skeletons to not drop as many bones and arrows
Preacher's victims now get pushed around a bit more



v1.4
-----
Added Baby Mummies who try to catch you in their sand traps. Stay away from sand!
Once a Bum cheats you, you can't bribe him any longer.
Reduced adult Mummy speed


v1.32
-----
Hunchback will fight back if not your servant. If he is, then wail away!
Hunchback now faces his demise if attacked
Hunchback will demand more cake after awhile. He loves it!
Carry a Guinea Pig on your head if right-click with empty hands
Guinea Pigs can now be stacked 20 high. Thanks to Kodaichi and 303 for code and help.



v1.31
-----
Fixed pacifist Preachers. You will now see sacrifices of all who dare to lay angry hands on these holy dudes
Fixed Preacher drop error. Preahcers sometimes drop books. They now will drop gold!
Fixed Hunchback Skeleton Army fighting amongst themselves if caught in the crossfire
Hunchback can now be beaten after he is caked up!
Added Hunchback sounds in gratitude for the beating his master gives him
Hunchback will now seek revenge if he isn't caked up.after being attacked



v1.3
----
Added Preachers which ramble on and on and perform rituals for the Gods of Minecraft. 
Invisible Man turns visible when hit. He gets invisible again after awhile.
Added Invisible Man angry voices. Now you can hear his displeasure!
Sometimes the Invisible Man carries cake
Hunchbacks will gobble up cake blocks and cake
Hunchbacks will follow you after they have cake
Hunchback Skeleton Army now attacks other mobs and creatures. They won't attack Guinea Pigs, Hunchbacks or SnowDevils
Decreased Rock Monster spawnrate




v1.2
----
Added Hunchbacks which love cake and will raise an army of skeletons for your amusement
Improved tail animation for DesertLizards
Reduced spawn rate of Guinea Pigs




v1.1
----
Added five varieties of Desert Lizards who are always on the lookout for a snack - YOU!
Guinea Pigs now keep their armor when reloading
Guinea Pig lag reduced. Tested to 20 tamed pigs
Guinea Pigs are now tamed instantly with Golden Apples
Added sound for equiping Guinea Pigs with armor
Added smoke effect for feeding, taming and armor
Added more Guinea Pig sounds for variety
Adjusted spawning of SnowDevils
Adjusted SnowDevil drops - random mostly snow and a few ice
Fixed SnowDevil sounds not playing



v1.0
----
Added Snow Devils which can be tamed with snowballs


v0.9 
----
New configuration file MoreCreeps.properties - turn off the creeps you don't want
Added three new guinea pigs for six total. 
Guinea pigs now fight [and die] for you if tamed.
Apples tame and heal Guinea Pigs faster than wheat.
Each guinea pig has a unique name and tells you when it is wounded. 
You can equip your Guinea Pigs with all kinds of armor.
Armor grants them increased attack and health stats depending on the quality of armor.
Guinea Pigs push you around less and follow eachother more.
Raise an army of pigs and charge into battle!
Thief now steals randomly from inventory and takes a random amount.
Invisible Man stops whistling when angry.
Bums are not be as generous.
Bums will sometimes make a sucker out of you.
BlackSoul sometimes drops more coal and diamonds.
Mummy drops more sand and cloth.

v0.8 Added Thieves. Lowered the volume of guinea pigs.

v0.7a Fixed spawn rates of daytime creeps and lag issues.

v0.7 Updated for MineCraft 1.2_02

v0.6 Spawn rates adjusted for Guinea Pigs, Rock Monster and Invisible man. Guinea Pigs make a chime sound when they are full. 

v0.55 Dirty Bums added. Guinea Pigs will no longer take over the world. Also, Mo Creatures and other mobs spawn correctly now. Invisible man should appear as a solitary figure instead of a group.

v0.5 New Guinea Pig added. Black Guinea Pig explodes on death. Pigs drop only one meat now. Pigs should not despawn.

v0.4 Guinea Pigs added. Invisible Man drops gold less frequently.

v0.3 BETA 1.1_02 compatible, texture fix on invisibleman, spawn logic updated

v0.2 renamed 'more creeps and weirdos' added invisible man and rock monster

v0.1 initial release - mummy and blacksoul




THANKS
-------

Shout out to my coding creeps who helped me - 303, Club559 and Okushama. Also DrZhark for the following and configuration code. Thanks, guys! Thanks to OgreSean for the name display code from his Builders mod.

Also thank you to Risugami for Modloader, 303 for Spawnlist and the MCP team for the tools! Thanks Okushama for the Dirty Bum idea. 



