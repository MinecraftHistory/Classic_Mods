Simply open up minecraft.jar with an archiver tool (WinRAR, etc.) and drag and drop the .class files into the jar.

You need to have ModLoader in order for this mod to work. Please read this post:

http://www.minecraftforum.net/viewtopic.php?f=25&t=80246


---------------------------------------------------------------------------------

Thanks!
~Jadaytime