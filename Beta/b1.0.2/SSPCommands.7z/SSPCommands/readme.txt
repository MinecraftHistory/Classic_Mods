General Information.

Created By: simo_415
Version: 1.4
Mincraft Version: Beta 1.1.2
Thread: http://www.minecraftforum.net/viewtopic.php?f=25&t=100267

---

Preview.

http://www.youtube.com/watch?v=P4qNc6FNLow

---

Install Instructions.

1. Go to the minecraft bin directory and backup minecraft.jar
2. Using 7zip or equally capable ZIP viewer open minecraft.jar
3. Delete the META-INF folder
4. Copy ALL the class files contained within the mod to minecraft.jar, replacing the existing files.
5. Enjoy the mod.

---

What's New.

V1.4

Single Player Commands mod now compatible with BETA 1.1.X

Added the ability to spawn custom mobs. This new feature changes the way /spawn works,
and changes all the NPC codes. Use /spawn list to find monster names and associated codes.
Please note that monster names ARE case sensitive.

You can now change the command names through a properties file, refer to the help
below for more information about this.

Fixed the bugs which were introduced in the last release

V1.3

Single Player Commands mod now compatible with BETA 1.0.X

/health inf == /health infinite
/health now provides a message when used
Fixed bug where if you die you lose your waypoints

V1.2

New Commands - 

difficulty
killall
music

Use /help <COMMANDNAME> to find out information about each command. For example - /help music

Added some extra functionality to /spawn
Moved the majority of the mod's functionality into a new class, PlayerHelper. This will help with compatability of other mods.
Fixed /time day and /time night to work like they should
Added more content to the readme

V1.1

New commands -
clear
heal
health
help
listwaypoints
spawn
time

Use /help <COMMANDNAME> to find out information about each command. For example - /help time

Removed changes to cy.class so only TWO classes needed for mod to function correctly.
Fixed player skin bug.
Seperated waypoint save from level.dat into a seperate file named waypoints.dat
Cleaned up code and made more robust
More detailed readme

---

Usage.

1. After applying mod open minecraft.
2. Start a saved world or new world (as per usual).
3. Type 't' (by default) to bring up the chat console.
4. Type in the command and hit enter; a list of commands can be found below.

---

Commands.

clear - Clears the console
difficulty <VALUE> - Sets the difficulty of the game, valid range is 0-3.
goto <NAME> - Goto a waypoint
heal <HEALTH> - Heals a player the specified number of points
health <MIN|MAX|INFINITE> - Sets the health of a player to pre-defined figures
help [COMMAND] - Gives general help when COMMAND isn't specified, gives specific help when COMMAND is specified.
home � Teleport to spawn point
item <ITEMCODE> [QUANTITY] � Gives player item, if quantity isn�t specified maximum amount of that item
kill � Kills the current player
killall - Kills all nearby living creatures except for yourself.
listwaypoints - Lists all waypoints
music [VOLUME] - Requests a music track to be played (max 2 per day, won't always work), if volume is specified, sets the volume
pos � Gives current player position
rem <NAME> - Removes the specified waypoint
set <NAME> - Mark a waypoint on the world
setspawn [<X> <Y> <Z>] � Set the current position as the spawn point, if X Y Z are specified sets that position as spawn point
*spawn <LIST|CREATURENAME|CREATURECODE|RANDOM> - Spawns the specified creature a few blocks away from your current position
tele <X> <Y> <Z> - Teleport to X Y Z coordinates.
time [set|get|day|night [minute|hour|day [TIME]]] - Set and get the time within minecraft.

* = New Command

---

Examples.

/clear - Clears the console.
/difficulty 0 - Sets the difficulty to peaceful
/difficulty 3 - Sets the difficulty to hard
/goto example - Teleports the player to the waypoint named "example"
/heal 10 - Heals a player 10 health
/heal -10 - Removes 10 health from the player
/health min - Sets the players health to half a heart health
/health max - Sets the players health to ten full hearts
/health infinite - Sets the players health to 65565 (maximum ammount of health allowed).
/help goto - Provides an ingame help message about the goto command
/help spawn - Provides an ingame help message about the spawn command
/help - Provides a generic help message.
/item 1 - Gives the player 64 stone
/item 278 - Gives the player 1 diamond pickaxe
/item 278 64 - Gives the player 64 diamond pickaxe's
/kill - Kills the current player
/killall - Kills all nearby living creatures.
/listwaypoints - Lists all waypoints that have been set on the given map
/music - Requests a music track to be played. Note that only one or two tracks can be player per day.
/music 10 - Sets the volume of music to 10.
/pos - Gives the players position in X Y Z coordinates
/rem example - Removes the waypoint named "example"
/set example - Sets a waypoint at the current position named "example"
/setspawn - Sets the current position as the spawn point
/setspawn 0 66 0 - Sets the spawn point at (0,66,0)
/spawn list - Prints a list of monsters and monster codes to screen
/spawn Zombie - Spawns a zombie nearby
/spawn 92 - Spawns the creature with id = 92, a cow in this case.
/spawn random - Spawns a random creature
/spawn r r - Spawns two random creatures ontop of one another
/spawn 92 Creeper 56 - Spawns creature 92 ontop of a creeper ontop of creature 56 (ghast > creeper > cow)
/tele 0 66 0 - Teleports the player to the coordinates (0,66,0)
/time - Gives the player the current time
/time day - Sets the time to the morning, ie: hour = 0, same as /time set hour 0
/time night - Sets the time to night, ie: hour = 13, same as /time set hour 13
/time get hour - Gets the current hour
/time get minute - Gets the current minute
/time set day 1 - Sets the current day as 1
/time set hour 10 - Sets the current hour as 10

---

List of Creature codes.
 Use /spawn list in game.

---

Command Properties File

To change command names from what they are to alternate versions you need to 
add this file to your .minecraft directory.

.minecraft/mods/sppcommands/sppcommands.properties

Within this properties file should be key value pairs seperated by an equals "=" 
sign. Where the key is the command name and the value is the new value.

For example to change /goto to /warp

goto = warp

Example sppcommands.properties file
#START OF FILE

give =
goto = warp
item = 
pos = 
p = 
spawn = q

#END OF FILE

---

Support.

If you are having any trouble with this mod please post on this forum thread, I check it regularly:
http://www.minecraftforum.net/viewtopic.php?f=25&t=100267

That way when I help you with your problem, people with the same problem can also find the solution.

Bugs Reports/Bug Fixes/Feature requests/Problems should all be posted on that forum thread.

I love hearing feedback, so any feedback so greatly appreciated, if you like the mod please tell me!
