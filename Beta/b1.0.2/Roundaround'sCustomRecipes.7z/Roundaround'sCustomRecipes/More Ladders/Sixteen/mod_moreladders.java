public class mod_moreladders extends BaseMod
{

    public mod_moreladders()
    {
    }

    public void AddRecipes(et et1)
    {
        et1.a(new fy(of.aF, 16), new Object[] {
            "# #", "###", "# #", Character.valueOf('#'), ed.B
        });
    }
}