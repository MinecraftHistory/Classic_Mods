import java.util.Random;

public class iu extends gh
{
  public iu(int paramInt1, int paramInt2)
  {
    super(paramInt1, paramInt2, hl.r, false);
    this.bt = 0.98F;
    b(true);
  }

  public int c() {
    return 1;
  }
}

/* Location:           C:\minecraft_dev\bin\
 * Qualified Name:     iu
 * JD-Core Version:    0.6.0
 */