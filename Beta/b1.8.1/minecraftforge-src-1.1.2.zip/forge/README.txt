*** HOW TO INSTALL ***

Extract the download archive directly into your MCP-directiory.
It should create a folder "forge" within that directory, containing all 
extracted files.

You should use freshly decompiled jars, solely including ModLoader & 
ModLoaderMP respectively. Anything else can eventually cause conflicts.

Now just start the install-bat, MCForge will install itself into the proper
locations and copy all ned files, as well as modifying the ned baseclasses.

