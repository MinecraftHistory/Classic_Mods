--------------------------------------
    Mystic Stones mod version:  0.3
--------------------------------------


DISCLAIMER:
--------------------------------------
The Mystic Stones mod was created by Axebane.  You MAY NOT release my mod within a "Compilation Mod Pack" or "Community Mod Pack" without my express permission.  To contact me, send a private message on the Minecraft Forums to: Axebane

The Mystic Ores mod requires adding files to your minecraft.jar file, therefore SMP may not work with the mod installed.  There are also many new blocks and items, and you CANNOT load a save game without the mod installed if it has any of these new blocks/items.  I am not responsible for any
damage done to your computer, worlds, or your copy of Minecraft.

Please make sure to save a BACKUP COPY OF YOUR MINECRAFT.JAR and SAVES folder BEFORE USING THIS MOD.


REQUIREMENTS:
--------------------------------------
ModLoader for Beta 1.6.6
WinRAR or 7zip.


INCOMPATIBILIES:
--------------------------------------
This mod IS NOT compatible with the following mods:
Nethercraft
Any mod that adds new material types for Tools. (This mod is not Tools Utils compatible yet unfortunately)


INSTALLATION:
--------------------------------------
1. Save a backup copy of your minecraft.jar.
2. Install Risugami's ModLoader for Beta 1.5_01
2. Right-Click your minecraft.jar and select "Open with WinRAR/7zip."
3. Delete the META-INF folder inside the minecraft.jar.
4. Drag all the files and the mysticores folder into the WinRAR window and then click OK.
5. Close the WinRAR window and then load the game.

NOTE: if you have trouble copying the files into the minecraft.jar, make sure Minecraft is not allready running! If you get a blackscreen, re-open minecraft.jar with WinRAR and make sure you deleted the META-INF folder!


MYSTIC STONES FEATURES:
--------------------------------------
6 new natural stone types, including:
Anorthosite, Limestone, Marble, Migmatite, Orthogneiss & Slate.

Each of the stones can be cooked in a furnace to create its smooth version. It can then be cooked again to create cobblestone.

6 new colored planks.

Combine regular planks with the rough version of any colored stone to create the new colored planks. These planks are considered wood and will burn if set on fire. To convert the colored planks back to regular planks, just place them anywhere in your crafting grid.


BLOCK IDs and ITEM IDs used:
--------------------------------------
Block IDs 205 - 222.
Item IDs (no Items added to the mod yet).


VERSION INFO:
--------------------------------------
v0.3 -- Updated to support Beta 1.6.6
	Made all stone types slightly less common for all versions (Common, Rare & Very_Rare)
	Marble now only spawns deep underground and is more rare.
v0.2 -- Created 3 seperate versions of the mod for optional rarities: Common, Rare & Very_Rare
	Improved the rough marble texture and made all colored stones a bit more "subdued" to make them look more natural.
	Added 6 new colored plank blocks.
	Anorthosite (purple) & Slate (blue) are now only found underground between levels 24 - 48.
	Limestone (green) & Migmatite (orange) are now only found above level 48.
	Orthogneiss (red) & Marble (black) are now found between levels 1 - 96.
v0.1 -- Initial release.