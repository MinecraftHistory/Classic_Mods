Millénaire installation

- install ModLoader Beta 1.6.5
- clear META-INF from the minecraft.jar
- put the content of "Put in minecraft folder" in the minecraft folder (.minecraft in Windows) (alongside bin, saves etc.)
- put the zip file from "Put in mods folder" in minecraft/mods (without unzipping). If you do not have a mods directory, create it.
- there are no Millénaire classes to be put in the minecraft.jar anymore. This is replaced by the zip in the mods folder.

If the mod is running properly, it will display this line stating that it is active when you first enter a world: "Millénaire is loaded. Explore and press 'v' to locate villages."

Millénaire update

- If you had made no change to the Millénaire files, simply delete the old millenaire directory and the millenaire zip and replace them with the new ones as outlined above
- If you had made changed (to the config file, to the building plans, etc.), you must manually move those changes to the new millenaire folder, then delete your old one

Need help?

Start by looking at the Millénaire Wiki at millenaire.wikia.com, and especially at the FAQ sections where common questions on installing Millénaire and on the gameplay are answered. If you can't find an answer there, ask on the Millénaire thread on http://www.minecraftforum.net/