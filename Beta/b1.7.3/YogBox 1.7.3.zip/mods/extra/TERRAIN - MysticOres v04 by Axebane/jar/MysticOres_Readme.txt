--------------------------------------
    Mystic Ores mod version:  0.4
--------------------------------------


DISCLAIMER:
--------------------------------------
The Mystic Ores mod was created by Axebane.  You MAY NOT release my mod within a "Compilation Mod Pack" or "Community Mod Pack" without my express permission.  To contact me, send a private message on the Minecraft Forums to: Axebane

The Mystic Ores mod requires adding files to your minecraft.jar file, therefore SMP may not work with the mod installed.  There are also many new blocks and items, and you CANNOT load a save game without the mod installed if it has any of these new blocks/items.  I am not responsible for any
damage done to your computer, worlds, or your copy of Minecraft.

Please make sure to save a BACKUP COPY OF YOUR MINECRAFT.JAR and SAVES folder BEFORE USING THIS MOD.


REQUIREMENTS:
--------------------------------------
ModLoader for Beta 1.7.3
WinRAR or 7zip.


INCOMPATIBILIES:
--------------------------------------
This mod IS NOT compatible with the following mods:
Nethercraft
Any mod that adds new material types for Tools. (This mod is not Tools Utils compatible yet unfortunately)


INSTALLATION:
--------------------------------------
1. Save a backup copy of your minecraft.jar.
2. Install the LATEST Risugami's ModLoader
2. Right-Click your minecraft.jar and select "Open with WinRAR/7zip."
3. Delete the META-INF folder inside the minecraft.jar.
4. Drag all the files and the mysticores folder into the WinRAR window and then click OK.
5. Close the WinRAR window and then load the game.

NOTE: if you have trouble copying the files into the minecraft.jar, make sure Minecraft is not allready running! If you get a blackscreen, re-open minecraft.jar with WinRAR and make sure you deleted the META-INF folder!



MYSTIC ORES FEATURES:
--------------------------------------

4 new metals, 1 new fuel, including:
Verdite, Mithril, Adamantine & Iridium

To mine the new metals, you will need the following type of pick:
Verdite - Any type of pickaxe.
Mithril - Iron pickaxe or better.
Adamantine - Diamond pickaxe or better.
Iridium - Diamond pickaxe or better.
Black/Red/Blue Soulstone - Iron pickaxe or better.
Bloodstone - Diamond pickaxe or better.


4 new mystic gemstones, including:
Emerald, Sapphire, Topaz & Amethyst.

To mine these gemstones, you must use an Iron pickaxe or better. These mysterious gemstones can be used to transmute certain materials. There are currently 64 transmutation recipes in total. No one knows what materials to use for each gem, so you will have to discover them yourself through trial-and-error!

To try and transmute a material, surround a gemstone with the material you want to transmute, as per this diagram:
XXX
XOX
XXX
 
X = material to transmute.
O = a mystic gemstone.

Mystic gemstones can now be crafted into Mystic Powder. (place 1 of each gem in the crafting grid to make) Combine Mystic powder with any uncooked ore or any dust (gunpowder, glowstone dust, redstone or sugar) to "enrich" the ore/dust.


4 new types of ore in the Nether, including:
Black Soulstone, Red Soulstone, Blue Soulstone & Bloodstone


6 new sets of Tools, including:
Verdite Tools, Mithril Tools, Adamantine Tools, Iridium Tools, Obsidian Tools & Bloodstone Tools. (all new tools except Verdite and Mithril require Obsidian Rods to craft. Stack 2 Obsidian Shards vertically to make Rods.)

The tool qualities are as follows:
Verdite - Better than stone tools, but not as good as iron.
Mithril - Better than iron tools, but not as good as diamond.
Adamantine - Better than diamond.
Iridium - Better than Adamantine.
Obsidian - Very fast mining speed, but slightly less durable than stone tools.
Bloodstone - Increadibly fast mining speed, but slightly less durable than iron tools.


A new kind of glass made from Glass Blocks + Obsidian Shards:
Reinforced Glass (Its explosion proof).

Normal glass no longer gives glass shards when broken to make the mod compatible with BetterGlass.


BLOCK IDs and ITEM IDs used:
--------------------------------------
Block IDs 180 - 192.
Item IDs 18000 - 18043.


VERSION INFO:
--------------------------------------
v0.4 -- Updated to support Beta 1.7.3
v0.3 -- Updated to support Beta 1.6.6
	Made Mithril and Iridium more rare.
	Made Verdite, Soulstone and all Mystic Gemstones slightly more common.
	Added 16 new transmutation recipes.
	Made the mod compatible with BetterGlass.
v0.2 -- You must now use the correct type of pickaxe to mine metals/gems.
	Tweaked rarity of some metals/gems. (Mithril, Soulstone & Bloodstone are more rare)
	Changed the types of items dropped from Soulstone & reduced the number of Block IDs used for Soulstone.
	Added a new fuel type: Iridium Nuggets.
	Added a new toolset: Iridium Tools.
	Added 36 new transmutation recipes.
	Added Mystic Powder, which can be used to "enrich" uncooked ore and dust.
	Removed Diamond Shards & Adamantine Shards. (Please incinerate these items BEFORE upgrading to v0.2)
v0.1 -- Initial release.