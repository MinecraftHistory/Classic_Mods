|==============================================================|
| INVENTORY TWEAKS Mod - By Jimeo Wan (jimeo.wan at gmail.com) |
| Lisez-moi                                                    |
|==============================================================|

====== [ INSTALLATION ] ======

1. V�rifiez que ModLoader est bien install� (pour le t�l�charger : http://www.minecraftforum.net/topic/75440-)
2. Supprimez toute ancienne version d'Inventory Tweaks
3. Mettez le Zip dans le dossier "mods" de Minecraft [OU] Copiez tout le contenu du Zip dans "minecraft.jar"
4. Lancez le jeu !

======= [ UTILISATION ] =======

* La touche par d�faut est R, mais vous pouvez la changer dans le menu des options. Le clic du milieu marche aussi.
* Au premier lancement du mod, plusieurs fichiers de configuration appara�tront dans le dossier "config" de Minecraft. Jetez-y un oeil pour d�couvrir comment personnaliser le mod !

====== [ LIENS ] ======

* Topic Minecraft Forum (en anglais) : http://www.minecraftforum.net/topic/323444-
* Topic Minecraft.fr (parce que l'auteur du mod est fran�ais =D) : http://minecraft.fr/forums/showthread.php?tid=15210
* Site officiel (en anglais) : http://wan.ka.free.fr/?invtweaks
* Code source : https://github.com/jimeowan/inventory-tweaks