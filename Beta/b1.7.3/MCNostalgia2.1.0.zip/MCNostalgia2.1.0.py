import mcnostalgialib, os, getpass, traceback
print "******** - MCNostalgia 2.1.0 - ********\n"
mcn = mcnostalgialib.MCNostalgia()
print "This program at its current version will assume that your \npatches are in the patches directory."
print "It is set to patch the minecraft files in \nyour .minecraft" + os.sep + "bin folder."
print "Once you press enter, I will list the versions available for \nyou to downgrade to.  This list is generated from the files \nthat you have in your patches directory"
print "Your patches directory is set to:", mcn.patchdir
print "Your .minecraft bin folder has been detected to be:", mcn.bindir
print "Press enter to see the list of downgrade possibilities."
getpass.getpass("")
available = mcn.fetchAvailableVersions()
for number, version in enumerate(available) :
    print number + 1, version
valid = False
while not valid :
    try :
        selectedversion = input("Please type the correspoding number on the left of the version you want to downgrade to and then press enter.\n")
        version = available[selectedversion - 1]
        valid = True
    except KeyboardInterrupt :
        print ""
        quit()
    except :
        print "That is not a valid choice number.  Please try again"
if mcn.checkFiles() :
    mcn.fetchVersion(version)
    if mcn.checkOrig(version) :    
        print "Thank you.  Now patching to version", version
        try :
            if mcn.patchTo(version) :
                print "Patching finished.  Have a nice day!"
                print "If you want to unpatch, run the launcher and do a forced update."
            else :
                print "Patching failed, if you get stuck at the 'Done Loading' screen, this is why.  You probably didn't have a fresh vanilla minecraft before you started."
        except :
            traceback.print_exc()
            print "An error has ocurred while running this program.  Please paste the above traceback into a code box in a spoiler box on a new post on the MCNostalgia thread.  Preferrably, however, is that you come onto IRC and ask about it and provide a link to the traceback.  The IRC network would be Esper, in the channel #risucraft.  So irc.esper.net channel #risucraft."
    else :
        print "Error: The files in", mcn.bindir, "are not for the current version or are not vanilla."
        print "Please delete your .minecraft bin folder and run the launcher again to get a vanilla minecraft of the current version"
else :
    print "You don't seem to have all the files you need in your minecraft bin folder.  Please delete your bin folder, run the launcher and login."
print getpass.getpass("Press ENTER to exit.")
