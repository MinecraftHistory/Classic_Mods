Auto Walk V1.0


//--How to Install--//

Open minecraft.jar in /minecraft/bin with 7-Zip or WinRar and copy and replace all .class files into it's root.

Delete the META-INF folder.

Close 7-Zip or WinRar.

//--Changelog--//

-Initial Release
-Default of x for toggle autowalk
-Toggle key can be changed in Options->Controls