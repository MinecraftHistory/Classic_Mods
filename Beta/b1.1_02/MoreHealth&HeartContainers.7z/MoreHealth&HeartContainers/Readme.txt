1.Drag the .class files into your minecraft.jar.
2. go to the gui folder in your .jar and then copy and replace the item.png with the one in my folder.
2. Delete the Meta-inf folder!
3. Run minecraft, enjoy!
4. Find heart pieces and containers in dungeon chests, per you request!
5. Any questions/suggestions, post in the thread!


The source folder contains the .java files incase you want to look at my what I did.

Backup your minecraft jar! This mod im going to assume is NOT compatible with mod loader or other mods that modify the classes I modified. 