package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 
import java.lang.Object;
//models the ItemFood class
public class ItemHeart extends Item
{

    public ItemHeart(int x)
    {
        super(x);
		
        maxStackSize = 1;
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
		
        itemstack.stackSize--;
		//MaxHealth myHealth = new MaxHealth(world);
        entityplayer.heal(99); //after taking out MaxHealth class, it became hard to call it (as the methods are now in entityliving)
		//so i improvised and made the heal 99. In the heal function in EntityLiving, if the variable is 99, then hpmax would increase by 2.
		
        return itemstack;
    }

  
	
}