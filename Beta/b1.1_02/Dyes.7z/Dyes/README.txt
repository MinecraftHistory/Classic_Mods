Dyes! rev 1
Adds 11 dyes, which you can use to color the cloth!

Put files from folder "JAR" into the minecraft.jar.
If you have ID conflicts between mods, let the game run once, close it and change IDs in file modDyes.properties in folder where you have Minecraft.exe.
If you can't run the game because of conflicts, copy the file from folder "Minecraft_exe" into folder with Minecraft.exe.