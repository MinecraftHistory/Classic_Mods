This is installed as every other mod, delete the META-INF folder in minecraft.jar, and then add the files supplied. 
Requires ModLoader to work. Make sure to copy the folder called carbonater into your minecraft.jar as well. The entire folder goes straight into minecraft.jar.
Some extra textures are supplied, use whatever you think is best. Just copy the desired texture into the folder carbonater before you put it into minecraft.jar.
The names of the textures have to be exactly the same as the textures in carbonater (carbon.png and redBlock.png).

WARNING:
A world that has blocks from this mod placed somewhere in it, is unusable without this mod. 
This is because then the world contains blocks that unmodded Minecraft doesn't know what to do with.
If you don't have this mod installed and try to open a world that contains placed redblock, Minecraft will crash. 
Redblock in chests are fine though, as long as you don't open the chests. Install at own risk. 
When Minecraft is updated, this mod will most likely stop to function properly, and then the world is unusable until this mod is updated. 
The blocks can be removed with software like MCEdit. Sometimes Minecraft corrupts save files. 
I strongly suggest to make backups of your worlds regularly.
