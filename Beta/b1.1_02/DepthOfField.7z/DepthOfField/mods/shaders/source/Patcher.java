// Bytecode patcher for depth of field.  
// I don't care what anyone does with this source but I'd like some credit if you reuse this in part or whole. - Chris Brown aka Daxnitro

import javassist.*;
import javassist.expr.*;

import java.lang.Exception;

class Patcher {
	public static void main(String[] argv) throws Exception {

		ClassPool pool = ClassPool.getDefault();
		CtClass entityRenderer = pool.get(EntityRenderer);
 
 		CtClass floatParameter[] = new CtClass[1];
 		floatParameter[0] = CtClass.floatType;
 		
		CtMethod renderEverything = entityRenderer.getDeclaredMethod(EntityRenderer_renderEverything, floatParameter);

		renderEverything.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals("Shaders") && m.getMethodName().equals("processScene")) {
						Patcher.alreadyInstalled = true;
					}
				}
			}
		);
		
		if (alreadyInstalled) {
			System.out.println("Already installed.");
			return;
		}
		
		renderEverything.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals(EntityRenderer) && m.getMethodName().equals(EntityRenderer_renderWorld) && m.getSignature().equals("(F)V")) {
						m.replace("{ $_ = $proceed($$); Shaders.instance.processScene("+EntityRenderer_mc+", "+EntityRenderer_farPlane+", "+EntityRenderer_red+", "+EntityRenderer_green+", "+EntityRenderer_blue+"); }");
					}
				}
			}
		);
		
		CtMethod renderWorld = entityRenderer.getDeclaredMethod(EntityRenderer_renderWorld, floatParameter);

		renderWorld.instrument(
			new ExprEditor() {
				public void edit(NewExpr e) throws CannotCompileException {
					if (e.getClassName().equals(Frustrum)) {
						e.replace("{ Shaders.instance.useProgram(Shaders.instance.baseProgram); $_ = $proceed($$); }");
					}
				}
			}
		);

		renderWorld.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals(EntityRenderer) && m.getMethodName().equals(EntityRenderer_renderPlayer) && m.getSignature().equals("(FI)V")) {
						m.replace("{ $_ = $proceed($$); Shaders.copyDepthTexture(Shaders.instance.depthTexture2Id("+EntityRenderer_mc+"), "+EntityRenderer_mc+"); Shaders.instance.useProgram(0); }");
					}
				}
			}
		);

		renderWorld.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals(RenderGlobal) && m.getMethodName().equals(RenderGlobal_function) && m.getSignature().equals("(F)V")) {
						m.replace("{ $_ = $proceed($$); Shaders.copyDepthTexture(Shaders.instance.depthTextureId("+EntityRenderer_mc+"), "+EntityRenderer_mc+"); }");
					}
				}
			}
		);
		
		if (argv.length >= 1) {
			entityRenderer.writeFile(argv[0]);
		}

	}
	
	static boolean alreadyInstalled = false;
	
	// Obfuscated names. Hopefully this is all that will need to be changed for future releases.
	static final String EntityRenderer = "kr";
	static final String EntityRenderer_mc = "h";
	static final String EntityRenderer_renderEverything = "b";
	static final String EntityRenderer_renderWorld = "c";
	static final String EntityRenderer_renderPlayer = "b";
	static final String EntityRenderer_farPlane = "this.i";
	static final String EntityRenderer_red = "e";
	static final String EntityRenderer_green = "this.f";
	static final String EntityRenderer_blue = "g";
	static final String Frustrum = "mr";
	static final String RenderGlobal = "f";	
	static final String RenderGlobal_function = "b";	
}