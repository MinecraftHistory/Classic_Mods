package net.minecraft.src;

import net.minecraft.client.Minecraft;

import java.nio.*;

import org.lwjgl.opengl.*;
import org.lwjgl.BufferUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Shaders
{

    private Shaders()
    {
    	// The Minecraft instance doesn't need to be sent to the handful of functions it's sent to now.
    	mc = null; 
        initShaders();
    }
    
    private void initShaders() {
		baseProgram = ARBShaderObjects.glCreateProgramObjectARB();
		if (baseProgram != 0) {
			baseVShader = createVertShader("/shaders/base.vsh");
			baseFShader = createFragShader("/shaders/base.fsh");
		}

		if (baseVShader != 0 && baseFShader != 0) {
			ARBShaderObjects.glAttachObjectARB(baseProgram, baseVShader);
			ARBShaderObjects.glAttachObjectARB(baseProgram, baseFShader);
			ARBShaderObjects.glLinkProgramARB(baseProgram);
			ARBShaderObjects.glValidateProgramARB(baseProgram);
			if (!printLogInfo(baseProgram)) {
				baseProgram = 0;
			}
		}
		
		finalProgram = ARBShaderObjects.glCreateProgramObjectARB();
		if (finalProgram != 0) {
			finalVShader = createVertShader("/shaders/final.vsh");
			finalFShader = createFragShader("/shaders/final.fsh");
		}

		if (finalVShader != 0 && finalFShader != 0) {
			ARBShaderObjects.glAttachObjectARB(finalProgram, finalVShader);
			ARBShaderObjects.glAttachObjectARB(finalProgram, finalFShader);
			ARBShaderObjects.glLinkProgramARB(finalProgram);
			ARBShaderObjects.glValidateProgramARB(finalProgram);
			if (!printLogInfo(finalProgram)) {
				finalProgram = 0;
			}
		}
	}
	
	public void useProgram(int program) {
		ARBShaderObjects.glUseProgramObjectARB(program);
		activeProgram = program;
		if (program != 0) {
		    int sampler0U = ARBShaderObjects.glGetUniformLocationARB(program, "sampler0");
		    ARBShaderObjects.glUniform1iARB(sampler0U, 0);
		    int fogMode = GL11.glGetInteger(GL11.GL_FOG_MODE);
		    int fogModeU = ARBShaderObjects.glGetUniformLocationARB(program, "fogMode");
		    ARBShaderObjects.glUniform1iARB(fogModeU, fogMode);
		    if (mc != null) {
			    int aspectRatioU = ARBShaderObjects.glGetUniformLocationARB(program, "aspectRatio");
			    ARBShaderObjects.glUniform1fARB(aspectRatioU, mc.displayWidth / mc.displayHeight);
			    int nearU = ARBShaderObjects.glGetUniformLocationARB(program, "near");
			    ARBShaderObjects.glUniform1fARB(nearU, 0.05F);
			    int farU = ARBShaderObjects.glGetUniformLocationARB(program, "far");
			    ARBShaderObjects.glUniform1fARB(farU, 256 >> mc.gameSettings.renderDistance);
		    }
		}
	}
	
	private int createVertShader(String filename) {
		int vertShader = ARBShaderObjects.glCreateShaderObjectARB(ARBVertexShader.GL_VERTEX_SHADER_ARB);
		if (vertShader == 0) {
			return 0;
		}
		String vertexCode = "";
		String line;
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader((Shaders.class).getResourceAsStream(filename)));
			while ((line=reader.readLine()) != null) {
				vertexCode += line + "\n";
			}
		} catch(Exception e) {
			System.out.println("Failed reading vertex shading code.");
			return 0;
		}
		ARBShaderObjects.glShaderSourceARB(vertShader, vertexCode);
		ARBShaderObjects.glCompileShaderARB(vertShader);
		if (!printLogInfo(vertShader)) {
			vertShader = 0;
		}
		return vertShader;
	}
	 
	private int createFragShader(String filename) {
		int fragShader = ARBShaderObjects.glCreateShaderObjectARB(ARBFragmentShader.GL_FRAGMENT_SHADER_ARB);
		if (fragShader == 0) {
			return 0;
		}
		String fragCode = "";
		String line;
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader((Shaders.class).getResourceAsStream(filename)));
			while ((line=reader.readLine()) != null) {
				fragCode += line + "\n";
			}
		} catch (Exception e) {
			System.out.println("Failed reading fragment shading code.");
			return 0;
		}
		ARBShaderObjects.glShaderSourceARB(fragShader, fragCode);
		ARBShaderObjects.glCompileShaderARB(fragShader);
		if (!printLogInfo(fragShader)) {
			fragShader = 0;
		}
		return fragShader;
	}

	private static boolean printLogInfo(int obj) {
		IntBuffer iVal = BufferUtils.createIntBuffer(1);
		ARBShaderObjects.glGetObjectParameterARB(obj, ARBShaderObjects.GL_OBJECT_INFO_LOG_LENGTH_ARB, iVal);
		 
		int length = iVal.get();
		if (length > 1) {
			ByteBuffer infoLog = BufferUtils.createByteBuffer(length);
			iVal.flip();
			ARBShaderObjects.glGetInfoLogARB(obj, iVal, infoLog);
			byte[] infoBytes = new byte[length];
			infoLog.get(infoBytes);
			String out = new String(infoBytes);
			System.out.println("Info log:\n" + out);
			return false;
		}
		return true;
	}
	
	private int createTexture(int width, int height, boolean depth) {
        int textureId = GL11.glGenTextures();
    	
    	GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
    	    	
    	if (depth) {
	       	ByteBuffer buffer = ByteBuffer.allocateDirect(width * height * 4 * 4);
			GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_DEPTH_COMPONENT, width, height, 0, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, buffer);
	    } else {
    	   	ByteBuffer buffer = ByteBuffer.allocateDirect(width * height * 4);
			GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, width, height, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, buffer);
    	}
    	
    	GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
		GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
		
		return textureId;
    }
    
    private void deleteTexture(int textureId) {
    	GL11.glDeleteTextures(textureId);
    }

	public int baseTextureId(Minecraft minecraft) {
		mc = minecraft;
		if (baseTextureId == 0 || baseTextureWidth != mc.displayWidth || baseTextureHeight != mc.displayHeight) {
			int textureId = createTexture(mc.displayWidth, mc.displayHeight, false);
			baseTextureId = textureId;
			baseTextureWidth = mc.displayWidth;
			baseTextureHeight = mc.displayHeight;
		}
		return baseTextureId;
	}

	public int depthTextureId(Minecraft minecraft) {
		mc = minecraft;
		if (depthTextureId == 0 || depthTextureWidth != mc.displayWidth || depthTextureHeight != mc.displayHeight) {
			int textureId = createTexture(mc.displayWidth, mc.displayHeight, true);
			depthTextureId = textureId;
			depthTextureWidth = mc.displayWidth;
			depthTextureHeight = mc.displayHeight;
		}
		return depthTextureId;
	}

	public int depthTexture2Id(Minecraft minecraft) {
		mc = minecraft;
		if (depthTexture2Id == 0 || depthTexture2Width != mc.displayWidth || depthTexture2Height != mc.displayHeight) {
			int textureId = createTexture(mc.displayWidth, mc.displayHeight, true);
			depthTexture2Id = textureId;
			depthTexture2Width = mc.displayWidth;
			depthTexture2Height = mc.displayHeight;
		}
		return depthTexture2Id;
	}
	
	public void processScene(Minecraft minecraft, float farPlaneDistance, float red, float green, float blue) { // farPlaneDistance doesn't need to be passed here.
		mc = minecraft;
		if (!mc.gameSettings.anaglyph && finalProgram != 0) {
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, baseTextureId(minecraft));
	  	    GL11.glCopyTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, 0, 0, mc.displayWidth, mc.displayHeight, 0);
	  	    GL13.glActiveTexture(GL13.GL_TEXTURE1);
	        GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTextureId(minecraft));
	  	    GL13.glActiveTexture(GL13.GL_TEXTURE2);
	        GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTexture2Id(minecraft));
	  	    GL13.glActiveTexture(GL13.GL_TEXTURE0);
		    useProgram(finalProgram);
		    int sampler1U = ARBShaderObjects.glGetUniformLocationARB(finalProgram, "sampler1");
		    ARBShaderObjects.glUniform1iARB(sampler1U, 1);
		    int sampler2U = ARBShaderObjects.glGetUniformLocationARB(finalProgram, "sampler2");
		    ARBShaderObjects.glUniform1iARB(sampler2U, 2);
	        GL11.glClearColor(red, green, blue, 0.0F);
	        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
			GL11.glDisable(GL11.GL_DEPTH_TEST);
			GL11.glDisable(GL11.GL_BLEND);
	        GL11.glMatrixMode(5889 /*GL_PROJECTION*/);
	        GL11.glLoadIdentity();
	        GL11.glOrtho(0, mc.displayWidth, mc.displayHeight, 0, -1, 1);
	        GL11.glMatrixMode(5888 /*GL_MODELVIEW0_ARB*/);
	        GL11.glLoadIdentity();
			GL11.glBegin(GL11.GL_QUADS);
			GL11.glTexCoord2f(0, 1);
			GL11.glVertex3f(0, 0, 0);
			GL11.glTexCoord2f(0, 0);
			GL11.glVertex3f(0, mc.displayHeight, 0);
			GL11.glTexCoord2f(1, 0);
			GL11.glVertex3f(mc.displayWidth, mc.displayHeight, 0);
			GL11.glTexCoord2f(1, 1);
			GL11.glVertex3f(mc.displayWidth, 0, 0);
			GL11.glEnd();
			GL11.glEnable(GL11.GL_DEPTH_TEST);
		    useProgram(0);
		}
	}
	
	public static void copyDepthTexture(int texture, Minecraft minecraft) {
		mc = minecraft;
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
    	GL11.glCopyTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_DEPTH_COMPONENT, 0, 0, mc.displayWidth, mc.displayHeight, 0);
	}
	
    public static final Shaders instance = new Shaders();
	public int activeProgram = 0;

	public int baseProgram = 0;
	private int baseVShader = 0;
	private int baseFShader = 0;

	public int finalProgram = 0;
	private int finalVShader = 0;
	private int finalFShader = 0;
	
	private int baseTextureId = 0;
	private int baseTextureWidth = 0;
	private int baseTextureHeight = 0;

	private int depthTextureId = 0;
	private int depthTextureWidth = 0;
	private int depthTextureHeight = 0;

	private int depthTexture2Id = 0;
	private int depthTexture2Width = 0;
	private int depthTexture2Height = 0;
	
	public static Minecraft mc = null;
}
