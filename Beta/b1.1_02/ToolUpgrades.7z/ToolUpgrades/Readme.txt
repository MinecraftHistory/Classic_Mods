The ee.class file contains the modifications that make gold tools stronger.
The ce.class file contrains the modifications that make tools last longer.

They do not need to be used together if you do not wish to do so.

Like quite a few other mods, you're going to crash if you try to use this at the same time as any other mod that modifies these files.

Remember to delete your META-INF folder, or you'll be getting a black screen after you log in.