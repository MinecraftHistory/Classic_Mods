This is an unofficial update to the WildGrass mod to support "BetterLight" and "BetterGrass" from MrMessiah.

Install:

1) Use MrMessiah's patcher and install BOTH the BetterLight and BetterGrass options.
2) Copy all files from this folder into your "minecraft.jar"
3) Run the game, and hope it works.

All credits for WildGrass go to ejhopkins, I just tweaked it a bit.



MrMessiah Patcher:
http://www.minecraftforum.net/viewtopic.php?f=25&t=55700


ejhopkins Wild Grass:
http://www.minecraftforum.net/viewtopic.php?f=25&t=100771



