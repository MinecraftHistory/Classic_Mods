/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.input.Mouse;

public class ZanMinimap implements Runnable
{
  private Minecraft game;
  
  /*Textures for each zoom level*/
  private BufferedImage[] map = new BufferedImage[4];
  
  /*Block colour array*/
  private int[] bc = new int[256];
  
  private int q = 0;
  
  /*Current Menu Loaded*/
  public int iMenu = 1; 
  
  /*Display anything at all, menu, etc..*/
  private boolean enabled = true; 
  
  /*Hide just the minimap*/
  private boolean hide = false; 
  
  /*Was mouse down last render?*/
  private boolean lfclick = false; 
  
  /*Toggle full screen map*/
  private boolean full = false; 
  
  /*Is map calc thread still executing?*/
  public boolean active = false; 
  
  /*Current level of zoom*/
  private int zoom = 2; 
  
  /*Current build version*/
  public String zmodver = "v0.9.4";
  
  /*Menu input string*/
  private String inStr = "";
  
  /*Waypoint name temporary input*/
  private String way = "";
  
  /*Waypoint X coord temp input*/
  private int wayX = 0;
  
  /*Z coord temp input*/
  private int wayZ = 0;
  
  /*Colour or black and white minimap?*/
  private boolean rc = true;
  
  /*Holds error exceptions thrown*/
  private String error = "";
  
  /*Strings to show for menu*/
  private String[][] sMenu = new String[2][8];
  
  /*Time remaining to show error thrown for*/
  private int ztimer = 0;
  
  /*Minimap update interval*/
  private int timer = 0;
  
  /*Key entry interval*/
  private int fudge = 0;
  
  /*Last X coordinate rendered*/
  private int lastX = 0;
  
  /*Last Z coordinate rendered*/
  private int lastZ = 0;
  
  /*Last zoom level rendered at*/
  private int lZoom = 0;
  
  /*Menu level for next render*/
  private int next = 0;
  
  /*Cursor blink interval*/
  private int blink = 0;
  
  /*Last key down on previous render*/
  private int lastKey= 0;
  
  /*Direction you're facing*/
  private float direction = 0.0f;
  
  /*Last direction you were facing*/
  private float oldDir = 0.0f;
  
  /*Setting file access*/
  private File zanFile;
  
  /*World currently loaded*/
  private String world = "";
  
  /*Is the scrollbar being dragged?*/
  private boolean scrClick = false;
  
  /*Scrollbar drag start position*/
  private int scrStart = 0;
  
  /*Scrollbar offset*/
  private int sMin = 0;
  
  /*Scrollbar size*/
  private int sMax = 67;
  
  /*1st waypoint entry shown*/
  private int min = 0;
  
  /*Zoom key index*/
  private int zoomKey = Keyboard.KEY_Z;
  
  /*Menu key index*/
  private int menuKey = Keyboard.KEY_M;

  /*Square map toggle*/
  private boolean showmap = false;
  
  /*Show coordinates toggle*/
  private boolean coords = false;
  
  /*Dynamic lighting toggle*/
  private boolean lightmap = true;
  
  /*Terrain depth toggle*/
  private boolean heightmap = true;
  
  /*Show welcome message toggle*/
  private boolean welcome = true;
  
  /*Waypoint names and data*/
  private ArrayList<String> wayName;
  private ArrayList<Integer> xWay;
  private ArrayList<Integer> zWay;
  private ArrayList<Boolean> wayOn;

  /*Polygon creation class*/
  private jg lDraw = jg.a;
  
  /*Font rendering class*/
  private mj lang;
  
  /*Render texture*/
  private ge gl;
  
  /*Map calculation thread*/
  public Thread zCalc = new Thread(this);

  public ZanMinimap() {
    zCalc.start();
    this.map[0] = new BufferedImage(32,32,2);
    this.map[1] = new BufferedImage(64,64,2);
    this.map[2] = new BufferedImage(128,128,2);
    this.map[3] = new BufferedImage(256,256,2);
    for (int m = 0; m<2;m++)
        for(int n = 0; n<8;n++)
            this.sMenu[m][n] = "";
    this.sMenu[0][0] = "§4Zan's§F Mod! " + this.zmodver;
    this.sMenu[0][1] = "Welcome to the RawCritics client, there are a";
    this.sMenu[0][2] = "number of features and commands available to you.";
    this.sMenu[0][3] = "- Press §B" + Keyboard.getKeyName(zoomKey) + " §Fto zoom in/out, or §B"+ Keyboard.getKeyName(menuKey) + "§F for options.";
    this.sMenu[1][0] = "Options";
    this.sMenu[1][1] = "Display Coordinates:";
    this.sMenu[1][2] = "Hide Minimap:";
    this.sMenu[1][3] = "Dynamic Lighting:";
    this.sMenu[1][4] = "Terrain Depth:";
    this.sMenu[1][5] = "Square Map:";
    this.sMenu[1][6] = "Welcome Screen:";

    zanFile = new File(game.a("minecraft"), "zan.settings");
    try {
      if(zanFile.exists()) {
        BufferedReader in = new BufferedReader(new FileReader(zanFile));
        String sCurrentLine;
        while ((sCurrentLine = in.readLine()) != null) {
	  String[] curLine = sCurrentLine.split(":");
          if(curLine[0].equals("Show Minimap"))
              showmap = Boolean.parseBoolean(curLine[1]);
          else if(curLine[0].equals("Show Coordinates"))
              coords = Boolean.parseBoolean(curLine[1]);
          else if(curLine[0].equals("Dynamic Lighting"))
              lightmap = Boolean.parseBoolean(curLine[1]);
          else if(curLine[0].equals("Terrain Depth"))
              heightmap = Boolean.parseBoolean(curLine[1]);
          else if(curLine[0].equals("Welcome Message"))
              welcome = Boolean.parseBoolean(curLine[1]);
          else if(curLine[0].equals("Zoom Key"))
              zoomKey = Keyboard.getKeyIndex(curLine[1]);
          else if(curLine[0].equals("Menu Key"))
              menuKey = Keyboard.getKeyIndex(curLine[1]);
        }
        in.close();
      }
    } catch (Exception e) {}
    
    for(int i = 0; i<bc.length; i++)
        bc[i] = 0xff00ff;
    
    zanFile = new File(game.a("minecraft"), "colours.txt");
    try {
      if(!zanFile.exists()) {
        PrintWriter out = new PrintWriter(new FileWriter(zanFile));
        out.println("Block:1:686868");
        out.println("Block:2:74b44a");
        out.println("Block:3:79553a");
        out.println("Block:4:959595");
        out.println("Block:5:bc9862");
        out.println("Block:6:946428");
        out.println("Block:7:333333");
        out.println("Block:8:3256ff");
        out.println("Block:9:3256ff");
        out.println("Block:10:d96514");
        out.println("Block:11:d96514");
        out.println("Block:12:ddd7a0");
        out.println("Block:13:747474");
        out.println("Block:14:747474");
        out.println("Block:15:747474");
        out.println("Block:16:747474");
        out.println("Block:17:342919");
        out.println("Block:18:164d0c");
        out.println("Block:19:e5e54e");
        out.println("Block:20:ffffff");
        out.println("Block:35:f1f1f1");
        out.println("Block:37:f1f902");
        out.println("Block:38:f7070f");
        out.println("Block:39:916d55");
        out.println("Block:40:9a171c");
        out.println("Block:41:fefb5d");
        out.println("Block:42:e9e9e9");
        out.println("Block:43:a8a8a8");
        out.println("Block:44:a8a8a8");
        out.println("Block:45:aa543b");
        out.println("Block:46:db441a");
        out.println("Block:47:b4905a");
        out.println("Block:48:1f471f");
        out.println("Block:49:101018");
        out.println("Block:50:ffd800");
        out.println("Block:51:c05a01");
        out.println("Block:52:265f87");
        out.println("Block:53:bc9862");
        out.println("Block:54:8f691d");
        out.println("Block:55:480000");
        out.println("Block:56:747474");
        out.println("Block:57:82e4e0");
        out.println("Block:58:a26b3e");
        out.println("Block:59:00e210");
        out.println("Block:60:633f24");
        out.println("Block:61:747474");
        out.println("Block:62:747474");
        out.println("Block:63:b4905a");
        out.println("Block:64:7a5b2b");
        out.println("Block:65:ac8852");
        out.println("Block:66:a4a4a4");
        out.println("Block:67:9e9e9e");
        out.println("Block:68:9f844d");
        out.println("Block:69:695433");
        out.println("Block:70:8f8f8f");
        out.println("Block:71:c1c1c1");
        out.println("Block:72:bc9862");
        out.println("Block:73:747474");
        out.println("Block:74:747474");
        out.println("Block:75:290000");
        out.println("Block:76:fd0000");
        out.println("Block:77:747474");
        out.println("Block:78:fbffff");
        out.println("Block:79:8ebfff");
        out.println("Block:80:ffffff");
        out.println("Block:81:11801e");
        out.println("Block:82:ffffff");
        out.println("Block:83:a1a7b2");
        out.println("Block:84:aadb74");
        out.println("Block:85:9b664b");
        out.println("Block:86:bc9862");
        out.println("Block:87:582218");
        out.println("Block:88:996731");
        out.println("Block:89:cda838");
        out.println("Block:90:732486");
        out.println("Block:91:ff97sf");
        out.close();
      }
        BufferedReader in = new BufferedReader(new FileReader(zanFile));
        String sCurrentLine;
        while ((sCurrentLine = in.readLine()) != null) {
	  String[] curLine = sCurrentLine.split(":");
          if(curLine[0].equals("Block")&&curLine.length==3)
              bc[Integer.parseInt(curLine[1])] = Integer.parseInt(curLine[2], 16);
        }
        in.close();
    } catch (Exception e) {}
    
  }

  private void saveAll() {
      zanFile = new File(game.a("minecraft"), "zan.settings");
      try {
        PrintWriter out = new PrintWriter(new FileWriter(zanFile));
        out.println("Show Minimap:" + Boolean.toString(showmap));
        out.println("Show Coordinates:" + Boolean.toString(coords));
        out.println("Dynamic Lighting:" + Boolean.toString(lightmap));
        out.println("Terrain Depth:" + Boolean.toString(heightmap));
        out.println("Welcome Message:" + Boolean.toString(welcome));
        out.println("Zoom Key:" + Keyboard.getKeyName(zoomKey));
        out.println("Menu Key:" + Keyboard.getKeyName(menuKey));
        out.close();
      } catch (Exception local) { game.u.a("§EError Saving Settings"); }
  }
  
  private void saveWaypoints() {
      zanFile = new File(game.a("minecraft"), world + ".points");
      try {
        PrintWriter out = new PrintWriter(new FileWriter(zanFile));
        for(int i = 0; i<wayName.size();i++) {
            out.println(wayName.get(i) + ":" + xWay.get(i) + ":" + zWay.get(i) + ":" + Boolean.toString(wayOn.get(i)));
        }
        out.close();
      } catch (Exception local) { game.u.a("§EError Saving Waypoints"); }
  }
  
  private void loadWaypoints() {
      String j;
        if(this.game.e.w.equals("MpServer")) {
            String[] i = this.game.y.y.toLowerCase().split(":");
            j = i[0];
        } else j = this.game.e.w;
        if(!world.equals(j)) {
            world = j;
            iMenu = 1;
            wayName = new ArrayList<String>();
            xWay = new ArrayList<Integer>();
            zWay = new ArrayList<Integer>();
            wayOn = new ArrayList<Boolean>();
            zanFile = new File(game.a("minecraft"), world + ".points");
            try {
                if(zanFile.exists()) {
                    BufferedReader in = new BufferedReader(new FileReader(zanFile));
                    String sCurrentLine;
                    while ((sCurrentLine = in.readLine()) != null) {
                        String[] curLine = sCurrentLine.split(":");
                        wayName.add(curLine[0]);
                        xWay.add(Integer.parseInt(curLine[1]));
                        zWay.add(Integer.parseInt(curLine[2]));
                        wayOn.add(Boolean.parseBoolean(curLine[3]));
                    }
                    in.close();
                    game.u.a("§EWaypoints loaded for " + world);
                } else game.u.a("§EError: No waypoints exist for this world/server.");
            } catch (Exception local) {game.u.a("§EError Loading Waypoints");}
        }
  }

  public void renderAll(Minecraft mc) {
    if(game==null) game = mc;
    if (!zCalc.isAlive()) {
        zCalc = new Thread(this);
        zCalc.start();
    }
    
    if (!(this.game.p instanceof bd) && !(this.game.p instanceof kx) && (this.game.g.p!=-1))
                try {this.zCalc.notify();} catch (Exception local) {}
    
    if(lang==null) lang = this.game.o;
    if(gl==null) gl = this.game.n;
    lc scSize = new lc(game.c, game.d);
    int scWidth = scSize.a();
    int scHeight = scSize.b();
    
    if (Keyboard.isKeyDown(menuKey) && this.game.p==null) {
      this.iMenu = 2;
      this.game.a(new br());
    }
    if (Keyboard.isKeyDown(zoomKey) && this.game.p==null) {
      this.SetZoom();
    }
    
    loadWaypoints();
        
    if (this.iMenu==1) {
        if (!welcome) this.iMenu = 0;
    }

    if ((this.game.p instanceof ka) || (Keyboard.isKeyDown(61)) || (this.game.g.p==-1))
            this.enabled=false;
        else this.enabled=true;

    if (this.game.p==null && this.iMenu>1)
        this.iMenu = 0;
    
    scWidth -= 5;
    scHeight -= 5;

    if (this.oldDir != this.radius()) {
      this.direction += this.oldDir - this.radius();
      this.oldDir = this.radius();
    }

    if (this.direction >= 360.0f)
      while (this.direction >= 360.0f)
        this.direction -= 360.0f;
    if (this.direction < 0.0f) {
      while (this.direction < 0.0f)
        this.direction += 360.0f;
    }

    if ((!this.error.equals("")) && (this.ztimer == 0)) this.ztimer = 500;
    if (this.ztimer > 0) this.ztimer -= 1;
    if (this.fudge > 0) this.fudge -= 1;
    if ((this.ztimer == 0) && (!this.error.equals(""))) this.error = "";
    
    if (this.enabled) {
      renderMap(scWidth);
      if(this.full) renderMapFull(scWidth,scHeight);
      if (ztimer > 0)
        this.write(this.error, 20, 20, 0xffffff);
      if (this.iMenu>0) showMenu(scWidth, scHeight);
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      if(coords) showCoords(scWidth, scHeight);
    }
    while (active) try {Thread.currentThread().sleep(1);} catch (Exception local) {}
  }
  
  private void renderMap (int scWidth) {
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glDepthMask(false);
      GL11.glBlendFunc(770, 0);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      if (!this.hide && !this.full) {
      
      if (this.q != 0) this.gl.a(this.q);

      if (showmap) {
        if (this.zoom == 3) {
          GL11.glPushMatrix();
          GL11.glScalef(0.5f, 0.5f, 1.0f);
          this.q = this.tex(this.map[this.zoom]);
          GL11.glPopMatrix();
        } else this.q = this.tex(this.map[this.zoom]);
        lDraw.b();
        this.setMap(scWidth);
        lDraw.a();
        try {
          this.disp(this.img("/minimap.png"));
          lDraw.b();
          this.setMap(scWidth);
          lDraw.a(); } catch (Exception localException) {
          this.error = "error: minimap overlay not found!";
        }
        try {
          GL11.glPushMatrix();
          this.disp(this.img("/mmarrow.png"));
          lDraw.b();
          this.setMap(scWidth);
          GL11.glTranslatef(scWidth - 32.0F, 37.0F, 0.0F);
          GL11.glRotatef(-this.direction - 90.0F, 0.0F, 0.0F, 1.0F);
          GL11.glTranslatef(-(scWidth - 32.0F), -37.0F, 0.0F);
          lDraw.a();
          GL11.glPopMatrix();
        } catch (Exception localException) {
          this.error = "Error: minimap arrow not found!";
        }
      } else {
        GL11.glPushMatrix();
        if (this.zoom == 3) {
          GL11.glPushMatrix();
          GL11.glScalef(0.5f, 0.5f, 1.0f);
          this.q = this.tex(this.map[this.zoom]);
          GL11.glPopMatrix();
        } else this.q = this.tex(this.map[this.zoom]);
        lDraw.b();
        this.setMap(scWidth);
        GL11.glTranslatef(scWidth - 32.0F, 37.0F, 0.0F);
        GL11.glRotatef(this.direction + 90.0F, 0.0F, 0.0F, 1.0F);
        GL11.glTranslatef(-(scWidth - 32.0F), -37.0F, 0.0F);
        if(this.zoom==0) GL11.glTranslatef(-1.1f, -0.8f, 0.0f);
          else GL11.glTranslatef(-0.5f, -0.5f, 0.0f);
        lDraw.a();
        GL11.glPopMatrix();
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        for(int n = 0;n<this.wayName.size();n++) {
            if(this.wayOn.get(n)) {
                int wayX = this.xCoord() - this.xWay.get(n);
                int wayY = this.yCoord() - this.zWay.get(n);
                float locate = (float)Math.toDegrees(Math.atan2(wayX, wayY));
                double hypot = Math.sqrt((wayX*wayX)+(wayY*wayY))/(Math.pow(2,this.zoom)/2);
                if (hypot >= 31.0D) {
                    try {
                        GL11.glPushMatrix();
                        this.disp(this.img("/marker.png"));
                        lDraw.b();
                        this.setMap(scWidth);
                        GL11.glTranslatef(scWidth - 32.0F, 37.0F, 0.0F);
                        GL11.glRotatef(-locate + this.direction + 180.0F, 0.0F, 0.0F, 1.0F);
                        GL11.glTranslatef(-(scWidth - 32.0F), -37.0F, 0.0F);
                        GL11.glTranslated(0.0D,-34.0D,0.0D);
                        lDraw.a();
                        GL11.glPopMatrix();
                    } catch (Exception localException) {
                        this.error = "Error: marker overlay not found!";
                    }
                }
            }
        }
        this.drawRound(scWidth);
        this.drawDirections(scWidth);
        for(int n = 0;n<this.wayName.size();n++) {
            if(this.wayOn.get(n)) {
                int wayX = this.xCoord() - this.xWay.get(n);
                int wayY = this.yCoord() - this.zWay.get(n);
                float locate = (float)Math.toDegrees(Math.atan2(wayX, wayY));
                double hypot = Math.sqrt((wayX*wayX)+(wayY*wayY))/(Math.pow(2,this.zoom)/2);
                if ( hypot < 31.0D) {
                    try {
                        GL11.glPushMatrix();
                        this.disp(this.img("/waypoint.png"));
                        lDraw.b();
                        this.setMap(scWidth);
                        GL11.glTranslatef(scWidth - 32.0F, 37.0F, 0.0F);
                        GL11.glRotatef(-locate + this.direction + 180.0F, 0.0F, 0.0F, 1.0F);
                        GL11.glTranslated(0.0D,-hypot,0.0D);
                        GL11.glRotatef(-(-locate + this.direction + 180.0F), 0.0F, 0.0F, 1.0F);
                        GL11.glTranslated(0.0D,hypot,0.0D);
                        GL11.glTranslatef(-(scWidth - 32.0F), -37.0F, 0.0F);
                        GL11.glTranslated(0.0D,-hypot,0.0D);
                        lDraw.a();
                        GL11.glPopMatrix();
                    } catch (Exception localException) {
                        this.error = "Error: waypoint overlay not found!";}
                }
            }
      }}}
  }
  
  private void renderMapFull (int scWidth, int scHeight) {
      this.q = this.tex(this.map[this.zoom]);
          lDraw.b();
          lDraw.a((scWidth+5)/2-128, (scHeight+5)/2+128, 1.0D, 0.0D, 1.0D);
          lDraw.a((scWidth+5)/2+128, (scHeight+5)/2+128, 1.0D, 1.0D, 1.0D);
          lDraw.a((scWidth+5)/2+128, (scHeight+5)/2-128, 1.0D, 1.0D, 0.0D);
          lDraw.a((scWidth+5)/2-128, (scHeight+5)/2-128, 1.0D, 0.0D, 0.0D);
          lDraw.a();
          try {
          GL11.glPushMatrix();
          this.disp(this.img("/mmarrow.png"));
          lDraw.b();
          lDraw.a((scWidth+5)/2-32, (scHeight+5)/2+32, 1.0D, 0.0D, 1.0D);
          lDraw.a((scWidth+5)/2+32, (scHeight+5)/2+32, 1.0D, 1.0D, 1.0D);
          lDraw.a((scWidth+5)/2+32, (scHeight+5)/2-32, 1.0D, 1.0D, 0.0D);
          lDraw.a((scWidth+5)/2-32, (scHeight+5)/2-32, 1.0D, 0.0D, 0.0D);
          GL11.glTranslatef((scWidth+5)/2, (scHeight+5)/2, 0.0F);
          GL11.glRotatef(-this.direction - 90.0F, 0.0F, 0.0F, 1.0F);
          GL11.glTranslatef(-((scWidth+5)/2), -((scHeight+5)/2), 0.0F);
          lDraw.a();
          GL11.glPopMatrix();
        } catch (Exception localException) {
          this.error = "Error: minimap arrow not found!";
        }
  }
  
  private void showMenu (int scWidth, int scHeight) {
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        int m;
        int maxSize = 0;
        int border = 2;
        boolean set = false;
        boolean click = false;
        int MouseX = Mouse.getX()*(scWidth+5)/this.game.c;
        int MouseY = (scHeight+5) - Mouse.getY() * (scHeight+5) / this.game.d - 1;
        if (Mouse.getEventButtonState() && Mouse.getEventButton() == 0)
            if (!this.lfclick) {
                set = true;
                this.lfclick = true;
            } else click = true;
        else if (this.lfclick) this.lfclick = false;
        String head = "Waypoints";
        String opt1 = "Exit Menu";
        String opt2 = "Waypoints";
        String opt3 = "Remove";
        if(this.iMenu<3) {
            head = this.sMenu[this.iMenu-1][0];
            for(m=1;!(this.sMenu[iMenu-1][m].equals(""));m++)
              if (this.chkLen(sMenu[iMenu-1][m])>maxSize) maxSize = this.chkLen(sMenu[iMenu-1][m]);
        } else {
            opt1 = "Back";
            if (this.iMenu==4) opt2 = "Cancel";
            else opt2 = "Add";
            maxSize = 80;
            for(int i = 0; i<wayName.size();i++)
                if(chkLen((i+1) + ") " + wayName.get(i))>maxSize)
                    maxSize = chkLen((i+1) + ") " + wayName.get(i));
            m = 10;
        }
        int title = this.chkLen(head);
        int centerX = (int)((scWidth+5)/2.0D);
        int centerY = (int)((scHeight+5)/2.0D);
        String hide = "§7Press §F" + Keyboard.getKeyName(zoomKey) + "§7 to hide.";
        int footer = this.chkLen(hide);
        
        GL11.glDisable(3553);
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.7f);

        double leftX = centerX - title/2.0D - border;
        double rightX = centerX + title/2.0D + border;
        double topY = centerY - (m-1)/2.0D*10.0D - border - 20.0D;
        double botY = centerY - (m-1)/2.0D*10.0D + border - 10.0D;
        this.drawBox(leftX, rightX, topY, botY);

        if(this.iMenu==1) {
          leftX = centerX - maxSize/2.0D - border;
          rightX = centerX + maxSize/2.0D + border;
          topY = centerY - (m-1)/2.0D*10.0D - border;
          botY = centerY + (m-1)/2.0D*10.0D + border;
          this.drawBox(leftX, rightX, topY, botY);
          leftX = centerX - footer/2.0D - border;
          rightX = centerX + footer/2.0D + border;
          topY = centerY + (m-1)/2.0D*10.0D - border + 10.0D;
          botY = centerY + (m-1)/2.0D*10.0D + border + 20.0D;
          this.drawBox(leftX, rightX, topY, botY);
        } else {
          leftX = centerX - maxSize/2.0D - 25 - border;
          rightX = centerX + maxSize/2.0D + 25 + border;
          topY = centerY - (m-1)/2.0D*10.0D - border;
          botY = centerY + (m-1)/2.0D*10.0D + border;
          this.drawBox(leftX, rightX, topY, botY);
          this.drawOptions(rightX-border, topY+border, MouseX, MouseY, set, click);
          footer = this.drawFooter(centerX, centerY, m, opt1, opt2, opt3, border, MouseX, MouseY, set, click);
        }
        GL11.glEnable(3553);
        this.write(head, centerX - title/2, (centerY - (m-1)*10/2) - 19, 0xffffff);
        if(this.iMenu==1) {
          for(int n=1;n<m;n++)
            this.write(this.sMenu[iMenu - 1][n], centerX - maxSize/2, ((centerY - (m-1)*10/2) + (n * 10))-9, 0xffffff);
          this.write(hide, centerX - footer/2, ((scHeight+5)/2 + (m-1)*10/2 + 11), 0xffffff);
        } else {
            if(this.iMenu==2) {
                for(int n=1;n<m;n++) {
                    this.write(this.sMenu[iMenu - 1][n], (int)leftX + border + 1, ((centerY - (m-1)*10/2) + (n * 10))-9, 0xffffff);
                    if(this.chkOptions(n-1)) hide = "On"; else hide = "Off";
                    this.write(hide, (int)rightX - border - 15 - this.chkLen(hide)/2, ((centerY - (m-1)*10/2) + (n * 10))-8, 0xffffff);
                }
            } else {
                int max = min+9;
                if(max>wayName.size()) {
                    max = wayName.size();
                    if(min>=0) {
                        if(max-9>0)
                            min = max-9;
                        else
                            min = 0;
                    }
                }
                for(int n=min;n<max;n++) {
                    int yTop = ((centerY - (m-1)*10/2) + ((n+1-min) * 10));
                    int leftTxt = (int)leftX + border + 1;
                    this.write((n+1) + ") " + this.wayName.get(n), leftTxt, yTop-9, 0xffffff);
                    if(this.iMenu==4) {
                        hide = "X";
                    } else {
                        if(this.wayOn.get(n)) hide = "On";
                        else hide = "Off";
                    }
                    this.write(hide, (int)rightX - border - 29 - this.chkLen(hide)/2, yTop-8, 0xffffff);
                    if (MouseX>leftTxt && MouseX<(rightX-border-45) && MouseY>yTop-10 && MouseY<yTop-1) {
                        String out = xWay.get(n) + ", " + zWay.get(n);
                        int len = chkLen(out)/2;
                        GL11.glDisable(3553);
                        GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.8f);
                        this.drawBox(MouseX-len-1, MouseX+len+1, MouseY-11, MouseY-1);
                        GL11.glEnable(3553);
                        this.write(out, MouseX-len, MouseY-10, 0xffffff);
                    }
                }
            }
            int footpos = ((scHeight+5)/2 + (m-1)*10/2 + 11);
            if (this.iMenu==2) {
                this.write(opt1, centerX - 5 - border - footer - this.chkLen(opt1)/2, footpos , 16777215);
                this.write(opt2, centerX + border +5 + footer - this.chkLen(opt2)/2, footpos, 16777215);
            } else {
                if (this.iMenu!=4)this.write(opt1, centerX - 5 - border*2 - footer*2 - this.chkLen(opt1)/2, footpos, 16777215);
                this.write(opt2, centerX - this.chkLen(opt2)/2, footpos, 16777215);
                if (this.iMenu!=4)this.write(opt3, centerX + 5 + border*2 + footer*2 - this.chkLen(opt3)/2, footpos, 16777215);
            }
        }
        if (this.iMenu>4) {
            String verify = " !\"#$%&'()*+,-./0123456789;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~⌂ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»";
            if(this.iMenu>5 && this.inStr.equals("")) verify = "-0123456789";
            else if (this.iMenu>5) verify = "0123456789";
            if(Keyboard.getEventKeyState()) {
                do {
                if(Keyboard.getEventKey() == Keyboard.KEY_RETURN && this.lastKey!= Keyboard.KEY_RETURN)
                    if (this.inStr.equals(""))
                        this.next = 3;
                    else if(this.iMenu == 5) {
                        this.next = 6;
                        this.way = this.inStr;
                        this.inStr = Integer.toString(this.xCoord());
                    } else if (this.iMenu==6) {
                        this.next = 7;
                        try {this.wayX = Integer.parseInt(this.inStr);} catch (Exception localException) {this.next=3;}
                        this.inStr = Integer.toString(this.yCoord());
                    } else {
                        this.next = 3;
                        try {this.wayZ = Integer.parseInt(this.inStr);} catch (Exception localException) {this.inStr="";}
                        if(!this.inStr.equals("")) {
                            wayName.add(this.way);
                            xWay.add(wayX);
                            zWay.add(wayZ);
                            wayOn.add(true);
                            this.saveWaypoints();
                            if(wayName.size()>9) min = wayName.size()-9;
                        }
                    }
                else if (Keyboard.getEventKey() == Keyboard.KEY_BACK && this.lastKey!= Keyboard.KEY_BACK)
                    if (this.inStr.length() > 0)
                        this.inStr = this.inStr.substring(0, this.inStr.length()-1);
                if(verify.indexOf(Keyboard.getEventCharacter()) >= 0 && Keyboard.getEventKey()!= this.lastKey)
                    if(this.chkLen(this.inStr + Keyboard.getEventCharacter()) < 148)
                        this.inStr = this.inStr + Keyboard.getEventCharacter();
                this.lastKey = Keyboard.getEventKey();
                } while (Keyboard.next());
            } else this.lastKey = 0;
            GL11.glDisable(3553);
            GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.7f);
            leftX = centerX - 75 - border;
            rightX = centerX + 75 + border;
            topY = centerY - 10 - border;
            botY = centerY + 10 + border;
            this.drawBox(leftX, rightX, topY, botY);
            leftX = leftX+border;
            rightX = rightX-border;
            topY = topY + 11;
            botY = botY - border;
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
            this.drawBox(leftX, rightX, topY, botY);
            GL11.glEnable(3553);
            String out = "Please enter a name:";
            if(this.iMenu==6) out = "Enter X coordinate:";
            else if(this.iMenu == 7) out = "Enter Z coordinate:";
            this.write(out, (int)leftX + border, (int)topY-11 + border, 0xffffff);
            if(this.blink>60)this.blink=0;
            if(this.blink<30)this.write(this.inStr + "|", (int)leftX + border, (int)topY + border, 0xffffff);
            else this.write(this.inStr, (int)leftX + border, (int)topY + border, 0xffffff);
            if(this.iMenu==6)
                try{if(Integer.parseInt(this.inStr)==this.xCoord()) this.write("(Current)", (int)leftX + border + this.chkLen(this.inStr) + 5, (int)topY + border, 0xa0a0a0);}
                  catch(Exception localException) {}
            else if (this.iMenu==7)
                try{if(Integer.parseInt(this.inStr)==this.yCoord()) this.write("(Current)", (int)leftX + border + this.chkLen(this.inStr) + 5, (int)topY + border, 0xa0a0a0);}
                  catch(Exception localException) {}
            this.blink++;
        }
        if(this.next!=0) {this.iMenu = this.next; this.next = 0;}
  }
  
  private void showCoords (int scWidth, int scHeight) {
      if(!this.hide) {
        GL11.glPushMatrix();
        GL11.glScalef(0.5f, 0.5f, 1.0f);
        String xy = this.dCoord(xCoord()) + ", " + this.dCoord(yCoord());
        int m = this.chkLen(xy)/2;
        this.write(xy, scWidth*2-32*2-m, 146, 0xffffff);
        xy = Integer.toString(this.zCoord());
        m = this.chkLen(xy)/2;
        this.write(xy, scWidth*2-32*2-m, 156, 0xffffff);
        GL11.glPopMatrix();
      } else this.write("(" + this.dCoord(xCoord()) + ", " + this.zCoord() + ", " + this.dCoord(yCoord()) + ") " + (int) this.direction + "'", 2, 2, 0xffffff);
  }

  private void drawRound(int paramInt1) {
      try {
        this.disp(this.img("/roundmap.png"));
        this.lDraw.b();
        this.setMap(paramInt1);
        this.lDraw.a(); } catch (Exception localException) {
        this.error = "Error: minimap overlay not found!";
      }
  }

  private void drawBox(double leftX, double rightX, double topY, double botY) {
      lDraw.b();
      lDraw.a(leftX, botY, 0.0D);
      lDraw.a(rightX, botY, 0.0D);
      lDraw.a(rightX, topY, 0.0D);
      lDraw.a(leftX, topY, 0.0D);
      lDraw.a();
  }

  private void drawOptions(double rightX,double topY,int MouseX,int MouseY,boolean set,boolean click) {
      if(this.iMenu>2) {
          if(min<0) min = 0;
          if(!Mouse.isButtonDown(0) && scrClick) scrClick = false;
          if (MouseX>(rightX-10) && MouseX<(rightX-2) && MouseY>(topY+1) && MouseY<(topY+10)) {
              if(set || click) {
                  if(set&&min>0) min--;
                  GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.7f);
              } else GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
          }
          else
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.3f);
          lDraw.b();
          lDraw.a(rightX-10, topY+10, 0.0D);
          lDraw.a(rightX-2, topY+10, 0.0D);
          lDraw.a(rightX-6, topY+1, 0.0D);
          lDraw.a(rightX-6, topY+1, 0.0D);
          lDraw.a();
          
          if(wayName.size()>9) {
              sMax = (int)(9.0D/wayName.size()*67.0D);
          } else {
              sMin = 0;
              sMax = 67;
          }
          
          if (MouseX>rightX-10 && MouseX<rightX-2 && MouseY>topY+12+sMin && MouseY<topY+12+sMin+sMax || scrClick) {
              if(Mouse.isButtonDown(0)&&!scrClick) {
                  scrClick = true;
                  scrStart = MouseY;
              } else if (scrClick && wayName.size()>9) {
                  int offset = MouseY-scrStart;
                  if(sMin+offset<0) sMin = 0;
                  else if (sMin+offset+sMax>67) sMin = 67-sMax;
                  else { sMin = sMin+offset; scrStart = MouseY; }
                  min = (int)((sMin/(67.0D-sMax))*(wayName.size()-9));
                  GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.7f);
              } else GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
          } else {
              if(wayName.size()>9)
                  sMin = (int)((double)min/(double)(wayName.size()-9)*(67.0D-sMax));
              GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.3f);
          }
          this.drawBox(rightX-10, rightX-2, topY+12+sMin, topY+12+sMin+sMax);
          if (MouseX>rightX-10 && MouseX<rightX-2 && MouseY>topY+81 && MouseY<topY+90) {
              if(set || click) {
                  if(set&&min<wayName.size()-9) min++;
                  GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.7f);
              } else GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
          }
          else
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.3f);
          lDraw.b();
          lDraw.a(rightX-6, topY+90, 0.0D);
          lDraw.a(rightX-6, topY+90, 0.0D);
          lDraw.a(rightX-2, topY+81, 0.0D);
          lDraw.a(rightX-10, topY+81, 0.0D);
          lDraw.a();
      }
      double leftX = rightX - 30;
      double botY = 0;
      topY+=1;
      
      int max = min+9;
      if(max>wayName.size()) {
          max = wayName.size();
          if(min>0) {
              if(max-9>0)
                  min = max-9;
              else
                  min = 0;
          }
      }
      
      if(this.iMenu>2) {
          leftX = leftX - 14;
          rightX = rightX - 14;
      } else { min = 0; max = 6; }
      for(int i = min; i<max; i++) {
          if(i>min) topY += 10;
          botY = topY + 9;
          if (MouseX>leftX && MouseX<rightX && MouseY>topY && MouseY<botY && this.iMenu < 5)
              if (set || click) {
                  if(set) {
                      if(this.iMenu==2)this.setOptions(i);
                      else if (this.iMenu==3) { wayOn.set(i, !wayOn.get(i)); this.saveWaypoints(); }
                      else {this.delWay(i);this.next=3;}
                  }
                  GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
              } else GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.6f);
          else {
              if(this.iMenu==2) {
                  if (this.chkOptions(i)) GL11.glColor4f(0.0f, 1.0f, 0.0f, 0.6f);
                  else GL11.glColor4f(1.0f, 0.0f, 0.0f, 0.6f);
              } else if (this.iMenu==4) {
                  GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.4f);
              } else {
                  if (wayOn.get(i)) {
                      GL11.glColor4f(0.0f, 1.0f, 0.0f, 0.6f);
                  } else GL11.glColor4f(1.0f, 0.0f, 0.0f, 0.6f);
              }

          }
          this.drawBox(leftX, rightX, topY, botY);
      }
  }

  private void delWay(int i) {
      wayName.remove(i);
      xWay.remove(i);
      zWay.remove(i);
      wayOn.remove(i);
      this.saveWaypoints();
  }

  private int drawFooter(int centerX,int centerY,int m, String opt1, String opt2, String opt3, int border,int MouseX,int MouseY,boolean set,boolean click) {
    int footer = this.chkLen(opt1);
    if (this.chkLen(opt2) > footer) footer = this.chkLen(opt2);
    double leftX = centerX - footer - border*2 - 5;
    double rightX = centerX - 5;
    double topY = centerY + (m-1)/2.0D*10.0D - border + 10.0D;
    double botY = centerY + (m-1)/2.0D*10.0D + border + 20.0D;
    if (this.iMenu>2) {
        if (this.chkLen(opt3) > footer) footer = this.chkLen(opt3);
        leftX = centerX - border*3 - footer*1.5 - 5;
        rightX = centerX - footer/2 - border - 5;
    }
    if (MouseX>leftX && MouseX<rightX && MouseY>topY && MouseY<botY && this.iMenu < 4)
      if (set || click) {
        if(set) {
            if (this.iMenu==2) this.game.p=null;
            else this.next=2;
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
      } else GL11.glColor4f(0.5f, 0.5f, 0.5f, 0.7f);
    else GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.7f);
    if (this.iMenu!=4)this.drawBox(leftX, rightX, topY, botY);
    if (this.iMenu==2) {
        leftX = centerX + 5;
        rightX = centerX + footer + border*2 + 5;
    } else {
        leftX = centerX - footer/2 - border;
        rightX = centerX + footer/2 + border;
    }
    if (MouseX>leftX && MouseX<rightX && MouseY>topY && MouseY<botY && this.iMenu < 5)
      if (set || click) {
        if(set) {
            if (this.iMenu==2 || this.iMenu==4) this.next=3;
            else {this.next = 5; this.inStr = ""; }
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
      } else GL11.glColor4f(0.5f, 0.5f, 0.5f, 0.7f);
    else GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.7f);
    this.drawBox(leftX, rightX, topY, botY);
    if (this.iMenu > 2) {
        rightX = centerX + border*3 + footer*1.5 + 5;
        leftX = centerX + footer/2 + border + 5;
        if (MouseX>leftX && MouseX<rightX && MouseY>topY && MouseY<botY && this.iMenu < 4)
            if (set || click) {
                if(set) this.next = 4;
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            } else GL11.glColor4f(0.5f, 0.5f, 0.5f, 0.7f);
        else GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.7f);
        if (this.iMenu!=4) this.drawBox(leftX, rightX, topY, botY);
    }
    return footer/2;
  }

  private boolean chkOptions(int i) {
      if (i==0) return coords;
      else if (i==1) return this.hide;
      else if (i==2) return lightmap;
      else if (i==3) return heightmap;
      else if (i==4) return showmap;
      else return welcome;
  }

  private void setOptions(int i) {
      if (i==0) coords = !coords;
      else if (i==1) this.hide = !this.hide;
      else if (i==2) lightmap = !lightmap;
      else if (i==3) heightmap = !heightmap;
      else if (i==4) showmap = !showmap;
      else welcome = !welcome;
      this.saveAll();
      this.timer=500;
  }

  private void setMap(int paramInt1) {
      lDraw.a(paramInt1 - 64.0D, 64.0D + 5.0D, 1.0D, 0.0D, 1.0D);
      lDraw.a(paramInt1, 64.0D + 5.0D, 1.0D, 1.0D, 1.0D);
      lDraw.a(paramInt1, 5.0D, 1.0D, 1.0D, 0.0D);
      lDraw.a(paramInt1 - 64.0D, 5.0D, 1.0D, 0.0D, 0.0D);
  }

  private void drawDirections(int paramInt1) {
      GL11.glPushMatrix();
      GL11.glScalef(0.5f, 0.5f, 1.0f);
      GL11.glTranslated((64.0D * Math.sin(Math.toRadians(-(this.direction-90.0D)))),(64.0D * Math.cos(Math.toRadians(-(this.direction-90.0D)))),0.0D);
      this.write("N", paramInt1*2-66, 70, 0xffffff);
      GL11.glPopMatrix();

      GL11.glPushMatrix();
      GL11.glScalef(0.5f, 0.5f, 1.0f);
      GL11.glTranslated((64.0D * Math.sin(Math.toRadians(-this.direction))),(64.0D * Math.cos(Math.toRadians(-this.direction))),0.0D);
      this.write("E", paramInt1*2-66, 70, 0xffffff);
      GL11.glPopMatrix();

      GL11.glPushMatrix();
      GL11.glScalef(0.5f, 0.5f, 1.0f);
      GL11.glTranslated((64.0D * Math.sin(Math.toRadians(-(this.direction+90.0D)))),(64.0D * Math.cos(Math.toRadians(-(this.direction+90.0D)))),0.0D);
      this.write("S", paramInt1*2-66, 70, 0xffffff);
      GL11.glPopMatrix();

      GL11.glPushMatrix();
      GL11.glScalef(0.5f, 0.5f, 1.0f);
      GL11.glTranslated((64.0D * Math.sin(Math.toRadians(-(this.direction+180.0D)))),(64.0D * Math.cos(Math.toRadians(-(this.direction+180.0D)))),0.0D);
      this.write("W", paramInt1*2-66, 70, 0xffffff);
      GL11.glPopMatrix();
  }

  private void SetZoom() {
    if (this.fudge > 0) return;
    if (this.iMenu != 0) {
        this.iMenu = 0;
        if(this.game.p!=null) this.game.p=null;
    }
    else {
        if (this.zoom == 3) {
            if(!this.full) this.full = true;
            else {
                this.zoom = 2;
                this.full = false;
                this.error = "Zoom Level: (1.0x)";
            }
        } else if (this.zoom == 0) {
            this.zoom = 3;
            this.error = "Zoom Level: (0.5x)";
        } else if (this.zoom==2) {
            this.zoom = 1;
            this.error = "Zoom Level: (2.0x)";
        } else {
            this.zoom = 0;
            this.error = "Zoom Level: (4.0x)";
        }
        this.timer = 500;
    }
    this.fudge = 20;
  }

  private int chkLen(String paramStr) {
      return this.lang.a(paramStr);
  }

  private void write(String paramStr, int paramInt1, int paramInt2, int paramInt3) {
      this.lang.a(paramStr, paramInt1, paramInt2, paramInt3);
  }

  private int xCoord() {
      int x = (int)this.game.g.aG;
      if (this.game.g.aG < 0.0D) x--;
      return x;
  }

  private int yCoord() {
      int y = (int)this.game.g.aI;
      if (this.game.g.aI < 0.0D) y--;
      return y;
  }

  private int zCoord() {
      return (int)this.game.g.aH;
  }

  private float radius() {
      return this.game.g.aM;
  }

  private String dCoord(int paramInt1) {
      if(paramInt1<0)
          return "-" + Math.abs(paramInt1+1);
      else
          return "+" + paramInt1;
  }

  private int tex(BufferedImage paramImg) {
      return this.gl.a(paramImg);
  }

  private int img(String paramStr) {
      return this.gl.a(paramStr);
  }

  private void disp(int paramInt) {
      this.gl.b(paramInt);
  }

  public void run() {
      while(true){
          this.active = true;
          while(this.game.g.p!=-1 && active) {
            if (this.enabled && !this.hide)
                if(((this.lastX!=this.xCoord()) || (this.lastZ!=this.yCoord()) || (this.timer>300)))
                    try {this.mapCalc(); this.timer = 1;} catch (Exception local) {}
            this.timer++;
            this.active = false;
          }
          active = false;
          try {this.zCalc.sleep(10);} catch (Exception exc) {}
          try {this.zCalc.wait(0);} catch (Exception exc) {}
      }
  }
  
  private void mapCalc() {
    dd data = this.game.e;
    this.lZoom = this.zoom;
    int multi = (int)Math.pow(2, this.lZoom);
    int i = this.xCoord();
    int j = this.yCoord();
    this.lastX = i;
    this.lastZ = j;
    i -= 16*multi;
    j += 16*multi;
      int k = 0;
      for (int m = 0; m < 32 * multi; m++) {
        for (int n = 0; n < 32 * multi; n++) {
          k = 0;
          boolean check = false;
          if (Math.sqrt((16 * multi - m) * (16 * multi - m) + (16 * multi - n) * (16 * multi - n)) < ((16 * multi)-((int)Math.sqrt(multi)))) check = true;

          int i1 = data.f(i + m, j - n);
          if ((check) || (showmap) || (this.full)) {
            if (this.rc) {
                if ((data.f(i + m, i1, j - n) == hm.s) || (data.f(i + m, i1, j - n) == hm.t)) k = 16777215; else {
                  k = this.bc[data.a(i + m, i1 - 1, j - n)]; }
            } else k = 16777215;
          }
          
          if ((k != this.bc[0]) && (k != 0) && ((check) || (showmap) || (this.full))) {
            if (heightmap) {
                int i2 = i1-this.zCoord();
                double sc = Math.log10(Math.abs(i2)/8.0D+1.0D)/1.3D;
                int r = k/0x10000;
                int g = (k-r*0x10000)/0x100;
                int b = (k-r*0x10000-g*0x100);
                if (i2>=0) {
                  r = (int)(sc*(0xff-r)) + r;
                  g = (int)(sc*(0xff-g)) + g;
                  b = (int)(sc*(0xff-b)) + b;
                } else {
                  i2=Math.abs(i2);
                  r = r -(int)(sc*r);
                  g = g -(int)(sc*g);
                  b = b -(int)(sc*b);
                }
                k = r*0x10000 + g*0x100 + b;
            }
            int i3 = 255;
            if (lightmap)
              i3 = data.a(i + m, i1, j - n, false) * 17;
            if(i3>255)i3=255;
            if(i3<32)i3=32;
            k = i3 * 0x1000000 + k;
          }
          this.map[this.lZoom].setRGB(n, m, k);
        }
      }
  }
}
