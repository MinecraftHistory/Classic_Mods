Handheld Torch Light v1.4
by Cryect

This mod changes the game so when the player is holding a torch it casts light that moves with the player. Currently it only works in single player.

Installation
Find where your minecraft.jar is located and open it up with a program that can manipulate JARs.  Delete the meta-inf folder if it is there and copy in all the class files from this zip.

History
V1.4 - Works for Beta 1.1_02 and additional performance improvements
V1.3 - Performance improvements
V1.2 - Fixes AO. Restores sorting on every tick but might cause some potential issues on chunk boundaries
V1.1 - Should now work with modloader
V1.0 - Original release