Minerals! rev 9
Adds new minerals to the game!

Put files from folder "JAR" into the minecraft.jar.
If you have ID conflicts between mods, let the game run once, close it and change IDs in file modMinerals.properties in folder where you have Minecraft.exe.
If you can't run the game because of conflicts, copy the file from folder "Minecraft_exe" into folder with Minecraft.exe.

Block IDs can be 1 - 127, item ID 256 - about 30000.
Blocks in the file are prefixed with "b", items with "i".

Classes this mod overwrites and for which modules you need them:
cs.class - for moduleFirestone
db.class - for moduleFirestone and moduleObsidian
ed.class - for moduleFirestone and moduleObsidian
fn.class - for moduleIvy
im.class - for moduleFirestone
iq.class - for moduleObsidian
iv.class - for moduleFrostrock
ma.class - for moduleFirestone
pe.class - for moduleFirestone

So - if you don't want to overwrite for example cs.class (because of mod conflicts), then just don't overwrite it and set moduleFirestone to false in modMinerals.properties.