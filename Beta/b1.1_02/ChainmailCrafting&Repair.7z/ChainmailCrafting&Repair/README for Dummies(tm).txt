If there is a folder named 'Source Code' then the contents of that folder will be the source code for the mod. If you dont know what source code is THEN YOU DONT NEED IT.  Move along grasshopper.

If there is a folder named 'resources' then THE ENTIRE CONTENTS of that folder need placed inside your .minecraft/resources folder. If you dont know where this is DONT ASK ME.  Use google.

The folder named 'minecraftjar' needs its ENTIRE CONTENTS drug directly inside your minecraft.jar.  This means open it, highlight EVERYTHING THERE INCLUDING ALL FOLDERS, and drag them where you were told.  its that simple.  Dont ask for help if you cant understand this, i will laugh at you.