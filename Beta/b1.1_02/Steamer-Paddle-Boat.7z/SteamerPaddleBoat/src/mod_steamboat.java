package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.util.Map;

public class mod_steamboat extends BaseMod
{

    public mod_steamboat()
    {
        ModLoader.AddName(steamBoat, "Steam Boat");
        ModLoader.RegisterEntityID(EntitySteamBoat.class, "SteamBoat", entityID);
    }

    public void AddRecipes(CraftingManager craftingmanager)
    {
        craftingmanager.addRecipe(new ItemStack(steamBoat, 1), new Object[] {
            "#X#", "###", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.ingotIron
        });
    }

    public void RegisterTextureOverrides()
    {
        ModLoader.addOverride("/gui/items.png", "/gui/steamboat.png", spriteindex);
    }

    public void AddRenderer(Map map)
    {
        map.put(EntitySteamBoat.class, new RenderSteamBoat());
    }

    public static int spriteindex;
    public static int entityID = ModLoader.getUniqueEntityId();
    public static Item steamBoat;

    static 
    {
        spriteindex = ModLoader.getUniqueSpriteIndex("/gui/items.png");
        steamBoat = (new ItemSteamBoat(1333)).setIconIndex(spriteindex).func_20011_a("Steam Boat");
    }
}
