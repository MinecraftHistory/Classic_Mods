Steam Paddle Boat Mod by MaudDib
================================

Prerequisites:
==============

- Minecraft Beta 1.1_02 (single player only for now)
- Risugami's ModLoader. get it here: http://www.minecraftforum.net/viewtopic.php?f=25&t=80246&hilit=modloader

How to use:
===========

- Install Risugami's ModLoader. see forum topic linked above, I will not repeat his instructions here.
- open minecraft.jar with winrar or winzip. 
- drag and drop files from mod package to jar file.
- play minecraft!


Crafting the steamboat:
=======================
- crafting recipe is:

   # I #
   # # #
   
   # = wood planks
   I = iron ingot
   

Special properties of the steam boat:
=====================================

- steam boats take twice as much damage as normal boats
- steam boats drop the same items used to craft it (it will drop 5 wood planks, 1 iron ingot)
- steam boats are about twice as fast as normal boats, and steer a bit faster than normal boats do

Credits:
========

The fantastic coders of the Minecraft Coders Pack. without their hard work and patience, this mod would not have been possible.
Glimmar (of Steampunk HD Texture pack fame) for the excellent steamboat skin and inspiring me for creating this mod for his texture pack
Risugami for his awesome modloader, made integrating this into minecraft so much easier
All the kind people in #mcp and #risucraft for showing me the way when I needed help with this mod
Notch and employees for making such an awesome game


source included. please do not ask for support, if you know how to code, then read the code =)
