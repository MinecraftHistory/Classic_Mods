step 1, open minecraft.jar with 7zip or winRAR, download them if you dont have them.
step 2, copy the (other than this) into minecraft.jar
step 4, enjoy!!!

this mod adds 4 new discs to minecraft.
ward, stal, mall and far
they are all tracks by c418
enjoy!!!
special thanks to roundabout and seronis for helping me with my coding problems.