When you empty one of the item slots in your quickbar, this mod will automatically refill the slot with a stack of the same item from your inventory.


Installation Instructions (Windows)

1) Extract the contents of this mod somewhere you can find them
2) Open %appdata%/.minecraft/bin
3) Make a backup of minecraft.jar
4) Open minecraft.jar with WinRAR
   - Drag and drop this mod's ei.class, fy.class, jj.class, and "net" folder into the archive
   - Delete the "META-INF" folder if it exists
5) Close WinRAR


Version History

v2
- Now compatible with Minecraft Beta v1.1_02

v1
- Initial release compatible with Minecraft Alpha v1.2.6
