Equivalent Exchange ~ Ayutashi

Updated for Beta 1.0!


::Install Notes::

eo.class - Bookshelf fix (bookshelves drop bookshelf blocks)
dj.class - Glass fix (glass drops glass blocks)

qy.class - Drops two single half-steps when a double step is broken!!
	   (Thanks to wolfkun for the unintentionally brilliant idea! :3)

iv.class - Ice Block variant.  This one lets Ice drop Ice Blocks in
	   addition to the usual "melting" function.  A bit messy,
	   considering you create MORE water every time you break it :\
	   Check out the variant below!

dw.class - Boat variant.  This drops five wooden plank blocks when a
           boat breaks, instead of three, plus two sticks.  This makes
           it easier to rebuild boats when broken, since no materials
           are lost in the process.



::OPTIONAL FILES::
(These are optional builds of the .class files above.  They are in separate
 folders, so you shouldn't need to worry about confusing them!)

waterless_ice/iv.class - WATERLESS variant of the Ice Block mod!  This one just drops Ice
	   blocks, without releasing any water whatsoever.  It's "cleaner"
	   than the first solution, but I consider it a more drastic change,
	   so I included it as a variant instead.

GlassFrame/1/dj.class & terrain.png
GlassFrame/2/dj.class & terrain.png
GlassFrame/3/dj.class & terrain.png
           These three folders are a small merge with Valance's GlassFrame mod.
           If you're already familiar with his mod, then you know what to do.
           Otherwise, search the Minecraft Modding&Mapping forums for his thread!


Just open your minecraft.jar with WinRAR, then drag and drop the mods you want!
These mods don't conflict with each other, so feel free to choose!
Make sure you don't try to use -BOTH- variants of a single mod...
that's just silly!  xD

Don't forget to delete the META-INF folder from minecraft.jar, and enjoy!  :3

