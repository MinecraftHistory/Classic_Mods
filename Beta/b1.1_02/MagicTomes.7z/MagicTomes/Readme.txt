To install this mod:

Open up a clean minecraft.jar with winRAR(If you do not have a clean minecraft.jar, delete/rename your current minecraft.jar, and then delete the file named VERSION in your minecraft/bin folder, and run minecraft.

Delete your META-INF folder.

Insert all the files except for items.png into your minecraft.jar

Then, put items.png into the folder named "gui" in your minecraft.jar
(Note to texture pack users, if your texture pack replaces the items.png file, when you run this mod the image for the books will not show up. To remedy this, please replace the items.png file in your texture pack folder.)

===Versions and future plans===
Version 1.0

Future tomes: Fireball tome, tree tome, Apple tome, all animal tomes.

===============================


===Crafting Recipes===

legend:

x - nothing

b - book

p - pork

f - feather

l - lightstone/glowstone/australium

o - obsidian

r - reed

s - stick

w - wheat


~pig tome~

   xpx
   xbx
   xxx

~day tome~

   xlx
   xbx
   xxx

~night tome~

   xox
   xbx
   xxx

~air tome~

   xrx
   xbx
   xxx

~health tome~

   www
   wbw
   www

~wings tome~

   fff
   fbf
   fff
========================


===Credits===

Notch, for making minecraft

MCP, for making this mod possible

Various modding guides and tutorials for telling me what the eff i'm doing.

My friends, for their support and opinions in the making of this simple, but fun mod

And last but not least, Adam, the ultimate modifier.