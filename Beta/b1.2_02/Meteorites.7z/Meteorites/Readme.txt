-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Meteorite Mod v1.3.0 
By Ethereal
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

This mod requires Risugami's ModLoader.

Install this mod like you would any other mod.

After running the game with this mod installed, an options file will
be created in your .minecraft folder. Inside are these options:

========================================
version: [String]
========================================
DO NOT change this value in the options file unless you want the
options file to be overwritten with the default settings.

This corresponds to the version of the mod. If different from the
version of the mod, the mod will overwrite the entire settings file.

========================================
meteorRarity: [integer]
========================================
This sets the rarity of the meteor; the higher it is, the more rare
meteors will be.

========================================
fire: [boolean (true or false)]
========================================
This sets whether or not the meteor will start a fire upon impact.

========================================
explosion: [boolean]
========================================
This sets whether or not the meteor will create an explosion upon
impact.

========================================
maxDiameter: [integer]
========================================
This sets the maximum diameter of the meteor.

========================================
minDiameter: [integer]
========================================
This sets the minimum diameter of the meteor.

========================================
oreIDs: [integer array ex: [1,2,3] ]
========================================
This is the list of block IDs that the meteor can create after it
hits the ground.

========================================
oreRarity: [integer array]
========================================
This is the list of ore rarities that corresponds with the list of
block IDs. Also, all the values should be percent values
corresponding to the item in the ore ID array, meaning that the
whole array should add up to 100.

ex: If your ore ID array is [89,16], and your rarity array is
[70,30], then you would have a 70% chance of getting a meteor that
spawns block 89 and a 30% chance of getting a meteor that spawns
block 16.