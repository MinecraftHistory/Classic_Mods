Add all the files in the "HiddenDoors Mod" folder to your minecraft.jar

ModLoader is required.
MoreBlockID's is also required.

NOTE: INSTALL MODLOADER/MOREIDS FIRST!