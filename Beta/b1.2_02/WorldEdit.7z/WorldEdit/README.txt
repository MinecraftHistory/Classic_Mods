WorldEdit
Copyright (c) 2010, 2011 sk89q <http://www.sk89q.com>
Licensed under the GNU General Public License v3

Introduction
------------

WorldEdit is a powerful in-game world manipulation plugin with
support for working with block data, copying and pasting regions,
undoing and redoing operations, loading and saving .schematic
files, and much more.

For installation and usage help, see:
http://wiki.sk89q.com/wiki/WorldEdit

Thanks
------

Thanks to the following individuals for their contributions to WorldEdit.

- Erik Broes
- Gunther De Wachter
- Dean Ward
- angelsl
- winzjany
- toi