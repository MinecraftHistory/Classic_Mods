TooManyItems (Mod for Minecraft Beta 1.2_02)
By Marglyph
Last update: 28 January 2011

TooManyItems is an inventory mod that allows you to create items in both
single- and multi-player (MP mode uses the /give command and requires you to
be a server op, of course).

Basic operation: When you open your inventory screen, left-click on the items
on the right to add a full stack, or right-click to add 1 at a time. Press the
"o" key to turn TMI on and off. Your preference will be remembered separately
for single- and multi-player.

Fast crafting: Right-click on the output square when crafting to craft the maximum possible amount. (Works while the inventory overlay is disabled).

Fast transfer: Hold shift while placing an item into a chest, or into your inventory from a chest, to transfer all items of the same type and combine stacks. (Works while the inventory overlay is disabled).

Trash (SP only): Drop an item on the Trash to delete it permanently.

Save states (SP only): Several slots are available for you to save your entire
inventory and restore it later. (The "x" button next to a saved state will
remove it.) This can be used to save your "real" inventory before editing,
save a blank inventory to clear out everything you're holding, save a full
inventory of materials, share inventories between characters, etc.

Multiplayer command setting: By default, TMI uses the command format /give
<player> <itemID> <quantity>, which is the one used by the "stock" Minecraft
server. Third-party and modded servers have different commands. Find
TooManyItems.txt in the same folder as your Minecraft options.txt, your
screenshots folder, etc., and change the "give-command" line as needed for
your server. Available insertions are: {0} player's username, {1} item ID, {2}
quantity, {3} damage.

You may edit TMI's preferences while the game is running.

=== Recommended Install ===

Use the Minecrafter mod utility.

http://minecrafterapp.wordpress.com/

=== Manual Install ===

Read and follow the instructions at:

http://www.minecraftforum.net/viewtopic.php?f=25&t=116234
