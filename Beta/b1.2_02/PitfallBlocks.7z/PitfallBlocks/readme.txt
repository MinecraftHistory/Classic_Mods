#####################
# Installation Instructions #
#####################
1. Download Risugami's ModLoader:
	http://www.minecraftforum.net/viewtopic.php?f=25&t=80246
2. Install Modloader
3. Open minecraft.jar in winRAR
4. Drag & Drop these class files into minecraft.jar

Recipe:
DSD
SRS
DSD

D= Dirt    S= Sand    R= Redstone Dust




- David Joslin