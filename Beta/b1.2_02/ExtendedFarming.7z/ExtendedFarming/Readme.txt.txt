Xie's Farming Mod v1.0.0 for MineCraft Beta 1.2_02, 31st January 2011

Requires Mod Loader.

Adds apple trees, watermelons and makes pumpkins edible, as well as making pumpkins, red flowers and yellow flowers growable. 

Seeds are yielded from tilling with a hoe, with a small chance of getting a seed other than wheat. Tilling near a plant will increase your chances of getting a seed of that plant, e.g. tilling near a pumpkin increases your chance of getting a pumpkin seed. Sometimes you'll get watermelon seeds from eating a watermelon piece.

I suggest using this mod with my Hunger and Food Stackability mods.

Compliments to qbicfeet for his excellent watermelon thread, and for the watermelon textures and icons.
http://www.minecraftforum.net/viewtopic.php?f=1&t=65953

Installing:
Please remember to make backups before installing.

1. Install the latest version of ModLoader.
2. Copy the mod files into minecraft.jar using your favourite archive program.
3. Delete the META-INF folder in minecraft.jar
4. Give it a shot.

Contents:
^at.class
XieMod.class
mod_XieFarming.class
XieBlockLeaves.class
XieBlockLog.class
XieBlockSapling.class
XieBlockSeedling.class
XieBlockWatermelon.class
XieItemFertiliser.class
XieItemHoe.class
XieMod.class
XieWatermelonPiece.class
XieWorldGenTree.class
XieWorldGenWatermelon.class
Xie/img/*

^ Compatability note: at.class is only required for toggling between Fancy and Fast graphics settings. If you don't need this feature, the at.class file can be omitted and this mod will still function.