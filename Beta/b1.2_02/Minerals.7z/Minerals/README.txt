Minerals! rev 16
Adds new minerals to the game!

Put files from folder "JAR" into the minecraft.jar.
If you have ID conflicts between mods, let the game run once, close it and change IDs in file modMinerals.props %appdata%\.minecraft\ .
If you can't run the game because of conflicts, copy the file from folder "appdata - .minecraft" into folder %appdata%\.minecraft\ .

If the game blackscreens - try to run debugFile.bat. When game blackscreens - just close it. Post the log.txt file on forums.
But if the log.txt doesn't have anything after "[Minerals! r16] Debug turned off" - try to turn on optionDebug in modMinerals.props.

Block IDs can be 1 - 255 (1 - 127 when you're not using my other mod - More Block IDs), item ID 256 - about 30000.
Blocks in the file are prefixed with "b", items with "i".

Classes this mod overwrites and for which modules/modifiers you need them:
da.class - moduleFirestone
dv.class - moduleObsidian, moduleFirestone
en.class - moduleObsidian, moduleFirestone
fz.class - moduleIvy
jd.class - moduleFirestone, modifierBetterOres
jh.class - moduleObsidian
jn.class - moduleColdinite
mx.class - moduleFirestone
qk.class - moduleFirestone

So - if you don't want to overwrite for example da.class (because of mod conflicts), then just don't overwrite it but set moduleFirestone to false in modMinerals.props.

Modifiers which you can turn on:
Better Ores (default: false):
	Iron and Gold Ores instead of themselves drop Iron or Gold Nuggets (which can be smelted in furnace, too)
	
	Options:
		MoreResources (default: true):
			Drops at random more resources from original ores
Redstone Fix (default: false):
	Fixes Redstone Ore mining speed. Stupid Notch's bug. It is now MUCH faster.