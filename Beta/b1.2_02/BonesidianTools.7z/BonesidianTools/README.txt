Installation :
1. Make sure you have Modloader and Tool Utils already installed
2. Copy files from Put into JAR into your AppData/.minecraft/bin/minecraft.jar
3. copy file from put into .minecraft folder to AppData/.minecraft/

Changing durability :
If you wish to change the durability of the bonesidian tools, open 
AppData/.minecraft/bonesidian.props with any text editing program and change 
the number to how many uses you want the tools to have and save the file. 

Compatibility Issues :
Everything but Props.class is a new class that shouldn't have any issues with
other mods, Props.class is from Shokah's Minerals! mod and should be exactly the
same file and cause no problems. Let me know if there are any issues because of that. 

Can't find AppData? :
Either search for %AppData% in windows explorer, or goto your user account directory 
and just type in AppData/ and hit enter after Users/YourUsername/ in the filepath bar.