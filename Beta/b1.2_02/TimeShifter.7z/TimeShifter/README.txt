Time Shifter rev 1

Put files from folder "JAR" into the minecraft.jar.
If you have ID conflicts between mods, let the game run once, close it and change IDs in file modMinerals.props %appdata%\.minecraft\ .
If you can't run the game because of conflicts, copy the file from folder "appdata - .minecraft" into folder %appdata%\.minecraft\ .

Block IDs can be 1 - 255 (1 - 127 when you're not using my other mod - More Block IDs), item ID 256 - about 30000.
Blocks in the file are prefixed with "b", items with "i".