Add all the files in the "PlasticCraft Mod" folder to your minecraft.jar

ModLoader is required, but not included.

NOTE: INSTALL MODLOADER FIRST!