Xie's Hunger Mod v1.0.1 for MineCraft Beta 1.2_02, 27th January 2011

Requires Mod Loader.

Enhances the survival aspect of the game by adding a simple hunger effect.

When the player starts getting hungry an icon will appear next to his or her health bar. The colour indicates how hungry they are,

Green - Peckish
Yellow - Hungry
Red - Starving

If the player continues to not eat even when starving, a red skull will appear above the indicator, and they will slowly start losing health.

There are two difficulty modes, the easier of the two (and the default) has food heal hearts and feed the player in equal measure. The more difficult mode makes it do one or the other, depending on how hungry the player is. If the player is starving, food will feed them but not heal them, if they are not starving it will heal them first, and feed them whatever is left over.

The difficulty can be set in the /mods/Xie/hungry.ini file, as can the rate at which the player gets hungry. The latter is a time in minutes that it takes the player to start starving to death (i.e. the time it takes to go from a fresh start through green, yellow and red to the red with a skull). Once starving to death it will take this amount of time again for the player to lose 10 health from starving.

Installing:
Please remember to make backups before installing.

1. Install the latest version of ModLoader.
2. Copy the mod files into minecraft.jar using your favourite archive program (replacing the existing eu.class).
3. Delete the META-INF folder in minecraft.jar
4. Give it a shot.

Contents:
XieMod.class
XieHunger.class
mod_XieHunger.class
eu.class
pc.class
Xie/img/xiehunger.png

Compliments to Chezzy for an inciteful discussion on implementing hunger, which formed the basis for the mechanic of this mod:
http://www.minecraftforum.net/viewtopic.php?f=1&t=117664
Also apologies for not implementing it exactly as proposed :P

Change Log
28/1/11, 1.0.1: Fixed a bug where cake was inedible when health full, even if player is hungry.