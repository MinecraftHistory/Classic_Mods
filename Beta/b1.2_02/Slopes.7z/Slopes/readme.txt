Kaevator SuperSlopes for Minecraft 2011
http://kaevator.blogspot.com/


- Presentation:

These Minecraft mods allow you to visualize slopes in Minecraft. It exists in 3 different versions, depending on your needs, all are compatible with Minecraft Beta 1.2_02

-> Kaevator_SuperSlopes_K1 : This mod simply makes Minecraft visualize all stairs as slopes, you won't see anymore stairs.
This is compatible with multiplayer.

-> Kaevator_SuperSlopes_K2 : Same as K1, but the stairs placed on a stone/dirt/sand/grass/double-stoneslabs/cobblestone block will remain stairs.
This is also compatible with multiplayer.

-> Kaevator_SuperSlopes_K3 : This one is for solo crafting purposes, it will allow you to create 3 more blocks from cobblestone and wooden planks:
	One ground slope with slope face up.
	Crafting:		| - - - |
				| X - - |
				| X X - |

	One ceiling slope with slope face down.
	Crafting:		| - - - |
				| X - - |
				| X X - |


	One ceiling stairs with stairs face down.
	Crafting:		| X X X |
				| - X X |
				| - - X |

The maps modified in Kaevator_SuperSlopes_K3 WON'T WORK WITHOUT THE MOD unless you remove all the Slopes and Reverted stairs blocks.
The K3 mod is NOT COMPATIBLE WITH MULTIPLAYER

- Installation: 

-> With a mod manager:
	- Don't open the .zip archive.
	- Download TFC Minecraft Mod Manager 11.3 from the website http://tfcmods.wordpress.com/
	- Follow the instruction from MMM to apply the mod.
	- I cannot guarantee any compatibility with other mods, but it should be working with any texture packs.

-> Without a mod manager:
	- In windows, press the Windows Key + R
	- Type down %appdata%
	- Open .minecraft directory
	- Open bin directory
	- Open minecraft.jar with your unzipper, if you don't have one, you can download 7-Zip at http://www.7-zip.org/
	- Open the mod Kaevator_SuperSlopes_K#.zip archive with your unzipper
	- Drop all the files from the mod file (except the readme) to minecraft.jar
	- If there is one, delete the META-INF folder in minecraft.jar
	- Start Minecraft, have fun !
	
- Help the modders:

If you have fun using these mods and would like to give to the author some motivation to get fitter, happier and more productive, go to http://kaevator.blogspot.com/ and press the "Donate" button; this will send you magically to a PayPal interface where you could insert 1 or 2 coins to continue the game.

- Thanks to Notch & Mojang Productions and to TFC for the Minecraft Mod Manager.
