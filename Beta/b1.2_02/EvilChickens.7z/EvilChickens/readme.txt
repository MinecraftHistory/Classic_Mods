How to install:
1. Goto run... or in windows 7 click start and type %appdata% and press enter.
2. Navigate to the .minecraft folder and goto bin.
2a. Backup minecraft.jar first.
3. Right click minecraft.jar and open with WinRAR.
4. Drag in the files in this folder into the minecraft.jar
5. Delete META-INF in minecraft.jar
6. Have fun!

Created by TheChe3zeeOne
No copyright intended.
All of minecraft is created by Notch and JAVA.