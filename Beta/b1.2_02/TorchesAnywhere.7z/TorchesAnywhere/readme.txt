Torches Anywhere v1
By ChocolateySyrup

INSTALLATION:
Open minecraft.jar with a suitable archive program (e.g. WinRAR) and add the included pv.class to it, replacing the default pv.class.
That's it! Torches can now be placed onto any block.