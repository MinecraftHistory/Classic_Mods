Install Instructions

Windows XP

1. Backup your Minecraft.jar file.
2. Go to start>run and type in %appdata%, press enter. Find the \.minecraft folder and open it. Open the bin folder.
3. Find the minecraft.jar file and right click it and open it with your archiving program, such as 7-zip (which is a free program) , winrar and winzip.
4. Drag and drop the eu.class file onto the 7-zip, winrar, winzip window. Click ok.
5. Delete the META-INF folder.

Windows Vista & Windows 7

The instructions are the same as windows xp, except you will want to navigate to \application data\roaming\.minecraft\bin.

Trouble Installing

If you get a black screen or the mod doesn't work. It is usually because:
1. The META-INF folder hasn't been deleted.
2. You have another mod installed that is conflicting with eu.class.
3. You are using the mod with the wrong version of minecraft.