Expanded Farming v.1.1
Formerly included in FancyPack

How to Install
--------
ALWAYS back up your worlds! ALWAYS!

0. Before you do anything else, download and extract ModLoader somewhere you can find it. Modloader can be found here: http://www.minecraftforum.net/viewtopic.php?f=25&t=80246
1. Open minecraft.jar with WinRAR or other archive program.
2. Delete the META-INF folder from inside minecraft.jar.
3. Add all the class files from ModLoader into your minecraft.jar.
4. If you want to be able to use bonemeal on the new crops to instantly grow them, open the folder "Bonemeal Fix (OPTIONAL)" and copy the class file found inside into your minecraft.jar as well.
5. Add all the contents of the install directory from this pack into your minecraft.jar. This means including the class files AND the folder called "fancypack", but NOT the "install" folder itself!
6. Close minecraft.jar.
7. Run Minecraft normally and enjoy!

A black screen means you did not install all the class files, or you did not install modloader, or you did not delete the META-INF folder from your minecraft.jar.


ABOUT THE MOD
--------
Expanded Farming adds the ability to cultivate and grow several more plants than Vanilla Minecraft allows, including flowers, pumpkins, and mushrooms. To get seeds, right click with the hoe on mushrooms, flowers, or pumpkins to get seeds. These can then be grown just like wheat. Mushrooms are a special case though: They can only be grown in great darkness! So if you want to cultivate mushrooms, you'll need to keep a nice dark area for them. How dark? Dark as moonlight -- or darker! Brighter light, even sun, will kill growing mushrooms.
Flowers, when fully grown, can be harvested. They will randomly yield yellow flowers (common) or roses (less common). Both red and yellow flowers use the same seeds and grow the same way. 

By tilling grass, you can get wheat seeds as you normally could, but you can also get grass seeds. Grass seeds can be planted on tilled soil to turn it into grassy soil instantly! No more building grass 'bridges' to get a soil area covered in lush green grass!

If you install the optional bonemeal fix, you will be able to use bonemeal to instantly grow mushrooms, flowers, and pumpkins in addition to saplings and wheat.

NEW CRAFTING RECIPE:
MILK
PUMPKIN
BOWL
Stacked vertically, these three items will make a pumpkin pie, which can heal for 8 hearts! Not too shabby!


Block IDs: Avoiding Conflicts!
--------
Block and Item IDs are limited. If FancyPack or one of its sub-mods uses the same block ID or item ID as another mod you're using, it will crash. Alternately, if Notch adds new official content that uses the same ID as an item or block from FancyPack, it will also crash! But you can avoid this! How?
Once you run Minecraft.exe for the first time after installing Expanded Farming a new file will be placed in the same directory as the exe. This file will be called "fancypack_farming.properties". Normally you don't have to do anything with this file.
However, if there is a conflict, you can open up any of these three files with a text editor (like Notepad) and you will see a list of all the items along with the IDs they use. Find the item that has the conflicting ID and change it to a new, free space. If you are using Shockah's "More Block IDs" mod, it's even easier, since there are more available spaces to change the block IDs to. Then just save the file and run minecraft.exe.

WARNING: It is best to configure these IDs BEFORE playing. Using Expanded Farming with one set of IDs, then changing them, then loading up that same world can leave problems. 
The bottom line: NEVER leave a placed block in your world with an ID that doesn't have a definition anymore! 


Texture Packs
--------
Expanded Farming uses some new graphics for both items and blocks. 
Fortunately, these textures are all external, which means they are automatically imported by the ModLoader over your existing texture pack while they're being used. This way, they can work with any texture pack!

If you want to change the way the new icons or blocks look, it's very easy. Just go into your /fancypack/ directory, found in the install directory, and look for the files you want to edit. They're all named for easy reference! Then once you've changed them, make sure they end up with all the other textures in the /fancypack/ folder inside your minecraft.jar.
That's all you have to do!


Multiplayer Mode?
--------
At the moment, Expanded Farming is a singleplayer-only mod. So sorry!


Mod Conflicts
--------
Expanded Farming should conflict minimally. However, it may have problems with other mods that alter the behavior of the hoe tool.


Credits
--------
Vib Rib and ChocolateySyrup, mod creators, for primary new coding, some new art assets, and the creation of this mod.
bbcisdabomb, for generous webhosting space.
Kas/Rhodox, for his fantastic work on the Minecraft Painterly Pack textures, from which most graphics are derived or copied (with permission), as well as suggestions and ideas.
The creators of the Minecraft Mod Creator Pack. Without your decompiling and de-obfuscation this would never be possible! Extra thanks are necessary for all your work helping with this project and providing great feedback and support.
Valance, for letting us know how to separate all the new textures into their own files.
Lilyo for the Quandary adaptation, and ExtraNoise for creating the fabulous Quandary pack in the first place.
A million thanks to Professor Mobius, Club559, 303, Risugami, and many more for their assistance and guidance in adapting this mod for ModLoader compatibility.
Risugami and 303 for making the fantastic ModLoader.
Seronis, for debugging help and making the final hurdle into ModLoader compatibility.
SomethingAwful, for support, suggestions, and ideas that helped shape this mod into what it is.
And of course, Notch, for creating Minecraft in the first place!

VERSION HISTORY
---------
V.1.0 
 Initial release
V.1.1
 Added bonemeal compatibility