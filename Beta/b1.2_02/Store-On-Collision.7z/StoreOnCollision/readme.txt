This is Store On Collision 2.4

Mod thread: http://www.minecraftforum.net/viewtopic.php?f=25&t=88767

You can chose features of Store On collision, install
	c.class	and gy.class	for chests
	sd.class		for minecarts
	rj.class		for dispenser
				to store on collision

If you have any questions, come to #mcp@esper.net

ZeuX :)