#####################
# Installation Instructions #
#####################

1. Download Risugami's ModLoader:
	http://www.minecraftforum.net/viewtopic.php?f=25&t=80246
2. Install Modloader
3. Download Shockah's MoreBlockIDs
	http://www.minecraftforum.net/viewtopic.php?f=25&t=83028
4. Install MoreBlockIDs
5. Open minecraft.jar in winRAR
6. Drag & Drop these class files and the imgz folder into minecraft.jar

TRANSMITTER:
Recipe:
###
GRG
###

R = Redstone   # = Iron Ingot    G= Gold Ingot


RECEIVER:
Recipe:
_#_
_R_
_#_

R = Redstone   # = Iron Ingot    _=Nothing




- David Joslin