#####################
# Installation Instructions #
#####################

1. Download Risugami's ModLoader:
	http://www.minecraftforum.net/viewtopic.php?f=25&t=80246
2. Install Modloader
3. Download Shockah's MoreBlockIDs
	http://www.minecraftforum.net/viewtopic.php?f=25&t=83028
4. Install MoreBlockIDs
5. Open minecraft.jar in winRAR
6. Drag & Drop these class files and the imgz folder into minecraft.jar

Recipe:
_#_
###
_#_

# = Redstone    _=Nothing




- David Joslin