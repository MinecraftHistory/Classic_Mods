
******IMPORTANT NOTICE************IMPORTANT NOTICE************IMPORTANT NOTICE************IMPORTANT NOTICE******

This version must be applied to a fresh unmodded minecraft.jar with no existing BiomeTerrainMod!

******IMPORTANT NOTICE************IMPORTANT NOTICE************IMPORTANT NOTICE************IMPORTANT NOTICE******


To use follow these steps:

1.)  First edit BiomeTerrainSettings.ini to your liking.  You can find a description of the settings at the bottom of this document.  

2.) Get a program that can open jar files and recompress them.  I use winrar personally, there is a free trial available.

3.)  Extract all the files from the zip you downloaded to some temporary folder.

4.) Find your minecraft.jar file.  Everyone has one, it's just hidden.  It can usually be found by opening internet explorer, navigating to %appdata% (type it in like a internet address or URL), opening the .minecraft folder, then the .bin folder.  See the file called "minecraft?"  Open it with winrar.

5.) Drag all the .class files from the temp folder into the minecraft.jar now open in winrar, as well as the META-INF folder.  All other files stay.  Do not miss anything mentioned here or it will not work!  Now in the resulting dialog, hit "ok"

6.)  Now put that BiomeTerrainSettings.ini file you made all nice and neat into your .minecraft folder.  Not the bin folder minecraft.jar is in, but the one directly beneath it.

7.) Your minecraft.jar should now be ready to run with biometerrain mod with no more modifications neccesary.  Just launch as you normally would.

Enjoy. :)

Settings:

See bottom for new tree plugin system details:

Biome Mod

All Biome Settings
biomeSize:1.5
Modifies the size of biomes. Larger values will generate larger biomes and smaller values will generate smaller biomes. This settings affects the average dimension of biomes on a linear scale, so every doubling of this value will quadruple the area of biomes.

minMoisture:0.0
maxMoisture:1.0
Sets the minimum and maximum moisture of the world.

minTemperature:0.0
maxTemperature:1.0
Sets the minimum and maximum temperature of the world.

snowThreshold:0.5
iceThreshold:0.5
Setting this value to a larger number will make snow and/or ice more common and a smaller number will make snow and/or ice less common. Values should be between -1 and 1.

Swamp Biome Settings
muddySwamps:false
claySwamps:false
Places a strip of mud or clay (size is dependent on the swampSize setting below) around the edge and below surface water. This will only occur in swampland biomes. Thw muddySwamp setting takes priority over the claySwamps setting.

swampSize:2
Adjusts how many blocks mud/clay extends from the edge of water for when either the muddySwamps or claySwamps options are turned on.

Desert Biome Settings
waterlessDeserts:false
Will remove all water from desert and ice desert biomes.

removeSurfaceDirtFromDesert:false
Will remove all dirt from the surface of deserts. This setting was introduced because changing some terrain generation settings will cause dirt to erroneously appear on the surface of desert biomes.

desertDirt:false
Will turn on the ability to let dirt appear on the surface. This setting occurs after removeSurfaceDirtFromDesert so turning both on will cause dirt to appear in your desert biomes.

desertDirtFrequency:0
Sets the frequency at which dirt will appear in the desert. The setting corresponds to the average number of chunks before a dirt block will appear. Example: setting desertDirtFrequency:100 means that, on average, you will encounter one dirt block every 100 chunks in the game.


Cave Mod

Cave Settings
caveRarity:7
This controls the odds that a given chunk will host a single cave and/or the start of a cave system.

caveFrequency:40
The number of times the cave generation algorithm will attempt to create single caves and cave systems in the given chunk. This value is larger because the likelihood for the cave generation algorithm to bailout is fairly high and it is used in a randomizer that trends towards lower random numbers. With an input of 40 (default) the randomizer will result in an average random result of 5 to 6. This can be turned off by setting the "even cave distribution" setting (below) to true.

evenCaveDistribution:false
Setting this to true will turn off the randomizer for cave frequency (above). Do note that if you turn this on you will probably want to adjust the cave frequency down to avoid long load times at world creation.

caveMinAltitude:8
caveMaxAltitude:128
Sets the minimum and maximum altitudes at which caves will be generated. These values are used in a randomizer that trends towards lower numbers so that caves become more frequent the closer you get to the bottom of the map. Setting even cave distribution (above) to true will turn off this randomizer and use a flat random number generator that will create an even density of caves at all altitudes.

individualCaveRarity:25
The odds that the cave generation algorithm will generate a single cavern without an accompanying cave system. Note that whenever the algorithm generates an individual cave it will also attempt to generate a pocket of cave systems in the vicinity (no guarantee of connection or that the cave system will actually be created).

caveSystemFrequency:1
The number of times the algorithm will attempt to start a cave system in a given chunk per cycle of the cave generation algorithm (see cave frequency setting above). Note that setting this value too high with an accompanying high cave frequency value can cause extremely long world generation time.

caveSystemPocketChance:0
This can be set to create an additional chance that a cave system pocket (a higher than normal density of cave systems) being started in a given chunk. Normally, a cave pocket will only be attempted if an individual cave is generated, but this will allow more cave pockets to be generated in addition to the individual cave trigger.

caveSystemPocketMinSize:0
caveSystemPocketMaxSize:4
The minimum and maximum size that a cave system pocket can be. This modifies/overrides the cave system frequency setting (above) when triggered.

Dungeon Settings
dungeonRarity:100
dungeonFrequency:8
dungeonMinAltitude:0
dungeonMaxAltitude:128
Sets the creation variables for dungeons (See explanation of material spawning variables near bottom)

Lava Pool Settings
lavaLevelMin:0
lavaLevelMax:10
Sets the minimum and maximum levels at which lava pools can form in caves.


Cloud Mod (SSP only)

Cloud Settings
cloud2DHeight:120.0
Adjusts the altitude at which 2D clouds occur. I never saw these in the game, but they are in the class so I went ahead and added the option to change their altitude just in case.

cloud3DHeight:108.0
Adjusts the altitude at which 3D clouds occur.

cloud3DThickness:4.0
Adjusts the thickness of 3D clouds.


Deposit Mod

Above Ground Settings
<x>DepositRarity:rarity_Int
<x>DepositFrequency:frequency_Int
<x>DepositMinAltitude:minAltitude_Int
<x>DepositMaxAltitude:maxAltitude_Int
These settings adjust the creation variables for above ground items. To save on space I just posted a generic representation of the settings for this section. <x> can be flower, rose, brownMushroom, redMushroom, reed, or pumpkin. See the settings file for all settings and see the explanation of material spawning variables near the bottom for more detail on what rarity, frequency, and min/max altitudes do.

Above/Below Ground Settings
evenWaterSourceDistribution:false
Changes the water source spawning algorithm to a flat distribution. Normally, water sources are distributed with a higher frequency toward the bottom of the map.

waterSourceDepositRarity:100
waterSourceDepositFrequency:50
waterSourceDepositMinAltitude:8
waterSourceDepositMaxAltitude:128
Sets the creation variables for water sources (See explanation of material spawning variables near bottom)

evenLavaSourceDistribution:false
Changes the lava source spawning algorithm to a flat distribution. Normally, lava sources are distributed with a much higher frequency toward the bottom of the map.

lavaSourceDepositRarity:100
lavaSourceDepositFrequency:20
lavaSourceDepositMinAltitude:8
lavaSourceDepositMaxAltitude:128
Sets the creation variables for lava sources (See explanation of material spawning variables near bottom)

Below Ground Settings
<x>DepositRarity<n>:rarity_Int
<x>DepositFrequency<n>:frequency_Int
<x>DepositSize<n>:size_Int
<x>DepositMinAltitude<n>:minAltitude_Int
<x>DepositMaxAltitude<n>:maxAltitude_Int
These settings adjust the creation variables for underground items. To save on space I just posted a generic representation of the settings for this section. <x> can be dirt, gravel, clay, coal, iron, gold, redstone, or diamond. There�s four sets of these settings for each ore type <x>. So <n> can be 1, 2, 3, or 4. See the settings file for all settings and see the explanation of material spawning variables near the bottom for more detail on what rarity, frequency, size, and min/max altitudes do.

Hell Settings
<x>DepositRarity<n>:rarity_Int
<x>DepositFrequency<n>:frequency_Int
<x>DepositMinAltitude<n>:minAltitude_Int
<x>DepositMaxAltitude<n>:maxAltitude_Int
These settings adjust the creation variables for underground items. To save on space I just posted a generic representation of the settings for this section. <x> can be lava source, fire, lightstone, brown mushroom, or redmushroom. See the settings file for all settings and see the explanation of material spawning variables near the bottom for more detail on what rarity, frequency, size, and min/max altitudes do.


Terrain Mod

Terrain Settings
waterLevel:64
Sets the water level of the world.

maxAverageHeight:0.0
If this value is greater than 0, then it will affect how much, on average, the terrain will rise before leveling off when it begins to increase in elevation. If the value is less than 0, then it will cause the terrain to either increase to a lower height before leveling out or decrease in height if the value is a large enough negative.

maxAverageDepth:0.0
If this value is greater than 0, then it will affect how much, on average, the terrain (usually at the bottom of the ocean) will fall before leveling off when it begins to decrease in elevation. If the value is less than 0, then it will cause the terrain to either fall to a lesser depth before leveling out or increase in height if the value is a large enough negative.

fractureHorizontal:0.0
Can increase (values greater than 0) or decrease (values less than 0) how much the landscape is fractured horizontally. If you want to use settings from BiomeTerrain Mod v9.1 or earlier, then you will need to do a conversion (See v9.1 and earlier to v10.0 and greater conversion section near bottom).

fractureVertical:0.0
Can increase (values greater than 0) or decrease (values less than 0) how much the landscape is fractured vertically. Positive values will lead to large cliffs/overhangs, floating islands, and/or a cavern world depending on other settings. If you want to use settings from BiomeTerrain Mod v9.1 or earlier, then you will need to do a conversion (See v9.1 and earlier to v10.0 and greater conversion section near bottom).

volatility1:0.0
volatility2:0.0
Hard to explain, but think of these as terrain chaos settings. The larger the values the more chaotic/volatile landscape generation becomes. Setting the values to negative will have the opposite effect and make landscape generation calmer/gentler. If you want to use settings from BiomeTerrain Mod v9.1 or earlier, then you will need to do a conversion (See v9.1 and earlier to v10.0 and greater conversion section near bottom).

volatilityWeight1:0.5
volatilityWeight2:0.45
Adjust the weight of the corresponding volatility settings. This allows you to change how prevalent you want either of the volatility settings to be in the terrain. Values should be between 0 and 1 and sum to some number equal to or less than 1. An example would be to set volatility1 to something high and volatility2 to some negative number. Then adjust volatilityWeight1 to a small number (say 0.1) and volatilityWeight2 to a larger number (0.85). This should result is mostly calm/flat landscape with the occasional chunk of terrain floating or jutting into the air.

Bedrock Settings
disableBedrock:false
Removes the bedrock form the bottom of the map.

flatBedrock:false
Turns the bedrock layer into a single, flat layer one block thick.

bedrockObsidian:false
Turns all bedrock into Obsidian


Replace Block Mod

Replace Settings
removeSurfaceStone:false
Attempts to replace all surface stone with its nearest non-stone neighbor block type (dirt, grass, sand, gravel, or clay). If it cannot find a suitable neighbor block to duplicate, then it will default to sand in Desert biome types and Grass in all others.

replace<block_A_Name>:<block_B_Name>
This is experimental and not completed yet, but it aims to be a universal, real-time block replacement option where you can type the above format, substituting <block_A_name> and <block_B_name> with actual block/material names, to replace all generated blocks of type A with those of type B. Currently this only works on normal terrain blocks (e.g. dirt, grass, sand, stone, gravel, ice, water, lava, air, etc... and not things like ores, trees, flowers, cacti, etc....).
Example:
replaceWater:Lava
replaceIce:Lava
replaceSand:Rock
(You can type out as many of these as you want in the settings file. The list of block names can be found here)

Tree Mod

Tree Settings
biomeTrees:false
Enabled the use of custom, biome specific trees in place of the standard Minecraft trees.

globalTreeDensity:0
Sets the global, starting tree density for all biomes. Increasing the value increases the density of trees in all biomes.

rainforestTreeDensity:5
swamplandTreeDensity:0
seasonalforestTreeDensity:2
forestTreeDensity:5
savannaTreeDensity:0
shrublandTreeDensity:0
taigaTreeDensity:5
desertTreeDensity:-20
plainsTreeDensity:-20
iceDesertTreeDensity:-20
tundraTreeDensity:-20
Sets the tree density in each biome individually. Large negative values are used to prevent trees from spawning at all.

globalCactusDensity:0
desertCactusDensity:10
cactusDepositRarity:100
cactusDepositMinAltitude:0
cactusDepositMaxAltitude:128
These settings adjust the creation variables for cacti. See the settings file for all settings and see the explanation of material spawning variables near the bottom for more detail on what rarity, frequency, size, and min/max altitudes do.


Underground Lake Mod

Underground Lake Settings
undergroundLakes:false
Enables underground lakes.

undergroundLakesInAir:false
Allows underground lakes to spawn in the air.

undergroundLakeFrequency:2
undergroundLakeRarity:5
undergroundLakeMinSize:40
undergroundLakeMaxSize:60
undergroundLakeMinAltitude:0
undergroundLakeMaxAltitude:50
These settings adjust the creation variables for underground lakes. See the settings file for all settings and see the explanation of material spawning variables near the bottom for more detail on what rarity, frequency, size, and min/max altitudes do.

TREE PLUGIN SYSTEM:

The Tree Plugin system is included in this build.  To use, first enable "CustomBiomeTrees" in BiomeTerrainSettings.ini.  You can do it with Notch trees or without (NotchBiomeTrees is the setting).  If you set both to true, there will be 50/50 of CustomBiomeTrees and NotchBiomeTrees.  If you set both to false, only alpha trees will be generated!.

Now, please either run the game once to create the "TreePlugins" folder in your appdata folder or create it yourself.  Now make a Tree plugin.  It's easier than it sounds!  Just take the included TreeExample.ini, read the comments (the text after the "#" sign), customize it to your needs, and then remove the comments (IMPORTANT STEP) and rename it to your liking, then throw it in the tree folder!  You've got a tree plugin!  It should appear in the specified biomes.

You can have up to 128 Custom BiomeTrees!