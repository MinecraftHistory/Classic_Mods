Humans+ v1.2 for Minecraft Beta 1.2_02
Adding mobs to your once empty world.

VERSION 1.3 coming soon!

Version 1.2 Changelog:-.

- Fixed a few spawnrate issues
- Haven't gotten round to changing the blockid of my mob spawner to anything other than 95, because 303 compiled this version, my mod_HumansPlus.class is currently hosting a secret new mob, so i'm using 303's compile
- 303 requested a next release because of some massive improvements to his pirates:
  * Fixed crashes with boat stealing.
  * Fixed a bug where pirates immediately chestified on peaceful.
  * Pirates will more fully ignore the player on peaceful.
  * Better pet mod compatibility: right click pet pirate to open inventory screen.
  * Instead of always making a loot chest, pirates will steal each other's inventories.
  * Pirates won't despawn, so if a pirate steals from you, your items should be secure.
  * Added rare items to pirate loot chests.
  * If a pirate's boat breaks and he has a boat in his inventory, he will use that.
  * Pirates now conserve their food better. They will only heal themselves if it wouldn't
    bring them above max health.
  * Casting fishing rods works more like the player's now. A bobber is rendered,
    it takes the bobber a while to get to the target before the pirate can pull on  it.
  * Increased max health of pirates to 60 as their loot is so precious.
  * There is a random chance now that pirates steal items from the player's inventory 
    while attacking. On hard they can steal from the whole inventory, on easier difficulties
    they ignore the quickbar.
  * There's a random chance now that pirates attack each other unprovoked.


Version 1.2 Installation:- (This is written on the premise you know how to get to your minecraft.jar).
0. Back up your minecraft.jar.
1. First make sure you have Risugami's Modloader and Audiomod installed to your minecraft.jar.
2. Copy ALL of the files from "Inject to minecraft.jar" Into your minecraft.jar.
3. Copy all skins from /mob/ to /mob/ in your minecraft.jar.
4. Add the files from resources to the resources in your .minecraft folder (%appdata%\.minecraft).
5. Copy HumansPlus.properties to your .minecraft folder.
6. Delete META-INF from your minecraft.jar and close.
7. Start up minecraft and test.

Editing HumansPlus.properties:-
Quite simple actually, it comes preconfigured with all the mobs enabled, simply edit the name of a mob you don't want, i.e. Obscure the line.

Available mobs are: (case sensitive)
Settler
Wanderer
Hunter
Rogue
RogueArcher
Bandit
Herobrine
ShadowWalker
Elf
LostMiner
Knight
Pirate
MobHorse

By addin in random junk on a line, you can stop a specific mob from spawning:

Settler
WandereLOLr
Hunter
Rogue
#RogueArcher
Bandit
Herobrine
ShadowWalker
23251234125Elf
LostMiner
Knight
Pirate
MobHorse

Wanderer, RogueArcher and Elf will not spawn, it's that simple, I don't want a single post asking on how to do that.

Coming soon:-
Custom Weapons,
More Mobs.

Credits:-
Mr_okushama - Mod Author.
_303 - Pirate Author, Pirate enthusiast and a great help from the beginning.
Corosus, Kodaichi, HarryPitFall, Club559 and Ayutashi - For helping me get to where I am today.
Props to the MCP team too, without you guys, i'd know obfuscated code. >_>
