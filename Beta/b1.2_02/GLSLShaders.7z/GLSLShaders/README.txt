
Installation:
	
	I highly recommend that you back up minecraft.jar before you do this, just in case something goes wrong.

	=== Mac OS X ===
	
		minecraft.jar is located in ~yourname/Library/Application Support/minecraft/bin

		1. Open Terminal.
		
		2. Click and drag install.sh to the Terminal window.
		
		3. Click and drag minecraft.jar to the Terminal window.
		
		4. Hit enter. If you don't see anything that looks like an error message, your mod installed successfully.
		
		If you hit enter and see something like "install.sh: Permission denied", type "chmod 0755 " then drag install.sh to the Terminal window and hit enter. Repeat the above steps.
		
	=== Linux ===
	
		Installation should be the same as for Mac OS X, except that minecraft.jar will be located somewhere else. Let me know if there are any problems.
		
	=== Windows ===
	
		1. Double click the file named "install" (not install.sh)
		
		If your minecraft.jar is located in an usual location, open a command prompt by pressing Windows + R, then typing "cmd". Hit enter.  
		
		Click and drag the install file to the command line, hit space, then click and drag minecraft.jar to the command line. Hit enter.

Shaders:

	The depth-of-field mod basically just enables GLSL vertex and fragment shaders and uses those instead of the OpenGL's fixed pipeline.
	
	I very strongly recommend checking out the additional shaders located in the mods/depthOfField/alternative shaders/ directory.
	
	Many people find the default depth-of-field effect to be too in-your-face and prefer something like Azraeil's more realistic depth-of-field shader instead.
	
	To use a set of a shader copy the shader files to the /shaders directory inside minecraft.jar (or the mods/depthOfField/files/shaders directory before patching).
	
	By modifying these files you can have full control over the actual rendering algorithm and also implement your own visual effects.

	There are four shaders you can create and modify: base.vsh, base.fsh, final.vsh, and final.fsh.
	
	If there is anything I can do to cater to shader writers (like provide additional uniforms) let me know.
	
Notice:

	Feel free to modify and/or redistribute these files as you wish, but if you do, all I ask is that you simply give me credit in some form for my work. :)
	
Contact:

	Email me at daxnitro@gmail.com