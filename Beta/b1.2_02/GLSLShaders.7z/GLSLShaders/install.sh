#!/bin/bash
# Installation script for my mods. - daxnitro

if [ $# -lt 1 ]; then
	echo "Usage: ./install.sh your_minecraft.jar"
	exit
fi

if [ ! -f "$1" ]; then
	echo "File not found."
	exit
fi

echo "Extracting JAR . . ."

BASEDIR=$(dirname "$0")
TEMPDIR="$BASEDIR/temp"

rm -r "$TEMPDIR" 2>/dev/null

mkdir -p "$TEMPDIR"

unzip "$1" -d "$TEMPDIR/minecraft" > /dev/null

rm "$TEMPDIR/minecraft/META-INF/MOJANG_C.DSA" 2>/dev/null
rm "$TEMPDIR/minecraft/META-INF/MOJANG_C.SF" 2>/dev/null

echo "Applying mods . . ."

SAVEDIFS=$IFS
IFS=$(echo)
for mod in "$BASEDIR/mods/*"; do
	if [ -d $mod ]; then
		echo "Installing $(basename $mod) . . ."
		source $mod"/install.sh"
	fi
done
IFS=$SAVEDIFS

echo "Recreating JAR . . ."

java -classpath "$BASEDIR/tools" JarHelper "$1" "$TEMPDIR/minecraft" . > /dev/null

echo "Cleaning up . . ."

rm -r "$TEMPDIR" 2>/dev/null

echo "Done!"
