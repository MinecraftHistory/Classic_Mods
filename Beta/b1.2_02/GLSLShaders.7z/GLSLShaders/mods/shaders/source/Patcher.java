// Bytecode patcher for GLSL shaders.  
// I don't care what you do with this source but I'd like some credit if you reuse this in part or whole. - Chris Brown aka Daxnitro

import javassist.*;
import javassist.expr.*;

import java.lang.Exception;

class Patcher {
	public static void main(String[] argv) throws Exception {


		ClassPool pool = ClassPool.getDefault();

		// EntityRenderer.class

		CtClass entityRenderer = pool.get(EntityRenderer);
 
 		CtClass floatParameter[] = {CtClass.floatType};
 		
		CtMethod renderEverything = entityRenderer.getDeclaredMethod(EntityRenderer_renderEverything, floatParameter);

		renderEverything.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals("Shaders") && m.getMethodName().equals("processScene")) {
						Patcher.alreadyInstalled = true;
					}
				}
			}
		);
		
		if (alreadyInstalled) {
			System.out.println("Already installed.");
			return;
		}
		
		renderEverything.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals(EntityRenderer) && m.getMethodName().equals(EntityRenderer_renderWorld) && m.getSignature().equals("(F)V")) {
						m.replace("{ $_ = $proceed($$); Shaders.instance.processScene("+EntityRenderer_red+", "+EntityRenderer_green+", "+EntityRenderer_blue+"); }");
					}
				}
			}
		);
		
		CtMethod renderWorld = entityRenderer.getDeclaredMethod(EntityRenderer_renderWorld, floatParameter);

		renderWorld.instrument(
			new ExprEditor() {
				public void edit(NewExpr e) throws CannotCompileException {
					if (e.getClassName().equals(Frustrum)) {
						e.replace("{ Shaders.instance.useProgram(Shaders.instance.baseProgram); $_ = $proceed($$); }");
					}
				}
			}
		);

		renderWorld.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals(EntityRenderer) && m.getMethodName().equals(EntityRenderer_renderPlayer) && m.getSignature().equals("(FI)V")) {
						m.replace("{ $_ = $proceed($$); Shaders.copyDepthTexture(Shaders.instance.depthTexture2Id("+EntityRenderer_mc+")); Shaders.instance.useProgram(0); }");
					}
				}
			}
		);

		renderWorld.instrument(
			new ExprEditor() {
				public void edit(MethodCall m) throws CannotCompileException {
					if (m.getClassName().equals(RenderGlobal) && m.getMethodName().equals(RenderGlobal_function) && m.getSignature().equals("(F)V")) {
						m.replace("{ $_ = $proceed($$); Shaders.copyDepthTexture(Shaders.instance.depthTextureId("+EntityRenderer_mc+")); }");
					}
				}
			}
		);
		
		// Tessellator.class
		
		CtClass tessellator = pool.get(Tessellator);
 
 		CtClass float3Parameter[] = {CtClass.floatType, CtClass.floatType, CtClass.floatType};
 		
		CtMethod setNormal = tessellator.getDeclaredMethod(Tessellator_setNormal, float3Parameter);

		setNormal.insertAfter(
			"byte byte0 = (byte)(int)($1 * 127F);" +
			""+Tessellator_normal+" &= 0xFFFFFF00;" +
			""+Tessellator_normal+" |= byte0;"
			);

 		CtClass double3Parameter[] = {CtClass.doubleType, CtClass.doubleType, CtClass.doubleType};
 		
		CtMethod addVertex = tessellator.getDeclaredMethod(Tessellator_addVertex, double3Parameter);

		addVertex.insertBefore(
			"if ("+Tessellator_drawMode+" == 7 && "+Tessellator_convertQuadsToTriangles+" && ("+Tessellator_addedVertices+" + 1) % 4 == 0 && "+Tessellator_hasNormals+") {" +
			""+Tessellator_rawBuffer+"["+Tessellator_rawBufferIndex+" + 6] = "+Tessellator_rawBuffer+"[("+Tessellator_rawBufferIndex+" - 24) + 6];" +
			""+Tessellator_rawBuffer+"["+Tessellator_rawBufferIndex+" + 8 + 6] = "+Tessellator_rawBuffer+"[("+Tessellator_rawBufferIndex+" + 8 - 16) + 6];" +
			"}"
			);
		
		// RenderBlocks.class
		
		CtClass renderBlocks = pool.get(RenderBlocks);

		CtClass block = pool.get(Block);
		
 		CtClass renderFaceParameter[] = {block, CtClass.doubleType, CtClass.doubleType, CtClass.doubleType, CtClass.intType};
 		
		CtMethod renderBottomFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderBottomFace, renderFaceParameter);		
		renderBottomFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(0.0F, -1.0F, 0.0F);");

		CtMethod renderTopFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderTopFace, renderFaceParameter);		
		renderTopFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(0.0F, 1.0F, 0.0F);");

		CtMethod renderEastFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderEastFace, renderFaceParameter);		
		renderEastFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(0.0F, 0.0F, -1.0F);");

		CtMethod renderWestFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderWestFace, renderFaceParameter);		
		renderWestFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(0.0F, 0.0F, 1.0F);");

		CtMethod renderNorthFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderNorthFace, renderFaceParameter);		
		renderNorthFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(-1.0F, 0.0F, 0.0F);");

		CtMethod renderSouthFace = renderBlocks.getDeclaredMethod(RenderBlocks_renderSouthFace, renderFaceParameter);		
		renderSouthFace.insertBefore(Tessellator+"."+Tessellator_instance+"."+Tessellator_setNormal+"(1.0F, 0.0F, 0.0F);");
		
		if (argv.length >= 1) {
			 entityRenderer.writeFile(argv[0]);
			 tessellator.writeFile(argv[0]);
			 renderBlocks.writeFile(argv[0]);
		}

	}
	
	static boolean alreadyInstalled = false;
	
	// Obfuscated names. Hopefully this is all that will need to be changed for future releases.

	static final String EntityRenderer = "ll";
	static final String EntityRenderer_mc = "h";
	static final String EntityRenderer_renderEverything = "b";
	static final String EntityRenderer_renderWorld = "c";
	static final String EntityRenderer_renderPlayer = "b";
	static final String EntityRenderer_red = "e";
	static final String EntityRenderer_green = "this.f";
	static final String EntityRenderer_blue = "g";
	static final String Frustrum = "np";
	static final String RenderGlobal = "h";	
	static final String RenderGlobal_function = "b";

	static final String Tessellator = "jy";
	static final String Tessellator_instance = "a";
	static final String Tessellator_setNormal = "b";
	static final String Tessellator_normal = "v";
	static final String Tessellator_addVertex = "a";
	static final String Tessellator_addedVertices = "p";
	static final String Tessellator_drawMode = "r";
	static final String Tessellator_convertQuadsToTriangles = "b";
	static final String Tessellator_hasNormals = "n";
	static final String Tessellator_rawBuffer = "g";
	static final String Tessellator_rawBufferIndex = "o";
	
	static final String RenderBlocks = "bt";
	static final String RenderBlocks_renderBottomFace = "a";
	static final String RenderBlocks_renderTopFace = "b";
	static final String RenderBlocks_renderEastFace = "c";
	static final String RenderBlocks_renderWestFace = "d";
	static final String RenderBlocks_renderNorthFace = "e";
	static final String RenderBlocks_renderSouthFace = "f";

	static final String Block = "pj";
	
}