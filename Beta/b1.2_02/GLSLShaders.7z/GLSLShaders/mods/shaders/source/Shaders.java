// Code written by Chris Brown aka daxnitro.  Do what you want with it but give me some credit if you use it in whole or in part.
// Some of this may be in kind of a weird state since I don't like to change the patcher between Minecraft updates.

package net.minecraft.src;

import net.minecraft.client.Minecraft;

import java.nio.*;

import org.lwjgl.opengl.*;
import org.lwjgl.BufferUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Shaders
{

	private Shaders()
	{
		mc = null;
		initShaders();
	}
	
	private void initShaders() {
		baseProgram = ARBShaderObjects.glCreateProgramObjectARB();
		if (baseProgram != 0) {
			baseVShader = createVertShader("/shaders/base.vsh");
			baseFShader = createFragShader("/shaders/base.fsh");
		}

		if (baseVShader != 0 || baseFShader != 0) {
			if (baseVShader != 0) {
				ARBShaderObjects.glAttachObjectARB(baseProgram, baseVShader);
			}
			if (baseFShader != 0) {
				ARBShaderObjects.glAttachObjectARB(baseProgram, baseFShader);
			}
			ARBShaderObjects.glLinkProgramARB(baseProgram);
			ARBShaderObjects.glValidateProgramARB(baseProgram);
			printLogInfo(baseProgram);
		} else {
			baseProgram = 0;
		}
		
		finalProgram = ARBShaderObjects.glCreateProgramObjectARB();
		if (finalProgram != 0) {
			finalVShader = createVertShader("/shaders/final.vsh");
			finalFShader = createFragShader("/shaders/final.fsh");
		}

		if (finalVShader != 0 || finalFShader != 0) {
			if (finalVShader != 0) {
				ARBShaderObjects.glAttachObjectARB(finalProgram, finalVShader);
			}
			if (finalFShader != 0) {
				ARBShaderObjects.glAttachObjectARB(finalProgram, finalFShader);
			}
			ARBShaderObjects.glLinkProgramARB(finalProgram);
			ARBShaderObjects.glValidateProgramARB(finalProgram);
			printLogInfo(finalProgram);
		} else {
			finalProgram = 0;
		}
	}
	
	public void useProgram(int program) {
		ARBShaderObjects.glUseProgramObjectARB(program);
		activeProgram = program;
		if (program != 0) {
			int sampler1U = ARBShaderObjects.glGetUniformLocationARB(program, "sampler1");
			ARBShaderObjects.glUniform1iARB(sampler1U, 1);
			int sampler2U = ARBShaderObjects.glGetUniformLocationARB(program, "sampler2");
			ARBShaderObjects.glUniform1iARB(sampler2U, 2);
			int fogMode = GL11.glGetInteger(GL11.GL_FOG_MODE);
			int fogModeU = ARBShaderObjects.glGetUniformLocationARB(program, "fogMode");
			ARBShaderObjects.glUniform1iARB(fogModeU, fogMode);
			if (mc != null) {
				int aspectRatioU = ARBShaderObjects.glGetUniformLocationARB(program, "aspectRatio");
				ARBShaderObjects.glUniform1fARB(aspectRatioU, (float)mc.displayWidth / (float)mc.displayHeight);
				int displayWidthU = ARBShaderObjects.glGetUniformLocationARB(program, "displayWidth");
				ARBShaderObjects.glUniform1fARB(displayWidthU, (float)mc.displayWidth);
				int displayHeightU = ARBShaderObjects.glGetUniformLocationARB(program, "displayHeight");
				ARBShaderObjects.glUniform1fARB(displayHeightU, (float)mc.displayHeight);
				int nearU = ARBShaderObjects.glGetUniformLocationARB(program, "near");
				ARBShaderObjects.glUniform1fARB(nearU, 0.05F);
				int farU = ARBShaderObjects.glGetUniformLocationARB(program, "far");
				ARBShaderObjects.glUniform1fARB(farU, 256 >> mc.gameSettings.renderDistance);
			}
		}
	}
	
	private int createVertShader(String filename) {
		int vertShader = ARBShaderObjects.glCreateShaderObjectARB(ARBVertexShader.GL_VERTEX_SHADER_ARB);
		if (vertShader == 0) {
			return 0;
		}
		String vertexCode = "";
		String line;
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader((Shaders.class).getResourceAsStream(filename)));
			while ((line=reader.readLine()) != null) {
				vertexCode += line + "\n";
			}
		} catch(Exception e) {
			return 0;
		}
		ARBShaderObjects.glShaderSourceARB(vertShader, vertexCode);
		ARBShaderObjects.glCompileShaderARB(vertShader);
		printLogInfo(vertShader);
		return vertShader;
	}
	 
	private int createFragShader(String filename) {
		int fragShader = ARBShaderObjects.glCreateShaderObjectARB(ARBFragmentShader.GL_FRAGMENT_SHADER_ARB);
		if (fragShader == 0) {
			return 0;
		}
		String fragCode = "";
		String line;
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader((Shaders.class).getResourceAsStream(filename)));
			while ((line=reader.readLine()) != null) {
				fragCode += line + "\n";
			}
		} catch (Exception e) {
			return 0;
		}
		ARBShaderObjects.glShaderSourceARB(fragShader, fragCode);
		ARBShaderObjects.glCompileShaderARB(fragShader);
		printLogInfo(fragShader);
		return fragShader;
	}

	private static boolean printLogInfo(int obj) {
		IntBuffer iVal = BufferUtils.createIntBuffer(1);
		ARBShaderObjects.glGetObjectParameterARB(obj, ARBShaderObjects.GL_OBJECT_INFO_LOG_LENGTH_ARB, iVal);
		 
		int length = iVal.get();
		if (length > 1) {
			ByteBuffer infoLog = BufferUtils.createByteBuffer(length);
			iVal.flip();
			ARBShaderObjects.glGetInfoLogARB(obj, iVal, infoLog);
			byte[] infoBytes = new byte[length];
			infoLog.get(infoBytes);
			String out = new String(infoBytes);
			System.out.println("Info log:\n" + out);
			return false;
		}
		return true;
	}
	
	private int createTexture(int width, int height, boolean depth) throws java.lang.OutOfMemoryError {
		int textureId = GL11.glGenTextures();
		
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
				
		if (depth) {
		   	ByteBuffer buffer = ByteBuffer.allocateDirect(width * height * 4 * 4);
			GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_DEPTH_COMPONENT, width, height, 0, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, buffer);
		} else {
		   	ByteBuffer buffer = ByteBuffer.allocateDirect(width * height * 4);
			GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, width, height, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, buffer);
		}
		
		GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
		GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
		
		return textureId;
	}
	
	private void deleteTexture(int textureId) {
		GL11.glDeleteTextures(textureId);
	}

	public int baseTextureId() {
		if (baseTextureId == 0 || baseTextureWidth != mc.displayWidth || baseTextureHeight != mc.displayHeight) {
			try {
				int textureId = createTexture(mc.displayWidth, mc.displayHeight, false);
				baseTextureId = textureId;
				baseTextureWidth = mc.displayWidth;
				baseTextureHeight = mc.displayHeight;
			} catch (java.lang.OutOfMemoryError e) {
			}
		}
		return baseTextureId;
	}

	public int depthTextureId(Minecraft minecraft) {
		mc = minecraft;
		if (depthTextureId == 0 || depthTextureWidth != mc.displayWidth || depthTextureHeight != mc.displayHeight) {
			try {
				int textureId = createTexture(mc.displayWidth, mc.displayHeight, true);
				depthTextureId = textureId;
				depthTextureWidth = mc.displayWidth;
				depthTextureHeight = mc.displayHeight;
			} catch (java.lang.OutOfMemoryError e) {
			}
		}
		return depthTextureId;
	}

	public int depthTexture2Id(Minecraft minecraft) {
		mc = minecraft;
		if (depthTexture2Id == 0 || depthTexture2Width != mc.displayWidth || depthTexture2Height != mc.displayHeight) {
			try {
			int textureId = createTexture(mc.displayWidth, mc.displayHeight, true);
				depthTexture2Id = textureId;
				depthTexture2Width = mc.displayWidth;
				depthTexture2Height = mc.displayHeight;
			} catch (java.lang.OutOfMemoryError e) {
			}
		}
		return depthTexture2Id;
	}
	
	public void processScene(float red, float green, float blue) {
		if (!mc.gameSettings.anaglyph && finalProgram != 0) {
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, baseTextureId());
	  		GL11.glCopyTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, 0, 0, baseTextureWidth, baseTextureHeight, 0);
	  		GL13.glActiveTexture(GL13.GL_TEXTURE1);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTextureId(mc));
	  		GL13.glActiveTexture(GL13.GL_TEXTURE2);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTexture2Id(mc));
	  		GL13.glActiveTexture(GL13.GL_TEXTURE0);
			useProgram(finalProgram);
			GL11.glClearColor(red, green, blue, 0.0F);
			GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
			GL11.glDisable(GL11.GL_DEPTH_TEST);
			GL11.glDisable(GL11.GL_BLEND);
			GL11.glMatrixMode(5889 /*GL_PROJECTION*/);
			GL11.glLoadIdentity();
			GL11.glOrtho(0, mc.displayWidth, mc.displayHeight, 0, -1, 1);
			GL11.glMatrixMode(5888 /*GL_MODELVIEW0_ARB*/);
			GL11.glLoadIdentity();
			GL11.glBegin(GL11.GL_QUADS);
			GL11.glTexCoord2f(0, 1);
			GL11.glVertex3f(0, 0, 0);
			GL11.glTexCoord2f(0, 0);
			GL11.glVertex3f(0, mc.displayHeight, 0);
			GL11.glTexCoord2f(1, 0);
			GL11.glVertex3f(mc.displayWidth, mc.displayHeight, 0);
			GL11.glTexCoord2f(1, 1);
			GL11.glVertex3f(mc.displayWidth, 0, 0);
			GL11.glEnd();
			GL11.glEnable(GL11.GL_DEPTH_TEST);
			useProgram(0);
		}
	}
	
	public static void copyDepthTexture(int texture) {
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
		if (texture == depthTextureId) {
			GL11.glCopyTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_DEPTH_COMPONENT, 0, 0, depthTextureWidth, depthTextureHeight, 0);
		} else if (texture == depthTexture2Id) {
			GL11.glCopyTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_DEPTH_COMPONENT, 0, 0, depthTexture2Width, depthTexture2Height, 0);
		} else {
			GL11.glCopyTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_DEPTH_COMPONENT, 0, 0, mc.displayWidth, mc.displayHeight, 0);
		}
	}
	
	public static void bindTexture(int activeTexture, int texture) {
		// Unused at the moment.
		GL13.glActiveTexture(activeTexture);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
	}
	
	public static final Shaders instance = new Shaders();
	public int activeProgram = 0;

	public int baseProgram = 0;
	private int baseVShader = 0;
	private int baseFShader = 0;

	public int finalProgram = 0;
	private int finalVShader = 0;
	private int finalFShader = 0;
	
	private static int baseTextureId = 0;
	private static int baseTextureWidth = 0;
	private static int baseTextureHeight = 0;

	private static int depthTextureId = 0;
	private static int depthTextureWidth = 0;
	private static int depthTextureHeight = 0;

	private static int depthTexture2Id = 0;
	private static int depthTexture2Width = 0;
	private static int depthTexture2Height = 0;
	
	public static Minecraft mc = null;
	
	public static final int RENDER_TYPE_UNKNOWN = 0;
	public static final int RENDER_TYPE_TERRAIN = 1;
}
