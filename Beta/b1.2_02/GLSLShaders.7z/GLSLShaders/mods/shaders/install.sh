#!/bin/bash
# GLSL shader mod by daxnitro.

if [ -z $mod ]; then
	echo "Run the other install.sh to install this mod."
	exit
fi

echo "shaders: Copying files . . ."

rm -r $TEMPDIR/minecraft/shaders 2>/dev/null

cp -R $mod/files/shaders $TEMPDIR/minecraft

cp $mod/files/Shaders.class $TEMPDIR/minecraft

echo "shaders: Patching bytecode . . ."

java -classpath $(echo $mod)"/patcher:$BASEDIR/tools/javassist.jar:$TEMPDIR/minecraft" Patcher "$TEMPDIR/minecraft"