// Helper utility to create JAR files by daxnitro.

// Stack Overflow is an amazing site.
// http://stackoverflow.com/questions/1281229/how-to-use-jaroutputstream-to-create-a-jar-file
// http://stackoverflow.com/questions/204784/how-to-construct-a-relative-path-in-java-from-two-absolute-paths-or-urls

import java.io.*;
import java.util.jar.*;

public class JarHelper {

	public static void main(String[] argv) throws IOException {
		if (argv.length < 3) {
			System.out.println("Usage: JarHelper outputjar chdir inputdir");
			return;
		}
		JarOutputStream target = new JarOutputStream(new FileOutputStream(argv[0]));
		add(new File(relativePath(argv[1], argv[2])), target, argv[1]);
		target.close();
	}
	
	private static void add(File source, JarOutputStream target, String basePath) throws IOException {
		BufferedInputStream in = null;
		try {
			String name = relativePath(source.getPath().replace("\\", "/"), basePath);
			System.out.println(name);
			if (source.isDirectory()) {
				for (File nestedFile: source.listFiles()) {
					add(nestedFile, target, basePath);
				}
				return;
			}
	
			JarEntry entry = new JarEntry(name);
			entry.setTime(source.lastModified());
			target.putNextEntry(entry);
			in = new BufferedInputStream(new FileInputStream(source));
	
			byte[] buffer = new byte[1024];
			while (true) {
				int count = in.read(buffer);
				if (count == -1)
					break;
				target.write(buffer, 0, count);
			}
			target.closeEntry();
		} finally {
			if (in != null) {
				in.close();
			}
		}
	}
	
	private static String relativePath(String path, String base) {
		return new File(base).toURI().relativize(new File(path).toURI()).getPath();
	}	
}