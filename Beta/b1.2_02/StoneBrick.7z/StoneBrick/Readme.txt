-- 19/01/2011 by RPFeltz (aka ss1122, MrTurtles, RPFproductions); modID_01 --


- How to install -

1) Download Mod Loader here: http://www.minecraftforum.net/viewtopic.php?f=25&t=80246
2) Download Tool Utils here: http://www.minecraftforum.net/viewtopic.php?f=25&t=97959
3) Download More IDs here: http://www.minecraftforum.net/viewtopic.php?f=25&t=83028
4) Drag all class files and the stonebrick folder into '%appdata%\.minecraft\bin\minecraft.jar'.