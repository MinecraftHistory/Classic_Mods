Installation Instructions:

1. Open your .minecraft folder.
2. Open the �Bin� folder.
3. Open Minecraft.jar with 7zip or Winrar.
4. Delete the META-INF folder
5. Place the modloader files in there
6. Place the �Place in minecraft.jar� files
7. Close everything.
8. Open your .minecraft folder again.
9. Place the �Mod� file there.

Goodluck, i have u any questions/problems/requests ask me.

Reinert

(it requires ModLoader:http://www.minecraftforum.net/viewtopic.php?f=25&t=80246)
(writen by Ansien12)