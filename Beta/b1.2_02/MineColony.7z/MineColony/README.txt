MineColony v0.32
by lacozzini 

Thread: http://www.minecraftforum.net/viewtopic.php?f=25&t=125803
compatible with minecraft Beta 1.2_02


HOW TO BUILD LUMBERJACK's HUT
Craft the lumberjack's chest using the following recipe:

###
#A#
###

Where:
	# - planks
	A - any type of axe

Place the chest on the ground and the hut should be placed instantly.


HOW TO BUILD MINER's HUT
Craft the miner's chest using the following recipe:

###
#T#
###

Where:
	# - planks
	T - any type of pickaxe

Place the chest on the ground and the hut should be placed instantly.

HOW TO PLACE BUILDING USING SCEPTER
First you must craft scepter using folling recipe:
 X
#

where:
	# - stick
	X - golden/iron ingot

Then equip yourself with the golden scepter and right click on lumberjack/miner chest.
To build a fence around the building, equip yourself with the iron scepter and click on the chest.

OTHER COMPATILE VERSIONS:
If you experience black screen issue, then you can try to use different compatible versions in other_compatile_versions folder. Just copy one of the mod_MineColony.class file from ther into root directory of this mod.

CREDITS
Miner's skin by Arbr