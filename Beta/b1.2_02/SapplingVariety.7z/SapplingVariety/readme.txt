VarietalSaplings (Mod for Minecraft Beta 1.2_02)
By Marglyph
Last update: 23 January 2011

VarietalSaplings is a mod that makes the saplings dropped by pine and birch
trees grow into the same kind of tree they came from.

RECOMMENDED INSTALL

Use the Minecrafter mod utility: http://minecrafterapp.wordpress.com/

MANUAL INSTALL

Read and follow the instructions at:
http://www.minecraftforum.net/viewtopic.php?f=25&t=116234
