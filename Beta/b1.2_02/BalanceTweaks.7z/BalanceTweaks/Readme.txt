SyrupTweaks v.1.0
Formerly included in FancyPack

How to Install
--------
ALWAYS back up your worlds! ALWAYS!

0. Before you do anything else, if you will be using any of the optional mods whose filename begins with "mod_", download and extract ModLoader somewhere you can find it. Modloader can be found here: http://www.minecraftforum.net/viewtopic.php?f=25&t=80246
1. Open minecraft.jar with WinRAR or other archive program.
2. Delete the META-INF folder from inside minecraft.jar.
3. Add all the class files from ModLoader into your minecraft.jar.
4. Add all the class files from the mod directories you wish to install from this pack into your minecraft.jar. Make sure you are adding the class files ONLY, not the entire folders that contain the class files!
5. Close minecraft.jar.
6. Run Minecraft normally and enjoy!

A black screen means you did not install all the class files in the specific packs you are using, or you did not install all the CORE files, or you did not delete the META-INF folder from your minecraft.jar.


ABOUT THE MODS
--------

*FASTER OBSIDIAN MINING will allow diamond picks to harvest obsidian much faster. Obsidian will not become any weaker or less resistant. It is simply quicker to mine when using diamond tools.
*CANOPY ITEMS comes in two versions. Both versions will have leaves occasionally drop placeable leaf blocks when destroyed as well as the normal saplings. One version will ALSO have leaf blocks occasionally drop apples when destroyed.
*CHEAPER GOLDEN APPLES changes the golden apple recipe to use gold ingots, instead of gold blocks.
*CHEAPER LIGHTSTONE allows you to make lightstone blocks with just 1 lightstone dust, instead of 9, so your return and yield are the same.


CREDITS
--------
Vib and ChocolateySyrup, for creating the mod.
Special thanks to Risugami and 303 for their awesome modloader, the entire team at MCP for creating an accessible tool, and all the countless people who helped us work out the bugs along the way.