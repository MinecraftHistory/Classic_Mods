Equivalent Exchange ~ Ayutashi

Updated for Beta 1.2!


::Install Notes::

il.class - Glowstone fix (glowstone drops a full glowstone block)
fa.class - Bookshelf fix (bookshelves drop bookshelf blocks)
dt.class - Glass fix (glass drops glass blocks)

sj.class - Drops two single half-steps when a double step is broken!!
	   (Thanks to wolfkun for the unintentionally brilliant idea! :3)

jn.class - Ice Block variant.  This one lets Ice drop Ice Blocks in
	   addition to the usual "melting" function.  A bit messy,
	   considering you create MORE water every time you break it :\
	   Check out the variant below!

eg.class - Boat variant.  This drops five wooden plank blocks when a
           boat breaks, instead of three, plus two sticks.  This makes
           it easier to rebuild boats when broken, since no materials
           are lost in the process.



::OPTIONAL FILES::
(These are optional builds of the .class files above.  They are in separate
 folders, so you shouldn't need to worry about confusing them!)

glowstone_dust/il.class - Allows Glowstone to drop 9x Glowstone Dust.

waterless_ice/jn.class - WATERLESS variant of the Ice Block mod!  This one just drops Ice
	   blocks, without releasing any water whatsoever.  It's "cleaner"
	   than the first solution, but I consider it a more drastic change,
	   so I included it as a variant instead.


Just open your minecraft.jar with WinRAR, then drag and drop the mods you want!
These mods don't conflict with each other, so feel free to choose!
Make sure you don't try to use -BOTH- variants of a single mod...
that's just silly!  xD

Don't forget to delete the META-INF folder from minecraft.jar, and enjoy!  :3

