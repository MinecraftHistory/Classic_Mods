Spawn Locus v.1.0

How to Install
--------
ALWAYS back up your worlds! ALWAYS!

0. Before you do anything else, download and extract ModLoader somewhere you can find it. Modloader can be found here: http://www.minecraftforum.net/viewtopic.php?f=25&t=80246
1. Open minecraft.jar with WinRAR or other archive program.
2. Delete the META-INF folder from inside minecraft.jar.
3. Add all the class files from ModLoader into your minecraft.jar.
4. Add the entire folder (including the folder itself) labeled "SpawnLocus" into your minecraft.jar. This is the folder that contains the new block textures.
5. Close minecraft.jar.
6. Run Minecraft normally and enjoy!

A black screen means you did not install modloader, did not add all the class files, or you did not delete the META-INF folder from your minecraft.jar.


ABOUT THE MOD
--------
The Spawn Locus is a craftable block that can change your spawn point.
To craft it, use this recipe:
#X#
XOX
#X#
Where # is soul sand, X is a gold ingot, and O is a fully-crafted compass.

To use it, simply place it in the world, and right-click it to use. From then on, that's your spawn point! A locus can be used as many times as you like, and you can place as many loci as you want throughout the world, but you'll only spawn at your most recently used locus. So it might be a smart idea to place one in each of your main bases across the world, and use it when you plan on staying in that location for a while.
Be aware that it will take you to the first available space vertically above the block, so if your spawn point is buried under a solid mountain without 2 free blocks above it, you'll spawn on top of that mountain after you die!

Once placed, a locus cannot be picked back up -- only destroyed. Be careful where you place them!


CREDITS
--------
Vib and ChocolateySyrup, for creating the mod.
Rhodox/kas for the images and textures from which the Spawn Locus's texture was composited.
Special thanks to Risugami and 303 for their awesome modloader, the entire team at MCP for creating an accessible tool, and all the countless people who helped us work out the bugs along the way.