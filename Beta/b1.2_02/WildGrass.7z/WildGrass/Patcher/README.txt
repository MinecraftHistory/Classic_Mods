WILD GRASS'S MINECRAFT MOD
==========================
by ejhopkins


INSTALLATION
------------

Extract the contents of this file to your minecraft folder. Under windows,
this is %appdata%\.minecraft 

PLEASE NOTE: This goes in the .minecraft folder NOT the .minecraft/bin folder

RUNNING THE PATCHER
-------------------

First things first: Though this patcher makes its own backups, I strongly 
advise you to make your own backup of minecraft.jar first. That way, if anything
goes wrong, you can go back easily to where you were.

The patcher is "install.bat" which is located int the WildGrassPatcher folder
You shouldbe able to run it just by double clicking on it.


THINGS TO KNOW
-------------------
If you are using MrMessiahs Better Light or Better Grass mods,
then you MUST install these BEFORE you run this patcher

You also MUST install Risugami's Modloader either before or after your run this patcher.


If you don't want to install lily pads, simply say "yes" when prompted to skip installation

If you don't want me to change the way hoes work in order to allow fun lawn maintinence,
then say "yes" when prompted to skip hoes.



UNINSTALLING
------------

To uninstall, restore your backed up minecraft.jar.

