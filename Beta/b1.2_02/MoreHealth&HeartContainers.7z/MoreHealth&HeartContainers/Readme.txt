For Beta 1.2_02
ModLoader required!

1.Drag the .class files into your minecraft.jar.
2.Drag the moreHealth folder into your jar.
2. Delete the Meta-inf folder!
3. Run minecraft, enjoy!
4. Find heart pieces and containers in dungeon chests, per you request!
5. Any questions/suggestions, post in the thread!

*Bosses Patch folder: Drag the .class files only if you have the mod installed! 
EX: CreeperQueen.class drag it into the .jar IF you installed simo's creeper queen mod! 
Compatible bosses:
Creeper Queen version 1.1


Backup your minecraft jar! Might conflict with other mods!