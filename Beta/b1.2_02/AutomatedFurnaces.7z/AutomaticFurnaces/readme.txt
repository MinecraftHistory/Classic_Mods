This is version 1.1

Mod thread: http://www.minecraftforum.net/viewtopic.php?f=25&t=102175

If you have any questions, come to #mcp@esper.net

ZeuX