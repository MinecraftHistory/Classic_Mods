Flan's Vehicles Mod for Minecraft 1.5_01

Version 3
------------
Installation
------------

1. Open the .zip archive (already done)
2. Open your .minecraft directory (appdata/.minecraft)
3. Drag the files from "resource files" into the folder called "resources"
4. Go to .minecraft/bin and open your minecraft.jar in winRAR, winZIP, 7zip or any other suitiable program
5. Drag the files from "jar files" into the minecraft.jar
6. Drag the vehicles.properties and vehicles.txt into your .minecraft folder
7. Install Risugami's ModLoader (similar instructions to above, included in ModLoader download)
8. Install SDK's ModLoaderMp (similar instructions to above)
9. Install GaryCXJk's TurboModel Thingy 2.2 Preview(same again)
10. DELETE THE META-INF FOLDER
11. Play!
