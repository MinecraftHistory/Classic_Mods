Xie's Mod Pack v1.3 for MineCraft Beta 1.5_01, 29th April 2011

Includes:
Xie's Farming Mod v1.3
Xie's Food Stacking Mod v1.2
Xie's Hunger Mod v1.3
Xie's Cooking Mod v1.2

Requires Mod Loader.

Installing:
Please remember to make backups before installing.

1. Install the latest version of ModLoader.
2. Copy the mod files into minecraft.jar using your favourite archive program.
3. Delete the META-INF folder in minecraft.jar
4. Profit.