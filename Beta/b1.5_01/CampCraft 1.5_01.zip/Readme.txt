Backup your minecraft.jar and saves, best to be safe then sorry :)

Instructions:
1. Put all the files in the "Install 1.5" folder into your minecraft.jar.
2. Move the tent.properties into your /.minecraft folder

Please post bugs or ideas you may have on this mod :)

