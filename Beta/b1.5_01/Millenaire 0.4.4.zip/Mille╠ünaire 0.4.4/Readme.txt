Millénaire 0.4.4 installation

- install ModLoader Beta 1.5_01v3
- clear META-INF from the minecraft.jar
- put the content of "Put in minecraft folder" in the minecraft folder (.minecraft in Windows) (alongside bin, saves etc.)
- put the zip file from "Put in mods folder" in minecraft/mods (without unzipping). If you do not have a mods directory, create it.
- there are no Millénaire classes to be put in the minecraft.jar anymore. This is replaced by the zip in the mods folder.

If the mod is running properly, it will display this line stating that it is active when you first enter a world: "Millénaire is loaded. Explore and press 'v' to locate villages."