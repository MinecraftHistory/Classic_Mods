MineColony v0.5
by lacozzini 

Thread: http://www.minecraftforum.net/viewtopic.php?f=25&t=125803
compatible with minecraft Beta 1.5

HOW TO INSTALL
1.Install ModLoader Beta 1.5_01v3
2.Copy the MineColony0.42.zip file into your minecraft mods folder.

HOW TO BUILD LUMBERJACK's HUT
Craft the lumberjack's chest using the following recipe:

###
#A#
###

Where:
	# - planks
	A - any type of axe

Place the chest on the ground and the hut should be placed instantly.


HOW TO BUILD MINER's HUT

###
#T#
###

Where:
	# - planks
	T - any type of pickaxe

HOW TO BUILD DELIVERY MAN'S HUT

###
#T#
###

Where:
	# - planks
	C - chest

HOW TO BUILD FARMER'S HUT

###
#H#
###

Where:
	# - planks
	C - any type of hoe

Place the chest on the ground and the hut should be placed instantly.

HOW TO PLACE BUILDING USING SCEPTER
First you must craft scepter using folling recipe:
 X
#

where:
	# - stick
	X - golden/iron ingot

Then equip yourself with the golden scepter and right click on lumberjack/miner chest.
To build a fence around the building, equip yourself with the iron scepter and click on the chest.

CREDITS
Main post edited by Vlad11
Miner's skin by Arbr
Farmer, Delivery Man and Lumberjack skin by godsblade
Farmer hut blueprint by Vlad11
Install instructions by Chiefwaffles
Coins icons by Heho