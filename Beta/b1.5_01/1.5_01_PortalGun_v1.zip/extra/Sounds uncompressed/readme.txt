This folder contains sounds that I used to create the sounds for the mod.

They are in their uncompressed states, direct from the Portal game.

The sound for the High Energy Pellet itself is not included due to it being 17 different parts.

Thanks to Valve for creating the sounds.