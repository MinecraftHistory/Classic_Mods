http://www.minecraftforum.net/viewtopic.php?f=1032&t=215961

This mod is all my hard work. Please drop a donation as a thank you or sorts, if you liked it.. Thanks