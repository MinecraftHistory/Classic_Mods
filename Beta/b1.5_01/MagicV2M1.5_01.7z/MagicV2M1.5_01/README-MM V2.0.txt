M3: Minecraft Magic Mod V2.0.

  /***********/
 / Overview  /
/___________/

This mod adds some RPG style elements to Minecraft 
including the ability to craft magic wands/staves
that consume magic powder (mp) to use there effects.

V1.1 Change: MP is now created by smelting redstone dust.

Note: This mod has not been tested along side any other mods
so please install it on a fresh copy of minecraft for the 
best results. Also note that this mod won't work with
custom texture packs as the textures for the new items
have been added to the standard minecraft texture.

  /***************/
 / File Changes  /
/_______________/

ItemWand
ItemMagicPowder
ItemFireWand
ItemWindWand
ItemWaterWand
ItemEarthWand
ItemIceWand
ItemLightningWand
ItemMagmaWand
ItemPlantWand
ItemHeatBeamStaff
ItemWaterfallStaff
ItemOreStaff
ItemGustStaff
BlockLightning
EntityFireSpell
EntityWindSpell
EntityWaterSpell
EntityMagmaSpell
EntityIceSpell
mod_magic



  /***************/
 / installation  /
/_______________/

Important: Minecraft magic requires Risugami's ModLoader V5.
Please install ModLoader first.

Windows:
1) Open up %appdata%, if you don't know how to do this, start>run, then type in %appdata%
2) Browse to .minecraft/bin
3) Open up minecraft.jar with WinRAR or 7zip.
4) Drag and drop the class files in the root of the jar.
5) Drag the magic folder into the root folder.
6) Copy the contents of the armor folder into the armor folder in the root of the jar.
7) Delete the META-INF folder in the jar (if you haven't already).
8) Run Minecraft, enjoy!

Macintosh (not tested):
1) Go to Applications>Utilities and open terminal.
2) Type in the following, line by line:

Code: Select all
    cd ~
    mkdir mctmp
    cd mctmp
    jar xf ~/Library/Application\ Support/minecraft/bin/minecraft.jar


3) Outside of terminal, copy all the files and folders into the mctmp directory.
4) Back inside terminal, type in the following:

Code: Select all
    rm META-INF/MOJANG_C.*
    jar uf ~/Library/Application\ Support/minecraft/bin/minecraft.jar ./
    cd ..
    rm -rf mctmp


5) Run Minecraft, enjoy!

  /***************/
 /   Changelog   /
/_______________/

v1.1
Added ModLoader V5 Support.
MP is now created by smelting redstone dust.
v1.2
Wands are now crafted using Magic Orbs.
Fixed the earth wand bug.
v1.3
Support for minecraft V1.4
Bugfixes.
v2.0
8 New wands.
Wand levelling.
Magic Armor.
Bugfixes.