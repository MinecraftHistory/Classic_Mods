/** 
 * Copyright (c) Krapht, 2012
 * 
 * "SneakyPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.sneakypipes;

import net.minecraft.src.TileEntity;
import net.minecraft.src.buildcraft.transport.PipeLogic;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;

public class PipeLogicSand extends PipeLogic{
	@Override
	public boolean isPipeConnected(TileEntity tile) {
		 return (tile instanceof TileGenericPipe);
	}
}
