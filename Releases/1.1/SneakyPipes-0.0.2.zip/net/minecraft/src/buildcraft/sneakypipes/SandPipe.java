/** 
 * Copyright (c) Krapht, 2012
 * 
 * "SneakyPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.sneakypipes;

import net.minecraft.src.mod_SneakyPipes;
import net.minecraft.src.buildcraft.transport.Pipe;
import net.minecraft.src.buildcraft.transport.PipeTransportItems;

public class SandPipe extends Pipe{
	 public SandPipe(int itemID) {
			super(new PipeTransportItems(), new PipeLogicSand(), itemID);
	}
	 
	 @Override
	public int getMainBlockTexture() {
		 return mod_SneakyPipes.sandPipeTexture;
	}

}