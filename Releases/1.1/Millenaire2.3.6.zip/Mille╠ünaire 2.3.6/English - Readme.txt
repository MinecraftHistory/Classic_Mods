==Millénaire installation==

To install Millénaire, the recommended way is to use the Millénaire Installer available from www.millenaire.org. If you want to install it manually, here are the requirements:

- ModLoader must be installed. Download and instructions from its thread: http://www.minecraftforum.net/topic/75440-v11/

- Starting with Millénaire 2.2, Forge's Sprites API must be installed. You can get it from the following ways:
* By installing Forge itself. This is recommended if you want to use Forge mods. Download and instructions: http://www.minecraftforum.net/topic/514000-api/
* OR, by installing the BetterThanWolves mod that ships with it included. This is recommended if you want to play that mod. Download and instructions: http://www.minecraftforum.net/topic/253365-11/
* OR, by installing the Forge Sprites API alone. This is recommended if you only want to play Millénaire, or want to play it with mods that are incompatible with the full Forge. To install it, simply put the content of "Put in minecraft.jar (if Forge absent)" in your minecraft.jar.
- Note that installing any of those three will break support for High-Res textures. To re-enable it, re-install MCPatcher or OptiFine afterward.

- Then put the zip file from "Put in mods folder" in the "mods" folder in your minecraft directory (if the folder does not exist, create it).

- Then put the millenaire and millenaire-custom directories inside "Put in minecraft folder" in your minecraft folder

==Millénaire resources==

To download the latest Millénaire release, check the official website: www.millenaire.org
For information on the mod, check the player-maintained wiki: www.millenaire.org/wiki
To download player-made extra content such as new buildings, check the Millénaire Library: www.millenaire.org/library
To discuss Millénaire, ask questions or get support, check the Millénaire forum thread: http://www.minecraftforum.net/topic/227822-11/

==Forge Sprites API credits==

The Forge Sprites API shipped with Millénaire are taken from the Forge project (http://www.minecraftforum.net/topic/514000-api/). Full credits for them goes to the Forge team.
The seperation of the Sprites API from the rest of Forge was done by FlowerChild for use in his BetterThanWolves mod. Re-use for Millénaire done with his permission.

Following the Forge licence, the source code for the modified Forge classes is included in "ForgeSpriteExtender-SRC". The classes ForgeHooksClient.java and MinecraftForgeClient.java are modified by FlowerChild, the rest are taken almost intact from Forge 1.3.1.