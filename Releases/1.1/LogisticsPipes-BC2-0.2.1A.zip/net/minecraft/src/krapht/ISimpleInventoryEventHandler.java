package net.minecraft.src.krapht;

public interface ISimpleInventoryEventHandler {

	void InventoryChanged(SimpleInventory inventory);
}
