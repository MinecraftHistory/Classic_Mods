package net.minecraft.src.buildcraft.krapht.logic;

import net.minecraft.src.EntityPlayer;

public class TemporaryLogic  extends BaseRoutingLogic{

	@Override
	public void onWrenchClicked(EntityPlayer entityplayer) {}

	@Override
	public void destroy() {	}

}
