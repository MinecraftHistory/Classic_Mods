package net.minecraft.src.buildcraft.logisticspipes;

import java.util.ArrayList;

import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.core_LogisticsPipes;
import net.minecraft.src.buildcraft.krapht.LogisticsItem;
import net.minecraft.src.buildcraft.logisticspipes.modules.ISendRoutedItem;
import net.minecraft.src.buildcraft.logisticspipes.modules.ModulePolymorphicItemSink;
import net.minecraft.src.buildcraft.logisticspipes.modules.ModuleExtractor;
import net.minecraft.src.buildcraft.logisticspipes.modules.ILogisticsModule;
import net.minecraft.src.buildcraft.logisticspipes.modules.ModuleItemSink;
import net.minecraft.src.buildcraft.logisticspipes.modules.ModulePassiveSupplier;
import net.minecraft.src.buildcraft.logisticspipes.modules.ModuleQuickSort;
import net.minecraft.src.buildcraft.logisticspipes.modules.ModuleTerminus;

public class ItemModule extends LogisticsItem{

	public ItemModule(int i) {
		super(i);
		this.hasSubtypes = true;
	}
	
	@Override
	public int getIconFromDamage(int i) {
		return 2 * 16 + i;
	}
	
	@Override
	public String getItemDisplayName(ItemStack itemstack) {
		switch(itemstack.getItemDamage()){
			case 0:
				return "Blank module";
			case 1:
				return "ItemSink module";
			case 2:
				return "Passive Supplier module";
			case 3:
				return "Extractor module";
			case 4: 
				return "Polymorphic ItemSink module";
			case 5:
				return "QuickSort module";
			case 6:
				return "Terminus module";
			default:
				return ""; 
		}
	}
	
	@Override
	public void addCreativeItems(ArrayList itemList) {
		for (int i = 0; i <= 6; i++){
			itemList.add(new ItemStack(this, 1, i));
		}
		
	}
	
	public ILogisticsModule getModuleForItem(ItemStack itemStack, ILogisticsModule currentModule, IInventoryProvider invProvider, ISendRoutedItem itemSender){
		if (itemStack == null) return null;
		if (itemStack.itemID != this.shiftedIndex) return null;
		switch (itemStack.getItemDamage()){
			case 1:
				if (currentModule instanceof ModuleItemSink) return currentModule;
				return new ModuleItemSink();
			case 2:
				if (currentModule instanceof ModulePassiveSupplier) return currentModule;
				return new ModulePassiveSupplier(invProvider);
			case 3:
				if (currentModule instanceof ModuleExtractor) return currentModule;
				return new ModuleExtractor(invProvider, itemSender);
			case 4:
				if (currentModule instanceof ModulePolymorphicItemSink) return currentModule;
				return new ModulePolymorphicItemSink(invProvider);
			case 5:
				if (currentModule instanceof ModuleQuickSort) return currentModule;
				return new ModuleQuickSort(invProvider, itemSender);
			case 6:
				if (currentModule instanceof ModuleTerminus) return currentModule;
				return new ModuleTerminus();
			default:
				return null;
		}
			
		
	}
	
	
	
}
