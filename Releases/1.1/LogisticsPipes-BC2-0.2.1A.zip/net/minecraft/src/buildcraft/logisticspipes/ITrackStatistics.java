package net.minecraft.src.buildcraft.logisticspipes;

/**
 * This interface tracks statistics
 * @author Krapht
 *
 */
public interface ITrackStatistics {
	void recievedItem(int count);

}
