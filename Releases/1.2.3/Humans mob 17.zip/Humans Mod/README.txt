Version 1.5 Warning: THis is in Beta, as it does may crash your computer, which has not happened in testing, Use at Your Own Risk

Ye've been Warned

How to install:
--------------------

Step 1: Put zf.class, ai.class, herobrine.class files and the "villager" folder and into minecraft.jar!Move the herobrine.png into your 'Mobs' folder.

Whalaa!

Step 2: YOU MUST DELETE THE META-INF FOLDER WHICH IS INSIDE OF MINECRAFT.JAR!!!

--------------------


Made by Jdembo/Giraffestock/Lazyb0ysd

Thankyou for using my mod!

:)

Credits to:

GIRAFFESTOCK For textures
 
Jdembo for organization/minor code

Luckymaxattack For code and texture! Thanks!



Hawkken for 2nd skins for different people, Thanks!



Thanks!

Extra: the Classes don't do much now


To add as a texture pack, drag the 'Villager' folder into the Texturepack! Enjoy!


