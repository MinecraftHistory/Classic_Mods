/**
 * This software is provided under the terms of the Minecraft Forge Public 
 * License v1.0.
 */

package net.minecraft.src.forge;

public class Property {
    public String name;
    public String value;
    public String comment;
}
