#!/bin/bash
python runtime/updatemcp.py "$@"
