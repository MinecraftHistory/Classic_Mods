"""
Extension 3 (ext3)
Used primarily for concurrent Linux systems (ext2 + journalling)
"""
