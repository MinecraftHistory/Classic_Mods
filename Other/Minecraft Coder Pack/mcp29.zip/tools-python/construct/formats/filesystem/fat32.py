"""
File Allocation Table (FAT) / 32 bit version
Used for USB flash disks, old MSWindows systems, etc.
"""
