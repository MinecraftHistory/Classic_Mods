"""
NT File System (NTFS) version 5
Used for MSWindows systems since Windows 2000
"""
