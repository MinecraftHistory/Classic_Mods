"""
File Allocation Table (FAT) / 12 bit version
Used primarily for diskettes
"""
