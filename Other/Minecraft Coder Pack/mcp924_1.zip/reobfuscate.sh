#!/bin/bash
./runtime/reobfuscate.py "$@"
