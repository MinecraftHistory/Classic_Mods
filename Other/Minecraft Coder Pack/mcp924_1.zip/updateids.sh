#!/bin/bash
./runtime/updateids.py "$@"
