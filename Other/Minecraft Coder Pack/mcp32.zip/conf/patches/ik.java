
// this is needed for the sound engine to work with deobfuscated sourcecode without crashing

public class ik {
    public static int b(double d)
    {
        int i = (int)d;
        return d >= (double)i ? i : i - 1;
    }
}
