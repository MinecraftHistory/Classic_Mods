#!/bin/bash
python runtime/startserver.py conf/mcp.cfg
