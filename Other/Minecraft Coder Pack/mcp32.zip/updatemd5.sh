#!/bin/bash
python runtime/updatemd5.py conf/mcp.cfg
