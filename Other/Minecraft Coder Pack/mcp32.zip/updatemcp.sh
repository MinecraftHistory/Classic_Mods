#!/bin/bash
python runtime/updatemcp.py conf/mcp.cfg
